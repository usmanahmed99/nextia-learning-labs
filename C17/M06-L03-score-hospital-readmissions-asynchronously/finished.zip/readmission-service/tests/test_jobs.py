import time
from pathlib import Path

from fastapi.testclient import TestClient

from readmission.jobs import Job
from readmission.store import SqliteStore
from tests.conftest import CSV, SAMPLE


def wait(client, location, until=("done", "failed")):
    for _ in range(200):
        body = client.get(location).json()
        if body["status"] in until:
            return body
        time.sleep(0.02)
    raise AssertionError(f"still {body['status']}")


def new_client():
    from readmission.main import create_app

    return TestClient(create_app())


def test_a_job_is_accepted_then_done(client):
    response = client.post("/v1/jobs", content=SAMPLE, headers=CSV)
    assert response.status_code == 202
    assert response.headers["Retry-After"] == "2"
    assert response.json()["status"] == "queued"
    body = wait(client, response.headers["Location"])
    assert body["status"] == "done" and body["records"] == body["scored"] == 5
    follow_up = client.get(body["results_url"])
    assert follow_up.headers["content-type"].startswith("text/csv")
    lines = follow_up.text.splitlines()
    assert lines[0] == "rank,encounter_id,score,call" and len(lines) == 6


def test_a_file_must_be_csv(client):
    response = client.post("/v1/jobs", json={"rows": []})
    assert response.status_code == 415
    assert response.json()["error"]["code"] == "not_csv"


def test_a_sensitive_column_is_refused_before_any_job(client):
    header, first = SAMPLE.decode().splitlines()[:2]
    response = client.post("/v1/jobs", content=f"{header},race\n{first},Caucasian\n", headers=CSV)
    assert response.status_code == 422
    assert response.json()["error"]["fields"] == ["race"]


def test_a_large_file_is_413(monkeypatch):
    monkeypatch.setenv("MAX_UPLOAD_BYTES", "500")
    with new_client() as client:
        response = client.post("/v1/jobs", content=SAMPLE, headers=CSV)
    assert response.status_code == 413
    assert response.json()["error"]["code"] == "file_too_large"


def test_a_full_queue_is_429(monkeypatch):
    monkeypatch.setenv("EXTRA_MS_PER_RECORD", "100")  # simulated: each job takes 0.5 s
    monkeypatch.setenv("MAX_QUEUED_JOBS", "1")
    with new_client() as client:
        codes = [client.post("/v1/jobs", content=SAMPLE, headers=CSV).status_code for _ in range(4)]
        assert codes[0] == 202 and codes[-1] == 429
        assert client.post("/v1/jobs", content=SAMPLE, headers=CSV).headers["Retry-After"] == "60"


def test_a_few_bad_rows_are_rejected_and_the_rest_scored(client):
    response = client.post("/v1/jobs", content=Path("data/discharges_typos.csv").read_bytes(), headers=CSV)
    body = wait(client, response.headers["Location"])
    assert body["status"] == "done" and body["scored"] == 197 and body["rejected"] == 3
    assert body["rejected_lines"][0] == {"line": 19, "encounter_id": "1115640", "fields": ["age_years"]}


def test_a_failed_job_does_not_stop_the_worker(client):
    hours = client.post("/v1/jobs", content=Path("data/discharges_hours.csv").read_bytes(), headers=CSV)
    sample = client.post("/v1/jobs", content=SAMPLE, headers=CSV)
    failed = wait(client, hours.headers["Location"])
    assert failed["status"] == "failed" and failed["results_url"] is None
    assert "rows do not match the contract" in failed["error"]
    assert client.get(f"{hours.headers['Location']}/results").json()["error"]["code"] == "job_failed"
    assert wait(client, sample.headers["Location"])["status"] == "done"


def test_results_before_the_end_is_409(monkeypatch):
    monkeypatch.setenv("EXTRA_MS_PER_RECORD", "100")
    with new_client() as client:
        location = client.post("/v1/jobs", content=SAMPLE, headers=CSV).headers["Location"]
        response = client.get(f"{location}/results")
        assert response.status_code == 409 and response.headers["Retry-After"] == "2"


def test_an_unknown_job_is_404(client):
    assert client.get("/v1/jobs/nothere").json()["error"]["code"] == "job_not_found"


def test_a_list_expires(monkeypatch):
    monkeypatch.setenv("KEEP_RESULTS_HOURS", "0.0003")  # about 1 second
    with new_client() as client:
        location = client.post("/v1/jobs", content=SAMPLE, headers=CSV).headers["Location"]
        assert wait(client, location)["status"] == "done"
        time.sleep(1.2)
        assert client.get(location).json()["status"] == "expired"
        assert client.get(f"{location}/results").status_code == 410


def test_a_memory_job_is_lost_on_restart(monkeypatch):
    monkeypatch.setenv("JOB_STORE", "memory")
    with new_client() as client:
        location = client.post("/v1/jobs", content=SAMPLE, headers=CSV).headers["Location"]
        assert wait(client, location)["status"] == "done"
    with new_client() as client:  # a restart
        assert client.get(location).status_code == 404


def test_a_stored_job_survives_a_restart():
    with new_client() as client:
        location = client.post("/v1/jobs", content=SAMPLE, headers=CSV).headers["Location"]
        assert wait(client, location)["status"] == "done"
    with new_client() as client:  # a restart
        assert client.get(location).json()["status"] == "done"
        assert len(client.get(f"{location}/results").text.splitlines()) == 6


def test_a_running_job_is_queued_again_after_a_restart(tmp_path):
    store = SqliteStore(tmp_path / "jobs")  # the JOBS_DIR of the test settings
    store.add(Job(id="interrupted1", records=5, input_sha256="-"), SAMPLE)
    assert store.claim_next().status == "running"  # the service stops here
    with new_client() as client:
        assert wait(client, "/v1/jobs/interrupted1")["status"] == "done"
