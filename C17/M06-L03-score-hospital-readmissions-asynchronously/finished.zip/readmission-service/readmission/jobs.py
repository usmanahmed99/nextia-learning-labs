"""Asynchronous scoring: accept a discharge file now, score it later, keep the list for a while.

    submit     check the queue limit, store the file, return the job at once
    work       one thread takes the oldest queued job and runs it
    run        check the rows, score them in chunks, store the follow-up list

A job is queued → running → done or failed, and expired when its time is up.
The runner keeps nothing itself: every job, file and list is in the store.
MemoryStore keeps them in this process's memory, so a restart loses them all.
"""

import hashlib
import logging
import threading
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone

from readmission.scoring import read_rows, results_csv, score_rows

logger = logging.getLogger("readmission")

CHUNK = 1000  # rows scored between two progress updates
MAX_REJECTED_SHARE = 0.05  # more bad rows than this: the file is wrong, not a few rows


class QueueFull(Exception):
    pass


class JobFailed(Exception):
    pass


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


@dataclass
class Job:
    id: str
    records: int
    input_sha256: str
    status: str = "queued"
    created_at: str = field(default_factory=now)
    started_at: str | None = None
    finished_at: str | None = None
    expires_at: str | None = None
    scored: int = 0
    rejected: list[dict] = field(default_factory=list)
    to_call: int | None = None
    unknown_values: dict[str, int] = field(default_factory=dict)
    seconds: float | None = None
    model_version: str | None = None
    error: str | None = None


class MemoryStore:
    """Jobs, files and lists in this process's memory. A restart loses every job."""

    def __init__(self):
        self.jobs: dict[str, Job] = {}
        self.files: dict[str, bytes] = {}
        self.lists: dict[str, str] = {}
        self.lock = threading.Lock()

    def add(self, job: Job, data: bytes) -> None:
        with self.lock:
            self.jobs[job.id], self.files[job.id] = job, data

    def get(self, job_id: str) -> Job | None:
        return self.jobs.get(job_id)

    def save(self, job: Job) -> None:
        self.jobs[job.id] = job

    def queued(self) -> int:
        return sum(job.status == "queued" for job in self.jobs.values())

    def claim_next(self) -> Job | None:
        with self.lock:
            waiting = [job for job in self.jobs.values() if job.status == "queued"]
            if not waiting:
                return None
            job = min(waiting, key=lambda j: j.created_at)
            job.status, job.started_at = "running", now()
            return job

    def file(self, job_id: str) -> bytes:
        return self.files[job_id]

    def finish(self, job: Job, follow_up_list: str | None) -> None:
        """Keep the list (if any), and drop the input file: it is not needed any more."""
        with self.lock:
            if follow_up_list is not None:
                self.lists[job.id] = follow_up_list
            self.files.pop(job.id, None)
            self.jobs[job.id] = job

    def follow_up_list(self, job_id: str) -> str | None:
        return self.lists.get(job_id)

    def expire(self) -> int:
        """Delete the lists whose time is up. The job stays, as "expired"."""
        count = 0
        with self.lock:
            for job in self.jobs.values():
                if job.expires_at and job.expires_at <= now() and job.status != "expired":
                    job.status = "expired"
                    self.lists.pop(job.id, None)
                    count += 1
        return count

    def recover(self) -> int:
        return 0  # nothing survives a restart, so there is nothing to recover


class JobRunner:
    def __init__(self, store, get_bundle, max_queued: int, keep_hours: float, extra_ms: float = 0.0):
        self.store, self.get_bundle = store, get_bundle
        self.max_queued, self.keep, self.extra_ms = max_queued, timedelta(hours=keep_hours), extra_ms
        self.wake = threading.Event()
        threading.Thread(target=self.work, daemon=True, name="job-worker").start()

    def submit(self, data: bytes, records: int) -> Job:
        if self.store.queued() >= self.max_queued:
            raise QueueFull
        job = Job(id=uuid.uuid4().hex[:12], records=records, input_sha256=hashlib.sha256(data).hexdigest())
        self.store.add(job, data)
        self.wake.set()
        return job

    def work(self) -> None:
        while True:
            self.store.expire()
            job = self.store.claim_next()
            if job is None:
                self.wake.wait(timeout=60)
                self.wake.clear()
                continue
            self.run(job)

    def run(self, job: Job) -> None:
        started, follow_up = time.perf_counter(), None
        try:
            rows, job.rejected = read_rows(self.store.file(job.id))
            if len(job.rejected) > MAX_REJECTED_SHARE * job.records:
                raise JobFailed(f"{len(job.rejected)} of {job.records} rows do not match the contract")
            bundle, results = self.get_bundle(), []
            for start in range(0, len(rows), CHUNK):
                results += score_rows(bundle, rows[start : start + CHUNK], self.extra_ms)
                job.scored = len(results)
                self.store.save(job)  # progress, for the status
            follow_up = results_csv(results)
            job.to_call = sum(r.call for r in results)
            for r in results:
                for name in r.unknown:
                    job.unknown_values[name] = job.unknown_values.get(name, 0) + 1
            job.model_version, job.status = bundle.version, "done"
        except JobFailed as error:
            job.status, job.error = "failed", str(error)
        except Exception:  # a failed job must not stop the worker
            logger.exception("job %s failed", job.id)
            job.status, job.error = "failed", "The job failed on the server. The log has the details."
        job.seconds = round(time.perf_counter() - started, 3)
        job.finished_at = now()
        job.expires_at = (datetime.now(timezone.utc) + self.keep).isoformat(timespec="seconds")
        self.store.finish(job, follow_up)
        logger.info("job %s %s: %d rows, %.2f s", job.id, job.status, job.records, job.seconds)
