"""The readmission service: the follow-up model behind an HTTP API.

Start-up does the slow work once: read the settings, check and load the
bundle, score the parity cases. Only then does the service accept requests.
"""

import logging
import time
import uuid
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request

from readmission.bundle import BundleError, load_bundle
from readmission.errors import add_error_handlers, error_response
from readmission.jobs import JobRunner, MemoryStore
from readmission.routes import router
from readmission.settings import Settings, SettingsError, load_settings
from readmission.store import SqliteStore

logger = logging.getLogger("readmission")


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or load_settings()
    logging.basicConfig(level=settings.log_level, format="%(levelname)s %(name)s: %(message)s")

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        started = time.perf_counter()
        try:
            app.state.bundle = load_bundle(settings.model_bundle, settings.model_sha256)
        except BundleError as error:
            logger.error("Start-up error: %s", error)
            raise
        logger.info(
            "model %s loaded (bundle %s...) in %.0f ms",
            app.state.bundle.version,
            app.state.bundle.digest[:12],
            (time.perf_counter() - started) * 1000,
        )
        if settings.job_store == "memory":
            store = MemoryStore()
            logger.warning("jobs are kept in memory: a restart loses them")
        else:
            store = SqliteStore(settings.jobs_dir)
            logger.info("jobs are kept in %s; %d running job(s) queued again", settings.jobs_dir, store.recover())
        app.state.jobs = JobRunner(
            store,
            lambda: app.state.bundle,
            settings.max_queued_jobs,
            settings.keep_results_hours,
            settings.extra_ms_per_record,
        )
        if settings.extra_ms_per_record:
            logger.warning("SIMULATED slow model: %.1f ms more per row", settings.extra_ms_per_record)
        yield

    app = FastAPI(
        title="Readmission Service",
        version="1.0.0",
        description=(
            "Scores discharge files for the risk of a readmission within 30 days. "
            "The list supports the care team's follow-up calls. It does not decide anything about a patient."
        ),
        lifespan=lifespan,
        redoc_url=None,
    )
    app.state.settings = settings

    @app.middleware("http")
    async def request_id_and_size(request: Request, call_next):
        request.state.request_id = uuid.uuid4().hex[:12]
        started = time.perf_counter()
        length = request.headers.get("content-length")
        if length and int(length) > settings.max_upload_bytes:
            response = error_response(
                request, 413, "file_too_large", f"A file can have at most {settings.max_upload_bytes} bytes."
            )
        else:
            response = await call_next(request)
        response.headers["X-Request-ID"] = request.state.request_id
        logger.info(
            "%s %s %d %.1fms id=%s",
            request.method,
            request.url.path,
            response.status_code,
            (time.perf_counter() - started) * 1000,
            request.state.request_id,
        )
        return response

    add_error_handlers(app)
    app.include_router(router)

    @app.get("/health", tags=["health"])
    def health() -> dict:
        return {"status": "ok"}

    @app.get("/ready", tags=["health"])
    def ready(request: Request) -> dict:
        if getattr(request.app.state, "bundle", None) is None:
            return error_response(request, 503, "not_ready", "The model is not loaded.")
        return {"status": "ready", "model_version": request.app.state.bundle.version}

    return app


try:
    app = create_app()
except (SettingsError, BundleError) as error:
    raise SystemExit(f"Start-up error: {error}") from None
