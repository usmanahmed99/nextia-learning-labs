"""Jobs that survive a restart: the jobs in SQLite, the files and lists on disk.

    jobs/jobs.db                 one row per job (SQLite, a database in one file)
    jobs/<id>.csv                the discharge file, until the job has run
    jobs/<id>.list.csv           the follow-up list, until the job expires

Put jobs/ on a volume, so that it outlives the container. At start-up,
recover() puts a job that was running back in the queue: a restart then costs
the time of that job, not the job.

One service process only: two processes would each start a worker, and each
would recover the other's running job. More processes need a queue service.
"""

import json
import os
import sqlite3
from contextlib import contextmanager
from dataclasses import asdict
from pathlib import Path

from readmission.jobs import Job, now

SCHEMA = """CREATE TABLE IF NOT EXISTS jobs (
    id TEXT PRIMARY KEY,
    status TEXT NOT NULL,
    created_at TEXT NOT NULL,
    expires_at TEXT,
    job TEXT NOT NULL
)"""


class SqliteStore:
    def __init__(self, folder: Path):
        self.folder = Path(folder)
        self.folder.mkdir(parents=True, exist_ok=True)
        self.db = self.folder / "jobs.db"
        with self.connect() as db:
            db.execute(SCHEMA)

    @contextmanager
    def connect(self):
        """One connection per call, safe across threads: commit at the end, then close."""
        db = sqlite3.connect(self.db, timeout=10)
        try:
            with db:
                yield db
        finally:
            db.close()

    def write(self, db: sqlite3.Connection, job: Job) -> None:
        db.execute(
            "INSERT OR REPLACE INTO jobs VALUES (?, ?, ?, ?, ?)",
            (job.id, job.status, job.created_at, job.expires_at, json.dumps(asdict(job))),
        )

    def add(self, job: Job, data: bytes) -> None:
        (self.folder / f"{job.id}.csv").write_bytes(data)  # the file first, then the row
        with self.connect() as db:
            self.write(db, job)

    def get(self, job_id: str) -> Job | None:
        with self.connect() as db:
            row = db.execute("SELECT job FROM jobs WHERE id = ?", (job_id,)).fetchone()
        return Job(**json.loads(row[0])) if row else None

    def save(self, job: Job) -> None:
        with self.connect() as db:
            self.write(db, job)

    def queued(self) -> int:
        with self.connect() as db:
            return db.execute("SELECT COUNT(*) FROM jobs WHERE status = 'queued'").fetchone()[0]

    def claim_next(self) -> Job | None:
        with self.connect() as db:
            row = db.execute(
                "SELECT job FROM jobs WHERE status = 'queued' ORDER BY created_at, rowid LIMIT 1"
            ).fetchone()
            if row is None:
                return None
            job = Job(**json.loads(row[0]))
            job.status, job.started_at = "running", now()
            self.write(db, job)
        return job

    def file(self, job_id: str) -> bytes:
        return (self.folder / f"{job_id}.csv").read_bytes()

    def finish(self, job: Job, follow_up_list: str | None) -> None:
        if follow_up_list is not None:
            partial = self.folder / f"{job.id}.list.csv.partial"
            partial.write_text(follow_up_list, encoding="utf-8")
            os.replace(partial, self.folder / f"{job.id}.list.csv")  # all or nothing
        with self.connect() as db:
            self.write(db, job)
        (self.folder / f"{job.id}.csv").unlink(missing_ok=True)

    def follow_up_list(self, job_id: str) -> str | None:
        path = self.folder / f"{job_id}.list.csv"
        return path.read_text(encoding="utf-8") if path.exists() else None

    def expire(self) -> int:
        with self.connect() as db:
            rows = db.execute(
                "SELECT job FROM jobs WHERE status != 'expired' AND expires_at <= ?", (now(),)
            ).fetchall()
            for (text,) in rows:
                job = Job(**json.loads(text))
                job.status = "expired"
                self.write(db, job)
                (self.folder / f"{job.id}.list.csv").unlink(missing_ok=True)
        return len(rows)

    def recover(self) -> int:
        """Put the jobs that were running when the service stopped back in the queue."""
        with self.connect() as db:
            rows = db.execute("SELECT job FROM jobs WHERE status = 'running'").fetchall()
            for (text,) in rows:
                job = Job(**json.loads(text))
                job.status, job.started_at, job.scored = "queued", None, 0
                self.write(db, job)
        return len(rows)
