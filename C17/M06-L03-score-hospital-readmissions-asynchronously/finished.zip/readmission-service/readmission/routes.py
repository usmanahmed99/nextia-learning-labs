from fastapi import APIRouter, Depends, Request, Response
from pydantic import BaseModel, Field

from readmission.errors import ErrorResponse, error_response
from readmission.jobs import Job, QueueFull, now
from readmission.scoring import FileProblem, check_upload
from readmission.security import require_api_key

router = APIRouter(prefix="/v1", dependencies=[Depends(require_api_key)])

CSV_BODY = {"requestBody": {"required": True, "content": {"text/csv": {"schema": {"type": "string"}}}}}


def errors(*codes: int) -> dict:
    return {code: {"model": ErrorResponse} for code in codes}


class ModelInfo(BaseModel):
    model_version: str
    bundle_sha256: str
    threshold: float
    capacity: float
    trained_at: str
    features: list[str]


class JobStatus(BaseModel):
    job_id: str
    status: str = Field(description="queued, running, done, failed or expired")
    records: int = Field(description="Rows in the file.")
    scored: int = Field(description="Rows scored so far.")
    rejected: int = Field(description="Rows that do not match the contract. They are not scored.")
    rejected_lines: list[dict] = Field(description="The first 20 rejected rows: line in the file, and fields.")
    to_call: int | None = Field(description="Stays with a score at or above the threshold.")
    unknown_values: dict[str, int] = Field(description="Category values the model never saw, by column.")
    created_at: str
    finished_at: str | None
    expires_at: str | None = Field(description="After this time, the list is deleted.")
    seconds: float | None
    model_version: str | None
    results_url: str | None
    error: str | None


@router.get("/model", tags=["model"], summary="Which model answers, and how to check it")
def model(request: Request) -> ModelInfo:
    bundle = request.app.state.bundle
    return ModelInfo(
        model_version=bundle.version,
        bundle_sha256=bundle.digest,
        threshold=bundle.threshold,
        capacity=bundle.metadata["capacity"],
        trained_at=bundle.metadata["trained_at"],
        features=bundle.contract["features"],
    )


def is_expired(job: Job) -> bool:
    return job.status == "expired" or (job.expires_at is not None and job.expires_at <= now())


def status_of(job: Job) -> JobStatus:
    expired = is_expired(job)
    return JobStatus(
        job_id=job.id,
        status="expired" if expired else job.status,
        records=job.records,
        scored=job.scored,
        rejected=len(job.rejected),
        rejected_lines=job.rejected[:20],
        to_call=job.to_call,
        unknown_values=job.unknown_values,
        created_at=job.created_at,
        finished_at=job.finished_at,
        expires_at=job.expires_at,
        seconds=job.seconds,
        model_version=job.model_version,
        results_url=f"/v1/jobs/{job.id}/results" if job.status == "done" and not expired else None,
        error=job.error,
    )


@router.post(
    "/jobs",
    tags=["jobs"],
    status_code=202,
    summary="Submit a discharge file (CSV) to score later",
    openapi_extra=CSV_BODY,
    responses=errors(401, 413, 415, 422, 429),
)
async def submit_job(request: Request, response: Response) -> JobStatus:
    settings = request.app.state.settings
    if request.headers.get("content-type", "").split(";")[0].strip() != "text/csv":
        return error_response(request, 415, "not_csv", "Send the file as text/csv.")
    body = await request.body()
    if len(body) > settings.max_upload_bytes:
        return error_response(request, 413, "file_too_large", f"A file can have at most {settings.max_upload_bytes} bytes.")
    try:
        records = check_upload(body, settings.max_records)
        job = request.app.state.jobs.submit(body, records)
    except FileProblem as problem:
        return error_response(request, problem.status, problem.code, problem.message, problem.fields)
    except QueueFull:
        return error_response(
            request, 429, "too_many_jobs", "Too many jobs are waiting. Try again later.", headers={"Retry-After": "60"}
        )
    response.headers["Location"] = f"/v1/jobs/{job.id}"
    response.headers["Retry-After"] = str(settings.poll_seconds)
    return status_of(job)


@router.get("/jobs/{job_id}", tags=["jobs"], summary="The status of a job", responses=errors(401, 404))
def get_job(job_id: str, request: Request, response: Response) -> JobStatus:
    job = request.app.state.jobs.store.get(job_id)
    if job is None:
        return error_response(request, 404, "job_not_found", "There is no job with this ID.")
    if job.status in ("queued", "running"):
        response.headers["Retry-After"] = str(request.app.state.settings.poll_seconds)
    return status_of(job)


@router.get(
    "/jobs/{job_id}/results",
    tags=["jobs"],
    summary="The follow-up list of a finished job (CSV, highest score first)",
    response_class=Response,
    responses={200: {"content": {"text/csv": {}}}, **errors(401, 404, 409, 410)},
)
def get_results(job_id: str, request: Request):
    store = request.app.state.jobs.store
    job = store.get(job_id)
    if job is None:
        return error_response(request, 404, "job_not_found", "There is no job with this ID.")
    if is_expired(job):
        return error_response(request, 410, "job_expired", f"The list expired at {job.expires_at}.")
    if job.status == "failed":
        return error_response(request, 409, "job_failed", f"The job failed: {job.error}")
    if job.status != "done":
        seconds = str(request.app.state.settings.poll_seconds)
        return error_response(request, 409, "job_not_done", "The job is not done yet.", headers={"Retry-After": seconds})
    return Response(store.follow_up_list(job_id), media_type="text/csv")
