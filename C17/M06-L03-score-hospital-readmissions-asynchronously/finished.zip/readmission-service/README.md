# readmission-service

A web service that scores **discharge files** for a care-coordination team. The team's system submits a file of hospital stays as a **job**, and fetches the **follow-up list** later: every stay with a score, the highest first, and `call = true` for about 1 stay in 10. The model is logistic regression, trained on public data of US hospitals (1999 to 2008).

**The list supports the team's follow-up calls. It never decides anything about a patient on its own.** Read [MODEL_CARD.md](MODEL_CARD.md) first.

## Set up (macOS or Linux; Windows in brackets)

```sh
python3 -m venv .venv                    # (python -m venv .venv)
source .venv/bin/activate                # (.venv\Scripts\Activate.ps1)
python -m pip install -r requirements.txt
cp .env.example .env                     # (Copy-Item .env.example .env)
python -m pytest                         # 32 passed
```

## Run

```sh
export MODEL_SHA256=89056e4cfab4a6a58180461ab01f8b53aeec448ed444ee808699abe2ed6cdf27
fastapi dev                                          # http://127.0.0.1:8000/docs
python scripts/follow_up.py data/discharges_night.csv  # in a second terminal
```

With Docker:

```sh
docker compose up -d --build --wait
python scripts/follow_up.py data/discharges_week.csv
docker compose down                      # the jobs stay in the volume; down -v deletes them
```

| Endpoint | Meaning |
|---|---|
| `POST /v1/jobs` | Submit a discharge file (`Content-Type: text/csv`). `202 Accepted`, with `Location` (the job's address) and `Retry-After` (seconds until you ask again). |
| `GET /v1/jobs/{id}` | The job's status: `queued`, `running` (with `scored` of `records`), `done`, `failed` or `expired`. |
| `GET /v1/jobs/{id}/results` | The follow-up list (CSV, the highest score first). `409` before the job is done, `410` after the list expired. |
| `GET /v1/model` | The model version, the bundle digest and the threshold |
| `GET /health`, `GET /ready` | Liveness, and readiness (the bundle passed its checks) |

Errors have the shape `{"error": {"code", "message", "request_id", "fields"}}`. A file is refused at once (no job) if it is not CSV (`415 not_csv`), larger than `MAX_UPLOAD_BYTES` (`413 file_too_large`), longer than `MAX_RECORDS` rows (`413 too_many_records`), or has missing or extra columns (`422 invalid_file`). When `MAX_QUEUED_JOBS` jobs wait, a new one gets `429 too_many_jobs` with `Retry-After: 60`. A row that does not match the contract is set aside with its line number; more than 5% such rows fail the job.

## Settings (environment variables)

| Variable | Default | Meaning |
|---|---|---|
| `MODEL_SHA256` | required | The bundle digest (the SHA-256 of `SHA256SUMS`). The service does not start without the right one. |
| `MODEL_BUNDLE` | `bundles/readmission-1.0.0` | The bundle folder |
| `API_KEY`, `API_KEY_FILE` | none | The key that `X-API-Key` must have. Always set one on a server. |
| `JOB_STORE` | `sqlite` | `sqlite`: jobs in `JOBS_DIR`, they survive a restart. `memory`: for tests and demonstrations only; a restart loses every job. |
| `JOBS_DIR` | `jobs` | The job database, the files and the lists. Put it on a volume. |
| `MAX_UPLOAD_BYTES`, `MAX_RECORDS` | `4000000`, `25000` | The largest file |
| `MAX_QUEUED_JOBS` | `3` | Jobs that may wait; the next one gets `429` |
| `KEEP_RESULTS_HOURS` | `48` | How long a list is kept after its job ends |
| `POLL_SECONDS` | `2` | The `Retry-After` value while a job waits or runs |
| `EXTRA_MS_PER_RECORD` | `0` | **Simulated** extra time per row, to try a slower model. Keep 0 in production. |

Run one service process only (the Compose file does): the job worker is a thread inside it. More processes need a queue service and shared storage.

## The bundle

`bundles/readmission-1.0.0/` holds the model, its contract, its metadata, 10 parity cases and `SHA256SUMS`. The service loads it only after the digest, the file hashes and the package versions match, and checks the parity cases before it is ready. To make the model again (downloads 3 MB of data, checks its SHA-256):

```sh
python training/train.py                 # writes model/ and the data files
shasum -a 256 model/readmission_model.joblib   # the same as model.joblib in the bundle's SHA256SUMS
```

## Data and licence

The code is under the MIT licence ([LICENSE](LICENSE)). The data is *Diabetes 130-US Hospitals for Years 1999-2008* (Clore, Cios, DeShazo and Strack, 2014; UCI Machine Learning Repository, https://doi.org/10.24432/C5230J), CC BY 4.0, changed as described in [data/README.md](data/README.md).
