import os
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from readmission.bundle import bundle_digest

ROOT = Path(__file__).parent.parent
BUNDLE = ROOT / "bundles" / "readmission-1.0.0"
SAMPLE = (ROOT / "data" / "discharges_sample.csv").read_bytes()
CSV = {"Content-Type": "text/csv"}


@pytest.fixture(autouse=True)
def settings_env(monkeypatch, tmp_path):
    monkeypatch.chdir(ROOT)
    monkeypatch.setenv("MODEL_BUNDLE", str(BUNDLE))
    monkeypatch.setenv("MODEL_SHA256", bundle_digest(BUNDLE))
    monkeypatch.setenv("JOBS_DIR", str(tmp_path / "jobs"))
    for name in ["API_KEY", "API_KEY_FILE", "REQUIRE_API_KEY", "EXTRA_MS_PER_RECORD", "JOB_STORE",
                 "MAX_QUEUED_JOBS", "KEEP_RESULTS_HOURS", "MAX_RECORDS", "MAX_UPLOAD_BYTES"]:
        monkeypatch.delenv(name, raising=False)


@pytest.fixture
def client():
    from readmission.main import create_app

    with TestClient(create_app()) as test_client:
        yield test_client
