import pytest
from pydantic import ValidationError

from readmission.contract import FEATURES, DischargeIn
from readmission.scoring import FileProblem, check_upload, read_rows
from tests.conftest import SAMPLE

ROW = dict(zip(SAMPLE.decode().splitlines()[0].split(","), SAMPLE.decode().splitlines()[1].split(",")))


def test_a_good_row_passes():
    stay = DischargeIn(**ROW)
    assert stay.encounter_id == 16680 and stay.time_in_hospital == 1


@pytest.mark.parametrize("name, value", [("time_in_hospital", "0"), ("age_years", ""), ("number_inpatient", "two")])
def test_a_bad_value_is_refused(name, value):
    with pytest.raises(ValidationError):
        DischargeIn(**{**ROW, name: value})


def test_a_sensitive_column_is_refused():
    with pytest.raises(ValidationError):
        DischargeIn(**ROW, race="Caucasian")


def test_a_file_with_an_extra_column_is_refused():
    header, first = SAMPLE.decode().splitlines()[:2]
    with pytest.raises(FileProblem) as problem:
        check_upload(f"{header},gender\n{first},Female\n".encode(), 100)
    assert problem.value.code == "invalid_file" and problem.value.fields == ["gender"]


def test_a_file_without_a_feature_is_refused():
    with pytest.raises(FileProblem) as problem:
        check_upload(b"encounter_id,age_years\n1,75\n", 100)
    assert problem.value.fields == [f for f in FEATURES if f != "age_years"]


def test_too_many_rows_is_413():
    with pytest.raises(FileProblem) as problem:
        check_upload(SAMPLE, 4)
    assert problem.value.status == 413


def test_bad_rows_are_set_aside_with_their_line():
    good, rejected = read_rows(open("data/discharges_typos.csv", "rb").read())
    assert len(good) == 197
    assert rejected == [
        {"line": 19, "encounter_id": "1115640", "fields": ["age_years"]},
        {"line": 66, "encounter_id": "2928240", "fields": ["time_in_hospital"]},
        {"line": 153, "encounter_id": "5683578", "fields": ["number_inpatient"]},
    ]
