def test_health(client):
    assert client.get("/health").json() == {"status": "ok"}


def test_ready_names_the_model(client):
    assert client.get("/ready").json() == {"status": "ready", "model_version": "1.0.0"}


def test_every_response_has_a_request_id(client):
    assert len(client.get("/health").headers["X-Request-ID"]) == 12


def test_the_model_endpoint_names_the_bundle(client):
    body = client.get("/v1/model").json()
    assert body["model_version"] == "1.0.0"
    assert body["threshold"] == 0.18
    assert len(body["bundle_sha256"]) == 64
