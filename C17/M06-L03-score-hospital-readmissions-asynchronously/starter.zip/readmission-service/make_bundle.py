"""Make a model bundle from model/ (written by training/train.py).

    python make_bundle.py --version 1.0.0

Writes bundles/readmission-<version>/ with the model, its contract, its
metadata, the parity cases and SHA256SUMS, and prints the bundle digest:
give it to the service as MODEL_SHA256.

Run it only on a model that you trained yourself: it loads the joblib file,
and loading can run code.
"""

import argparse
import json
import shutil
import sys
from importlib.metadata import version
from pathlib import Path

import joblib
import pandas as pd

from readmission.bundle import FILES, PACKAGES, bundle_digest, sha256
from readmission.contract import CATEGORIES, FEATURES, NUMBERS, DischargeFeatures

# Fixed stays that every copy of the model must score the same way.
# Normal: the first stays of the discharge file. Unknown: a category value the
# model never saw. Extreme: every number at the lowest or highest value of the
# contract.
EDGE_CASES = [
    ("unknown", 900001, dict(admission_type="Walk-in")),
    ("unknown", 900002, dict(diagnosis_group="dental", specialty="Telehealth")),
    ("extreme", 900003, {name: DischargeFeatures.model_fields[name].metadata[0].ge for name in NUMBERS}),
    ("extreme", 900004, {name: DischargeFeatures.model_fields[name].metadata[1].le for name in NUMBERS}),
]


def parity_cases(discharges: Path) -> pd.DataFrame:
    stays = pd.read_csv(discharges, nrows=6)
    rows = [{"case": "normal", **r} for r in stays.to_dict("records")]
    base = rows[0]
    rows += [{**base, "case": case, "encounter_id": eid, **change} for case, eid, change in EDGE_CASES]
    cases = pd.DataFrame(rows, columns=["case", "encounter_id"] + FEATURES)
    for row in cases[FEATURES].to_dict("records"):  # every case must pass the contract
        DischargeFeatures(**row)
    return cases


def main():
    parser = argparse.ArgumentParser(description="Make a model bundle from model/.")
    parser.add_argument("--version", required=True, help="the model version, for example 1.0.0")
    args = parser.parse_args()

    info = json.loads(Path("model/model_info.json").read_text(encoding="utf-8"))
    pipeline = joblib.load("model/readmission_model.joblib")
    if list(pipeline.feature_names_in_) != FEATURES:
        sys.exit("Stopped: the model was trained on other features than this service expects.")
    trained = {p: info["versions"][p] for p in PACKAGES}
    installed = {p: version(p) for p in PACKAGES}
    if trained != installed:
        sys.exit(f"Stopped: the model was trained with {trained}, but this environment has {installed}.")

    out = Path("bundles") / f"readmission-{args.version}"
    if out.exists():
        sys.exit(f"Stopped: {out} exists. A version is never changed: choose a new version.")
    out.mkdir(parents=True)
    shutil.copyfile("model/readmission_model.joblib", out / "model.joblib")

    cases = parity_cases(Path("data/discharges_week.csv"))
    cases["expected_score"] = pipeline.predict_proba(cases[FEATURES])[:, 1]
    cases.to_csv(out / "parity_cases.csv", index=False)

    contract = {
        "model": "readmission",
        "model_version": args.version,
        "unit": "one hospital stay of a patient with diabetes, scored on the day of discharge",
        "features": FEATURES,
        "schema": DischargeFeatures.model_json_schema(),
        "known_categories": {name: info["known_categories"][name] for name in CATEGORIES},
        "missing_values": "none: every cell must have a value ('missing', 'unknown' and 'not measured' are values)",
        "unknown_categories": "allowed; scored like a rare value; counted in the job summary",
        "output": {
            "score": "0 to 1; a higher score means a higher risk of a readmission within 30 days; it ranks stays",
            "call": "true if score >= threshold: the care team offers a follow-up call",
            "threshold": info["threshold"],
        },
    }
    (out / "contract.json").write_text(json.dumps(contract, indent=2) + "\n", encoding="utf-8")

    metadata = {
        "model_version": args.version,
        "description": info["model"],
        "trained_at": info["trained_at"],
        "train_rows": info["train_rows"],
        "data_sha256": info["data_sha256"],
        "capacity": info["capacity"],
        "evaluation": {"valid": info["valid"], "test": info["test"]},
        "python": info["versions"]["python"],
        "versions": installed,
    }
    (out / "metadata.json").write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")

    lines = [f"{sha256(out / name)}  {name}" for name in FILES]
    (out / "SHA256SUMS").write_text("\n".join(lines) + "\n", encoding="utf-8")

    print(f"Made {out}: {len(cases)} parity cases, threshold {info['threshold']}.")
    print(f"Bundle digest (MODEL_SHA256): {bundle_digest(out)}")


if __name__ == "__main__":
    main()
