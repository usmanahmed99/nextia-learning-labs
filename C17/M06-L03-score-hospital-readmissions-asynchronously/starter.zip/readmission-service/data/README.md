# The discharge files

These files are made by `training/train.py` from the *Diabetes 130-US Hospitals for Years 1999-2008* dataset:

> Clore, J., Cios, K., DeShazo, J., & Strack, B. (2014). *Diabetes 130-US Hospitals for Years 1999-2008* [Dataset]. UCI Machine Learning Repository. https://doi.org/10.24432/C5230J. Licensed under CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/).

**Changed by Nextia Learning.** Each row is one hospital stay of a patient in the test part of the data (19,608 stays of 13,852 patients that the model never saw). The columns are the stay's number (`encounter_id`) and the 19 features of the model, prepared as in `training/train.py`: the code columns are translated to text, the main diagnosis is in 9 groups, and the age band is its middle year. The stays that ended in death or a hospice discharge are removed. There are no names, no patient numbers, no dates, and no race, gender or payer columns.

| File | Rows | What it is |
|---|---|---|
| `discharges_week.csv` | 19,608 | All the test stays, in the order of the source file. In the case study: a week of discharges. |
| `discharges_night.csv` | 2,801 | The first seventh of the week: one night's file. |
| `discharges_sample.csv` | 5 | The first 5 stays, to try the service. |
| `discharges_typos.csv` | 200 | The first 200 stays, with 3 cells broken on purpose (lines 19, 66 and 153). |
| `discharges_hours.csv` | 200 | The first 200 stays, with `time_in_hospital` in hours instead of days, as a broken export would write it. |
| `outcomes_week.csv` | 19,608 | `readmitted_30` for each stay of the week: 1 if the patient came back within 30 days. Never send it to the service; use it only to check the list afterwards. |

The data is de-identified by its source. It is still health data about real people: do not try to find out who anyone is.
