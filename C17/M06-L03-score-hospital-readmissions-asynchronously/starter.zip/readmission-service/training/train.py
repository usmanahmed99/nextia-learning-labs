"""Train the readmission model and write the discharge files.

    python training/train.py

This is how the model in bundles/readmission-1.0.0 was made. It repeats the
machine learning course's case study "Choose a model for hospital
readmissions" (C05-M09-L05): the same data preparation, the same split by
patient, and the model that the case study chose (logistic regression,
C = 0.01), with a threshold for a call capacity of 10%.

It downloads the data (3 MB) into data/raw/ and checks its SHA-256 first.
It writes:

    model/readmission_model.joblib   the fitted pipeline
    model/model_info.json            what make_bundle.py needs
    data/discharges_*.csv            the test patients' stays, as discharge files
    data/outcomes_week.csv           what happened to them (for checks only)

Data: Clore, J., Cios, K., DeShazo, J., & Strack, B. (2014). Diabetes 130-US
Hospitals for Years 1999-2008. UCI Machine Learning Repository.
https://doi.org/10.24432/C5230J. CC BY 4.0.
"""

import csv
import hashlib
import json
import platform
import sys
from datetime import datetime, timezone
from importlib.metadata import version
from pathlib import Path

import httpx
import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score, roc_auc_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from readmission.contract import CATEGORIES, FEATURES, NUMBERS  # noqa: E402

DATA_URL = "https://raw.githubusercontent.com/usmanahmed99/nextia-learning-labs/main/C05/case-studies/data/"
FILES = {
    "diabetes_130_hospitals.csv.gz": "7e2cd49bd158b99bef449897d3f5118881dc469115c6e80189fd248355b08eac",
    "IDS_mapping.csv": "f1bb82b471cb34649352597572c9b1fb00bd27f77b9f5a22a03dc3eb1039749e",
}
RAW = Path("data/raw")
TARGET = "readmitted_30"
CAPACITY = 0.10  # the team can call one discharged patient in ten
ENDED = [11, 13, 14, 19, 20, 21]  # the patient died or went to a hospice: they cannot come back
UNKNOWN = ["NULL", "Not Available", "Not Mapped", "Unknown/Invalid"]
GROUPS = [("circulatory", 390, 460, "785"), ("respiratory", 460, 520, "786"),
          ("digestive", 520, 580, "787"), ("injury", 800, 1000, None),
          ("musculoskeletal", 710, 740, None), ("genitourinary", 580, 630, "788"),
          ("neoplasms", 140, 240, None)]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def get_data() -> None:
    """Download each file once, and refuse a file that is not the expected one."""
    RAW.mkdir(parents=True, exist_ok=True)
    for name, expected in FILES.items():
        path = RAW / name
        if not path.exists():
            print(f"Downloading {name}...")
            response = httpx.get(DATA_URL + name, follow_redirects=True, timeout=60)
            response.raise_for_status()
            path.write_bytes(response.content)
        if sha256(path) != expected:
            path.unlink()
            sys.exit(f"Stopped: {name} is not the expected file (SHA-256). It was deleted; run again.")


def read_codes() -> dict:
    """IDS_mapping.csv holds three code tables, one after the other."""
    codes, column = {}, None
    with open(RAW / "IDS_mapping.csv", newline="") as file:
        for row in csv.reader(file):
            if not row or not row[0]:
                continue
            if not row[0].isdigit():
                column = row[0]
                codes[column] = {}
            else:
                codes[column][int(row[0])] = row[1].strip()
    return codes


def diagnosis_group(code):
    """The group of the main diagnosis (an ICD-9 code), as in Strack et al. (2014)."""
    if pd.isna(code):
        return "missing"
    if code.startswith(("V", "E")):
        return "other"
    if code.startswith("250"):
        return "diabetes"
    number = float(code)
    for name, low, high, extra in GROUPS:
        if low <= number < high or (extra and code.startswith(extra)):
            return name
    return "other"


def prepare() -> pd.DataFrame:
    """The C05 preparation: remove stays that cannot come back, translate the codes."""
    raw = pd.read_csv(RAW / "diabetes_130_hospitals.csv.gz", na_values="?", low_memory=False)
    codes = read_codes()
    data = raw[~raw["discharge_disposition_id"].isin(ENDED)].copy()
    data[TARGET] = (data["readmitted"] == "<30").astype(int)
    for column, name in [("admission_type_id", "admission_type"), ("admission_source_id", "admission_source"),
                         ("discharge_disposition_id", "discharge_to")]:
        data[name] = data[column].map(codes[column]).replace(UNKNOWN, "unknown").fillna("unknown")
    data["diagnosis_group"] = data["diag_1"].map(diagnosis_group)
    data["age_years"] = data["age"].str.extract(r"(\d+)")[0].astype(int) + 5
    data["specialty"] = data["medical_specialty"].fillna("missing")
    tests = ["A1Cresult", "max_glu_serum"]
    data[tests] = data[tests].fillna("not measured")
    return data


def split_by_patient(data: pd.DataFrame):
    """60% / 20% / 20% of the patients, each patient with all their stays in one part."""
    patients = data["patient_nbr"].unique()
    rng = np.random.default_rng(0)
    part_of = dict(zip(patients, rng.choice(["train", "valid", "test"], size=len(patients), p=[0.6, 0.2, 0.2])))
    part = data["patient_nbr"].map(part_of)
    return (data[part == name].copy() for name in ["train", "valid", "test"])


def build_pipeline() -> Pipeline:
    prepare_step = ColumnTransformer([
        ("categories", OneHotEncoder(handle_unknown="infrequent_if_exist", min_frequency=100,
                                     sparse_output=False), CATEGORIES),
        ("numbers", StandardScaler(), NUMBERS)])
    return Pipeline([("prepare", prepare_step), ("model", LogisticRegression(C=0.01, max_iter=1000))])


def precision_at(y, score, share=CAPACITY) -> float:
    y, score = np.asarray(y), np.asarray(score)
    top = np.argsort(-score, kind="stable")[: int(share * len(y))]
    return float(y[top].mean())


def evaluate(y, score, threshold) -> dict:
    y, called = np.asarray(y) == 1, np.asarray(score) >= threshold
    return {
        "encounters": int(len(y)),
        "roc_auc": round(roc_auc_score(y, score), 3),
        "average_precision": round(average_precision_score(y, score), 3),
        "precision_at_10pct": round(precision_at(y, score), 3),
        "called": int(called.sum()),
        "precision": round(float(y[called].mean()), 3),
        "recall": round(float(called[y].mean()), 3),
    }


def write_files(test: pd.DataFrame) -> None:
    """The test patients' stays as discharge files, in the order of the source file."""
    columns = ["encounter_id"] + FEATURES
    week = test[columns]
    week.to_csv("data/discharges_week.csv", index=False)
    week.head(len(week) // 7).to_csv("data/discharges_night.csv", index=False)
    week.head(5).to_csv("data/discharges_sample.csv", index=False)
    test[["encounter_id", TARGET]].to_csv("data/outcomes_week.csv", index=False)

    # Two broken files from the first 200 stays of the night, as exports can go wrong.
    typos = week.head(200).astype(object).copy()
    typos.loc[typos.index[17], "age_years"] = ""            # an empty cell
    typos.loc[typos.index[64], "time_in_hospital"] = 0      # a stay of 0 days
    typos.loc[typos.index[151], "number_inpatient"] = "two"  # a word for a number
    typos.to_csv("data/discharges_typos.csv", index=False)
    hours = week.head(200).copy()
    hours["time_in_hospital"] = hours["time_in_hospital"] * 24  # the export wrote hours, not days
    hours.to_csv("data/discharges_hours.csv", index=False)


def main() -> None:
    get_data()
    data = prepare()
    train, valid, test = split_by_patient(data)

    pipeline = build_pipeline().fit(train[FEATURES], train[TARGET])
    valid_score = pipeline.predict_proba(valid[FEATURES])[:, 1]
    calls = int(CAPACITY * len(valid))
    threshold = round(float(np.sort(valid_score)[::-1][calls - 1]), 3)

    Path("model").mkdir(exist_ok=True)
    joblib.dump(pipeline, "model/readmission_model.joblib", protocol=5)
    encoder = pipeline.named_steps["prepare"].named_transformers_["categories"]
    info = {
        "model": "Logistic regression (C = 0.01) on 19 features: one-hot categories, scaled numbers",
        "trained_at": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"),
        "train_rows": len(train),
        "data_sha256": FILES["diabetes_130_hospitals.csv.gz"],
        "threshold": threshold,
        "capacity": CAPACITY,
        "valid": evaluate(valid[TARGET], valid_score, threshold),
        "test": evaluate(test[TARGET], pipeline.predict_proba(test[FEATURES])[:, 1], threshold),
        "known_categories": {name: [str(v) for v in values]
                             for name, values in zip(CATEGORIES, encoder.categories_)},
        "versions": {"python": platform.python_version(),
                     **{p: version(p) for p in ["scikit-learn", "numpy", "pandas", "joblib"]}},
    }
    Path("model/model_info.json").write_text(json.dumps(info, indent=2) + "\n", encoding="utf-8")
    write_files(test)

    print(f"Trained on {len(train)} stays of {train['patient_nbr'].nunique()} patients."
          f" Threshold {threshold} for a call capacity of 10%.")
    for name in ["valid", "test"]:
        r = info[name]
        print(f"{name.capitalize()}: ROC AUC {r['roc_auc']}, average precision {r['average_precision']},"
              f" called {r['called']} of {r['encounters']}, precision {r['precision']}, recall {r['recall']}.")
    print(f"Model file SHA-256: {sha256(Path('model/readmission_model.joblib'))}")


if __name__ == "__main__":
    main()
