"""Submit a discharge file, wait for the job as the service asks, and save the follow-up list.

    python scripts/follow_up.py data/discharges_night.csv
    python scripts/follow_up.py --job 3f2a9c1d0b7e          (fetch a job submitted before)

This is what the care team's system does each night. It waits between two
status requests for the time in the Retry-After header, so it never asks
more often than the service wants. Set API_KEY if the service needs a key,
and SERVICE_URL if it does not run at http://127.0.0.1:8000.
"""

import argparse
import os
import sys
import time
from pathlib import Path

import httpx

URL = os.environ.get("SERVICE_URL", "http://127.0.0.1:8000")
HEADERS = {"X-API-Key": os.environ["API_KEY"]} if os.environ.get("API_KEY") else {}


def submit(client: httpx.Client, path: Path) -> str:
    response = client.post("/v1/jobs", content=path.read_bytes(), headers={"Content-Type": "text/csv"})
    if response.status_code != 202:
        sys.exit(f"Not accepted: {response.status_code} {response.text}")
    print(f"Accepted: job {response.json()['job_id']}, {response.json()['records']} rows.")
    return response.headers["Location"]


def wait(client: httpx.Client, location: str) -> dict:
    started = time.perf_counter()
    while True:
        response = client.get(location)
        if response.status_code != 200:
            sys.exit(f"{response.status_code} {response.text}")
        job = response.json()
        if job["status"] not in ("queued", "running"):
            return job
        print(f"{time.perf_counter() - started:5.0f} s  {job['status']}: {job['scored']} of {job['records']} scored")
        time.sleep(int(response.headers.get("Retry-After", "5")))


def main() -> None:
    parser = argparse.ArgumentParser(description="Submit a discharge file and save the follow-up list.")
    parser.add_argument("file", nargs="?", type=Path, help="the discharge file (CSV)")
    parser.add_argument("--job", help="the ID of a job submitted before")
    args = parser.parse_args()
    if bool(args.file) == bool(args.job):
        parser.error("give a file or --job, not both")

    with httpx.Client(base_url=URL, headers=HEADERS, timeout=30) as client:
        location = submit(client, args.file) if args.file else f"/v1/jobs/{args.job}"
        job = wait(client, location)
        if job["status"] != "done":
            sys.exit(f"Job {job['job_id']} {job['status']}: {job['error'] or 'no list'}")
        follow_up = client.get(job["results_url"])
        out = Path("out") / f"{job['job_id']}.csv"
        out.parent.mkdir(exist_ok=True)
        out.write_text(follow_up.text, encoding="utf-8")
    print(f"Done in {job['seconds']} s: {job['scored']} scored, {job['rejected']} rejected,"
          f" {job['to_call']} to call (model {job['model_version']}).")
    print(f"Saved {out}. The service deletes its copy at {job['expires_at']}.")


if __name__ == "__main__":
    main()
