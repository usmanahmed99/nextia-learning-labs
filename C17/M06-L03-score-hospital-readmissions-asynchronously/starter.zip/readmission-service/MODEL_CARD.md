# Model card: readmission, version 1.0.0

The machine-readable facts are in `bundles/readmission-1.0.0/metadata.json` and `contract.json`. The service names the version and the bundle digest at `GET /v1/model`.

## Intended use

A **follow-up list** for a care-coordination team. The model ranks the stays of a discharge file by the risk that the patient comes back to hospital within 30 days. The team offers a follow-up phone call to the stays with a score of **0.18 or more**: about 1 stay in 10, the team's capacity.

**Users:** the care-coordination team's nurses, through their own system, which submits the file and reads the list.

## Not for

- **Any decision about a patient on its own.** The list says whom to offer a call first. A nurse can add any patient to it, and nobody is removed from care because of a low score.
- Deciding who may leave hospital, who gets less care, or what a patient pays.
- Patients without diabetes, children, or a hospital whose own data has not been used to test it.
- Diagnosis. A score is a ranking, not a diagnosis, and not a calibrated probability.

## Data

- **Source:** Clore, J., Cios, K., DeShazo, J., & Strack, B. (2014). *Diabetes 130-US Hospitals for Years 1999-2008* [Dataset]. UCI Machine Learning Repository. https://doi.org/10.24432/C5230J
- **Licence:** [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). Changed by Nextia Learning: see `data/README.md`.
- **File:** `diabetes_130_hospitals.csv.gz` from the Nextia labs repository, SHA-256 `7e2cd49bd158b99bef449897d3f5118881dc469115c6e80189fd248355b08eac`. 101,766 stays of patients with diabetes, 130 US hospitals, 1999 to 2008.
- **Preparation:** stays that ended in death or a hospice discharge are removed (they cannot be readmitted); the code columns are translated to text; the main diagnosis is put in 9 groups; the age band becomes its middle year.
- **Split by patient, 60/20/20:** each patient, with all their stays, is in one part. Train: 59,556 stays of 41,999 patients. Valid: 20,179 stays. Test: 19,608 stays of 13,852 patients.
- **Not inputs:** race, gender and the payer (insurance). They are kept out of the model, and only used to check the model for each group (in the C05 case study).

## Model

Logistic regression (`C = 0.01`, scikit-learn 1.9.1) after one-hot encoding of 10 categories (values seen fewer than 100 times are grouped) and scaling of 9 numbers. The threshold, 0.18, is the score of the patient at the 10% mark of the validation set, rounded to 3 decimals.

`training/train.py` builds the same model file again, byte for byte, with the same package versions.

## Results

| Set | ROC AUC | Average precision | Called (score ≥ 0.18) | Precision of the calls | Recall |
|---|---|---|---|---|---|
| Valid (20,179 stays) | 0.671 | 0.206 | 2,013 (10.0%) | 0.261 | 0.231 |
| Test (19,608 stays, used once) | 0.663 | 0.217 | 1,866 (9.5%) | 0.270 | 0.221 |

About 27 calls in 100 reach a patient who comes back within 30 days. At random, about 11 in 100 would. The calls reach about 22% of all the patients who come back.

## Known limits

- **The signal is weak.** A ROC AUC of 0.66 means many patients who come back get low scores. About half of the patients who come back had no hospital stay in the year before, and the model finds few of them.
- **The data is old and from one country:** US hospitals, 1999 to 2008, ICD-9 codes. Care, coding and insurance have changed since. A hospital must train and test the model on its own, recent patients before any real use.
- **No dates:** the split is by patient, not by time, so we do not know how fast the model ages.
- **The score is not a probability.** It ranks stays; 0.3 does not mean "3 in 10".
- **Groups:** in the C05 case study, the model worked less well for the oldest patients. Check precision and recall by age, race, gender and payer every month.

## Owner and review

The care-coordination team owns the decision to use the list. A data scientist owns the model and its bundle. Each new model gets a new version, a new bundle folder and a new digest. Stop using the list if the precision of the calls falls below the rule of thumb that the team used before (call the patients with the most hospital stays in the past year).

Source of the analysis: the Nextia case study *Choose a model for hospital readmissions* (C05).
