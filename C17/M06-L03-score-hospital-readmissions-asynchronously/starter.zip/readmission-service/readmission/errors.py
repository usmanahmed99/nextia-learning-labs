"""One error shape for every failure, as in the course's services:
{"error": {"code": ..., "message": ..., "request_id": ..., "fields": [...]}}"""

import logging

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from starlette.exceptions import HTTPException

logger = logging.getLogger("readmission")

CODES = {401: "unauthorized", 404: "not_found", 405: "method_not_allowed"}


class ErrorDetail(BaseModel):
    code: str = Field(description="A stable code that a program can check.")
    message: str = Field(description="A short explanation for a person.")
    request_id: str | None = None
    fields: list[str] = []


class ErrorResponse(BaseModel):
    error: ErrorDetail


def error_response(request: Request, status: int, code: str, message: str, fields=(), headers=None) -> JSONResponse:
    detail = ErrorDetail(
        code=code, message=message, request_id=getattr(request.state, "request_id", None), fields=list(fields)
    )
    return JSONResponse(status_code=status, content=ErrorResponse(error=detail).model_dump(), headers=headers)


def add_error_handlers(app: FastAPI) -> None:
    @app.exception_handler(RequestValidationError)
    async def invalid_request(request: Request, exc: RequestValidationError):
        fields = sorted({".".join(str(p) for p in e["loc"][1:]) or "body" for e in exc.errors()})
        return error_response(request, 422, "invalid_request", "The request is not valid.", fields)

    @app.exception_handler(HTTPException)
    async def http_error(request: Request, exc: HTTPException):
        return error_response(request, exc.status_code, CODES.get(exc.status_code, "http_error"), str(exc.detail))

    @app.exception_handler(Exception)
    async def unexpected(request: Request, exc: Exception):
        logger.exception("unexpected error id=%s", getattr(request.state, "request_id", None))
        return error_response(request, 500, "internal_error", "Something went wrong on the server.")
