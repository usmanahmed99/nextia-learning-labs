"""Settings from environment variables. A wrong setting stops the service at start."""

import os
from dataclasses import dataclass, field
from pathlib import Path


class SettingsError(Exception):
    """A required setting is missing or not valid. The service must not start."""


@dataclass(frozen=True)
class Settings:
    model_bundle: Path
    model_sha256: str
    api_key: str | None = field(repr=False)
    log_level: str = "INFO"
    max_upload_bytes: int = 4_000_000  # the week's file of 19,608 stays is 2.8 MB
    max_records: int = 25_000
    max_queued_jobs: int = 3
    keep_results_hours: float = 48.0
    poll_seconds: int = 2
    extra_ms_per_record: float = 0.0  # SIMULATED cost of a slower model; 0 in production


def read_secret(name: str) -> str | None:
    """Return the value of NAME, or the contents of the file in NAME_FILE."""
    path = os.environ.get(f"{name}_FILE")
    if path:
        try:
            return Path(path).read_text(encoding="utf-8").strip() or None
        except OSError as error:
            raise SettingsError(f"{name}_FILE: cannot read {path}: {error.strerror}")
    return os.environ.get(name) or None


def load_settings() -> Settings:
    env = os.environ
    sha = env.get("MODEL_SHA256", "").strip().lower()
    if len(sha) != 64:
        raise SettingsError("MODEL_SHA256 must be the 64-character digest of the bundle")
    settings = Settings(
        model_bundle=Path(env.get("MODEL_BUNDLE", "bundles/readmission-1.0.0")),
        model_sha256=sha,
        api_key=read_secret("API_KEY"),
        log_level=env.get("LOG_LEVEL", "INFO").upper(),
        max_upload_bytes=int(env.get("MAX_UPLOAD_BYTES", "4000000")),
        max_records=int(env.get("MAX_RECORDS", "25000")),
        max_queued_jobs=int(env.get("MAX_QUEUED_JOBS", "3")),
        keep_results_hours=float(env.get("KEEP_RESULTS_HOURS", "48")),
        poll_seconds=int(env.get("POLL_SECONDS", "2")),
        extra_ms_per_record=float(env.get("EXTRA_MS_PER_RECORD", "0")),
    )
    if env.get("REQUIRE_API_KEY", "false").lower() == "true" and not settings.api_key:
        raise SettingsError("REQUIRE_API_KEY is true, but API_KEY is not set")
    return settings
