"""Read a discharge file, check each row, and score the rows with a loaded bundle.

    check_upload   the fast checks of a whole file, done while the caller waits
    read_rows      each row against the contract: good rows, and rejected rows with their line
    score_rows     the model's scores for checked rows
    results_csv    the follow-up list: the highest scores first
"""

import csv
import io
import time
from dataclasses import dataclass

from pydantic import ValidationError

from readmission.bundle import Bundle
from readmission.contract import COLUMNS, DischargeIn, to_frame, unknown_categories


class FileProblem(Exception):
    """The file cannot be scored at all. The caller gets an error, not a job."""

    def __init__(self, status: int, code: str, message: str, fields=()):
        super().__init__(message)
        self.status, self.code, self.message, self.fields = status, code, message, list(fields)


@dataclass
class Result:
    encounter_id: int
    score: float
    call: bool
    unknown: list[str]


def check_upload(body: bytes, max_records: int) -> int:
    """Check what is fast to check: the text, the columns, the number of rows. Return the rows."""
    try:
        text = body.decode("utf-8")
    except UnicodeDecodeError:
        raise FileProblem(422, "invalid_file", "The file is not UTF-8 text.") from None
    header = next(csv.reader(io.StringIO(text)), [])
    missing = [c for c in COLUMNS if c not in header]
    extra = [c for c in header if c not in COLUMNS]
    if missing:
        raise FileProblem(422, "invalid_file", "The file has no column for some features.", missing)
    if extra:
        raise FileProblem(
            422, "invalid_file", "The file has columns that the model does not use. Do not send them.", extra
        )
    records = text.count("\n") - 1 + (not text.endswith("\n"))
    if records < 1:
        raise FileProblem(422, "invalid_file", "The file has no rows.")
    if records > max_records:
        raise FileProblem(413, "too_many_records", f"A file can have at most {max_records} rows.")
    return records


def read_rows(body: bytes) -> tuple[list[DischargeIn], list[dict]]:
    """Check every row. A bad row is set aside with its line number; it does not stop the others."""
    good, rejected = [], []
    reader = csv.DictReader(io.StringIO(body.decode("utf-8")))
    for line, row in enumerate(reader, start=2):  # line 1 is the header
        try:
            good.append(DischargeIn(**row))
        except ValidationError as error:
            fields = sorted({str(e["loc"][0]) for e in error.errors()})
            rejected.append({"line": line, "encounter_id": row.get("encounter_id"), "fields": fields})
    return good, rejected


def score_rows(bundle: Bundle, rows: list[DischargeIn], extra_ms: float = 0.0) -> list[Result]:
    scores = bundle.pipeline.predict_proba(to_frame(rows))[:, 1]
    if extra_ms:  # SIMULATED: a stand-in for a slower model. The real model needs no time here.
        time.sleep(extra_ms * len(rows) / 1000)
    return [
        Result(r.encounter_id, float(s), bool(s >= bundle.threshold), unknown_categories(r, bundle.known))
        for r, s in zip(rows, scores)
    ]


def results_csv(results: list[Result]) -> str:
    """The follow-up list: one line per stay, the highest score first."""
    out = io.StringIO()
    out.write("rank,encounter_id,score,call\n")
    ordered = sorted(results, key=lambda r: r.score, reverse=True)
    for rank, r in enumerate(ordered, start=1):
        out.write(f"{rank},{r.encounter_id},{r.score:.6f},{str(r.call).lower()}\n")
    return out.getvalue()
