from fastapi import APIRouter, Depends, Request, Response
from fastapi.concurrency import run_in_threadpool
from pydantic import BaseModel

from readmission.errors import ErrorResponse, error_response
from readmission.scoring import FileProblem, check_upload, read_rows, results_csv, score_rows
from readmission.security import require_api_key

router = APIRouter(prefix="/v1", dependencies=[Depends(require_api_key)])

CSV_BODY = {"requestBody": {"required": True, "content": {"text/csv": {"schema": {"type": "string"}}}}}


def errors(*codes: int) -> dict:
    return {code: {"model": ErrorResponse} for code in codes}


class ModelInfo(BaseModel):
    model_version: str
    bundle_sha256: str
    threshold: float
    capacity: float
    trained_at: str
    features: list[str]


@router.get("/model", tags=["model"], summary="Which model answers, and how to check it")
def model(request: Request) -> ModelInfo:
    bundle = request.app.state.bundle
    return ModelInfo(
        model_version=bundle.version,
        bundle_sha256=bundle.digest,
        threshold=bundle.threshold,
        capacity=bundle.metadata["capacity"],
        trained_at=bundle.metadata["trained_at"],
        features=bundle.contract["features"],
    )


@router.post(
    "/follow-up-list",
    tags=["scoring"],
    summary="Score a discharge file (CSV) and wait for the follow-up list",
    openapi_extra=CSV_BODY,
    response_class=Response,
    responses={200: {"content": {"text/csv": {}}}, **errors(401, 413, 415, 422)},
)
async def follow_up_list(request: Request):
    """The first version: the caller sends the file and waits until every row is scored."""
    settings = request.app.state.settings
    if request.headers.get("content-type", "").split(";")[0].strip() != "text/csv":
        return error_response(request, 415, "not_csv", "Send the file as text/csv.")
    body = await request.body()
    if len(body) > settings.max_upload_bytes:
        return error_response(request, 413, "file_too_large", f"A file can have at most {settings.max_upload_bytes} bytes.")
    try:
        check_upload(body, settings.max_records)
    except FileProblem as problem:
        return error_response(request, problem.status, problem.code, problem.message, problem.fields)
    rows, rejected = read_rows(body)
    if rejected:
        lines = [f"line {r['line']}: {', '.join(r['fields'])}" for r in rejected[:20]]
        return error_response(request, 422, "invalid_rows", "Some rows do not match the contract.", lines)
    results = await run_in_threadpool(score_rows, request.app.state.bundle, rows, settings.extra_ms_per_record)
    return Response(results_csv(results), media_type="text/csv")
