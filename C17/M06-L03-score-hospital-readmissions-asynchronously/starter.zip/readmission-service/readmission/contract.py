"""The inference contract: what one discharge must look like before the model scores it.

The model learned from 19 features of a hospital stay, all known on the day
the patient leaves hospital. This file says, for each one, its name, its
type and the values it may take. The job worker checks every row of a
discharge file with these classes before it scores anything.

Not in the contract, on purpose: race, gender and the payer (insurance). The
model never uses them, so a file must not send them.
"""

import pandas as pd
from pydantic import BaseModel, ConfigDict, Field

# The order of the columns that the pipeline was fitted on (training/train.py).
CATEGORIES = [
    "admission_type",
    "admission_source",
    "discharge_to",
    "specialty",
    "diagnosis_group",
    "A1Cresult",
    "max_glu_serum",
    "insulin",
    "change",
    "diabetesMed",
]
NUMBERS = [
    "age_years",
    "time_in_hospital",
    "num_lab_procedures",
    "num_procedures",
    "num_medications",
    "number_outpatient",
    "number_emergency",
    "number_inpatient",
    "number_diagnoses",
]
FEATURES = CATEGORIES + NUMBERS
COLUMNS = ["encounter_id"] + FEATURES  # the columns of a discharge file, in any order


def text(description: str | None = None):
    """A category value: any text of 1 to 120 characters."""
    return Field(min_length=1, max_length=120, description=description)


class DischargeFeatures(BaseModel):
    """The 19 features of one hospital stay, as they are on the day of discharge."""

    model_config = ConfigDict(extra="forbid")

    admission_type: str = text()
    admission_source: str = text()
    discharge_to: str = text("Where the patient goes next.")
    specialty: str = text("The admitting doctor's specialty.")
    diagnosis_group: str = text("The main diagnosis, in 9 groups.")
    A1Cresult: str = text("HbA1c test result, or 'not measured'.")
    max_glu_serum: str = text("Glucose test result, or 'not measured'.")
    insulin: str = text()
    change: str = text()
    diabetesMed: str = text()
    age_years: int = Field(ge=0, le=110, description="The middle of the 10-year age band, for example 75.")
    time_in_hospital: int = Field(ge=1, le=14, description="Days in hospital (the data has stays of 1 to 14 days).")
    num_lab_procedures: int = Field(ge=0, le=300)
    num_procedures: int = Field(ge=0, le=50)
    num_medications: int = Field(ge=0, le=200)
    number_outpatient: int = Field(ge=0, le=200, description="Outpatient visits in the year before the stay.")
    number_emergency: int = Field(ge=0, le=200, description="Emergency visits in the year before the stay.")
    number_inpatient: int = Field(ge=0, le=100, description="Hospital stays in the year before the stay.")
    number_diagnoses: int = Field(ge=1, le=50)


class DischargeIn(DischargeFeatures):
    """One row of a discharge file: the stay's number and its features."""

    encounter_id: int = Field(gt=0, description="The stay's number. No name, no patient number.")


def unknown_categories(row: DischargeFeatures, known: dict[str, list[str]]) -> list[str]:
    """The category columns whose value the model never saw in training.

    They are allowed: the encoder scores them like a rare value. Many of them
    mean that the export has changed, so the job counts them.
    """
    return [name for name in CATEGORIES if getattr(row, name) not in known[name]]


def to_frame(rows: list[DischargeFeatures]) -> pd.DataFrame:
    """The rows as a table with the training columns, in the training order."""
    frame = pd.DataFrame([r.model_dump(include=set(FEATURES)) for r in rows], columns=FEATURES)
    frame[NUMBERS] = frame[NUMBERS].astype("float64")
    return frame
