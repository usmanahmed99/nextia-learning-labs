# readmission-service (starter)

The starter project of the Nextia case study *Score hospital readmissions asynchronously* (C17). It has the model bundle, the contract, the bundle checks, and a first, **synchronous** endpoint: `POST /v1/follow-up-list` scores a whole discharge file while the caller waits. In the case study, you replace it with queued jobs, put the service in a container, and make the jobs survive a restart.

**The list supports a care team's follow-up calls. It never decides anything about a patient on its own.** Read [MODEL_CARD.md](MODEL_CARD.md) first.

## Set up (macOS or Linux; Windows in brackets)

```sh
python3 -m venv .venv                    # (python -m venv .venv)
source .venv/bin/activate                # (.venv\Scripts\Activate.ps1)
python -m pip install -r requirements.txt
python -m pytest                         # 19 passed
```

## Run

```sh
export MODEL_SHA256=89056e4cfab4a6a58180461ab01f8b53aeec448ed444ee808699abe2ed6cdf27
fastapi dev                              # http://127.0.0.1:8000/docs
```

## Data and licence

The code is under the MIT licence ([LICENSE](LICENSE)). The data is *Diabetes 130-US Hospitals for Years 1999-2008* (Clore, Cios, DeShazo and Strack, 2014; UCI Machine Learning Repository, https://doi.org/10.24432/C5230J), CC BY 4.0, changed as described in [data/README.md](data/README.md).
