"""Send recorded requests to a running API, one at a time, as the intake tool did.

    python scripts/replay.py http://127.0.0.1:8000 replay/requests-2015-04-05.jsonl replay/out/answers.csv

Set HOUSE_API_KEY first if the API needs a key. For each request, the script
keeps the sale ID, the X-Request-ID that the API gave, the status and the
estimate. compare.py joins these with the API's prediction log (by request ID)
and with the sale prices (by sale ID).
"""

import csv
import json
import os
import statistics
import sys
import time
from collections import Counter
from pathlib import Path

import httpx


def main() -> int:
    if len(sys.argv) != 4:
        print(__doc__)
        return 2
    url, requests_file, out = sys.argv[1], Path(sys.argv[2]), Path(sys.argv[3])
    key = os.environ.get("HOUSE_API_KEY")
    lines = requests_file.read_text("utf-8").splitlines()
    out.parent.mkdir(parents=True, exist_ok=True)
    statuses, times = Counter(), []
    started = time.perf_counter()
    with httpx.Client(base_url=url, timeout=10, headers={"X-API-Key": key} if key else {}) as api, \
            out.open("w", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(["sale_id", "request_id", "status", "code", "estimate_usd", "model_version", "ms"])
        for line in lines:
            request = json.loads(line)
            sent = time.perf_counter()
            response = api.post("/v1/estimates", json=request["house"])
            ms = (time.perf_counter() - sent) * 1000
            body = response.json()
            code = body.get("error", {}).get("code", "")
            statuses[(response.status_code, code)] += 1
            times.append(ms)
            writer.writerow([request["sale_id"], response.headers.get("x-request-id"), response.status_code,
                             code, body.get("estimate_usd", ""), body.get("model_version", ""), f"{ms:.2f}"])
    seconds = time.perf_counter() - started
    times.sort()
    answered = sum(n for (status, _), n in statuses.items() if status == 200)
    refused = ", ".join(f"{status} {code}: {n}" for (status, code), n in sorted(statuses.items()) if status != 200)
    print(f"Sent {len(lines)} requests in {seconds:.1f} s: {answered} answered 200"
          + (f", refused {refused}" if refused else "") + ".")
    print(f"Time per request: median {statistics.median(times):.1f} ms, "
          f"95th percentile {times[int(len(times) * 0.95)]:.1f} ms.")
    print(f"Wrote {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
