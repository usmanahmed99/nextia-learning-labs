"""Make the replay: the requests of a later period, and their sale prices.

    python replay/make_replay.py

Uses the course data (training/train.py downloads it). The requests are the
houses first sold from 2015-04-01 to the end of the data (2015-05-27), in the
order of their sale dates, in the API's terms. The prices go to a separate
file: the service never sees them. They arrive later, like real sale prices.

    replay/requests-2015-04-05.jsonl   one line per sale: {"sale_id", "house"}
    replay/sales-2015-04-05.csv        sale_id, date, price, zipcode
"""

import csv
import json
import sys
from pathlib import Path

PROJECT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT / "training"))
from train import DATA_FILE, download, load_data  # noqa: E402

FROM = "2015-04-01"
REQUESTS = PROJECT / "replay" / "requests-2015-04-05.jsonl"
SALES = PROJECT / "replay" / "sales-2015-04-05.csv"


def house_in_api_terms(row) -> dict:
    """The fields of HouseIn: no sqft_above, true/false, and null for 'never'."""
    return {
        "bedrooms": int(row.bedrooms),
        "bathrooms": float(row.bathrooms),
        "sqft_living": int(row.sqft_living),
        "sqft_lot": int(row.sqft_lot),
        "floors": float(row.floors),
        "waterfront": bool(row.waterfront),
        "view": int(row.view),
        "condition": int(row.condition),
        "grade": int(row.grade),
        "sqft_basement": int(row.sqft_basement),
        "yr_built": int(row.yr_built),
        "yr_renovated": int(row.yr_renovated) or None,
        "lat": float(row.lat),
        "long": float(row.long),
        "sqft_living15": int(row.sqft_living15),
        "sqft_lot15": int(row.sqft_lot15),
    }


def main() -> None:
    download()
    houses = load_data(DATA_FILE)
    first_sale = houses.groupby("id")["date"].transform("min")
    later = houses[first_sale >= FROM].sort_values(["date", "id"], kind="stable")
    with REQUESTS.open("w", encoding="utf-8") as requests, SALES.open("w", newline="") as sales:
        writer = csv.writer(sales)
        writer.writerow(["sale_id", "date", "price", "zipcode"])
        for row in later.itertuples():
            sale_id = f"{row.id}-{row.date:%Y%m%d}"
            requests.write(json.dumps({"sale_id": sale_id, "house": house_in_api_terms(row)}) + "\n")
            writer.writerow([sale_id, f"{row.date:%Y-%m-%d}", int(row.price), row.zipcode])
    print(f"wrote {REQUESTS.relative_to(PROJECT)} and {SALES.relative_to(PROJECT)}: "
          f"{len(later)} sales from {later['date'].min():%Y-%m-%d} to {later['date'].max():%Y-%m-%d}")


if __name__ == "__main__":
    main()
