"""Make the county's "new export" that the analyst used for the first candidate.

    python training/simulate_export.py

Reads the course data (data/king_county_house_sales.csv.gz; run
training/train.py once to download it) and writes
data/county-export-2015-04-01.csv.gz: the same sales and columns, with one
change in how one column is coded. The case study shows the change and its
effect (Part 4). The real county data never had this change: this script
simulates a new export, a common way for a retrained model to go wrong.
"""

import gzip
from pathlib import Path

import pandas as pd

PROJECT = Path(__file__).resolve().parent.parent
SOURCE = PROJECT / "data" / "king_county_house_sales.csv.gz"
EXPORT = PROJECT / "data" / "county-export-2015-04-01.csv.gz"


def main() -> None:
    houses = pd.read_csv(SOURCE, dtype={"date": str})
    never = houses["yr_renovated"] == 0
    # The new export gives the year of the last work on the house: the
    # renovation year, or the build year for a house never renovated.
    houses.loc[never, "yr_renovated"] = houses.loc[never, "yr_built"]
    # mtime=0: the same input gives the same file, byte for byte.
    with gzip.GzipFile(EXPORT, "wb", mtime=0) as file:
        file.write(houses.to_csv(index=False).encode("utf-8"))
    print(f"wrote {EXPORT.relative_to(PROJECT)}: {len(houses)} sales")


if __name__ == "__main__":
    main()
