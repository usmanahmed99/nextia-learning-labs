# house-price-api (starter for "Release a new house-price model")

The starter project of the Nextia Learning case study *Release a new house-price model* (course C17, *Deploying AI Models for Real Users*). It is the finished project of the C16 case study *Serve a house-price model*, plus the tools that this case study needs. The case study page guides you step by step.

What is here:

- `house_price_api/`, `model/`, `tests/`, `contract/`: the C16 API, its model (version kc-hgb-2015-02) and its 49 tests. Read `MODEL_CARD.md` first.
- `training/train.py`: the analyst's training script. It now takes `--until`, `--version`, `--data` and `--out`, to make a new model with newer sales.
- `training/simulate_export.py`: makes a changed copy of the data, a "new export". The case study explains why.
- `replay/make_replay.py` and `scripts/replay.py`: make the requests and sale prices of April and May 2015, and send the requests to a running API.

## Set up

```sh
python3 -m venv .venv                # Windows: python -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\Activate.ps1
python -m pip install -r requirements-lock.txt
python -m pytest                     # 49 passed
```

The code is under the MIT licence (`LICENSE`). The data behind the model is *House Sales in King County, USA* (harlfoxem, Kaggle 2016; OpenML 42092), CC0 1.0.
