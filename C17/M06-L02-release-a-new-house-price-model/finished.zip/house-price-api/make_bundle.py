"""Make a versioned model bundle from a folder that training/train.py wrote.

    python make_bundle.py candidates/kc-hgb-2015-03

Reads house_price.joblib and model_card.json from the folder, and writes
bundles/<model_version>/ with four files:

    model.joblib        the model, copied byte for byte
    model_card.json     its card, copied byte for byte (GET /v1/model serves it)
    parity_cases.json   fixed houses and the estimates this model gives them
    SHA256SUMS          the SHA-256 of each file above

It prints the bundle digest: the SHA-256 of SHA256SUMS. Add it to BUNDLES in
house_price_api/config.py, in a reviewed change, before the service may load
the bundle. A version is never changed: if the folder exists, the script stops.

It loads the joblib file to compute the parity estimates, and loading can run
code: run it only on a model that you trained, or that comes from a source
that you trust.
"""

import argparse
import hashlib
import json
import shutil
import sys
from pathlib import Path

import joblib

from house_price_api.estimator import FEATURES
from house_price_api.models import TYPICAL_HOUSE, HouseIn

FILES = ["model.joblib", "model_card.json", "parity_cases.json"]
GOLDEN = Path("tests/golden_houses.json")

# Fixed houses that every copy of a model must estimate the same way: the
# three golden houses of C16, and houses at the edges of the contract.
EDGE_CASES = {
    "never_renovated_new": {"yr_built": 2014, "yr_renovated": None},
    "renovated_old": {"yr_built": 1905, "yr_renovated": 2010},
    "smallest": {
        "bedrooms": 0, "bathrooms": 0.0, "sqft_living": 250, "sqft_lot": 500,
        "floors": 1.0, "view": 0, "condition": 1, "grade": 1, "sqft_basement": 0,
        "yr_built": 1900, "sqft_living15": 400, "sqft_lot15": 600,
    },
    "largest": {
        "bedrooms": 11, "bathrooms": 8.0, "sqft_living": 14000, "sqft_lot": 1100000,
        "floors": 3.5, "waterfront": True, "view": 4, "condition": 5, "grade": 13,
        "sqft_basement": 5000, "yr_built": 2015, "yr_renovated": 2015,
        "sqft_living15": 6500, "sqft_lot15": 900000,
    },
    "south_west_corner": {"lat": 47.15, "long": -122.52},
    "north_east_corner": {"lat": 47.78, "long": -121.31},
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def parity_cases(model) -> list[dict]:
    golden = json.loads(GOLDEN.read_text("utf-8"))
    houses = {g["name"]: g["house"] for g in golden}
    houses |= {name: {**TYPICAL_HOUSE, **change} for name, change in EDGE_CASES.items()}
    cases = []
    for name, house in houses.items():
        inputs = HouseIn(**house).model_inputs()  # every case must pass the contract
        [estimate] = model.predict([[inputs[f] for f in FEATURES]]).tolist()
        cases.append({"name": name, "house": house, "expected_estimate": estimate})
    return cases


def main() -> None:
    parser = argparse.ArgumentParser(description="Make a model bundle.")
    parser.add_argument("source", type=Path, help="a folder with house_price.joblib and model_card.json")
    args = parser.parse_args()

    card = json.loads((args.source / "model_card.json").read_text("utf-8"))
    model_file = args.source / "house_price.joblib"
    if sha256(model_file) != card["sha256"]:
        sys.exit("Stopped: model_card.json describes another model file.")
    if card["features"] != FEATURES:
        sys.exit("Stopped: the model was trained on other features than the API sends.")

    out = Path("bundles") / card["model_version"]
    if out.exists():
        sys.exit(f"Stopped: {out} exists. A version is never changed: choose a new version.")
    out.mkdir(parents=True)
    shutil.copyfile(model_file, out / "model.joblib")
    shutil.copyfile(args.source / "model_card.json", out / "model_card.json")

    cases = parity_cases(joblib.load(model_file))
    (out / "parity_cases.json").write_text(json.dumps(cases, indent=2) + "\n", "utf-8")

    lines = [f"{sha256(out / name)}  {name}" for name in FILES]
    (out / "SHA256SUMS").write_text("\n".join(lines) + "\n", "utf-8")

    print(f"Made {out}: {len(cases)} parity cases.")
    print(f"Bundle digest: {sha256(out / 'SHA256SUMS')}")


if __name__ == "__main__":
    main()
