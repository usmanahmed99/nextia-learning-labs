"""Train the house-price model, and write house_price.joblib and model_card.json.

Run it from the project folder, with the training packages installed
(requirements.txt):

    python training/train.py                       # version 1, as in C16
    python training/train.py --until 2015-04-01 --version kc-hgb-2015-03

It downloads the data (0.7 MB) into data/ the first time, and checks its
SHA-256. The model is the one from the Nextia case study "Estimate house
prices" (C05): gradient boosting on the log of the price, with latitude and
longitude for the place.

--until is the first day that the model must not see. Houses first sold
before it are the training data; houses first sold from it on are the test
data. --data trains from another file with the same columns, for example a
new export; its SHA-256 goes into the card.

The model goes to --out (default: candidates/<version>/). It is a candidate:
make a bundle of it with make_bundle.py before the service can use it.
"""

import argparse
import hashlib
import json
import time
from pathlib import Path

import httpx
import joblib
import numpy as np
import pandas as pd
import sklearn
from sklearn.compose import TransformedTargetRegressor
from sklearn.ensemble import HistGradientBoostingRegressor

PROJECT = Path(__file__).resolve().parent.parent
DATA_URL = (
    "https://github.com/usmanahmed99/nextia-learning-labs/raw/main/"
    "C05/case-studies/data/king_county_house_sales.csv.gz"
)
DATA_FILE = PROJECT / "data" / "king_county_house_sales.csv.gz"
DATA_SHA256 = "0e2fd1937fbc724622e00fefebe060e28587882725663050c5c25fef74ce193c"
DATA_SOURCE = "House Sales in King County, USA (harlfoxem, Kaggle 2016; OpenML 42092)"

PICKLE_PROTOCOL = 5
VALID_FROM = "2015-01-01"  # C05's validation months start here
FEATURES = [
    "bedrooms", "bathrooms", "sqft_living", "sqft_lot", "floors", "waterfront",
    "view", "condition", "grade", "sqft_above", "sqft_basement", "yr_built",
    "yr_renovated", "lat", "long", "sqft_living15", "sqft_lot15",
]
# Inputs whose unusual values get a "rare_value" warning in the API.
RARE_CHECKED = [
    "bedrooms", "bathrooms", "sqft_living", "sqft_lot", "sqft_basement",
    "sqft_living15", "sqft_lot15",
]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def download() -> None:
    if not DATA_FILE.exists():
        DATA_FILE.parent.mkdir(exist_ok=True)
        print("Downloading", DATA_URL)
        response = httpx.get(DATA_URL, follow_redirects=True, timeout=60)
        response.raise_for_status()
        DATA_FILE.write_bytes(response.content)
    if sha256(DATA_FILE) != DATA_SHA256:
        raise SystemExit(f"{DATA_FILE} is not the expected file. Delete it and run again.")


def check_codes(houses: pd.DataFrame) -> None:
    """Stop if a column uses another code than the API sends to the model."""
    if not (houses["yr_renovated"] == 0).any():
        raise SystemExit(
            "Stopped: yr_renovated is never 0 in this file. The API sends 0 for "
            "'never renovated', so the model must learn from that code."
        )


def load_data(path: Path) -> pd.DataFrame:
    houses = pd.read_csv(path, parse_dates=["date"])
    houses.loc[houses["bedrooms"] == 33, "bedrooms"] = 3  # 1,620 sq ft: a typing error for 3
    check_codes(houses)
    return houses


def report(real: pd.Series, estimate: np.ndarray) -> dict:
    """Errors as percentages of the real price (positive = the estimate is too low)."""
    pct = 100 * (real - estimate) / real
    return {
        "median_error_pct": round(float(np.median(pct)), 1),
        "mape_pct": round(float(np.mean(np.abs(pct))), 1),
        "within_10pct": round(float(np.mean(np.abs(pct) <= 10)), 3),
        "over_by_10pct_or_more": round(float(np.mean(pct < -10)), 3),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Train the house-price model.")
    parser.add_argument("--until", default="2015-03-01", help="the first day the model must not see")
    parser.add_argument("--version", default="kc-hgb-2015-02", help="the model version")
    parser.add_argument("--data", type=Path, help="train from this file instead of the course data")
    parser.add_argument("--out", type=Path, help="the output folder (default: candidates/<version>)")
    args = parser.parse_args()

    if args.data is None:
        download()
        data_file, data_sha, source = DATA_FILE, DATA_SHA256, DATA_SOURCE
    else:
        data_file, data_sha = args.data, sha256(args.data)
        source = f"{args.data.name} (not the reviewed course file)"
        print(f"data: {args.data.name}, SHA-256 {data_sha[:12]}... (not the reviewed course file)")
    houses = load_data(data_file)

    until = pd.Timestamp(args.until)
    last_day = (until - pd.Timedelta(days=1)).date()
    # Every sale of a house goes where its first sale goes.
    first_sale = houses.groupby("id")["date"].transform("min")
    # The C05 case study's train part, then its validation part, in this
    # order: the order decides which rows boosting keeps aside to stop early.
    train = pd.concat([
        houses[first_sale < VALID_FROM],
        houses[(first_sale >= VALID_FROM) & (first_sale < until)],
    ])
    test = houses[first_sale >= until]
    print(f"train {len(train)} sales | test {len(test)} sales")

    model = TransformedTargetRegressor(
        regressor=HistGradientBoostingRegressor(
            learning_rate=0.05, max_iter=600, random_state=0
        ),
        func=np.log,
        inverse_func=np.exp,
    )
    started = time.perf_counter()
    model.fit(train[FEATURES].to_numpy(dtype=float), train["price"].to_numpy())
    print(f"trained in {time.perf_counter() - started:.1f} s")

    estimate = model.predict(test[FEATURES].to_numpy(dtype=float))
    test_result = report(test["price"], estimate)
    print("test:", test_result)

    # The range: 80% of the test sales sold between these two multiples of
    # their estimate.
    ratio = test["price"].to_numpy() / estimate
    low, high = np.quantile(ratio, [0.10, 0.90])
    inside = float(np.mean((ratio >= low) & (ratio <= high)))
    print(f"range: {low:.3f} to {high:.3f} times the estimate ({inside:.0%} of test sales inside)")

    out = (args.out or PROJECT / "candidates" / args.version).resolve()
    out.mkdir(parents=True, exist_ok=True)
    model_file, card_file = out / "house_price.joblib", out / "model_card.json"
    # A fixed pickle protocol: Python 3.12 uses 4 by default, 3.14 uses 5, so
    # without it the file (and its SHA-256) would depend on the Python version.
    joblib.dump(model, model_file, compress=3, protocol=PICKLE_PROTOCOL)
    digest = sha256(model_file)

    usual = train[RARE_CHECKED].quantile([0.01, 0.99])
    card = {
        "name": "king-county-house-price",
        "model_version": args.version,
        "sha256": digest,
        "prices_as_of": str(train.loc[train["date"] < until, "date"].max().date()),
        "intended_use": (
            "A first estimate of the sale price of a house in King County, Washington, "
            "before a human appraisal."
        ),
        "not_for": [
            "lending, underwriting or insurance decisions about a person",
            "setting a loan amount or a price",
            "houses outside King County, Washington",
            f"today's prices: the model knows sales from May 2014 to {last_day:%B %Y}",
        ],
        "training_data": {
            "source": source,
            "licence": "CC0 1.0",
            "file_sha256": data_sha,
            "sales": len(train),
            "first_sales": f"{train['date'].min().date()} to {last_day}",
        },
        "test": {
            "sales": len(test),
            "first_sales": f"{until.date()} to {test['date'].max().date()}",
            **test_result,
        },
        "range": {"coverage": 0.8, "low_factor": round(float(low), 3), "high_factor": round(float(high), 3)},
        "usual_values": {
            column: [round(float(usual.loc[q, column]), 2) for q in (0.01, 0.99)]
            for column in RARE_CHECKED
        },
        "model": (
            "HistGradientBoostingRegressor on the log of the price, learning rate 0.05, "
            f"at most 600 trees (early stopping kept {model.regressor_.n_iter_})"
        ),
        "features": FEATURES,
        "trained_with": {
            "pickle_protocol": PICKLE_PROTOCOL,
            "scikit-learn": sklearn.__version__,
            "numpy": np.__version__,
            "joblib": joblib.__version__,
        },
    }
    card_file.write_text(json.dumps(card, indent=2) + "\n", encoding="utf-8")
    size_mb = model_file.stat().st_size / 1e6
    shown = out.relative_to(PROJECT) if out.is_relative_to(PROJECT) else out
    print(f"wrote {shown}/ (house_price.joblib {size_mb:.2f} MB, model_card.json)")
    print("sha256", digest)


if __name__ == "__main__":
    main()
