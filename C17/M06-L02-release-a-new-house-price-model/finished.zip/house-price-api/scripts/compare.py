"""Compare the live model and the shadow on a replay, and run the release checks.

    python scripts/compare.py replay/out/answers.csv replay/out/service.log replay/sales-2015-04-05.csv

answers.csv comes from replay.py, service.log is the API's log during the
replay, and the sales file has the prices that arrived later. The script
joins the three, prints the error of each model on the sale prices and how
much the estimates move, runs the release checks, and lists the largest
moves. It writes the joined rows to compare-<shadow version>.csv next to
answers.csv.

A regression model has no threshold to check. So the checks look at two
things: is the new model's error lower, and how much do the answers that
clients see change? A person reads the largest moves before deciding.
"""

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

# The release checks, agreed with the valuation team before the shadow ran.
MAX_ERROR_INCREASE = 0.01  # the shadow's MAE may be at most 1% above the live MAE
BIG_MOVE = 0.10  # an estimate "moves" when it changes by more than 10%
MAX_MOVED_SHARE = 0.05  # at most 5% of estimates may move
MAX_AREA_MOVE = 0.05  # no zip code's median estimate may move by more than 5%
MIN_AREA_SALES = 10  # areas with fewer sales are too small to judge
MARKER = "house_price_api.predictions: "


def read_log(path: Path) -> pd.DataFrame:
    """The prediction lines of the log, one row per estimated house."""
    rows = [json.loads(line.split(MARKER, 1)[1]) for line in path.read_text("utf-8").splitlines() if MARKER in line]
    return pd.DataFrame(rows)


def errors(price: pd.Series, estimate: pd.Series) -> dict:
    pct = (price - estimate) / price
    return {
        "Mean absolute error (USD)": f"{np.mean(np.abs(price - estimate)):,.0f}",
        "Within 10% of the price": f"{np.mean(np.abs(pct) <= 0.10):.1%}",
        "Median error (+ = too low)": f"{np.median(pct):+.1%}",
    }


def main() -> int:
    if len(sys.argv) != 4:
        print(__doc__)
        return 2
    answers_file, log_file, sales_file = map(Path, sys.argv[1:])
    answers = pd.read_csv(answers_file, dtype={"sale_id": str})
    answers = answers[answers["status"] == 200].drop(columns="model_version")
    log = read_log(log_file)
    if "shadow_estimate" not in log:
        print("The log has no shadow estimates: start the API with SHADOW_VERSION.")
        return 2
    sales = pd.read_csv(sales_file, dtype={"sale_id": str, "zipcode": str})
    rows = (
        answers.merge(log, on="request_id", validate="one_to_one")
        .merge(sales, on="sale_id", validate="one_to_one")
    )
    rows["move"] = rows["shadow_estimate"] / rows["estimate"] - 1
    live, shadow = rows["model_version"].iloc[0], rows["shadow_version"].iloc[0]
    print(f"Joined {len(rows)} answers with the log and the sale prices.")
    print(f"Live {live}, shadow {shadow}.\n")

    live_errors, shadow_errors = errors(rows["price"], rows["estimate"]), errors(rows["price"], rows["shadow_estimate"])
    print(f"{'':28}{'live':>12}{'shadow':>12}")
    for name in live_errors:
        print(f"{name:28}{live_errors[name]:>12}{shadow_errors[name]:>12}")

    mae_live = np.mean(np.abs(rows["price"] - rows["estimate"]))
    mae_shadow = np.mean(np.abs(rows["price"] - rows["shadow_estimate"]))
    change = mae_shadow / mae_live - 1
    moved = rows["move"].abs() > BIG_MOVE
    areas = rows.groupby("zipcode")["move"].agg(["median", "size"])
    areas = areas[areas["size"] >= MIN_AREA_SALES]
    worst = areas["median"].abs().idxmax()
    checks = [
        (change <= MAX_ERROR_INCREASE,
         f"error: the shadow's MAE is at most {MAX_ERROR_INCREASE:.0%} above the live MAE ({change:+.1%})"),
        (moved.mean() <= MAX_MOVED_SHARE,
         f"moves: at most {MAX_MOVED_SHARE:.0%} of estimates move by more than {BIG_MOVE:.0%} "
         f"({moved.mean():.1%}, {moved.sum()} houses)"),
        (abs(areas.loc[worst, "median"]) <= MAX_AREA_MOVE,
         f"areas: no zip code's median estimate moves by more than {MAX_AREA_MOVE:.0%} "
         f"(largest {worst}: {areas.loc[worst, 'median']:+.1%}, {areas.loc[worst, 'size']} sales)"),
    ]
    print("\nRelease checks")
    for passed, text in checks:
        print(f"  {'PASS' if passed else 'FAIL'}  {text}")

    print("\nThe 5 largest moves (read them before you decide)")
    print(f"  {'sale':22}{'live':>11}{'shadow':>11}{'move':>8}{'price':>11}  closer")
    for row in rows.reindex(rows["move"].abs().sort_values(ascending=False).index).head(5).itertuples():
        closer = "shadow" if abs(row.price - row.shadow_estimate) < abs(row.price - row.estimate) else "live"
        print(f"  {row.sale_id:22}{row.estimate:>11,.0f}{row.shadow_estimate:>11,.0f}"
              f"{row.move:>+8.1%}{row.price:>11,}  {closer}")

    out = answers_file.with_name(f"compare-{shadow}.csv")
    rows[["sale_id", "date", "zipcode", "price", "estimate", "shadow_estimate", "move"]].to_csv(out, index=False)
    print(f"\nWrote {out}")
    return 0 if all(passed for passed, _ in checks) else 1


if __name__ == "__main__":
    sys.exit(main())
