"""Check that a running API serves the version that you released, unchanged.

    python scripts/check_release.py http://127.0.0.1:8000 kc-hgb-2015-02

Run it after every promotion and every rollback. Set HOUSE_API_KEY first if
the API needs a key. It checks four things against the files in this project:

1. /ready is 200.
2. /v1/model names the version, and the SHA-256 of its model file.
3. Parity: each parity case of bundles/<version>/ gets the estimate that the
   bundle recorded, rounded to 1,000 USD as the API rounds it.
4. The contract: /openapi.json equals contract/openapi.json, byte for byte.

The exit code is 0 if every check passed, and 1 if one failed.
"""

import json
import os
import sys
from pathlib import Path

import httpx

PROJECT = Path(__file__).resolve().parent.parent
failures = []


def check(passed: bool, text: str) -> None:
    print(f"  {'PASS' if passed else 'FAIL'}  {text}")
    if not passed:
        failures.append(text)


def main() -> int:
    if len(sys.argv) != 3:
        print(__doc__)
        return 2
    url, version = sys.argv[1], sys.argv[2]
    bundle = PROJECT / "bundles" / version
    card = json.loads((bundle / "model_card.json").read_text("utf-8"))
    cases = json.loads((bundle / "parity_cases.json").read_text("utf-8"))
    key = os.environ.get("HOUSE_API_KEY")
    api = httpx.Client(base_url=url, timeout=10, headers={"X-API-Key": key} if key else {})

    print(f"Release check: expected {version}")
    check(api.get("/ready").status_code == 200, "/ready is 200")

    served = api.get("/v1/model").json()
    check(
        served.get("model_version") == version and served.get("sha256") == card["sha256"],
        f"/v1/model names {served.get('model_version')}, model file {served.get('sha256', '?')[:12]}...",
    )

    matched = 0
    for case in cases:
        answer = api.post("/v1/estimates", json=case["house"]).json()
        expected = int(round(case["expected_estimate"], -3))
        if answer.get("estimate_usd") == expected:
            matched += 1
        else:
            print(f"        {case['name']}: got {answer.get('estimate_usd')}, expected {expected}")
    check(matched == len(cases), f"parity: {matched} of {len(cases)} cases give the bundle's estimates")

    response = api.get("/openapi.json")
    if response.status_code == 404:
        print("  INFO  /openapi.json is hidden (SHOW_DOCS=false): the contract was not compared")
    else:
        reviewed = (PROJECT / "contract" / "openapi.json").read_text("utf-8")
        check(json.dumps(response.json(), indent=2) + "\n" == reviewed,
              "contract: /openapi.json equals contract/openapi.json")

    print("All checks passed." if not failures else f"{len(failures)} check(s) failed.")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
