import os
from dataclasses import dataclass, field
from pathlib import Path

PROJECT = Path(__file__).resolve().parent.parent

# The reviewed bundles: model version -> bundle digest (the SHA-256 of its
# SHA256SUMS file). The service loads only these. A new bundle needs a new
# line here, in a reviewed change; the environment only chooses among them.
BUNDLES = {
    "kc-hgb-2015-02": "29752760649bf79193867d4a5887ee47c361aa913315d831b0e9fafe6f50d1cf",
    "kc-hgb-2015-03": "1ed11041ebcd4ccb751b599269c119d4d1d1978b620ac87e04ccf17c83dca30f",
}
DEFAULT_VERSION = "kc-hgb-2015-02"


@dataclass(frozen=True)
class Settings:
    api_key: str | None = field(repr=False)
    allowed_origins: list[str]
    bundles_dir: Path
    model_version: str
    shadow_version: str | None
    reviewed: dict[str, str]
    estimate_timeout: float
    log_level: str
    show_docs: bool


def load_settings() -> Settings:
    """Read the settings from environment variables, with safe defaults."""
    origins = os.environ.get("ALLOWED_ORIGINS", "")
    return Settings(
        api_key=os.environ.get("API_KEY") or None,
        allowed_origins=[o.strip() for o in origins.split(",") if o.strip()],
        bundles_dir=Path(os.environ.get("BUNDLES_DIR", PROJECT / "bundles")),
        model_version=os.environ.get("MODEL_VERSION", DEFAULT_VERSION),
        shadow_version=os.environ.get("SHADOW_VERSION") or None,
        reviewed=BUNDLES,
        estimate_timeout=float(os.environ.get("ESTIMATE_TIMEOUT", "2.0")),
        log_level=os.environ.get("LOG_LEVEL", "INFO").upper(),
        show_docs=os.environ.get("SHOW_DOCS", "true").lower() == "true",
    )
