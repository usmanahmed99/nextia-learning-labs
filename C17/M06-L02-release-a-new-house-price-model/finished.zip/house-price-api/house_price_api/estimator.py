import hashlib
import json
import warnings
from dataclasses import dataclass
from importlib.metadata import version
from pathlib import Path

import joblib
import numpy as np
from sklearn.exceptions import InconsistentVersionWarning

# The model's inputs, in the order that it was trained with.
FEATURES = [
    "bedrooms", "bathrooms", "sqft_living", "sqft_lot", "floors", "waterfront",
    "view", "condition", "grade", "sqft_above", "sqft_basement", "yr_built",
    "yr_renovated", "lat", "long", "sqft_living15", "sqft_lot15",
]

# The typical house of the documentation, in the model's own terms, for the
# readiness check: sqft_above is a column, and 0 means "never renovated".
READY_CHECK_HOUSE = {
    "bedrooms": 3, "bathrooms": 1.75, "sqft_living": 1560, "sqft_lot": 9452,
    "floors": 1, "waterfront": 0, "view": 0, "condition": 4, "grade": 8,
    "sqft_above": 1560, "sqft_basement": 0, "yr_built": 1974, "yr_renovated": 0,
    "lat": 47.5197, "long": -122.18, "sqft_living15": 2200, "sqft_lot15": 9985,
}


# The packages that must have the versions that saved the model.
PACKAGES = ["scikit-learn", "numpy", "joblib"]
# The self-check allows this relative difference: 1e-9 of 400,000 USD is 0.0004 USD.
TOLERANCE = 1e-9


class ModelUnavailable(Exception):
    """The model cannot answer now. The request may work later."""


@dataclass(frozen=True)
class Estimate:
    value: float
    low: float
    high: float


def file_sha256(path: Path) -> str:
    """The SHA-256 of a file, read in blocks of 1 MB."""
    digest = hashlib.sha256()
    with path.open("rb") as file:
        for block in iter(lambda: file.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


class HouseEstimator:
    """The loaded model, its card, and the digest of its bundle."""

    def __init__(self, model, card: dict, digest: str = ""):
        self.model = model
        self.card = card
        self.digest = digest
        self.version: str = card["model_version"]
        self.prices_as_of: str = card["prices_as_of"]
        self.low_factor: float = card["range"]["low_factor"]
        self.high_factor: float = card["range"]["high_factor"]
        self.usual_values: dict[str, list[float]] = card["usual_values"]

    def estimate(self, rows: list[dict[str, float]]) -> list[Estimate]:
        """Estimate the price of each house, with the range around it."""
        x = np.array([[row[name] for name in FEATURES] for row in rows], dtype=float)
        return [
            Estimate(value, value * self.low_factor, value * self.high_factor)
            for value in self.model.predict(x).tolist()
        ]

    def rare_values(self, row: dict[str, float]) -> list[str]:
        """The inputs outside the values of 98% of the training houses."""
        return [
            name
            for name, (low, high) in self.usual_values.items()
            if not low <= row[name] <= high
        ]


def check_files(path: Path, expected_digest: str) -> None:
    """Gates 1 and 2: this is the reviewed bundle, and no file in it changed."""
    sums = path / "SHA256SUMS"
    if not sums.is_file():
        raise ModelUnavailable(f"no bundle at {path}")
    digest = file_sha256(sums)
    if digest != expected_digest:
        raise ModelUnavailable(
            f"{path.name}: the bundle digest is {digest[:12]}..., "
            f"but config.BUNDLES expects {expected_digest[:12]}..."
        )
    for line in sums.read_text("utf-8").splitlines():
        expected, name = line.split()
        if file_sha256(path / name) != expected:
            raise ModelUnavailable(f"{path.name}/{name} changed after the bundle was made")


def check_card(path: Path, card: dict) -> None:
    """Gate 3: the card names this model file, this version and these packages."""
    if card["model_version"] != path.name:
        raise ModelUnavailable(f"{path.name}: the card says version {card['model_version']}")
    if card["sha256"] != file_sha256(path / "model.joblib"):
        raise ModelUnavailable(f"{path.name}: the card describes another model file")
    for package in PACKAGES:
        tested, installed = card["trained_with"][package], version(package)
        if installed != tested:
            raise ModelUnavailable(
                f"{path.name}: {package} {installed} is installed, "
                f"but the model was saved with {tested}"
            )
    if card["features"] != FEATURES:
        raise ModelUnavailable(f"{path.name}: the model expects other features")


def self_check(estimator: HouseEstimator, path: Path) -> None:
    """Gate 5: the parity cases get the estimates that they got at bundling."""
    # Imported here: models.py does not need the estimator, and the self-check
    # must turn each house into model inputs exactly as a request does.
    from house_price_api.models import HouseIn

    cases = json.loads((path / "parity_cases.json").read_text("utf-8"))
    rows = [HouseIn(**case["house"]).model_inputs() for case in cases]
    for case, result in zip(cases, estimator.estimate(rows)):
        expected = case["expected_estimate"]
        if abs(result.value - expected) > TOLERANCE * expected:
            raise ModelUnavailable(
                f"{path.name}: self-check failed for {case['name']}: "
                f"{result.value:.2f} instead of {expected:.2f}"
            )


def load_bundle(path: Path, expected_digest: str) -> HouseEstimator:
    """Check a bundle, then load it. Raise ModelUnavailable if anything is wrong."""
    check_files(path, expected_digest)
    try:
        card = json.loads((path / "model_card.json").read_text("utf-8"))
    except (OSError, ValueError) as error:
        raise ModelUnavailable(f"cannot read model_card.json: {error}") from None
    check_card(path, card)
    # Every byte is the reviewed one. Only now is it safe to load the model:
    # joblib uses pickle, which can run code from the file (gate 4).
    with warnings.catch_warnings():
        warnings.simplefilter("error", InconsistentVersionWarning)
        try:
            model = joblib.load(path / "model.joblib")
        except InconsistentVersionWarning as warning:
            raise ModelUnavailable(
                f"the model was saved with scikit-learn "
                f"{warning.original_sklearn_version}, this server has "
                f"{warning.current_sklearn_version}"
            ) from None
    estimator = HouseEstimator(model, card, file_sha256(path / "SHA256SUMS"))
    self_check(estimator, path)
    return estimator
