# house-price-api

A web API that gives a **first estimate** of the sale price of a house in King County, Washington, with a range and warnings. A valuation team calls it from its intake tool before a human appraisal. The model is gradient boosting, trained on public sales from 2014 and 2015.

**Not for lending, underwriting or insurance decisions.** Read [MODEL_CARD.md](MODEL_CARD.md) first.

This version of the project releases new models safely: each model is a **versioned bundle** with a pinned digest, a candidate runs in the **shadow** on a replay of real requests, a script compares it with the live model, and a **rollback** is one setting. The release history is in [RELEASES.md](RELEASES.md).

## Requirements

- Python 3.12 or newer.
- Docker Desktop (or Docker Engine with Compose) for the container.

## Set up and test

```sh
python3 -m venv .venv                # Windows: python -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\Activate.ps1
python -m pip install -r requirements-lock.txt
python -m pytest
```

## Run

```sh
fastapi dev                          # version kc-hgb-2015-02, http://127.0.0.1:8000/docs
MODEL_VERSION=kc-hgb-2015-03 fastapi dev
```

In a container, with the limits of a small cloud container (1 CPU, 512 MiB, no swap):

```sh
cp .env.example .env                 # then choose IMAGE_TAG, MODEL_VERSION, SHADOW_VERSION
docker compose up -d --build --wait
docker compose down
```

| Variable | Default | Meaning |
|---|---|---|
| `MODEL_VERSION` | `kc-hgb-2015-02` | The live model. It must be in `BUNDLES` in `house_price_api/config.py`. |
| `SHADOW_VERSION` | none | A candidate that estimates every house too. Its estimates go to the log only. |
| `API_KEY` | none | The key that `X-API-Key` must have. Always set it on a server. |
| `SHOW_DOCS` | `true` | `false` hides `/docs`, `/redoc` and `/openapi.json`. |
| `ALLOWED_ORIGINS` | none | Browser origins for CORS, separated by commas. |
| `ESTIMATE_TIMEOUT` | `2.0` | The time limit for the live model, in seconds. |
| `LOG_LEVEL` | `INFO` | The log level. The prediction lines are `INFO`. |
| `BUNDLES_DIR` | `bundles` | The folder with the bundles. |

| Endpoint | Key | Meaning |
|---|---|---|
| `POST /v1/estimates` | `X-API-Key` | Estimate one house |
| `POST /v1/estimates/batch` | `X-API-Key` | Estimate 1 to 100 houses, in order |
| `GET /v1/model` | no | The live model's card |
| `GET /health` | no | Liveness: the process runs |
| `GET /ready` | no | Readiness: the live model is loaded and answers |

Every error has the shape `{"error": {"code", "message", "request_id", "fields"}}`. The contract is `contract/openapi.json`. It is the same for every model version: a new model is not a new contract.

## Bundles

A bundle is a folder `bundles/<version>/` with `model.joblib`, `model_card.json`, `parity_cases.json` and `SHA256SUMS`. Its **digest** is the SHA-256 of `SHA256SUMS`. The service loads a bundle only if its version is in `BUNDLES` in `house_price_api/config.py` with that digest, every file matches `SHA256SUMS`, the card names the installed package versions, and the parity cases give the recorded estimates. joblib files use Python's pickle format, which can run code when it is loaded, so the model file is loaded only after these checks.

## Release a new model

```sh
python training/train.py --until 2015-04-01 --version kc-hgb-2015-03    # the analyst: a candidate
python make_bundle.py candidates/kc-hgb-2015-03                        # prints the digest
# add the version and digest to BUNDLES in house_price_api/config.py, and run the tests
python replay/make_replay.py                                           # the requests and prices of April-May 2015
# .env: SHADOW_VERSION=kc-hgb-2015-03, a new IMAGE_TAG; then docker compose up -d --build --wait
python scripts/replay.py http://127.0.0.1:8000 replay/requests-2015-04-05.jsonl replay/out/answers.csv
docker compose logs --no-log-prefix api > replay/out/service.log
python scripts/compare.py replay/out/answers.csv replay/out/service.log replay/sales-2015-04-05.csv
# decide; to promote: MODEL_VERSION=kc-hgb-2015-03 and SHADOW_VERSION= in .env, then
docker compose up -d --wait
python scripts/check_release.py http://127.0.0.1:8000 kc-hgb-2015-03
```

`replay.py` and `check_release.py` read the key from `HOUSE_API_KEY`. A rollback is the same last two commands with the previous `MODEL_VERSION`. Record every release, rejection and rollback in RELEASES.md.

The golden tests (`tests/golden_houses.json`) and the Postman collection pin the answers of version kc-hgb-2015-02, the version that the tests use. To check a running service with any version, use `scripts/check_release.py`.

## Data and licence

The code is under the MIT licence ([LICENSE](LICENSE)). The data is *House Sales in King County, USA* (harlfoxem, Kaggle 2016; OpenML 42092), CC0 1.0 (public domain). The data is not in this project: `training/train.py` downloads it. `training/simulate_export.py` makes a changed copy of it to show a failure; the real county data never had that change.
