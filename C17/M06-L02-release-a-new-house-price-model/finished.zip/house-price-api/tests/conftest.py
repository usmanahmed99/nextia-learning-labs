import json
from dataclasses import replace
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from house_price_api.config import BUNDLES, PROJECT, Settings
from house_price_api.main import create_app

TEST_SETTINGS = Settings(
    api_key=None,
    allowed_origins=[],
    bundles_dir=PROJECT / "bundles",
    model_version="kc-hgb-2015-02",  # the golden answers in golden_houses.json are this version's
    shadow_version=None,
    reviewed=BUNDLES,
    estimate_timeout=2.0,
    log_level="WARNING",
    show_docs=True,
)

GOLDEN_FILE = Path(__file__).parent / "golden_houses.json"


@pytest.fixture
def make_client():
    """Return a function that makes a test client with changed settings."""

    def make(**changes) -> TestClient:
        return TestClient(create_app(replace(TEST_SETTINGS, **changes)))

    return make


@pytest.fixture
def client(make_client) -> TestClient:
    return make_client()


@pytest.fixture
def house() -> dict:
    """The typical golden house, a new copy for each test."""
    return json.loads(GOLDEN_FILE.read_text("utf-8"))[0]["house"]
