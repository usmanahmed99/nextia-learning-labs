import json
import logging
import shutil
from pathlib import Path

import joblib
import pytest

from house_price_api.config import BUNDLES, PROJECT
from house_price_api.estimator import file_sha256, load_bundle

CONTRACT = PROJECT / "contract" / "openapi.json"
LIVE = "kc-hgb-2015-02"


def assert_not_ready(client):
    """Liveness stays 200; readiness gives 503, without internals."""
    assert client.get("/health").status_code == 200
    response = client.get("/ready")
    assert response.status_code == 503
    assert response.json()["error"]["code"] == "model_unavailable"


def changed_copy(tmp_path: Path, name: str, change) -> str:
    """Copy the live bundle, change one file, write new sums. Return the new digest."""
    folder = tmp_path / LIVE
    shutil.copytree(PROJECT / "bundles" / LIVE, folder)
    path = folder / name
    data = json.loads(path.read_text("utf-8"))
    change(data)
    path.write_text(json.dumps(data, indent=2) + "\n", "utf-8")
    sums = [f"{file_sha256(folder / n)}  {n}" for n in ("model.joblib", "model_card.json", "parity_cases.json")]
    (folder / "SHA256SUMS").write_text("\n".join(sums) + "\n", "utf-8")
    return file_sha256(folder / "SHA256SUMS")


@pytest.fixture
def no_unpickling(monkeypatch):
    """Fail the test if anything calls joblib.load."""

    def refuse(*args, **kwargs):
        raise AssertionError("joblib.load ran before the checks passed")

    monkeypatch.setattr(joblib, "load", refuse)


@pytest.mark.parametrize("version", BUNDLES)
def test_every_reviewed_bundle_loads_and_passes_its_self_check(version):
    path = PROJECT / "bundles" / version
    assert file_sha256(path / "SHA256SUMS") == BUNDLES[version]
    assert load_bundle(path, BUNDLES[version]).version == version


@pytest.mark.parametrize("version", BUNDLES)
def test_a_new_model_is_not_a_new_contract(make_client, version):
    current = json.dumps(make_client(model_version=version).get("/openapi.json").json(), indent=2)
    assert current + "\n" == CONTRACT.read_text("utf-8")


def test_wrong_digest_stops_before_loading(make_client, no_unpickling):
    assert_not_ready(make_client(reviewed={LIVE: "0" * 64}))


def test_unreviewed_version_is_not_loaded(make_client, no_unpickling):
    assert_not_ready(make_client(model_version="kc-hgb-2015-04"))


def test_changed_file_is_not_loaded(make_client, tmp_path, no_unpickling):
    shutil.copytree(PROJECT / "bundles" / LIVE, tmp_path / LIVE)
    with (tmp_path / LIVE / "parity_cases.json").open("a") as file:
        file.write(" ")
    assert_not_ready(make_client(bundles_dir=tmp_path))


def test_other_package_version_is_not_loaded(make_client, tmp_path, no_unpickling):
    def older(card):
        card["trained_with"]["scikit-learn"] = "1.0.0"

    digest = changed_copy(tmp_path, "model_card.json", older)
    assert_not_ready(make_client(bundles_dir=tmp_path, reviewed={LIVE: digest}))


def test_self_check_catches_another_estimate(make_client, tmp_path):
    def one_dollar_more(cases):
        cases[0]["expected_estimate"] += 1

    digest = changed_copy(tmp_path, "parity_cases.json", one_dollar_more)
    assert_not_ready(make_client(bundles_dir=tmp_path, reviewed={LIVE: digest}))


def test_shadow_is_logged_but_never_answers(make_client, house, caplog):
    caplog.set_level(logging.INFO, logger="house_price_api.predictions")
    # Any reviewed version can be the shadow, even the live one.
    client = make_client(shadow_version=LIVE)
    response = client.post("/v1/estimates", json=house)
    assert response.json()["model_version"] == LIVE
    [line] = [r.getMessage() for r in caplog.records if r.name == "house_price_api.predictions"]
    record = json.loads(line)
    assert record["request_id"] == response.headers["X-Request-ID"]
    assert record["model_version"] == LIVE
    assert record["shadow_version"] == LIVE
    assert record["shadow_estimate"] == record["estimate"]


def test_a_broken_shadow_does_not_stop_the_live_model(make_client, house):
    client = make_client(shadow_version="kc-hgb-2015-04")
    assert client.get("/ready").status_code == 200
    assert client.post("/v1/estimates", json=house).json()["model_version"] == LIVE
