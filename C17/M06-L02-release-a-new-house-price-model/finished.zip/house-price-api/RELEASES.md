# Releases of the house-price model

The model registry of this API, kept by hand. Each version is a bundle in
`bundles/` and a line in `BUNDLES` in `house_price_api/config.py`. The
digest is the SHA-256 of the bundle's `SHA256SUMS`. A version is never
changed; a new model gets a new version.

| Version | Bundle digest | Status | Trained with sales to | Image |
|---|---|---|---|---|
| kc-hgb-2015-02 | `29752760649bf79193867d4a5887ee47c361aa913315d831b0e9fafe6f50d1cf` | previous: the rollback target | 2015-02-28 | 1.1.2 |
| kc-hgb-2015-03-rc1 | `10652d2d82d7e619c49756ebb9c5c8f9ec261c73c7df645136c2b4f89f001275` | rejected, retired | 2015-03-31 (new export) | 1.1.1 only |
| kc-hgb-2015-03 | `1ed11041ebcd4ccb751b599269c119d4d1d1978b620ac87e04ccf17c83dca30f` | **live** | 2015-03-31 | 1.1.2 |

## The release checks

Agreed with Hannah Osei (valuation lead) before any shadow run. `scripts/compare.py` runs them on a replay of the 2,819 requests of April and May 2015, with the sale prices that arrived later.

1. **Error:** the candidate's mean absolute error (MAE) on the sale prices is at most 1% above the live model's.
2. **Moves:** at most 5% of estimates change by more than 10%.
3. **Areas:** no zip code (with 10 or more sales) has a median change of more than 5%.
4. **Contract and parity:** the tests pass, and `scripts/check_release.py` passes after the release.
5. **A person** reads the largest moves and explains them.

## Log

### kc-hgb-2015-02: first version (from C16)

- Made into a bundle with `make_bundle.py model`. The model file is C16's reviewed file (`8d0483d05cfc...`).
- Live in image 1.1.0. `check_release.py`: parity 9 of 9, contract equal.

### kc-hgb-2015-03-rc1: rejected

- Trained by the analyst from the county's new export (`county-export-2015-04-01.csv.gz`, SHA-256 `50d99029d343...`, not the reviewed course file). Offline test on April and May: MAPE 13.1%, as good as version 1.
- All 54 tests passed, including its self-check and the contract.
- Shadow in image 1.1.1, 2,817 answered requests: MAE 93,864 USD against 77,300 live (+21.4%); 23.7% of estimates moved by more than 10%; zip code 98092 moved by -11.9%. **All three checks failed.**
- Cause: in the new export, `yr_renovated` holds the build year for a house never renovated. The API sends 0 for "never". So the candidate saw a code at serving time that it never saw in training; newer houses lost the most (median -10.7% for houses built from 2000 that were never renovated).
- Decision: rejected by Hannah Osei. Retired: bundle deleted, its line removed from `BUNDLES`, not in image 1.1.2. `training/train.py` now stops when `yr_renovated` is never 0.

### kc-hgb-2015-03: promoted

- Trained from the reviewed course data with sales to 2015-03-31. Offline test on April and May: MAPE 12.9% (version 1: 13.1%).
- Shadow in image 1.1.2, 2,817 answered requests: MAE 76,960 USD against 77,300 live (-0.4%); 2.9% of estimates moved by more than 10% (82 houses); largest zip code median move 98014: -2.8%. **All three checks passed.** The moves are largest for houses of 1 million USD or more, where both versions are weak: 14.7% of them moved by more than 10%, against 2.2% of the other houses, and four of the five largest moves are such houses. The new version was closer to the sale price for 39 of the 82 houses that moved: about half, so these moves are uncertainty, not a fix.
- Decision: promoted by Hannah Osei. The gain is small; the reason to release is one more month of prices (prices as of 2015-03-31). `MODEL_VERSION=kc-hgb-2015-03`, no shadow.
- `check_release.py` after the promotion: parity 9 of 9, contract equal.

### Rollback drill to kc-hgb-2015-02

- `MODEL_VERSION=kc-hgb-2015-02` in `.env`, then `docker compose up -d --wait`: healthy after 6.4 s. The API gave no answer for about 1.6 s.
- `check_release.py`: version kc-hgb-2015-02, parity 9 of 9, contract equal.
- Back to kc-hgb-2015-03 with the same two steps, and `check_release.py` passed again. The drill showed that the previous version is ready and that one setting brings it back.
