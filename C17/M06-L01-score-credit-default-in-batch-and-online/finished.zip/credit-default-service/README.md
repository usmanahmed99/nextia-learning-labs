# Credit default service

One credit-default model, served two ways from **one versioned bundle**:

- a **monthly batch job** that scores every client in a file
  (`python -m default_risk.batch`), and
- an **online API** that scores one client while a call centre agent waits
  (`POST /v1/score`).

Both paths check each client against the same contract, score with the same
code, and give the same scores on the bundle's parity cases.

This is the finished project of the Nextia Learning case study
*Score credit default in batch and online* (course C17, *Deploying AI Models
for Real Users*).

## Run it (macOS/Linux; Windows PowerShell in the case study)

```sh
python3 -m venv .venv && source .venv/bin/activate
python -m pip install -r requirements.txt
python -m pytest                                          # 37 passed

python scripts/export_month.py data/clients-2005-09.csv   # the monthly file
export MODEL_SHA256=$(python -c "import hashlib; print(hashlib.sha256(open('bundles/default-risk-1.0.0/SHA256SUMS','rb').read()).hexdigest())")
python -m default_risk.batch data/clients-2005-09.csv out/2005-09
fastapi dev                                               # http://127.0.0.1:8000/docs

cp .env.example .env
docker compose up -d --build --wait
docker compose run --rm batch data/clients-2005-09.csv out/2005-09
docker compose run --rm batch bundles/default-risk-1.0.0/parity_cases.csv out/parity
python parity/check_paths.py http://127.0.0.1:8000 bundles/default-risk-1.0.0 out/parity/scores.csv
python bench/bench.py http://127.0.0.1:8000 --requests 1000 --concurrency 1
docker compose down
```

To train the model again and make your own bundle (it gets a new digest):

```sh
python -m training.train
python make_bundle.py --version 1.1.0
```

## The bundle

| Bundle | Digest (`MODEL_SHA256`) |
|---|---|
| `bundles/default-risk-1.0.0` | `078d4b443c1eace7cff6132ea9a0a9df066694f2aa7132900cf7889d5a617078` |

## Licences

Code: MIT (`LICENSE`). Data: CC BY 4.0, with the attribution in
`data/README.md`. Read `MODEL_CARD.md` before you use the scores: the model
is for supportive early-help calls only.

Tested on 2026-10-08 with Python 3.14.6 and Docker Desktop (Docker Engine
29.6.1) on macOS, Apple silicon. The Windows and Linux steps are not tested.
