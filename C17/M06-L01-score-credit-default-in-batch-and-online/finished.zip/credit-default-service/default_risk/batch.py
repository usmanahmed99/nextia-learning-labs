"""The monthly batch job: score every client in a file with the same bundle and contract as the API.

    python -m default_risk.batch data/clients-2005-09.csv out/2005-09

Writes three files into the output folder:

    scores.csv      client_id, score, flag, model_version (one row per good client)
    rejected.csv    row, client_id, problem (one row per client that fails the contract)
    summary.json    what was read and written (with SHA-256 hashes), with which model, and how long it took

A bad row does not stop the job: it is set aside in rejected.csv, and the
other rows are scored. But if more than --max-rejected of the rows are bad,
the file itself is probably broken, so the job fails (exit code 1) and writes
no scores.csv. Every file is written under a temporary name and renamed at
the end, so a reader never sees half a file.
"""

import argparse
import hashlib
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd
from pydantic import ValidationError

from default_risk.bundle import BundleError, load_bundle
from default_risk.contract import FEATURES, ClientIn
from default_risk.scoring import score_clients
from default_risk.settings import SettingsError, load_settings

try:
    import resource  # not on Windows
except ImportError:
    resource = None

COLUMNS = ["client_id"] + FEATURES


def problem(error: ValidationError) -> str:
    first = error.errors()[0]
    where = ".".join(str(p) for p in first["loc"]) or "row"
    return f"{where}: {first['msg']}"


def check_rows(chunk: pd.DataFrame, first_row: int):
    good, bad = [], []
    for offset, row in enumerate(chunk.to_dict("records")):
        values = {k: v for k, v in row.items() if not pd.isna(v)}  # an empty cell is a missing value
        try:
            good.append(ClientIn(**values))
        except ValidationError as error:
            bad.append({"row": first_row + offset, "client_id": values.get("client_id"), "problem": problem(error)})
    return good, bad


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_atomic(path: Path, write) -> None:
    """Write to NAME.partial, then rename: the rename replaces the old file in one step."""
    temporary = path.with_name(path.name + ".partial")
    write(temporary)
    temporary.replace(path)


def peak_memory_mb() -> float | None:
    if resource is None:
        return None
    peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss  # KiB on Linux, bytes on macOS
    return round(peak / (1024 * 1024 if sys.platform == "darwin" else 1024), 1)


def main() -> int:
    parser = argparse.ArgumentParser(description="Score a CSV file of clients.")
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path, help="a folder for scores.csv, rejected.csv and summary.json")
    parser.add_argument("--chunk", type=int, default=5000, help="clients per chunk")
    parser.add_argument("--max-rejected", type=float, default=0.01, help="the largest share of bad rows")
    args = parser.parse_args()

    started_at = datetime.now(timezone.utc)
    started = time.perf_counter()
    try:
        settings = load_settings()
        bundle = load_bundle(settings.model_bundle, settings.model_sha256)
        reader = pd.read_csv(args.input, usecols=COLUMNS, dtype=str, keep_default_na=False,
                             na_values=[""], chunksize=args.chunk)
    except (SettingsError, BundleError, ValueError, OSError) as error:
        print(f"Stopped: {error}", file=sys.stderr)
        return 2
    seconds = {"load": time.perf_counter() - started, "check": 0.0, "score": 0.0}

    scored, rejected, rows = [], [], 0
    for chunk in reader:
        step = time.perf_counter()
        good, bad = check_rows(chunk, first_row=rows + 2)  # row 1 is the header
        seconds["check"] += time.perf_counter() - step
        rows += len(chunk)
        rejected += bad
        if good:
            step = time.perf_counter()
            results, _ = score_clients(bundle, good)
            scored += [{"client_id": c.client_id, "score": r.score, "flag": int(r.flag),
                        "model_version": bundle.version} for c, r in zip(good, results)]
            seconds["score"] += time.perf_counter() - step

    step = time.perf_counter()
    args.output.mkdir(parents=True, exist_ok=True)
    scores = pd.DataFrame(scored, columns=["client_id", "score", "flag", "model_version"])
    rejects = pd.DataFrame(rejected, columns=["row", "client_id", "problem"])
    write_atomic(args.output / "rejected.csv", lambda p: rejects.to_csv(p, index=False))
    failed = rows == 0 or len(rejected) / rows > args.max_rejected
    if not failed:
        write_atomic(args.output / "scores.csv", lambda p: scores.to_csv(p, index=False))
    seconds["write"] = time.perf_counter() - step
    total = time.perf_counter() - started

    summary = {
        "status": "failed: too many rejected rows" if failed else "done",
        "input": str(args.input),
        "input_sha256": sha256(args.input),
        "rows": rows,
        "scored": 0 if failed else len(scores),
        "rejected": len(rejected),
        "flagged": None if failed else int(scores["flag"].sum()),
        "flag_rate": None if failed else round(float(scores["flag"].mean()), 3),
        "model_version": bundle.version,
        "bundle_sha256": bundle.digest,
        "scores_sha256": None if failed else sha256(args.output / "scores.csv"),
        "started_at": started_at.isoformat(timespec="seconds"),
        "seconds": round(total, 2),
        "steps_seconds": {k: round(v, 2) for k, v in seconds.items()},
        "rows_per_second": round(rows / total),
        "peak_memory_mb": peak_memory_mb(),
    }
    write_atomic(args.output / "summary.json",
                 lambda p: p.write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8"))

    if failed:
        print(f"Failed: {len(rejected)} of {rows} rows were rejected (the limit is {args.max_rejected:.0%}). "
              f"No scores.csv was written. See {args.output / 'rejected.csv'}.", file=sys.stderr)
        return 1
    print(f"Read {rows} rows: scored {len(scores)}, rejected {len(rejected)}, flagged {summary['flagged']} "
          f"({summary['flag_rate']}). Model {bundle.version}. {summary['seconds']} s, "
          f"{summary['rows_per_second']} rows/s.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
