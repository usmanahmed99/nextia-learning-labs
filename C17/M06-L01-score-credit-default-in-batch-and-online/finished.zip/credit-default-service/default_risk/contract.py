"""The inference contract: what a client's record must look like before the model scores it.

The model learned from 20 columns. This file gives, for each one, its name,
its type and the values it may take. The ranges are the smallest and largest
values in the 30,000 clients of the data: the model has never seen anything
outside them. The batch job and the API both check clients with these
classes, so the two paths always apply the same rules.
"""

from typing import Annotated

import pandas as pd
from pydantic import BaseModel, ConfigDict, Field

STATUS = [f"PAY_{m}" for m in range(1, 7)]
BILLS = [f"BILL_AMT{m}" for m in range(1, 7)]
PAYMENTS = [f"PAY_AMT{m}" for m in range(1, 7)]
# The order of the columns that the pipeline was fitted on (training/train.py).
FEATURES = ["EDUCATION"] + STATUS + ["LIMIT_BAL"] + BILLS + PAYMENTS

# Repayment status: -1 paid on time, 1 to 8 months late; -2 and 0 are not
# documented (often read as "no use" and "minimum paid"). 9 never occurs.
Status = Annotated[int, Field(ge=-2, le=8)]
# NT dollars. A negative bill means the client paid more than they owed.
Bill = Annotated[int, Field(ge=-339_603, le=1_664_089)]
Payment = Annotated[int, Field(ge=0, le=1_684_259)]


class ClientFeatures(BaseModel):
    """The 20 features of one client, from the last six monthly statements."""

    model_config = ConfigDict(extra="forbid")

    EDUCATION: int = Field(ge=0, le=6, description="1 graduate school, 2 university, 3 high school, 4 others (0, 5, 6 undocumented).")
    PAY_1: Status = Field(description="Repayment status in the last month (September).")
    PAY_2: Status
    PAY_3: Status
    PAY_4: Status
    PAY_5: Status
    PAY_6: Status = Field(description="Repayment status six months ago (April).")
    LIMIT_BAL: int = Field(ge=10_000, le=1_000_000, description="Credit limit in NT dollars.")
    BILL_AMT1: Bill = Field(description="Bill amount in the last month, NT dollars.")
    BILL_AMT2: Bill
    BILL_AMT3: Bill
    BILL_AMT4: Bill
    BILL_AMT5: Bill
    BILL_AMT6: Bill
    PAY_AMT1: Payment = Field(description="Amount paid in the last month, NT dollars.")
    PAY_AMT2: Payment
    PAY_AMT3: Payment
    PAY_AMT4: Payment
    PAY_AMT5: Payment
    PAY_AMT6: Payment


EXAMPLE = {
    "client_id": "C-000002",
    "EDUCATION": 2,
    "PAY_1": -1, "PAY_2": 2, "PAY_3": 0, "PAY_4": 0, "PAY_5": 0, "PAY_6": 2,
    "LIMIT_BAL": 120000,
    "BILL_AMT1": 2682, "BILL_AMT2": 1725, "BILL_AMT3": 2682, "BILL_AMT4": 3272, "BILL_AMT5": 3455, "BILL_AMT6": 3261,
    "PAY_AMT1": 0, "PAY_AMT2": 1000, "PAY_AMT3": 1000, "PAY_AMT4": 1000, "PAY_AMT5": 0, "PAY_AMT6": 2000,
}


class ClientIn(ClientFeatures):
    """A client to score: the client's ID and features."""

    model_config = ConfigDict(extra="forbid", json_schema_extra={"examples": [EXAMPLE]})

    client_id: str = Field(pattern=r"^C-\d{6}$", description="The client's ID, for example C-000002.")


def unseen_values(client: ClientFeatures, known: dict[str, list[int]]) -> list[str]:
    """Warnings for status codes inside the contract that the model never saw for that month.

    They are allowed: the encoder scores them like its group of rare codes.
    But the score is less certain, so the answer says so.
    """
    return [
        f"{name}: {getattr(client, name)} is a value the model never saw"
        for name in STATUS
        if getattr(client, name) not in known[name]
    ]


def to_frame(clients: list[ClientFeatures]) -> pd.DataFrame:
    """The clients as a table with the training columns, in the training order."""
    rows = [c.model_dump(include=set(FEATURES)) for c in clients]
    return pd.DataFrame(rows, columns=FEATURES).astype("int64")
