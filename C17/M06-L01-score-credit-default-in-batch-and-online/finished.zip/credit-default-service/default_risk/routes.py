import json
import logging

from fastapi import APIRouter, Depends, Request, Response
from pydantic import BaseModel, Field

from default_risk.contract import ClientIn
from default_risk.errors import ErrorResponse
from default_risk.scoring import score_clients
from default_risk.security import require_api_key

predictions = logging.getLogger("default_risk.predictions")

router = APIRouter(prefix="/v1", dependencies=[Depends(require_api_key)])

ERRORS = {
    401: {"model": ErrorResponse, "description": "The API key is missing or wrong."},
    422: {"model": ErrorResponse, "description": "The client does not match the contract."},
}


class ScoreOut(BaseModel):
    client_id: str
    score: float = Field(ge=0, le=1, description="0 to 1. Higher means a higher risk of missing the next payment.")
    flag: bool = Field(description="True: offer the client an early-help plan.")
    threshold: float = Field(description="The score at and above which a client is flagged.")
    model_version: str
    warnings: list[str] = Field(description="Values the model never saw. The score is less certain.")


class ModelInfo(BaseModel):
    model_version: str
    bundle_sha256: str
    threshold: float
    trained_at: str
    features: list[str]


@router.post("/score", tags=["scoring"], summary="Score one client now", responses=ERRORS)
def score(client: ClientIn, request: Request, response: Response) -> ScoreOut:
    bundle = request.app.state.bundle
    [result], times = score_clients(bundle, [client])
    response.headers["Server-Timing"] = ", ".join(f"{k};dur={v:.2f}" for k, v in times.items())
    predictions.info(json.dumps({"request_id": request.state.request_id, "client_id": client.client_id,
                                 "model_version": bundle.version, "score": result.score, "flag": result.flag}))
    return ScoreOut(client_id=client.client_id, score=result.score, flag=result.flag,
                    threshold=bundle.threshold, model_version=bundle.version, warnings=result.warnings)


@router.get("/model", tags=["model"], summary="Which model answers, and how to check it")
def model(request: Request) -> ModelInfo:
    bundle = request.app.state.bundle
    return ModelInfo(model_version=bundle.version, bundle_sha256=bundle.digest, threshold=bundle.threshold,
                     trained_at=bundle.metadata["trained_at"], features=bundle.contract["features"])
