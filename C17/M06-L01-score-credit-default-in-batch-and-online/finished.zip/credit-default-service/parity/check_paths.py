"""Compare the two serving paths with training on the bundle's parity cases.

    python parity/check_paths.py http://127.0.0.1:8000 bundles/default-risk-1.0.0 out/parity/scores.csv

The batch scores come from a run of the batch job on the parity cases:

    python -m default_risk.batch bundles/default-risk-1.0.0/parity_cases.csv out/parity

The online scores come from POST /v1/score on the running API. Each must
equal expected_score, the score that training gave the same client, within
the tolerance; so the batch and online scores also equal each other.
"""

import argparse
import json
import os
import sys
import urllib.request
from pathlib import Path

import pandas as pd

TOLERANCE = 1e-9


def online_score(url: str, client: dict, key: str | None) -> float:
    request = urllib.request.Request(
        f"{url}/v1/score",
        data=json.dumps(client).encode(),
        headers={"Content-Type": "application/json", **({"X-API-Key": key} if key else {})},
    )
    with urllib.request.urlopen(request, timeout=10) as response:
        return json.load(response)["score"]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("url")
    parser.add_argument("bundle", type=Path)
    parser.add_argument("batch_scores", type=Path, help="scores.csv of a batch run on the parity cases")
    parser.add_argument("--tolerance", type=float, default=TOLERANCE)
    args = parser.parse_args()

    cases = pd.read_csv(args.bundle / "parity_cases.csv")
    batch = pd.read_csv(args.batch_scores).set_index("client_id")["score"]
    key = os.environ.get("API_KEY")
    failed = 0
    print(f"{'case':9} {'client':9} {'training':>9} {'batch':>9} {'online':>9} {'largest diff':>12}")
    for row in cases.to_dict("records"):
        expected, case = row.pop("expected_score"), row.pop("case")
        online = online_score(args.url, {k: (v.item() if hasattr(v, "item") else v) for k, v in row.items()}, key)
        batch_score = float(batch[row["client_id"]])
        largest = max(abs(batch_score - expected), abs(online - expected), abs(batch_score - online))
        ok = largest <= args.tolerance
        failed += not ok
        print(f"{case:9} {row['client_id']:9} {expected:9.6f} {batch_score:9.6f} {online:9.6f} {largest:12.1e}"
              f"{'' if ok else '  FAIL'}")
    print(f"{len(cases) - failed} of {len(cases)} cases match on both paths within {args.tolerance:g}.")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
