# Credit default service (starter)

The starter project of the Nextia Learning case study *Score credit default
in batch and online* (course C17, *Deploying AI Models for Real Users*).
Follow the case study page: it builds this project into one model bundle
served two ways, a monthly batch job and an online API.

```sh
python3 -m venv .venv && source .venv/bin/activate
python -m pip install -r requirements.txt
python -m pytest              # 3 passed, the rest skipped until you write their parts
```

What is here: the data (`data/`, CC BY 4.0), the training script
(`training/train.py`), the export of the monthly file
(`scripts/export_month.py`), the parts of the service from the course
(`default_risk/`: features, bundle loader, settings, scoring, errors,
security), `make_bundle.py`, the benchmark (`bench/bench.py`) and the
tests. You write `default_risk/contract.py`, `default_risk/batch.py`,
`default_risk/routes.py` and the new `default_risk/main.py`,
`parity/check_paths.py`, the `Dockerfile` and `compose.yaml`.

Code: MIT (`LICENSE`). Data: CC BY 4.0, with the attribution in
`data/README.md`. Read `MODEL_CARD.md`: the model is for supportive
early-help calls only.
