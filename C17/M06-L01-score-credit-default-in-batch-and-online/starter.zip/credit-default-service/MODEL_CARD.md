# Model card: default-risk 1.0.0

**What it does.** Gives a credit-card client a score from 0 to 1: the risk of
missing the next payment. A client with a score of at least **0.17** is
flagged for an **early-help call**: an agent offers a payment plan before the
client falls behind.

**Model.** A scikit-learn pipeline: education codes grouped and one-hot
encoded, six monthly repayment statuses one-hot encoded (rare codes grouped),
13 amounts log-scaled and standardised, then logistic regression. 20 inputs.
`training/train.py` rebuilds it, byte for byte on the same computer and
package versions.

**Data.** UCI *Default of Credit Card Clients* (one bank in Taiwan, 2005;
CC BY 4.0; see `data/README.md`). Sex, marital status and age are **not**
inputs, and the monthly file does not contain them.

**Threshold.** 0.17: the lowest cost on the validation set when a missed
default costs 5 and a false alarm costs 1 (the card-risk team's estimate).

**Results** (random split: train 18,000, validation 6,000, test 6,000; the
test set was used once):

| | ROC AUC | Flagged | Precision | Recall |
|---|---|---|---|---|
| Validation | 0.775 | 39.9% | 0.395 | 0.713 |
| Test | 0.770 | 38.2% | 0.406 | 0.701 |

**Intended use.** Choosing clients for a supportive call, and showing a call
centre agent the same score during a call.

**Not for:** refusing credit, lowering a credit limit, setting a price or an
interest rate, or any judgement of a person. The costs, the threshold and
the fairness checks were made for a supportive call only.

**Known limits.** One bank, one place, 2005, during a period of high card
debt; no time-based test is possible with this data. Young clients are
flagged more often, mostly through their lower credit limits (see the C05
case study *Predict credit-card default*). Undocumented codes: education 0,
5 and 6 (grouped into 4), status -2 and 0.

**Monitoring.** Each batch run writes the flag rate to `summary.json`
(39.0% on the September file). A large change from month to month means the
clients or the export changed: check before the calls start.
