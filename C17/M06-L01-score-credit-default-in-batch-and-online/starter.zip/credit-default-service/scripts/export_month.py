"""Make the monthly file that the batch job scores: the data team's export.

    python scripts/export_month.py data/clients-2005-09.csv

Writes one row per client with client_id and the 20 columns of the model's
contract, and nothing else: no sex, marital status, age or default. The
source names its September status PAY_0; the export calls it PAY_1, as the
model does.

The data has one statement month (September 2005), so this file holds the
same 30,000 clients that the model was trained and tested on. A real monthly
file has new months.

--limit-in-thousands writes LIMIT_BAL in thousands of NT dollars (50000
becomes 50). Use it to see what the batch job does with a changed export.
"""

import argparse
from pathlib import Path

import pandas as pd

SOURCE = Path("data/credit_default_taiwan.csv.gz")
STATUS = [f"PAY_{m}" for m in range(1, 7)]
AMOUNTS = ["LIMIT_BAL"] + [f"BILL_AMT{m}" for m in range(1, 7)] + [f"PAY_AMT{m}" for m in range(1, 7)]
COLUMNS = ["client_id", "EDUCATION"] + STATUS + AMOUNTS


def main() -> None:
    parser = argparse.ArgumentParser(description="Export the monthly file of clients to score.")
    parser.add_argument("output", type=Path)
    parser.add_argument("--limit-in-thousands", action="store_true", help="a changed export: LIMIT_BAL / 1000")
    args = parser.parse_args()

    clients = pd.read_csv(SOURCE).rename(columns={"PAY_0": "PAY_1"})
    clients["client_id"] = [f"C-{n:06d}" for n in clients["ID"]]
    if args.limit_in_thousands:
        clients["LIMIT_BAL"] = clients["LIMIT_BAL"] // 1000
    clients[COLUMNS].to_csv(args.output, index=False)
    print(f"Wrote {args.output}: {len(clients)} clients, {len(COLUMNS)} columns.")


if __name__ == "__main__":
    main()
