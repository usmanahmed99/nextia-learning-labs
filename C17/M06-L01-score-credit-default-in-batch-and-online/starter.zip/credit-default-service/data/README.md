# Data

`credit_default_taiwan.csv.gz` (0.98 MB, SHA-256
`a773cfc32f6759261cebfdfdc4f744bce1b247a583fe7c06363a12702c98f727`): 30,000
credit-card clients of a bank in Taiwan, April to September 2005, and whether
each one missed the payment due in October 2005.

**Licence: CC BY 4.0** (https://creativecommons.org/licenses/by/4.0/). The MIT
licence of this project covers the code only, not this file.

> Data: "Default of Credit Card Clients" by I-Cheng Yeh, UCI Machine Learning
> Repository, https://doi.org/10.24432/C55S3H, licensed under CC BY 4.0.
> Changed by Nextia Learning: converted from XLS to gzip CSV, the first header
> row removed and the target column renamed to `default`.

Citation: Yeh, I.-C., & Lien, C.-H. (2009). The comparisons of data mining
techniques for the predictive accuracy of probability of default of credit
card clients. *Expert Systems with Applications*, 36(2), 2473-2480.

The full dataset card, with the known traps (undocumented codes, `PAY_0` is
September), is in the Nextia Learning labs repository:
https://github.com/usmanahmed99/nextia-learning-labs/blob/main/C05/case-studies/data/credit_default_taiwan.md

Files that the scripts make here (`clients-*.csv`) are not kept in Git.
