import shutil

import pytest

from tests.conftest import BUNDLE, needs_bundle

needs_bundle()
from default_risk import bundle as bundle_module  # noqa: E402
from default_risk.bundle import BundleError, bundle_digest, load_bundle  # noqa: E402


def test_the_bundle_loads_and_passes_its_self_check():
    bundle = load_bundle(BUNDLE, bundle_digest(BUNDLE))
    assert bundle.version == "1.0.0"
    assert bundle.threshold == 0.17


def test_a_wrong_digest_stops_before_loading(monkeypatch):
    def never(*args):
        raise AssertionError("joblib.load ran")

    monkeypatch.setattr(bundle_module.joblib, "load", never)
    with pytest.raises(BundleError, match="MODEL_SHA256 expects"):
        load_bundle(BUNDLE, "0" * 64)


def test_a_changed_file_is_refused(tmp_path):
    copy = tmp_path / "bundle"
    shutil.copytree(BUNDLE, copy)
    digest = bundle_digest(copy)
    with open(copy / "contract.json", "a", encoding="utf-8") as f:
        f.write(" ")
    with pytest.raises(BundleError, match="changed after the bundle was made"):
        load_bundle(copy, digest)


def test_other_features_code_is_refused(monkeypatch):
    real = bundle_module.sha256
    monkeypatch.setattr(bundle_module, "sha256",
                        lambda path: "0" * 64 if path.name == "features.py" else real(path))
    with pytest.raises(BundleError, match="features.py"):
        load_bundle(BUNDLE, bundle_digest(BUNDLE))
