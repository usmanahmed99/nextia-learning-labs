"""Both paths give the training score for every parity case: the batch job and the API."""

import os
import subprocess
import sys

import pandas as pd
import pytest

from tests.conftest import BUNDLE, ROOT, needs_bundle

needs_bundle()
pytest.importorskip("default_risk.batch", reason="written in Part 4")
pytest.importorskip("default_risk.routes", reason="written in Part 5")
from default_risk.bundle import bundle_digest  # noqa: E402

CASES = pd.read_csv(BUNDLE / "parity_cases.csv")


@pytest.fixture(scope="module")
def batch_scores(tmp_path_factory):
    out = tmp_path_factory.mktemp("parity")
    env = {**os.environ, "MODEL_BUNDLE": str(BUNDLE), "MODEL_SHA256": bundle_digest(BUNDLE)}
    subprocess.run([sys.executable, "-m", "default_risk.batch", str(BUNDLE / "parity_cases.csv"), str(out)],
                   check=True, capture_output=True, cwd=ROOT, env=env)
    return pd.read_csv(out / "scores.csv").set_index("client_id")["score"]


@pytest.mark.parametrize("row", CASES.to_dict("records"), ids=lambda r: f"{r['case']}-{r['client_id']}")
def test_both_paths_match_training(client, batch_scores, row):
    expected = row.pop("expected_score")
    row.pop("case")
    online = client.post("/v1/score", json=row).json()["score"]
    assert online == pytest.approx(expected, abs=1e-9)
    assert batch_scores[row["client_id"]] == pytest.approx(expected, abs=1e-9)
