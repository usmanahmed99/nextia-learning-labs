import json
import subprocess
import sys

import pandas as pd
import pytest

from tests.conftest import needs_bundle

needs_bundle()
pytest.importorskip("default_risk.batch", reason="written in Part 4")
from default_risk.contract import EXAMPLE  # noqa: E402


def run_batch(tmp_path, rows):
    source = tmp_path / "clients.csv"
    pd.DataFrame(rows).to_csv(source, index=False)
    out = tmp_path / "out"
    result = subprocess.run([sys.executable, "-m", "default_risk.batch", str(source), str(out)],
                            capture_output=True, text=True)
    return result, out


def clients(n):
    return [{**EXAMPLE, "client_id": f"C-{i:06d}"} for i in range(1, n + 1)]


def test_a_bad_row_is_set_aside(tmp_path):
    rows = clients(200)
    rows[5]["PAY_1"] = "late"
    result, out = run_batch(tmp_path, rows)
    assert result.returncode == 0, result.stderr
    assert len(pd.read_csv(out / "scores.csv")) == 199
    rejected = pd.read_csv(out / "rejected.csv").to_dict("records")
    assert rejected == [{"row": 7, "client_id": "C-000006", "problem": "PAY_1: Input should be a valid integer, "
                                                                       "unable to parse string as an integer"}]
    assert json.loads((out / "summary.json").read_text())["status"] == "done"


def test_too_many_bad_rows_fail_the_job(tmp_path):
    rows = [{**row, "LIMIT_BAL": 50} for row in clients(10)]
    result, out = run_batch(tmp_path, rows)
    assert result.returncode == 1
    assert not (out / "scores.csv").exists()
    assert len(pd.read_csv(out / "rejected.csv")) == 10
    assert not list(out.glob("*.partial"))


def test_the_same_input_gives_the_same_scores(tmp_path):
    first, out = run_batch(tmp_path, clients(50))
    hash_1 = json.loads((out / "summary.json").read_text())["scores_sha256"]
    second, out = run_batch(tmp_path, clients(50))
    assert hash_1 == json.loads((out / "summary.json").read_text())["scores_sha256"]
