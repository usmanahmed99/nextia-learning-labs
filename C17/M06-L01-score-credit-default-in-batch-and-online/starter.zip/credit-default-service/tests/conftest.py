from pathlib import Path

import pytest

ROOT = Path(__file__).parent.parent
BUNDLE = ROOT / "bundles" / "default-risk-1.0.0"


def needs_bundle() -> None:
    """Skip the tests of a file until the bundle exists (Part 3)."""
    if not (BUNDLE / "SHA256SUMS").exists():
        pytest.skip("needs bundles/default-risk-1.0.0 (Part 3)", allow_module_level=True)


@pytest.fixture(autouse=True)
def settings_env(monkeypatch):
    monkeypatch.chdir(ROOT)
    monkeypatch.delenv("API_KEY", raising=False)
    if (BUNDLE / "SHA256SUMS").exists():
        from default_risk.bundle import bundle_digest

        monkeypatch.setenv("MODEL_BUNDLE", str(BUNDLE))
        monkeypatch.setenv("MODEL_SHA256", bundle_digest(BUNDLE))


@pytest.fixture
def client():
    from fastapi.testclient import TestClient

    from default_risk.main import create_app

    with TestClient(create_app()) as test_client:
        yield test_client


@pytest.fixture
def example():
    from default_risk.contract import EXAMPLE

    return dict(EXAMPLE)
