import pytest
from pydantic import ValidationError

contract = pytest.importorskip("default_risk.contract", reason="written in Part 2")
ClientIn, unseen_values = contract.ClientIn, contract.unseen_values

KNOWN = {f"PAY_{m}": [-2, -1, 0, 1, 2] for m in range(1, 5)} | {"PAY_5": [-2, -1, 0, 2], "PAY_6": [-2, -1, 0, 2]}


def test_the_example_is_accepted(example):
    assert ClientIn(**example).LIMIT_BAL == 120000


@pytest.mark.parametrize("name, value", [("LIMIT_BAL", 120), ("PAY_1", 9), ("EDUCATION", 7),
                                         ("BILL_AMT1", 2_000_000), ("PAY_AMT1", -1), ("client_id", "42")])
def test_values_outside_the_contract_are_rejected(example, name, value):
    with pytest.raises(ValidationError) as error:
        ClientIn(**{**example, name: value})
    assert error.value.errors()[0]["loc"] == (name,)


def test_a_missing_or_null_feature_is_rejected(example):
    without = {k: v for k, v in example.items() if k != "PAY_AMT1"}
    with pytest.raises(ValidationError):
        ClientIn(**without)
    with pytest.raises(ValidationError):
        ClientIn(**{**example, "PAY_AMT1": None})


def test_personal_data_is_not_accepted(example):
    with pytest.raises(ValidationError):
        ClientIn(**{**example, "AGE": 35})


def test_a_status_code_never_seen_gives_a_warning(example):
    client = ClientIn(**{**example, "PAY_5": 1})
    assert unseen_values(client, KNOWN) == ["PAY_5: 1 is a value the model never saw"]
