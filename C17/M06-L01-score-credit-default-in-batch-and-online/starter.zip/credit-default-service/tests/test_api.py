import pytest

from tests.conftest import needs_bundle

needs_bundle()
pytest.importorskip("default_risk.routes", reason="written in Part 5")


def test_score_answers_with_the_model_version(client, example):
    response = client.post("/v1/score", json=example)
    assert response.status_code == 200
    body = response.json()
    assert body["client_id"] == "C-000002"
    assert body["model_version"] == "1.0.0"
    assert body["threshold"] == 0.17
    assert body["flag"] is (body["score"] >= 0.17)
    assert body["warnings"] == []


def test_an_unseen_code_is_scored_with_a_warning(client, example):
    body = client.post("/v1/score", json={**example, "PAY_5": 1}).json()
    assert body["warnings"] == ["PAY_5: 1 is a value the model never saw"]


def test_a_client_outside_the_contract_gets_the_error_shape(client, example):
    response = client.post("/v1/score", json={**example, "LIMIT_BAL": 120, "PAY_1": "late"})
    assert response.status_code == 422
    error = response.json()["error"]
    assert error["code"] == "invalid_client"
    assert error["fields"] == ["LIMIT_BAL", "PAY_1"]


def test_the_api_key_is_required_when_set(monkeypatch, example):
    from fastapi.testclient import TestClient

    from default_risk.main import create_app

    monkeypatch.setenv("API_KEY", "test-key")
    with TestClient(create_app()) as keyed:
        assert keyed.post("/v1/score", json=example).status_code == 401
        assert keyed.post("/v1/score", json=example, headers={"X-API-Key": "test-key"}).status_code == 200


def test_ready_and_model(client):
    assert client.get("/ready").json() == {"status": "ready", "model_version": "1.0.0"}
    info = client.get("/v1/model").json()
    assert info["threshold"] == 0.17
    assert len(info["features"]) == 20
