import numpy as np

from default_risk.features import group_education, signed_log


def test_signed_log_keeps_the_sign():
    assert list(signed_log(np.array([-99.0, 0.0, 99.0]))) == [-np.log(100), 0.0, np.log(100)]


def test_undocumented_education_codes_become_others():
    assert list(group_education(np.array([0, 1, 2, 3, 4, 5, 6]))) == [4, 1, 2, 3, 4, 4, 4]
