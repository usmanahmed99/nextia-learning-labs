"""Train the credit-default model (the idea of the C05 case study) and save it to model/.

    python -m training.train

Reads data/credit_default_taiwan.csv.gz (UCI, CC BY 4.0; see data/README.md),
splits the 30,000 clients into train (18,000), validation (6,000) and test
(6,000), fits a scikit-learn pipeline on train, chooses the threshold with the
lowest cost on validation (a missed default costs 5, a false alarm 1), and
scores the test set once. Writes:

    model/model.joblib      the fitted pipeline (preprocessing + logistic regression)
    model/model_info.json   the threshold, the results and the package versions
"""

import hashlib
import json
import platform
from datetime import datetime, timezone
from importlib.metadata import version
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score, roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import FunctionTransformer, OneHotEncoder, StandardScaler

from default_risk.features import group_education, signed_log

DATA = Path("data/credit_default_taiwan.csv.gz")
DATA_SHA256 = "a773cfc32f6759261cebfdfdc4f744bce1b247a583fe7c06363a12702c98f727"
OUT = Path("model")

STATUS = [f"PAY_{m}" for m in range(1, 7)]  # repayment status, September (1) to April (6)
AMOUNTS = ["LIMIT_BAL"] + [f"BILL_AMT{m}" for m in range(1, 7)] + [f"PAY_AMT{m}" for m in range(1, 7)]
FEATURES = ["EDUCATION"] + STATUS + AMOUNTS
TARGET = "default"
MISS_COST, ALARM_COST = 5, 1


def build_pipeline() -> Pipeline:
    """Codes one-hot (rare codes grouped), amounts log-scaled and standardised, then logistic regression."""
    prepare = ColumnTransformer([
        ("education", Pipeline([
            ("group", FunctionTransformer(group_education, feature_names_out="one-to-one")),
            ("onehot", OneHotEncoder(handle_unknown="infrequent_if_exist", min_frequency=50)),
        ]), ["EDUCATION"]),
        ("status", OneHotEncoder(handle_unknown="infrequent_if_exist", min_frequency=50), STATUS),
        ("amounts", Pipeline([
            ("log", FunctionTransformer(signed_log, feature_names_out="one-to-one")),
            ("scale", StandardScaler()),
        ]), AMOUNTS),
    ])
    return Pipeline([("prepare", prepare), ("model", LogisticRegression(max_iter=2000))])


def results(y, scores, threshold: float) -> dict:
    y, flags = np.asarray(y, dtype=bool), scores >= threshold
    caught, alarms = int((flags & y).sum()), int((flags & ~y).sum())
    return {
        "clients": len(y),
        "roc_auc": round(roc_auc_score(y, scores), 3),
        "average_precision": round(average_precision_score(y, scores), 3),
        "flag_rate": round(float(flags.mean()), 3),
        "precision": round(caught / max(int(flags.sum()), 1), 3),
        "recall": round(caught / int(y.sum()), 3),
    }


def cost(y, flags) -> int:
    y = np.asarray(y, dtype=bool)
    return MISS_COST * int((~flags & y).sum()) + ALARM_COST * int((flags & ~y).sum())


def main() -> None:
    if hashlib.sha256(DATA.read_bytes()).hexdigest() != DATA_SHA256:
        raise SystemExit(f"{DATA} is not the expected file: its SHA-256 differs.")
    clients = pd.read_csv(DATA).rename(columns={"PAY_0": "PAY_1"})  # PAY_0 is September

    rest, test = train_test_split(clients, test_size=0.2, stratify=clients[TARGET], random_state=0)
    train, valid = train_test_split(rest, test_size=0.25, stratify=rest[TARGET], random_state=0)

    pipeline = build_pipeline().fit(train[FEATURES], train[TARGET])

    valid_scores = pipeline.predict_proba(valid[FEATURES])[:, 1]
    thresholds = np.round(np.arange(0.01, 1.0, 0.01), 2)
    costs = [cost(valid[TARGET], valid_scores >= t) for t in thresholds]
    threshold = float(thresholds[int(np.argmin(costs))])

    test_scores = pipeline.predict_proba(test[FEATURES])[:, 1]  # the test set, used once

    OUT.mkdir(exist_ok=True)
    joblib.dump(pipeline, OUT / "model.joblib")
    info = {
        "model": "Credit default: logistic regression on 20 features (C05 case study idea)",
        "trained_at": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"),
        "data_sha256": DATA_SHA256,
        "train_rows": len(train),
        "features": FEATURES,
        "threshold": threshold,
        "decision": "Call the client for an early-help call if score >= threshold.",
        "costs": {"missed_default": MISS_COST, "false_alarm": ALARM_COST},
        "valid": results(valid[TARGET], valid_scores, threshold),
        "test": results(test[TARGET], test_scores, threshold),
        "versions": {"python": platform.python_version(),
                     **{p: version(p) for p in ["scikit-learn", "numpy", "pandas", "joblib"]}},
    }
    (OUT / "model_info.json").write_text(json.dumps(info, indent=2) + "\n", encoding="utf-8")

    v, t = info["valid"], info["test"]
    print(f"Trained on {len(train)} clients. Threshold {threshold} (the lowest cost on validation).")
    print(f"Valid: ROC AUC {v['roc_auc']:.3f}, flagged {v['flag_rate']:.1%}, precision {v['precision']}, recall {v['recall']}.")
    print(f"Test:  ROC AUC {t['roc_auc']:.3f}, flagged {t['flag_rate']:.1%}, precision {t['precision']}, recall {t['recall']}.")


if __name__ == "__main__":
    main()
