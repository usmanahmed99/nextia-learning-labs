"""Send clients to a running API and measure how long each answer takes.

    python bench/bench.py http://127.0.0.1:8000 --requests 1000 --concurrency 1

The workload is fixed, so two runs can be compared: the clients of
data/clients-2005-09.csv, in file order, one client per request. The first
--warmup requests are sent but not measured. Prints p50, p95, p99 and the
throughput. --raw FILE also writes every measured time, in milliseconds.
"""

import argparse
import json
import os
import statistics
import time
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import pandas as pd


def load_clients(path: Path, n: int) -> list[bytes]:
    rows = pd.read_csv(path, nrows=n).to_dict("records")
    return [json.dumps({k: (v.item() if hasattr(v, "item") else v) for k, v in row.items()}).encode() for row in rows]


def percentile(values: list[float], p: int) -> float:
    return statistics.quantiles(values, n=100, method="inclusive")[p - 1]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("url")
    parser.add_argument("--requests", type=int, default=1000)
    parser.add_argument("--concurrency", type=int, default=1)
    parser.add_argument("--warmup", type=int, default=50)
    parser.add_argument("--clients", type=Path, default=Path("data/clients-2005-09.csv"))
    parser.add_argument("--raw", type=Path, help="write every measured time (ms) to this JSON file")
    args = parser.parse_args()

    bodies = load_clients(args.clients, args.warmup + args.requests)
    headers = {"Content-Type": "application/json"}
    if os.environ.get("API_KEY"):
        headers["X-API-Key"] = os.environ["API_KEY"]

    def send(i: int) -> tuple[float, int]:
        request = urllib.request.Request(f"{args.url}/v1/score", data=bodies[i % len(bodies)], headers=headers)
        started = time.perf_counter()
        try:
            with urllib.request.urlopen(request, timeout=30) as response:
                response.read()
                status = response.status
        except urllib.error.HTTPError as error:
            status = error.code
        except OSError:
            status = 0
        return (time.perf_counter() - started) * 1000, status

    for i in range(args.warmup):
        send(i)
    started = time.perf_counter()
    with ThreadPoolExecutor(max_workers=args.concurrency) as pool:
        results = list(pool.map(send, range(args.warmup, args.warmup + args.requests)))
    seconds = time.perf_counter() - started

    ms = [r[0] for r in results if r[1] == 200]
    errors = len(results) - len(ms)
    print(f"{args.requests} requests, concurrency {args.concurrency}: p50 {percentile(ms, 50):.1f} ms, "
          f"p95 {percentile(ms, 95):.1f} ms, p99 {percentile(ms, 99):.1f} ms, max {max(ms):.1f} ms, "
          f"{args.requests / seconds:.0f} requests/s, {errors} errors.")
    if args.raw:
        args.raw.write_text(json.dumps([round(m, 3) for m in ms]) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
