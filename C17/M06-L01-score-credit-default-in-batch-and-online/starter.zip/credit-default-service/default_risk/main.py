"""The online path. For now it only answers /health: Part 5 replaces this file."""

from fastapi import FastAPI


def create_app() -> FastAPI:
    app = FastAPI(title="Credit Default Service", version="1.0.0")

    @app.get("/health", tags=["health"])
    def health() -> dict:
        return {"status": "ok"}

    return app


app = create_app()
