"""Two functions that the model's pipeline calls when it prepares a client.

joblib saves the pipeline with the *names* of these functions, not their code.
So the service must have this file, unchanged, wherever it loads the model.
The bundle records the SHA-256 of this file, and the loader checks it.
"""

import numpy as np

# The source documents education codes 1 to 4. The codes 0, 5 and 6 are in
# the data but not documented, so the pipeline puts them into 4 (others).
UNDOCUMENTED_EDUCATION = [0, 5, 6]


def signed_log(values):
    """log(1 + |x|) with the sign of x: it shrinks large amounts and keeps negative bills negative."""
    return np.sign(values) * np.log1p(np.abs(values))


def group_education(values):
    """Education codes 0, 5 and 6 become 4 (others)."""
    values = np.asarray(values)
    return np.where(np.isin(values, UNDOCUMENTED_EDUCATION), 4, values)
