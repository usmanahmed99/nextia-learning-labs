"""Settings from environment variables. A wrong setting stops the job or the service at start."""

import os
from dataclasses import dataclass, field
from pathlib import Path


class SettingsError(Exception):
    """A required setting is missing or not valid."""


@dataclass(frozen=True)
class Settings:
    model_bundle: Path
    model_sha256: str
    api_key: str | None = field(repr=False)
    log_level: str = "INFO"
    show_docs: bool = True


def load_settings() -> Settings:
    env = os.environ
    sha = env.get("MODEL_SHA256", "").strip().lower()
    if len(sha) != 64:
        raise SettingsError("MODEL_SHA256 must be the 64-character digest of the bundle")
    return Settings(
        model_bundle=Path(env.get("MODEL_BUNDLE", "bundles/default-risk-1.0.0")),
        model_sha256=sha,
        api_key=env.get("API_KEY") or None,
        log_level=env.get("LOG_LEVEL", "INFO").upper(),
        show_docs=env.get("SHOW_DOCS", "true").lower() == "true",
    )
