"""Score clients with a loaded bundle. The batch job and the API both use this.

The work of each call is split into three timed steps:

    frame     the checked clients -> a table with the training columns
    prepare   the pipeline's preprocessing (group, one-hot, log, scale)
    model     the logistic regression's score
"""

import time
from dataclasses import dataclass

from default_risk.bundle import Bundle
from default_risk.contract import ClientFeatures, to_frame, unseen_values


@dataclass
class Result:
    score: float
    flag: bool
    warnings: list[str]


def score_clients(bundle: Bundle, clients: list[ClientFeatures]) -> tuple[list[Result], dict[str, float]]:
    """Scores for the clients, in order, and the milliseconds of each step."""
    times = {}
    started = time.perf_counter()
    frame = to_frame(clients)
    times["frame"], started = (time.perf_counter() - started) * 1000, time.perf_counter()
    prepared = bundle.pipeline[:-1].transform(frame)
    times["prepare"], started = (time.perf_counter() - started) * 1000, time.perf_counter()
    scores = bundle.pipeline[-1].predict_proba(prepared)[:, 1]
    times["model"] = (time.perf_counter() - started) * 1000
    results = [
        Result(float(score), bool(score >= bundle.threshold), unseen_values(client, bundle.known))
        for client, score in zip(clients, scores)
    ]
    return results, times
