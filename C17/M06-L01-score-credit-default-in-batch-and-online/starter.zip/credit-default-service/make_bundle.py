"""Make a model bundle from the trained model in model/.

    python make_bundle.py --version 1.0.0

Reads model/model.joblib and model/model_info.json (from training/train.py)
and data/clients-2005-09.csv (for the normal parity cases), and writes
bundles/default-risk-<version>/ with the model, its contract, its metadata,
the parity cases and SHA256SUMS. It prints the bundle digest: give it to the
batch job and the API as MODEL_SHA256.

Run it only on a model that you trained yourself: it loads the joblib file,
and loading can run code.
"""

import argparse
import json
import shutil
import sys
from importlib.metadata import version
from pathlib import Path

import joblib
import pandas as pd

from default_risk import features
from default_risk.bundle import FILES, PACKAGES, bundle_digest, sha256
from default_risk.contract import EXAMPLE, FEATURES, STATUS, ClientFeatures

LOW, HIGH = {}, {}
for name, rules in ClientFeatures.model_json_schema()["properties"].items():
    LOW[name], HIGH[name] = rules["minimum"], rules["maximum"]

# Fixed clients that every copy of the model must score the same way.
BASE = {k: v for k, v in EXAMPLE.items() if k != "client_id"}
EDGE_CASES = [
    ("odd code", "C-900001", dict(EDUCATION=5)),
    ("odd code", "C-900002", dict(EDUCATION=0, **{c: 0 for c in FEATURES if c.startswith(("BILL", "PAY_AMT"))},
                                  **{s: -2 for s in STATUS})),
    ("extreme", "C-900003", {c: LOW[c] if c != "EDUCATION" else 1 for c in FEATURES}),
    ("extreme", "C-900004", {c: HIGH[c] if c != "EDUCATION" else 1 for c in FEATURES}),
    ("extreme", "C-900005", dict(BILL_AMT1=-2000)),
    ("unseen", "C-900006", dict(PAY_5=1, PAY_6=1)),
]


def parity_cases(monthly: Path) -> pd.DataFrame:
    normal = pd.read_csv(monthly).head(6)
    rows = [{"case": "normal", **row} for row in normal[["client_id"] + FEATURES].to_dict("records")]
    rows += [{"case": case, "client_id": cid, **{**BASE, **change}} for case, cid, change in EDGE_CASES]
    cases = pd.DataFrame(rows, columns=["case", "client_id"] + FEATURES)
    for row in cases[FEATURES].to_dict("records"):  # every case must pass the contract
        ClientFeatures(**row)
    return cases


def main():
    parser = argparse.ArgumentParser(description="Make a model bundle from model/.")
    parser.add_argument("--version", required=True, help="the model version, for example 1.0.0")
    parser.add_argument("--monthly", type=Path, default=Path("data/clients-2005-09.csv"))
    args = parser.parse_args()

    source = Path("model")
    info = json.loads((source / "model_info.json").read_text(encoding="utf-8"))
    pipeline = joblib.load(source / "model.joblib")
    if list(pipeline.feature_names_in_) != FEATURES:
        sys.exit("Stopped: the model was trained on other features than the contract lists.")
    installed = {p: version(p) for p in PACKAGES}
    trained = {p: info["versions"][p] for p in PACKAGES}
    if trained != installed:
        sys.exit(f"Stopped: the model was trained with {trained}, but this environment has {installed}.")

    out = Path("bundles") / f"default-risk-{args.version}"
    if out.exists():
        sys.exit(f"Stopped: {out} exists. A version is never changed: choose a new version.")
    out.mkdir(parents=True)

    shutil.copyfile(source / "model.joblib", out / "model.joblib")

    cases = parity_cases(args.monthly)
    cases["expected_score"] = pipeline.predict_proba(cases[FEATURES])[:, 1]
    cases.to_csv(out / "parity_cases.csv", index=False)

    status_encoder = pipeline.named_steps["prepare"].named_transformers_["status"]
    contract = {
        "model": "default-risk",
        "model_version": args.version,
        "unit": "one credit-card client, after the monthly statement",
        "features": FEATURES,
        "schema": ClientFeatures.model_json_schema(),
        "known_values": {name: [int(v) for v in values]
                         for name, values in zip(STATUS, status_encoder.categories_)},
        "missing_values": "none: every feature is required and may not be null",
        "undocumented_codes": "EDUCATION 0, 5 and 6 are scored as 4 (others) by the pipeline",
        "unseen_values": "a status code inside the range that the model never saw for that month: "
                         "allowed, scored with the rare codes, reported as a warning",
        "output": {
            "score": "0 to 1; a higher score means a higher risk of missing the next payment",
            "flag": "true if score >= threshold",
            "threshold": info["threshold"],
            "decision": info["decision"],
        },
    }
    (out / "contract.json").write_text(json.dumps(contract, indent=2) + "\n", encoding="utf-8")

    metadata = {
        "model_version": args.version,
        "description": info["model"],
        "trained_at": info["trained_at"],
        "train_rows": info["train_rows"],
        "data_sha256": info["data_sha256"],
        "costs": info["costs"],
        "valid": info["valid"],
        "test": info["test"],
        "python": info["versions"]["python"],
        "versions": installed,
        "features_py_sha256": sha256(Path(features.__file__)),
    }
    (out / "metadata.json").write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")

    lines = [f"{sha256(out / name)}  {name}" for name in FILES]
    (out / "SHA256SUMS").write_text("\n".join(lines) + "\n", encoding="utf-8")

    print(f"Made {out}: {len(cases)} parity cases, threshold {info['threshold']}.")
    print(f"Bundle digest (MODEL_SHA256): {bundle_digest(out)}")


if __name__ == "__main__":
    main()
