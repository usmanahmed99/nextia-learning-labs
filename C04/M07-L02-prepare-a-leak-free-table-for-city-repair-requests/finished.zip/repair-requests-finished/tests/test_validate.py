"""Tests of the validation rules. Each test starts from a tiny table that
keeps the contract, breaks one rule, and checks that the rule notices.

    python -m pytest
"""

import io

import pandas as pd
import pytest

import validate as v


def as_text(df):
    """Write a table to CSV and read it back the way validate.load() does."""
    return pd.read_csv(io.StringIO(df.to_csv(index=False)), dtype=str, keep_default_na=False, na_values=[""])


@pytest.fixture
def table():
    """12 requests that keep the contract: 4 per split, 1 of each 4 late (25%)."""
    created = ["2024-02-01 08:00:00", "2024-05-01 09:30:00", "2024-08-01 10:00:00", "2024-12-31 23:00:00",
               "2025-01-02 07:00:00", "2025-02-01 12:00:00", "2025-03-01 13:00:00", "2025-03-31 22:10:00",
               "2025-04-01 00:00:00", "2025-05-01 14:00:00", "2025-06-01 15:00:00", "2025-06-16 23:47:00"]
    return pd.DataFrame({
        "request_id": range(60000001, 60000013),
        "created_at": created,
        "complaint_type": ["Street Condition"] * 12,
        "descriptor": ["Pothole"] * 12,
        "location_type": ["unknown"] * 12,
        "borough": ["QUEENS", "BRONX", "unknown", "MANHATTAN"] * 3,
        "channel": ["PHONE", "ONLINE", "unknown", "MOBILE"] * 3,
        "created_hour": [int(t[11:13]) for t in created],
        "created_weekday": [pd.Timestamp(t).weekday() for t in created],
        "batch_time": [0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0],
        "has_location": [1, 1, 0, 1] * 3,
        "prior_same_place_30d": [0, 2, None, 1] * 3,
        "late_14d": [1, 0, 0, 0] * 3,
    })


def parts_of(df):
    return {"train": df.iloc[0:4], "valid": df.iloc[4:8], "test": df.iloc[8:12]}


def failed_rules(df):
    raw = as_text(df)
    results = v.check_table(raw)
    if all(not problems for _, problems in results):
        results += v.check_splits(raw, {name: as_text(part) for name, part in parts_of(df).items()})
    return {name: problems for name, problems in results if problems}


def test_the_tiny_table_keeps_the_contract(table):
    assert failed_rules(table) == {}


def test_a_missing_column_fails(table):
    failed = failed_rules(table.drop(columns="channel"))
    assert failed["required columns are present"] == ["missing column: channel"]


def test_a_leaky_column_fails(table):
    failed = failed_rules(table.assign(status="Closed"))
    assert "status must not be in the dataset" in failed["no column that is known only after creation"][0]


def test_a_value_of_the_wrong_type_fails(table):
    table["created_hour"] = table["created_hour"].astype(object)
    table.loc[3, "created_hour"] = "late evening"
    assert "created_hour: not a valid integer in 1 row" in failed_rules(table)["every value has its column's type"][0]


def test_a_missing_required_value_fails(table):
    table["borough"] = table["borough"].astype(object)
    table.loc[0, "borough"] = None
    assert failed_rules(table)["no missing values in required columns"] == ["borough: missing in 1 row"]


def test_a_repeated_key_fails(table):
    table.loc[1, "request_id"] = table.loc[0, "request_id"]
    assert "1 key repeated" in failed_rules(table)["request_id is unique"][0]


def test_an_unknown_category_fails(table):
    table.loc[0, "borough"] = "Unspecified"
    assert "['Unspecified']" in failed_rules(table)["categories use allowed values only"][0]


def test_a_value_out_of_range_fails(table):
    table.loc[0, "created_hour"] = 24
    assert "created_hour: outside 0 to 23" in failed_rules(table)["numbers and dates are in their allowed ranges"][0]


def test_a_request_without_a_final_target_fails(table):
    table.loc[11, "created_at"] = "2025-06-20 10:00:00"  # less than 14 days before the snapshot
    problems = failed_rules(table)["numbers and dates are in their allowed ranges"]
    assert "created_at: outside" in problems[0]


def test_a_count_without_a_location_fails(table):
    table.loc[2, "prior_same_place_30d"] = 0  # has_location is 0 in this row
    assert "must be missing exactly when has_location = 0" in \
        failed_rules(table)["missing values only where the contract allows them"][0]


def test_a_target_that_is_not_0_or_1_fails(table):
    table.loc[0, "late_14d"] = 2
    assert "late_14d: values not allowed" in failed_rules(table)["categories use allowed values only"][0]


def test_splits_that_share_a_request_fail():
    df = as_text(pd.DataFrame({"request_id": [1, 2, 3], "created_at": ["2024-02-01 00:00:00"] * 3}))
    parts = {"train": df.iloc[0:2], "valid": df.iloc[1:3]}
    assert v.no_key_in_two_splits(parts) == ["train and valid share 1 key (first: 2)"]


def test_splits_out_of_time_order_fail():
    df = as_text(pd.DataFrame({"request_id": [1, 2], "created_at": ["2025-02-01 00:00:00", "2025-01-01 00:00:00"]}))
    parts = {"train": df.iloc[0:1], "valid": df.iloc[1:2]}
    assert "train ends at 2025-02-01" in v.splits_in_time_order(parts)[0]


def test_a_late_rate_out_of_range_fails(table):
    table["late_14d"] = [1, 1, 0, 0] * 3  # 50% late
    problems = failed_rules(table)["late rate between 5% and 30%"]
    assert problems[0] == "all rows: late rate 50.0% is outside 5% to 30%"
