# A leak-free table for NYC street-repair requests

A repeatable pipeline that turns 315,424 real NYC 311 requests to the Department of Transportation (January 2024 to June 2025) into a documented, validated modelling table. The question behind it: **when a request is created, will it still be open 14 days later?** About 13.7% are.

The table contains only facts that exist at the moment a request is created. A time split, 13 validation rules with tests, and a manifest with checksums make it safe to reuse. The pipeline also writes a clean SQLite database for dashboards and APIs.

## Data and licence

- Source: [311 Service Requests from 2020 to Present](https://data.cityofnewyork.us/Social-Services/311-Service-Requests-from-2020-to-Present/erm2-nwe9), NYC Open Data, agency DOT, created 2024-01-01 to 2025-06-30, pulled on 2026-10-07.
- Terms: NYC Open Data has no restrictions on use. The source, the version and the changes are in [DATASET.md](DATASET.md).
- Code: MIT licence ([LICENSE](LICENSE)).

## Approach

1. **Profile in SQL** (`queries/01` to `12`): 392 repeated submissions, 1,482 requests closed before they were created, placeholders such as `Unspecified` and `UNKNOWN`, 1,908 requests at exactly 07:00:00, mis-encoded text, and statuses that disagree with the closing time.
2. **Extract** with a parameterised query and a manifest (`scripts/extract.py`).
3. **Clean** with counted decisions and a quarantine (`scripts/clean.py`, `reports/cleaning.json`).
4. **Frame the target** `late_14d` at creation time. Only requests created at least 14 days before the snapshot get a target. Features use only earlier rows, for example `prior_same_place_30d`, computed with a SQL window frame that ends one second before the request (`scripts/build_features.py`).
5. **Split by time:** train 2024-02 to 2024-12, valid 2025-01 to 2025-03, test 2025-04 to 2025-06-16 (`scripts/split.py`).
6. **Validate** against a written contract, with tests for every rule (`scripts/validate.py`, `scripts/contract.py`, `tests/`).
7. **Deliver** with one command, checksums and a dataset card (`run_pipeline.py`, `data/model/MANIFEST.json`, `DATASET.md`).

## Results

| Part | Rows | Late |
|---|---|---|
| train | 186,339 | 13.9% |
| valid | 53,156 | 11.1% |
| test | 47,138 | 15.7% |

Leak check on the validation set (`scripts/leak_check.py`, logistic regression, ROC AUC):

| Features | ROC AUC |
|---|---|
| Type of problem only | 0.812 |
| All honest features | 0.816 |
| + `status` (leak) | 0.863 |
| + `resolution_description` (leak) | 0.865 |

The leaky columns add more to the score than all the honest features together. In real use they do not exist when the request is created, so that score would be false.

## How to run

```sh
python3 -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python get_data.py                 # downloads the frozen file, builds nyc311.db
python run_pipeline.py             # 15 to 30 seconds
python -m pytest                   # the tests of the validation rules
python scripts/leak_check.py       # optional: the leak check
```

## Project layout

```text
get_data.py         downloads the frozen file and builds nyc311.db
q.py                runs a .sql file and prints a table
run_pipeline.py     runs every step and writes data/model/MANIFEST.json
queries/            the profile queries and the SQL that the scripts use
scripts/            extract, clean, build_db, build_features, split, contract, validate, leak_check
tests/              tests of the validation rules
reports/            cleaning.json, validation.json, leak_check.json
DATASET.md          the dataset card
```

## Limits

- The target says whether the record was closed in time, not whether the street was repaired.
- The late rate changes with the season; one validation period is not enough to judge a model.
- 57.8% of the requests have no channel and 14.8% of the clean requests have no coordinates.
- The city updates the source every day; a fresh pull (`python get_data.py --fresh`) gives other numbers.

Made in the Nextia Learning case study "Prepare a leak-free table for city repair requests" (C04 SQL and Data Preparation for AI).
