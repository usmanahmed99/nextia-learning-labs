"""Run the whole preparation, in order, from nyc311.db to a validated
dataset. Stop at the first step that fails. At the end, write
data/model/MANIFEST.json with a SHA-256 checksum of every output file.

    python get_data.py        once: build nyc311.db from the frozen file
    python run_pipeline.py    every time: delete the old outputs and make them again
"""

import csv
import hashlib
import json
import shutil
import sqlite3
import subprocess
import sys
from datetime import datetime, timezone
from importlib.metadata import version
from pathlib import Path

STEPS = [
    "scripts/extract.py",
    "scripts/clean.py",
    "scripts/build_db.py",
    "scripts/build_features.py",
    "scripts/split.py",
    "scripts/validate.py",
]
# Folders that only the pipeline writes. They are deleted before a run, so an
# old file can never look like the output of this run.
OUTPUT_FOLDERS = [Path("data/extract"), Path("data/clean"), Path("data/model")]
OUTPUTS = [
    "data/extract/requests.csv",
    "data/clean/requests.csv", "data/clean/quarantine.csv", "data/clean/service_requests.db",
    "data/model/requests_model.csv", "data/model/train.csv", "data/model/valid.csv", "data/model/test.csv",
    "data/model/build_summary.json", "data/model/split_manifest.json",
    "reports/cleaning.json", "reports/validation.json",
]
MANIFEST = Path("data/model/MANIFEST.json")


def sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def describe(path):
    """Checksum, and the number of data rows for a CSV file."""
    entry = {"sha256": sha256(path)}
    if path.endswith(".csv"):
        with open(path, newline="", encoding="utf-8") as f:
            entry["rows"] = sum(1 for _ in csv.reader(f)) - 1  # minus the header
    return entry


def main():
    if not Path("nyc311.db").exists():
        sys.exit("nyc311.db not found. Run: python get_data.py")
    for folder in OUTPUT_FOLDERS:
        shutil.rmtree(folder, ignore_errors=True)

    started = datetime.now(timezone.utc)
    for number, step in enumerate(STEPS, start=1):
        name = Path(step).stem
        result = subprocess.run([sys.executable, step], capture_output=True, text=True)
        if result.returncode != 0:
            print(f"{number}/{len(STEPS)} {name}: FAILED\n")
            print((result.stdout + result.stderr).rstrip())
            print(f"\nStopped at step {number} ({name}). No MANIFEST.json was written: this run delivered no dataset.")
            sys.exit(1)
        print(f"{number}/{len(STEPS)} {name}: ok")

    extract = json.loads(Path("data/extract/manifest.json").read_text(encoding="utf-8"))
    outputs = {path: describe(path) for path in OUTPUTS}
    manifest = {
        "dataset": "NYC 311 DOT requests: late_14d modelling dataset",
        "source": extract["source"],
        "selection": extract["selection"],
        "query": {extract["query"]: extract["query_sha256"]},
        "steps": STEPS,
        "outputs": outputs,
        # One checksum for all outputs together: equal outputs give an equal
        # fingerprint, whatever the time of the run.
        "outputs_fingerprint": hashlib.sha256(json.dumps(outputs, sort_keys=True).encode()).hexdigest(),
        "run": {
            "started_at": started.isoformat(timespec="seconds"),
            "extracted_at": extract["extracted_at"],
            "python": sys.version.split()[0],
            "sqlite": sqlite3.sqlite_version,
            "pandas": version("pandas"),
        },
    }
    MANIFEST.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    model = outputs["data/model/requests_model.csv"]["rows"]
    parts = ", ".join(f"{p} {outputs[f'data/model/{p}.csv']['rows']:,}" for p in ["train", "valid", "test"])
    print(f"Done: {model:,} rows ({parts}).")
    print(f"Wrote {MANIFEST}. Outputs fingerprint: {manifest['outputs_fingerprint']}")


if __name__ == "__main__":
    main()
