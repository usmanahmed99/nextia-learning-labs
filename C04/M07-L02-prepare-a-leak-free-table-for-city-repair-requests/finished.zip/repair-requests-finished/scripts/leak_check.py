"""Show what leaky columns do to a score. Not part of the delivered dataset.

    python scripts/leak_check.py

The same simple model (logistic regression on one-hot categories) is trained
on train.csv and scored on valid.csv four times: with the type of problem
only, with all the honest features, and twice with one leaky column added
from the clean table. The score is ROC AUC: 0.5 is guessing, 1.0 is a perfect
ranking. Training models well is the subject of C05; here the model is only
a measuring tool. Takes less than a minute.
"""

import json
from pathlib import Path

import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

MODEL = Path("data/model")
CLEAN = Path("data/clean/requests.csv")
REPORT = Path("reports/leak_check.json")
TARGET = "late_14d"
HONEST = ["complaint_type", "descriptor", "location_type", "borough", "channel",
          "created_hour", "created_weekday", "batch_time", "prior_band"]
LEAKS = ["status", "resolution_description"]


def prior_band(count):
    """The count as a category: 0, 1, 2, 3, 4, 5+, or 'no location'. A simple
    model reads a raw count as a straight line, and 71 earlier requests do not
    tell 71 times as much as one."""
    if pd.isna(count):
        return "no location"
    return "5+" if count >= 5 else str(int(count))


def score(train, valid, columns):
    """Fit on train only, then score valid. The pipeline learns the categories
    from train, so valid stays unseen."""
    model = Pipeline([("one_hot", OneHotEncoder(handle_unknown="ignore", min_frequency=20)),
                      ("model", LogisticRegression(max_iter=2000))])
    model.fit(train[columns], train[TARGET])
    return round(roc_auc_score(valid[TARGET], model.predict_proba(valid[columns])[:, 1]), 3)


def main():
    read = {"dtype": "string", "keep_default_na": False, "na_values": [""]}
    train = pd.read_csv(MODEL / "train.csv", **read)
    valid = pd.read_csv(MODEL / "valid.csv", **read)
    for df in (train, valid):
        df["prior_band"] = pd.to_numeric(df["prior_same_place_30d"]).map(prior_band)
        df[TARGET] = df[TARGET].astype(int)
    # The leaky columns are not in the delivered dataset; take them from the clean table.
    leaks = pd.read_csv(CLEAN, usecols=["request_id"] + LEAKS, dtype="string",
                        keep_default_na=False, na_values=[""]).fillna("none")
    train = train.merge(leaks, on="request_id", how="left", validate="one_to_one")
    valid = valid.merge(leaks, on="request_id", how="left", validate="one_to_one")

    runs = {
        "type of problem only (complaint_type, descriptor)": ["complaint_type", "descriptor"],
        "honest features (the delivered dataset)": HONEST,
        "honest + status (leak)": HONEST + ["status"],
        "honest + resolution_description (leak)": HONEST + ["resolution_description"],
    }
    results = {}
    print(f"train {len(train):,} rows, valid {len(valid):,} rows\n")
    print(f"{'features':<52} ROC AUC on valid")
    for name, columns in runs.items():
        results[name] = score(train, valid, columns)
        print(f"{name:<52} {results[name]:.3f}")
    REPORT.parent.mkdir(exist_ok=True)
    REPORT.write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
