"""Write the clean requests into a SQLite database for other teams:
data/clean/service_requests.db. One row per clean request, without free
text, with the schema below. The C16 case study (a data API) reads it.

    python scripts/build_db.py

The database holds facts as they were when the data was pulled, including
the status and the closing time. It is for reports and dashboards. It is
not a modelling table: a model must not use status, closed_at or
days_to_close, which are known only after a request is created.
"""

import json
import sqlite3
from pathlib import Path

import pandas as pd

IN = Path("data/clean/requests.csv")
EXTRACT_MANIFEST = Path("data/extract/manifest.json")
CLEANING = Path("reports/cleaning.json")
DB = Path("data/clean/service_requests.db")
TIME_FORMAT = "%Y-%m-%d %H:%M:%S"
SCHEMA_VERSION = "1.0"

SCHEMA = """
CREATE TABLE service_requests (
    id               INTEGER PRIMARY KEY,  -- NYC 311 unique_key
    created_at       TEXT NOT NULL,        -- 'YYYY-MM-DD HH:MM:SS', New York local time
    closed_at        TEXT,                 -- NULL: not closed when the data was pulled
    days_to_close    REAL,                 -- closed_at - created_at in days, 2 decimals
    status           TEXT NOT NULL,        -- the status when the data was pulled
    complaint_type   TEXT NOT NULL,
    descriptor       TEXT,
    location_type    TEXT,
    borough          TEXT CHECK (borough IN ('BRONX', 'BROOKLYN', 'MANHATTAN', 'QUEENS', 'STATEN ISLAND')),
    community_board  TEXT,                 -- for example '07 QUEENS'
    council_district TEXT,                 -- '01' to '51'
    incident_zip     TEXT,                 -- five digits
    channel          TEXT CHECK (channel IN ('ONLINE', 'PHONE', 'MOBILE', 'OTHER')),
    latitude         REAL,
    longitude        REAL,
    CHECK (closed_at IS NULL OR closed_at >= created_at),
    CHECK ((closed_at IS NULL) = (days_to_close IS NULL))
);
CREATE INDEX ix_created ON service_requests (created_at, id);
CREATE INDEX ix_borough_created ON service_requests (borough, created_at, id);
CREATE INDEX ix_type_created ON service_requests (complaint_type, created_at, id);
CREATE INDEX ix_status_created ON service_requests (status, created_at, id);
CREATE TABLE meta (
    name  TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
"""
COLUMNS = ["id", "created_at", "closed_at", "days_to_close", "status", "complaint_type", "descriptor",
           "location_type", "borough", "community_board", "council_district", "incident_zip", "channel",
           "latitude", "longitude"]


def main():
    df = pd.read_csv(IN, dtype={"request_id": "Int64", "council_district": "string", "incident_zip": "string"},
                     parse_dates=["created_at", "closed_at"], date_format=TIME_FORMAT,
                     keep_default_na=False, na_values=[""], float_precision="round_trip")
    df = df.rename(columns={"request_id": "id"}).sort_values("id")
    seconds = (df["closed_at"] - df["created_at"]).dt.total_seconds()
    # Python's round() on each value, so a value that ends in 5 rounds the
    # same way here as in other tools that read the same file.
    df["days_to_close"] = seconds.map(lambda s: round(s / 86400, 2), na_action="ignore")
    for column in ["created_at", "closed_at"]:
        df[column] = df[column].dt.strftime(TIME_FORMAT)
    table = df[COLUMNS].astype(object).where(df[COLUMNS].notna(), None)

    extract = json.loads(EXTRACT_MANIFEST.read_text(encoding="utf-8"))
    cleaning = json.loads(CLEANING.read_text(encoding="utf-8"))
    source, selection = extract["source"], extract["selection"]
    meta = {
        "schema_version": SCHEMA_VERSION,
        "dataset": source["dataset"],
        "dataset_url": source["dataset_url"],
        "pulled_on": source["pulled_on"],
        "source_file": source["file"],
        "source_sha256": source["file_sha256"],
        "selection": f"agency = 'DOT' and {selection['created_from']} <= created_date "
                     f"< {selection['created_before']}",
        "rows": str(len(table)),
        "rows_left_out": (f"{cleaning['repeated_submissions_removed']} repeated submissions, "
                          f"{cleaning['quarantined']} closed before created"),
        "missing_means": "borough, community_board, channel, incident_zip: not recorded in the source "
                         "(Unspecified, UNKNOWN or not five digits there)",
        "times": "New York local time, as published; no time zone in the source",
        "made_by": "C04 case study 'Prepare a leak-free table for city repair requests', scripts/build_db.py",
        "terms": source["terms"],
    }

    DB.parent.mkdir(parents=True, exist_ok=True)
    DB.unlink(missing_ok=True)
    con = sqlite3.connect(DB)
    con.executescript(SCHEMA)
    con.executemany(f"INSERT INTO service_requests VALUES ({', '.join('?' * len(COLUMNS))})",
                    table.itertuples(index=False, name=None))
    con.executemany("INSERT INTO meta VALUES (?, ?)", meta.items())
    con.commit()
    con.execute("VACUUM")
    rows = con.execute("SELECT COUNT(*) FROM service_requests").fetchone()[0]
    con.close()
    print(f"{DB}: service_requests {rows:,} rows, meta {len(meta)} rows, "
          f"{DB.stat().st_size / 1e6:.0f} MB")


if __name__ == "__main__":
    main()
