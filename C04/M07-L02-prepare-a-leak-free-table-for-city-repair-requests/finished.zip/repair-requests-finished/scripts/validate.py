"""Check the delivered dataset against its contract (scripts/contract.py).
Prints PASS or FAIL for each rule, writes reports/validation.json, and exits
with code 1 if any rule fails.

    python scripts/validate.py

Each rule is a function that returns a list of problems. An empty list
means that the rule passes. tests/test_validate.py breaks each rule on a
tiny table and checks that the rule notices.
"""

import json
import sys
from pathlib import Path

import pandas as pd

import contract as c

MODEL = Path("data/model")
REPORT = Path("reports/validation.json")
TIME_FORMAT = "%Y-%m-%d %H:%M:%S"


# ---------------------------------------------------------------- helpers

def n(count, word):
    """'1 row', '3 rows'."""
    return f"{count} {word}" + ("" if count == 1 else "s")


def first(df, mask, column):
    """The first bad row, as an example: its key and its value."""
    row = df[mask].iloc[0]
    value = row[column]
    shown = repr(value) if isinstance(value, str) else value
    return f"first: {c.KEY} {row[c.KEY]}, {shown}"


def load(path):
    """Read every value as text. The rules check the types; nothing is assumed."""
    return pd.read_csv(path, dtype=str, keep_default_na=False, na_values=[""])


def convert(text, kind):
    """Convert a text column to its type. A value that cannot be read becomes missing."""
    if kind == "text":
        return text
    if kind == "datetime":
        return pd.to_datetime(text, format=TIME_FORMAT, errors="coerce")
    numbers = pd.to_numeric(text, errors="coerce")
    if kind == "integer":
        numbers = numbers.where(numbers % 1 == 0)  # 2.5 is not an integer
    return numbers


def typed(raw):
    """The table with each column converted to its contract type."""
    df = raw.copy()
    for column, (kind, _) in c.COLUMNS.items():
        df[column] = convert(raw[column], kind)
    return df


# ---------------------------------------------------------------- table rules

def columns_present(raw):
    return [f"missing column: {col}" for col in c.COLUMNS if col not in raw.columns]


def no_leaky_columns(raw):
    leaky = [f"{col} must not be in the dataset (known only after creation)"
             for col in raw.columns if col in c.NEVER]
    extra = [f"unexpected column: {col}" for col in raw.columns if col not in c.COLUMNS and col not in c.NEVER]
    return leaky + extra


def values_have_types(raw):
    problems = []
    df = typed(raw)
    for column, (kind, _) in c.COLUMNS.items():
        bad = raw[column].notna() & df[column].isna()
        if bad.any():
            problems.append(f"{column}: not a valid {kind} in {n(bad.sum(), 'row')} ({first(raw, bad, column)})")
    return problems


def required_values_present(raw):
    return [f"{column}: missing in {n(raw[column].isna().sum(), 'row')}"
            for column, (_, required) in c.COLUMNS.items() if required and raw[column].isna().any()]


def key_is_unique(df):
    repeated = df[c.KEY].duplicated(keep=False)
    if not repeated.any():
        return []
    return [f"{n(df.loc[repeated, c.KEY].nunique(), 'key')} repeated (first: {df.loc[repeated, c.KEY].iloc[0]})"]


def categories_allowed(df):
    problems = []
    for column, allowed in c.ALLOWED.items():
        bad = df[column].notna() & ~df[column].isin(allowed)
        if bad.any():
            values = sorted(df.loc[bad, column].astype(str).unique())
            problems.append(f"{column}: values not allowed in {n(bad.sum(), 'row')}: {values}")
    return problems


def values_in_ranges(df):
    problems = []
    for column, (low, high) in c.RANGES.items():
        values = df[column]
        bad = pd.Series(False, index=df.index)
        if low is not None:
            bad |= values < low
        if high is not None:
            bad |= values > high
        bad = bad.fillna(False).astype(bool)
        if bad.any():
            problems.append(f"{column}: outside {low} to {high} in {n(bad.sum(), 'row')} ({first(df, bad, column)})")
    return problems


def missing_exactly_when(df):
    problems = []
    for column, (other, value) in c.MISSING_EXACTLY_WHEN.items():
        bad = df[column].isna() != (df[other] == value)
        if bad.any():
            problems.append(f"{column} must be missing exactly when {other} = {value}: "
                            f"not true in {n(bad.sum(), 'row')} ({first(df, bad, column)})")
    return problems


def late_rate_in_range(name, df):
    low, high = c.LATE_RATE
    rate = pd.to_numeric(df[c.TARGET]).mean()
    if not low <= rate <= high:
        return [f"{name}: late rate {rate:.1%} is outside {low:.0%} to {high:.0%}"]
    return []


# ---------------------------------------------------------------- split rules

def splits_not_empty(parts):
    return [f"{name} has no rows" for name, part in parts.items() if len(part) == 0]


def splits_make_the_table(table, parts):
    problems = []
    for name, part in parts.items():
        if list(part.columns) != list(table.columns):
            problems.append(f"{name}: the columns are not the same as in the modelling table")
    together = pd.concat(parts.values())
    if len(together) != len(table):
        problems.append(f"the splits have {len(together)} rows together; the modelling table has {len(table)}")
    if set(together[c.KEY]) != set(table[c.KEY]):
        problems.append("the splits do not hold the same requests as the modelling table")
    return problems


def no_key_in_two_splits(parts):
    problems = []
    names = list(parts)
    for i, a in enumerate(names):
        for b in names[i + 1:]:
            shared = set(parts[a][c.KEY]) & set(parts[b][c.KEY])
            if shared:
                problems.append(f"{a} and {b} share {n(len(shared), 'key')} (first: {sorted(shared)[0]})")
    return problems


def splits_in_time_order(parts):
    problems = []
    names = list(parts)
    for a, b in zip(names, names[1:]):
        last = pd.to_datetime(parts[a][c.TIME], format=TIME_FORMAT).max()
        start = pd.to_datetime(parts[b][c.TIME], format=TIME_FORMAT).min()
        if not last < start:
            problems.append(f"{a} ends at {last}, which is not before the start of {b} at {start}")
    return problems


# ---------------------------------------------------------------- run

def check_table(raw):
    """All the table rules, as (rule, problems) pairs. Stops early if the
    columns or the types are wrong, because the later rules need them."""
    results = [("required columns are present", columns_present(raw)),
               ("no column that is known only after creation", no_leaky_columns(raw))]
    if results[0][1]:
        return results
    results.append(("every value has its column's type", values_have_types(raw)))
    results.append(("no missing values in required columns", required_values_present(raw)))
    if results[-2][1]:
        return results
    df = typed(raw)
    results += [
        (f"{c.KEY} is unique", key_is_unique(df)),
        ("categories use allowed values only", categories_allowed(df)),
        ("numbers and dates are in their allowed ranges", values_in_ranges(df)),
        ("missing values only where the contract allows them", missing_exactly_when(df)),
    ]
    return results


def check_splits(table, parts):
    results = [("every split has rows", splits_not_empty(parts))]
    if results[0][1]:
        return results
    rate_problems = late_rate_in_range("all rows", table)
    for name, part in parts.items():
        rate_problems += late_rate_in_range(name, part)
    results += [
        ("together, the splits are exactly the modelling table", splits_make_the_table(table, parts)),
        ("no request is in two splits", no_key_in_two_splits(parts)),
        ("the splits are in time order: train, then valid, then test", splits_in_time_order(parts)),
        (f"late rate between {c.LATE_RATE[0]:.0%} and {c.LATE_RATE[1]:.0%}", rate_problems),
    ]
    return results


def main():
    files = ["requests_model.csv"] + [f"{name}.csv" for name in c.SPLITS]
    missing = [f for f in files if not (MODEL / f).exists()]
    if missing:
        print(f"FAIL  missing file(s) in {MODEL}: {', '.join(missing)}")
        print("Run build_features.py and split.py first.")
        sys.exit(1)

    print(f"Checking {MODEL} against the contract")
    table = load(MODEL / "requests_model.csv")
    results = check_table(table)
    if all(not problems for _, problems in results):
        results += check_splits(table, {name: load(MODEL / f"{name}.csv") for name in c.SPLITS})

    for name, problems in results:
        print(f"{'PASS' if not problems else 'FAIL'}  {name}")
        for problem in problems:
            print(f"      {problem}")
    failed = [name for name, problems in results if problems]
    REPORT.parent.mkdir(exist_ok=True)
    report = {"files": files, "passed": not failed,
              "rules": [{"rule": name, "passed": not problems, "problems": problems} for name, problems in results]}
    REPORT.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    if failed:
        print(f"{len(failed)} of {len(results)} rules failed. Fix the step that made the data, then run it again.")
        sys.exit(1)
    print(f"All {len(results)} rules passed.")


if __name__ == "__main__":
    main()
