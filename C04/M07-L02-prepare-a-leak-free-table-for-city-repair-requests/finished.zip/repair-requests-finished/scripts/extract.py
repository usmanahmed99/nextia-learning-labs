"""Extract the selected requests from nyc311.db into a CSV file, with a manifest.

    python scripts/extract.py
    python scripts/extract.py --created-from 2025-01-01 --created-before 2025-04-01

Before it selects anything, the script checks the source: the columns that
the query needs, and the form of the times. A text time in another form
would make the date filter wrong without an error. Exit code 1 on failure.
"""

import argparse
import csv
import hashlib
import json
import sqlite3
import sys
from datetime import datetime, timezone
from pathlib import Path

DB = Path("nyc311.db")
QUERY = Path("queries/extract_requests.sql")
OUT = Path("data/extract")
NEEDED = [
    "unique_key", "created_date", "closed_date", "agency", "status", "complaint_type",
    "descriptor", "location_type", "borough", "community_board", "council_district",
    "incident_zip", "open_data_channel_type", "latitude", "longitude",
    "resolution_description", "resolution_action_updated_date",
]
# 2024-01-01T00:30:02.000: the form of every time in the source.
TIME_PATTERN = "[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]T[0-9][0-9]:[0-9][0-9]:[0-9][0-9]*"


def check_source(con):
    """Return a list of problems. An empty list means the source is usable."""
    columns = [row[1] for row in con.execute("PRAGMA table_info(requests)")]
    problems = [f"missing column in requests: {c}" for c in NEEDED if c not in columns]
    if problems:
        return problems
    for column in ["created_date", "closed_date", "resolution_action_updated_date"]:
        bad = con.execute(f"SELECT COUNT(*), MIN({column}) FROM requests "
                          f"WHERE {column} IS NOT NULL AND {column} NOT GLOB ?", (TIME_PATTERN,)).fetchone()
        if bad[0]:
            problems.append(f"{column}: {bad[0]} values are not in the form 2024-01-01T00:30:02 "
                            f"(first: {bad[1]!r})")
    return problems


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--created-from", default="2024-01-01")
    parser.add_argument("--created-before", default="2025-07-01")
    args = parser.parse_args()
    params = {"created_from": args.created_from, "created_before": args.created_before}

    if not DB.exists():
        sys.exit(f"{DB} not found. Run: python get_data.py")
    if not QUERY.exists():
        sys.exit(f"{QUERY} not found. Write the extraction query first.")
    con = sqlite3.connect(f"file:{DB}?mode=ro", uri=True)
    problems = check_source(con)
    if problems:
        print("FAIL  the source does not match what the query expects:")
        for problem in problems:
            print(f"      {problem}")
        sys.exit(1)

    source = dict(con.execute("SELECT name, value FROM source").fetchall())
    total = con.execute("SELECT COUNT(*) FROM requests").fetchone()[0]
    sql = QUERY.read_text(encoding="utf-8")
    cursor = con.execute(sql, params)
    header = [d[0] for d in cursor.description]
    OUT.mkdir(parents=True, exist_ok=True)
    out_file = OUT / "requests.csv"
    rows = 0
    with open(out_file, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f, lineterminator="\n")
        writer.writerow(header)
        for row in cursor:
            writer.writerow(row)
            rows += 1
    con.close()

    manifest = {
        "extracted_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "source": source,
        "selection": {**params, "rule": "agency = 'DOT' and created_from <= created_date < created_before"},
        "query": str(QUERY),
        "query_sha256": hashlib.sha256(sql.encode()).hexdigest(),
        "rows_in_source": total,
        "rows_selected": rows,
        "rows_not_selected": total - rows,
        "file": str(out_file),
    }
    (OUT / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print("PASS  the source has the expected columns and time format")
    print(f"{out_file}: {rows:,} rows")
    print(f"Not selected: {total - rows:,} rows")


if __name__ == "__main__":
    main()
