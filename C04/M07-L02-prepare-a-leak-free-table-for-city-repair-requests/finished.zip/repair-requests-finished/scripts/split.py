"""Split the modelling table by time: train on the past, check on the future."""

import json
from pathlib import Path

import pandas as pd

IN = Path("data/model/requests_model.csv")
OUT = Path("data/model")
VALID_FROM = pd.Timestamp("2025-01-01")
TEST_FROM = pd.Timestamp("2025-04-01")
TIME_FORMAT = "%Y-%m-%d %H:%M:%S"


def main():
    # Int64 keeps a missing count missing; without it, 3 would become 3.0.
    df = pd.read_csv(IN, parse_dates=["created_at"], date_format=TIME_FORMAT,
                     dtype={"prior_same_place_30d": "Int64"}, keep_default_na=False, na_values=[""])
    df["split"] = "train"
    df.loc[df["created_at"] >= VALID_FROM, "split"] = "valid"
    df.loc[df["created_at"] >= TEST_FROM, "split"] = "test"
    manifest = {"rule": f"train < {VALID_FROM.date()} <= valid < {TEST_FROM.date()} <= test", "parts": {}}
    for name in ["train", "valid", "test"]:
        part = df[df["split"] == name].drop(columns="split")
        part.to_csv(OUT / f"{name}.csv", index=False, date_format=TIME_FORMAT)
        manifest["parts"][name] = {
            "rows": len(part), "late": int(part["late_14d"].sum()),
            "late_rate": round(part["late_14d"].mean(), 3),
            "first_created": str(part["created_at"].min()), "last_created": str(part["created_at"].max()),
        }
    (OUT / "split_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
