"""Build the modelling table: one row per request, with only the facts known
when the request is created, and the target, late_14d."""

import json
import sqlite3
from pathlib import Path

import pandas as pd

IN = Path("data/clean/requests.csv")
OUT = Path("data/model")
PRIOR_QUERY = Path("queries/prior_same_place.sql")
TIME_FORMAT = "%Y-%m-%d %H:%M:%S"
SNAPSHOT = pd.Timestamp("2025-07-01 00:00:00")  # the end of the selection
WINDOW = pd.Timedelta(days=14)
HISTORY_FROM = pd.Timestamp("2024-02-01")  # the first day with 30 days of history before it
BATCH_TIMES = {"07:00:00", "22:10:00"}  # times that many requests share (see the profile)

# Filled in after the request is created. They describe its future, so
# they must never be features.
AFTER_CREATION = ["status", "closed_at", "resolution_description", "resolution_updated_at"]
CATEGORIES = ["complaint_type", "descriptor", "location_type", "borough", "channel"]
FEATURES = CATEGORIES + ["created_hour", "created_weekday", "batch_time", "has_location",
                         "prior_same_place_30d"]


def add_target(df):
    """late_14d = 1 if the request was not closed within 14 days of its creation.
    A request that is still open counts as late."""
    on_time = df["closed_at"].notna() & (df["closed_at"] <= df["created_at"] + WINDOW)
    df["late_14d"] = (~on_time).astype(int)
    return df


def add_features(df):
    for column in CATEGORIES:
        df[column] = df[column].fillna("unknown")
    df["created_hour"] = df["created_at"].dt.hour
    df["created_weekday"] = df["created_at"].dt.weekday  # 0 = Monday
    df["batch_time"] = df["created_at"].dt.strftime("%H:%M:%S").isin(BATCH_TIMES).astype(int)
    df["has_location"] = df["latitude"].notna().astype(int)
    df["prior_same_place_30d"] = prior_same_place(df)
    return df


def prior_same_place(df):
    """Earlier requests about the same problem at the same place, from the SQL
    in queries/prior_same_place.sql. Missing when the request has no location."""
    con = sqlite3.connect(":memory:")
    columns = ["request_id", "created_at", "complaint_type", "descriptor", "latitude", "longitude"]
    df[columns].to_sql("requests", con, index=False)
    prior = pd.read_sql(PRIOR_QUERY.read_text(encoding="utf-8"), con).set_index("request_id")
    con.close()
    return df["request_id"].map(prior["prior_same_place_30d"]).astype("Int64")


def main():
    df = pd.read_csv(IN, dtype={"request_id": "Int64", "council_district": "string", "incident_zip": "string"},
                     parse_dates=["created_at", "closed_at"], date_format=TIME_FORMAT,
                     keep_default_na=False, na_values=[""], float_precision="round_trip")
    counts = {"clean_rows": len(df)}
    df = add_target(df)
    # Features come from all clean rows: January 2024 is history for February.
    df = add_features(df)

    # A request needs 14 days before the snapshot for a final target, and
    # 30 days of earlier data for a complete history.
    too_recent = df["created_at"] > SNAPSHOT - WINDOW
    too_early = df["created_at"] < HISTORY_FROM
    counts["too_recent_for_target"] = int(too_recent.sum())
    counts["before_history_from"] = int(too_early.sum())
    df = df[~too_recent & ~too_early].sort_values(["created_at", "request_id"])

    table = df[["request_id", "created_at"] + FEATURES + ["late_14d"]]
    OUT.mkdir(parents=True, exist_ok=True)
    table.to_csv(OUT / "requests_model.csv", index=False, date_format=TIME_FORMAT)
    counts.update({"rows": len(table), "late": int(table["late_14d"].sum()),
                   "late_rate": round(table["late_14d"].mean(), 3)})
    (OUT / "build_summary.json").write_text(json.dumps(counts, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(counts, indent=2))


if __name__ == "__main__":
    main()
