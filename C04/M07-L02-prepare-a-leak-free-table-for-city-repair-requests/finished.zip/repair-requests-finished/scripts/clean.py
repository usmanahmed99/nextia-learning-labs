"""Clean the extracted requests. Every input row ends in exactly one place:
the clean table, the quarantine table, or the count of removed repeated
submissions. Each correction is counted in reports/cleaning.json."""

import json
from pathlib import Path

import pandas as pd

IN = Path("data/extract/requests.csv")
OUT = Path("data/clean")
REPORTS = Path("reports")
TIME_FORMAT = "%Y-%m-%d %H:%M:%S"
TYPES = {
    "request_id": "Int64", "status": "string", "complaint_type": "string", "descriptor": "string",
    "location_type": "string", "borough": "string", "community_board": "string",
    "council_district": "string", "incident_zip": "string", "channel": "string",
    "latitude": "float64", "longitude": "float64", "resolution_description": "string",
}
TIMES = ["created_at", "closed_at", "resolution_updated_at"]


def load():
    # float_precision="round_trip" reads each coordinate exactly as written.
    # The faster default can change its last digit.
    df = pd.read_csv(IN, dtype=TYPES, keep_default_na=False, na_values=[""], float_precision="round_trip")
    for column in TIMES:
        df[column] = pd.to_datetime(df[column], format=TIME_FORMAT)
    return df


def remove_repeated_submissions(df):
    """Rows that are equal in every column except request_id are one request
    sent more than once. Keep the first one (the lowest request_id)."""
    other_columns = [c for c in df.columns if c != "request_id"]
    df = df.sort_values("request_id")
    repeated = df.duplicated(subset=other_columns, keep="first")
    return df[~repeated], int(repeated.sum())


def quarantine_rows(df):
    """Rows that we cannot correct with confidence go to quarantine, with a reason."""
    reason = pd.Series(pd.NA, index=df.index, dtype="string")
    reason[df["closed_at"] < df["created_at"]] = "closed_before_created"
    quarantine = df[reason.notna()].assign(reject_reason=reason[reason.notna()])
    return df[reason.isna()], quarantine


def standardise(df, counts):
    """One way to write 'not recorded': a missing value (NULL in SQL)."""
    df = df.copy()
    placeholders = {
        "borough": df["borough"] == "Unspecified",
        "community_board": df["community_board"].str.contains("Unspecified", na=False),
        "channel": df["channel"] == "UNKNOWN",
        "incident_zip": ~df["incident_zip"].str.fullmatch(r"\d{5}", na=True),
    }
    for column, mask in placeholders.items():
        df.loc[mask, column] = pd.NA
        counts[f"{column}_placeholder_to_missing"] = int(mask.sum())

    # Some texts were saved as UTF-8 and read back as Latin-1, so a
    # right quote (’) shows as three characters (â, \x80, \x99).
    repaired = df["resolution_description"].map(repair_text, na_action="ignore")
    changed = repaired.ne(df["resolution_description"]).fillna(False)
    df["resolution_description"] = repaired
    df["resolution_repaired"] = changed
    counts["resolution_text_repaired"] = int(changed.sum())
    return df


def repair_text(text):
    """Undo UTF-8 read as Latin-1. A text that is already right stays the same:
    either the first step fails, or the second one does."""
    try:
        return text.encode("latin-1").decode("utf-8")
    except (UnicodeEncodeError, UnicodeDecodeError):
        return text


def main():
    raw = load()
    counts = {"input_rows": len(raw)}
    df, counts["repeated_submissions_removed"] = remove_repeated_submissions(raw)
    df, quarantine = quarantine_rows(df)
    counts["quarantined"] = len(quarantine)
    df = standardise(df, counts)
    counts["clean_rows"] = len(df)
    assert counts["clean_rows"] + counts["quarantined"] + counts["repeated_submissions_removed"] == len(raw)
    assert df["request_id"].is_unique

    OUT.mkdir(parents=True, exist_ok=True)
    REPORTS.mkdir(exist_ok=True)
    df.to_csv(OUT / "requests.csv", index=False, date_format=TIME_FORMAT)
    quarantine.to_csv(OUT / "quarantine.csv", index=False, date_format=TIME_FORMAT)
    (REPORTS / "cleaning.json").write_text(json.dumps(counts, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(counts, indent=2))


if __name__ == "__main__":
    main()
