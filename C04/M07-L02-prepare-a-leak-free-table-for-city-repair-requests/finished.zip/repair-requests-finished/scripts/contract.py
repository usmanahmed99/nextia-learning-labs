"""The contract of the delivered dataset: the rules that the person who trains
the model can rely on in data/model/. scripts/validate.py checks each rule.
To change a rule, change it here."""

import pandas as pd

KEY = "request_id"
TIME = "created_at"
TARGET = "late_14d"
SPLITS = ["train", "valid", "test"]

# Every column, its type, and whether a value is required.
COLUMNS = {
    "request_id": ("integer", True),
    "created_at": ("datetime", True),
    "complaint_type": ("text", True),
    "descriptor": ("text", True),
    "location_type": ("text", True),
    "borough": ("text", True),
    "channel": ("text", True),
    "created_hour": ("integer", True),
    "created_weekday": ("integer", True),
    "batch_time": ("integer", True),
    "has_location": ("integer", True),
    "prior_same_place_30d": ("integer", False),  # no location, no count
    "late_14d": ("integer", True),               # the target
}

# Known only after the request is created: never in the dataset.
NEVER = ["status", "closed_at", "days_to_close", "resolution_description", "resolution_updated_at"]

ALLOWED = {
    "borough": {"BRONX", "BROOKLYN", "MANHATTAN", "QUEENS", "STATEN ISLAND", "unknown"},
    "channel": {"ONLINE", "PHONE", "MOBILE", "OTHER", "unknown"},
    "batch_time": {0, 1},
    "has_location": {0, 1},
    "late_14d": {0, 1},
}

RANGES = {  # inclusive; None means no limit
    "created_hour": (0, 23),
    "created_weekday": (0, 6),
    "prior_same_place_30d": (0, None),
    # From the first day with full history to the snapshot minus 14 days.
    "created_at": (pd.Timestamp("2024-02-01"), pd.Timestamp("2025-06-17 00:00:00")),
}

# A value that must be missing exactly when another column has a given value.
MISSING_EXACTLY_WHEN = {"prior_same_place_30d": ("has_location", 0)}

# The share of late requests, in the whole table and in each split.
LATE_RATE = (0.05, 0.30)
