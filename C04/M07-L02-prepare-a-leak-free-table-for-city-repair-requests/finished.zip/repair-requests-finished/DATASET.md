# Dataset card: NYC street-repair requests, late_14d

Version 1.0 of the dataset. Made from NYC Open Data's 311 service requests for the Department of Transportation (DOT), pulled on 2026-10-07.

## What it is

One row per service request to DOT (potholes, street lights, traffic signals, sidewalks and others), as it was at the moment of its creation. The target, `late_14d`, is 1 if the request was not closed within 14 days of its creation. Every feature is known when the request is created, so a model can use it at that moment.

| File | Rows | What one row is |
|---|---|---|
| `data/model/train.csv` | 186,339 | a request created from 2024-02-01 to 2024-12-31 |
| `data/model/valid.csv` | 53,156 | a request created from 2025-01-01 to 2025-03-31 |
| `data/model/test.csv` | 47,138 | a request created from 2025-04-01 to 2025-06-16 |
| `data/model/requests_model.csv` | 286,633 | all three parts together |

Late rate: 13.7% overall (39,145 of 286,633); train 13.9%, valid 11.1%, test 15.7%.

The pipeline also writes `data/clean/service_requests.db`: the clean requests (313,573 rows) for reports and dashboards, with their status and closing time. It is not a modelling table. Its schema is at the end of this card.

## Provenance

| Field | Value |
|---|---|
| Source | "311 Service Requests from 2020 to Present", NYC Open Data, dataset `erm2-nwe9`: https://data.cityofnewyork.us/Social-Services/311-Service-Requests-from-2020-to-Present/erm2-nwe9 |
| Publisher | City of New York (311 and the responding agencies) |
| Terms | NYC Open Data has no restrictions on use (NYC Administrative Code § 23-502(d)). The city asks users to state the source, the version and any changes; this card does that. |
| Version | Pulled on 2026-10-07 through the city's API, with this query: `$select` = the 20 columns below; `$where` = `agency='DOT' AND created_date >= '2024-01-01T00:00:00' AND created_date < '2025-07-01T00:00:00'`; `$order` = `unique_key`. |
| Frozen file | `nyc311_dot_2024-01_2025-06.csv.gz`, 315,424 rows, SHA-256 `31240271a6961024526bca4750f09ed6297b24fee1dcc5d506004102066cf9e2`, from https://github.com/usmanahmed99/nextia-learning-labs/tree/main/C04/case-studies/data |
| Changes in the frozen file | Only 20 of the source's columns (no street addresses). The values are as the API returned them; the file was written again as CSV, with quotes only where a value needs them, and compressed with gzip. |
| Snapshot | The dataset is built as on 2025-07-01 00:00, the end of the selection: a request needs 14 days before that time for a final target. |

## Transformation order

Run `python get_data.py` once, then `python run_pipeline.py`. The pipeline stops at the first step that fails.

| Step | Script | Rows in → out | Lineage record |
|---|---|---|---|
| 0 | `get_data.py` | frozen file → `nyc311.db`, table `requests`, 315,424 rows | the checksum; the `source` table |
| 1 | `scripts/extract.py` + `queries/extract_requests.sql` | 315,424 → 315,424 (all of the file is in the selection); checks the columns and the time format first | `data/extract/manifest.json` |
| 2 | `scripts/clean.py` | 315,424 → 313,573: 392 repeated submissions removed, 1,459 quarantined (closed before created) | `reports/cleaning.json`, `data/clean/quarantine.csv` |
| 3 | `scripts/build_db.py` | 313,573 → `data/clean/service_requests.db` | the `meta` table in the database |
| 4 | `scripts/build_features.py` + `queries/prior_same_place.sql` | 313,573 → 286,633: 17,319 created before 2024-02-01 (no full 30-day history), 9,621 created after 2025-06-17 00:00 (target not final) | `data/model/build_summary.json` |
| 5 | `scripts/split.py` | 286,633 → train 186,339, valid 53,156, test 47,138 | `data/model/split_manifest.json` |
| 6 | `scripts/validate.py` + `scripts/contract.py` | 13 rules, no change to the data | `reports/validation.json` |

`run_pipeline.py` writes `data/model/MANIFEST.json`: the source, the selection, the query checksum, a SHA-256 checksum and row count of every output file, and one `outputs_fingerprint` for all outputs together.

### Cleaning decisions

- **Repeated submissions (removed, 392 rows).** 273 groups of rows are equal in every column except `unique_key`: the same request, sent again in the same second. The row with the lowest key stays.
- **Closed before created (quarantined, 1,459 rows).** Mostly street-light requests with status `Pending`. The closing time cannot be right, and there is no way to correct it.
- **Placeholders become missing values.** `borough` = `Unspecified` (1,721), `community_board` containing `Unspecified` (21,765), `open_data_channel_type` = `UNKNOWN` (180,366) and a ZIP code that is not five digits (1). In the modelling table, a missing category becomes the category `unknown`.
- **Mis-encoded text repaired (95,560 rows).** In `resolution_description`, UTF-8 text that was read as Latin-1 (`Transportationâ\x80\x99s` → `Transportation’s`). The column is not in the modelling table.
- **Kept as they are:** 10,858 requests closed in the same second as they were created (5,919 of them are marked as duplicates of an earlier request), 1,444 requests open for more than a year, 6,081 requests still open, and the statuses that disagree with the closing time. `closed_at` decides the target.

## Columns of the modelling table

| Column | Type | Missing allowed | Meaning |
|---|---|---|---|
| `request_id` | integer | no | NYC 311 `unique_key` |
| `created_at` | datetime | no | `YYYY-MM-DD HH:MM:SS`, New York local time |
| `complaint_type` | text | no | the type of problem, for example `Street Condition` |
| `descriptor` | text | no | the detail, for example `Pothole`; `unknown` if missing |
| `location_type` | text | no | for example `Street`, `Sidewalk`; `unknown` if missing |
| `borough` | text | no | `BRONX`, `BROOKLYN`, `MANHATTAN`, `QUEENS`, `STATEN ISLAND`, `unknown` |
| `channel` | text | no | `ONLINE`, `PHONE`, `MOBILE`, `OTHER`, `unknown` (`UNKNOWN` in the source) |
| `created_hour` | integer | no | 0 to 23 |
| `created_weekday` | integer | no | 0 = Monday to 6 = Sunday |
| `batch_time` | integer | no | 1 if created at exactly 07:00:00 or 22:10:00, times that many requests share |
| `has_location` | integer | no | 1 if the request has coordinates |
| `prior_same_place_30d` | integer | yes (no location) | requests about the same problem (type and descriptor) at the same place (coordinates rounded to 4 decimals, about 10 m), created in the 30 days before this one |
| `late_14d` | integer | no | the target: 1 if not closed within 14 days of `created_at` |

Never in the modelling table: `status`, `closed_at`, `days_to_close`, `resolution_description` and `resolution_updated_at`. They are written after the request is created (leakage). On the validation set, adding `status` to a simple model raises ROC AUC from 0.816 to 0.863, and adding `resolution_description` raises it to 0.865 (`scripts/leak_check.py`). A model in real use would not have these columns.

## Tool versions

Tested 2026-10-07 on macOS: Python 3.14.6 (SQLite 3.50.4), pandas 3.0.6, scikit-learn 1.9.1 (only for `leak_check.py`), pytest 9.1.1. The SQL needs SQLite 3.38 or later (`unixepoch`).

## Output checksums (SHA-256)

| File | Rows | SHA-256 |
|---|---|---|
| `data/model/requests_model.csv` | 286,633 | 9742f9adfa9c095f7da637e0f77f5904d0aba43b20c4b292a971dc560db4b2a4 |
| `data/model/train.csv` | 186,339 | 775ada40c729cc3284756f208b8b9bd80bd1b7c83b3068b54144ef459b43fbe0 |
| `data/model/valid.csv` | 53,156 | 7e79819c5d9ba6cc07aef5bcc73ca5e3f01100a859a47e81f5aa3d03b39d2ff4 |
| `data/model/test.csv` | 47,138 | 0ed2f248b10e890681d37b7dfacf66ecf7361c1db35d4d231701b4730df4dd84 |
| `data/clean/service_requests.db` | 313,573 | ea39d4ae36ad5232bb3521dc957d63267d392d5f4f7a95fa65fbc5440d682e65 |

Outputs fingerprint (all 12 output files): `e833003d8eddcf489566d48244501929a997464d122949c060e62b2c69f127d1`. Two runs on 2026-10-07 gave the same fingerprint. On Windows, pandas writes CSV files with other line endings, so the checksums differ from these; compare two runs on the same computer.

## Known limitations

- **The target is about closing, not repairing.** A request can be closed because it is a duplicate, because the condition was not found, or because another agency is responsible. `late_14d` says only whether the record was closed in time.
- **The late rate changes with the season.** In this data it is 14% to 16% from April to August and 10% to 13% from December to March. Valid (January to March) has 11.1%, test (April to June) 15.7%. A model must be checked on more than one season.
- **Channel is unknown for 57.8% of the source rows.** `unknown` is a real category here: these requests are late less often (10.8%) than requests from the mobile app (25.9%).
- **14.8% of the clean rows have no coordinates:** 29% of the street-condition requests (potholes and others) and nearly all highway requests. For them, `prior_same_place_30d` is missing.
- **The source changes every day.** The city updates the data daily: closing times, statuses and texts can change. A fresh pull is a new version; record its date and checksum.
- **Status is from the pull, not from the snapshot.** `status` in `service_requests.db` is the status on 2026-10-07, more than a year after the last request was created.
- **What not to conclude.** A model trained on this table ranks requests by risk of being late. It does not say why a request is late, and it must not be used to judge neighbourhoods or the people who report problems.

## Schema of data/clean/service_requests.db (version 1.0)

One table `service_requests` (one row per clean request) and one table `meta` (`name`, `value`: source, version, rules). Times are text `YYYY-MM-DD HH:MM:SS`, New York local time.

| Column | Type | NULL means | Notes |
|---|---|---|---|
| `id` | INTEGER PRIMARY KEY | (never NULL) | NYC 311 `unique_key` |
| `created_at` | TEXT NOT NULL | (never NULL) | |
| `closed_at` | TEXT | not closed on 2026-10-07 | never before `created_at` |
| `days_to_close` | REAL | not closed | `closed_at − created_at` in days, 2 decimals |
| `status` | TEXT NOT NULL | (never NULL) | the status on 2026-10-07: `Closed`, `Pending`, `Assigned`, `Open`, `In Progress`, `Unspecified` |
| `complaint_type` | TEXT NOT NULL | (never NULL) | 33 values |
| `descriptor` | TEXT | not recorded | |
| `location_type` | TEXT | not recorded | |
| `borough` | TEXT | `Unspecified` in the source | `BRONX`, `BROOKLYN`, `MANHATTAN`, `QUEENS`, `STATEN ISLAND` |
| `community_board` | TEXT | `Unspecified` in the source | for example `07 QUEENS` |
| `council_district` | TEXT | not recorded | `01` to `51` |
| `incident_zip` | TEXT | not recorded, or not five digits | |
| `channel` | TEXT | `UNKNOWN` in the source | `ONLINE`, `PHONE`, `MOBILE`, `OTHER` |
| `latitude`, `longitude` | REAL | no coordinates | WGS 84 degrees |

Indexes: `(created_at, id)`, `(borough, created_at, id)`, `(complaint_type, created_at, id)`, `(status, created_at, id)`.

## Changes

| Version | Date | Change |
|---|---|---|
| 1.0 | 2026-10-07 | First delivery, from the pull of 2026-10-07. |
