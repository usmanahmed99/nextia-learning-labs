"""Get the NYC 311 street-repair requests and build the source database.

Nextia Learning, C04 case study: Prepare a leak-free table for city repair requests.

    python get_data.py                download the frozen file (if needed) and build nyc311.db
    python get_data.py --reset        delete nyc311.db and build it again from the file
    python get_data.py --from FILE    use a copy of the frozen file that you downloaded yourself
    python get_data.py --fresh        pull today's data from NYC Open Data instead (slow; other numbers)

The script uses the Python standard library only. By default it downloads
the frozen file into data/raw/, checks its SHA-256 checksum, and loads it
into a SQLite database file, nyc311.db, in the current folder.

The frozen file is a copy of NYC Open Data's "311 Service Requests from 2020
to Present" (erm2-nwe9): every request for the Department of Transportation
(DOT) created from 2024-01-01 to 2025-06-30, pulled on 2026-10-07. The city
updates the data every day, so a fresh pull gives other numbers than the
case study. Use --fresh only when you want today's data.

The database keeps every problem of the source on purpose. The table
`requests` has the 20 columns of the file, all as TEXT, with an empty value
stored as NULL. The table `source` says where the data came from.
"""

import argparse
import csv
import gzip
import hashlib
import shutil
import sqlite3
import subprocess
import sys
import urllib.parse
import urllib.request
from datetime import date
from pathlib import Path

FROZEN = "nyc311_dot_2024-01_2025-06.csv.gz"
FROZEN_URL = ("https://raw.githubusercontent.com/usmanahmed99/nextia-learning-labs/main/"
              "C04/case-studies/data/" + FROZEN)
FROZEN_SHA256 = "31240271a6961024526bca4750f09ed6297b24fee1dcc5d506004102066cf9e2"
FROZEN_PULLED_ON = "2026-10-07"
RAW = Path("data/raw")
DB = Path("nyc311.db")

# The query that selected the data from the city's API (Socrata SODA).
API = "https://data.cityofnewyork.us/resource/erm2-nwe9.csv"
COLUMNS = [
    "unique_key", "created_date", "closed_date", "agency", "complaint_type", "descriptor",
    "location_type", "incident_zip", "address_type", "city", "status", "due_date",
    "resolution_description", "resolution_action_updated_date", "community_board",
    "council_district", "borough", "open_data_channel_type", "latitude", "longitude",
]
WHERE = ("agency='DOT' AND created_date >= '2024-01-01T00:00:00' "
         "AND created_date < '2025-07-01T00:00:00'")
PAGE = 50_000


def sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def download(url, path):
    """Save the file at url as path."""
    try:
        with urllib.request.urlopen(url, timeout=300) as response, open(path, "wb") as f:
            shutil.copyfileobj(response, f)
    except OSError as error:
        # Python from the python.org installer on macOS has no certificates
        # until you run "Install Certificates.command". curl uses the
        # computer's own certificates, so try it before giving up.
        try:
            subprocess.run(["curl", "-fsSL", "-o", str(path), url], check=True)
        except (OSError, subprocess.CalledProcessError) as curl_error:
            path.unlink(missing_ok=True)
            sys.exit(f"Could not download {url}\n  Python: {error}\n  curl: {curl_error}\n"
                     "Check your internet connection, then run the script again. On macOS, if Python\n"
                     "says CERTIFICATE_VERIFY_FAILED, open Applications > Python 3.x and run\n"
                     "Install Certificates.command.")


def download_frozen():
    path = RAW / FROZEN
    if not path.exists():
        print(f"Downloading {FROZEN} (17 MB) ...", flush=True)
        download(FROZEN_URL, path)
    return path


def check_frozen(path):
    found = sha256(path)
    if found != FROZEN_SHA256:
        sys.exit(f"{path} has the wrong SHA-256 checksum:\n  expected {FROZEN_SHA256}\n  found    {found}\n"
                 "Delete the file and run the script again.")
    print(f"Checked {path.name}: SHA-256 OK")


def pull_fresh():
    """Pull today's version of the same selection, page by page, in unique_key order."""
    path = RAW / f"nyc311_dot_fresh_{date.today().isoformat()}.csv.gz"
    print(f"Pulling today's data from {API}")
    print("This takes several minutes. The numbers will not match the case study.", flush=True)
    rows = 0
    with gzip.open(path, "wt", encoding="utf-8", newline="") as out:
        writer = csv.writer(out, lineterminator="\n")
        writer.writerow(COLUMNS)
        while True:
            query = urllib.parse.urlencode({
                "$select": ",".join(COLUMNS), "$where": WHERE, "$order": "unique_key",
                "$limit": PAGE, "$offset": rows,
            })
            page_file = RAW / "page.csv"
            download(f"{API}?{query}", page_file)
            with open(page_file, newline="", encoding="utf-8") as f:
                body = list(csv.reader(f))[1:]  # every page starts with the header
            page_file.unlink()
            writer.writerows(body)
            rows += len(body)
            print(f"  {rows:,} rows", flush=True)
            if len(body) < PAGE:
                break
    return path


def build(path, pulled_on):
    if DB.exists():
        DB.unlink()
    con = sqlite3.connect(DB)
    with gzip.open(path, "rt", encoding="utf-8", newline="") as f:
        reader = csv.reader(f)
        header = next(reader)
        if header != COLUMNS:
            sys.exit(f"{path.name} does not have the expected columns.\n  expected {COLUMNS}\n  found    {header}")
        con.execute(f"CREATE TABLE requests ({', '.join(c + ' TEXT' for c in header)})")
        marks = ", ".join("?" * len(header))
        con.executemany(f"INSERT INTO requests VALUES ({marks})",
                        ([None if v == "" else v for v in row] for row in reader))
    rows = con.execute("SELECT COUNT(*) FROM requests").fetchone()[0]
    con.execute("CREATE TABLE source (name TEXT, value TEXT)")
    con.executemany("INSERT INTO source VALUES (?, ?)", [
        ("dataset", "311 Service Requests from 2020 to Present (NYC Open Data, erm2-nwe9)"),
        ("dataset_url", "https://data.cityofnewyork.us/Social-Services/311-Service-Requests-from-2020-to-Present/erm2-nwe9"),
        ("api_query", f"{API}?$select={','.join(COLUMNS)}&$where={WHERE}&$order=unique_key"),
        ("pulled_on", pulled_on),
        ("file", path.name),
        ("file_sha256", sha256(path)),
        ("rows", str(rows)),
        ("terms", "NYC Open Data: no restrictions on use (NYC Admin Code 23-502(d)); "
                  "state the source, the version and the changes"),
    ])
    con.commit()
    con.close()
    return rows


def main():
    parser = argparse.ArgumentParser(description="Build nyc311.db from the frozen file.")
    parser.add_argument("--reset", action="store_true", help="build nyc311.db again")
    parser.add_argument("--from", dest="source", type=Path, help="a copy of the frozen file")
    parser.add_argument("--fresh", action="store_true", help="pull today's data from NYC Open Data")
    args = parser.parse_args()

    if DB.exists() and not (args.reset or args.source or args.fresh):
        print(f"{DB} already exists. Use --reset to build it again.")
        return
    RAW.mkdir(parents=True, exist_ok=True)
    if args.fresh:
        path, pulled_on = pull_fresh(), date.today().isoformat()
    else:
        if args.source and args.source.resolve() != (RAW / FROZEN).resolve():
            shutil.copyfile(args.source, RAW / FROZEN)
        path, pulled_on = download_frozen(), FROZEN_PULLED_ON
        check_frozen(path)
    rows = build(path, pulled_on)
    print(f"Built {DB}. Check: requests {rows:,} rows.")


if __name__ == "__main__":
    main()
