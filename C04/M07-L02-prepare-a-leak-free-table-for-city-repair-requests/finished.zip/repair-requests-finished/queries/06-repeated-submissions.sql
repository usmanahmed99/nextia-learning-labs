-- Groups of rows that are equal in every column except unique_key.
-- GROUP BY puts rows with equal values (NULLs too) in one group.
WITH groups AS (
    SELECT COUNT(*) AS copies
    FROM requests
    GROUP BY created_date, closed_date, agency, complaint_type, descriptor, location_type,
             incident_zip, address_type, city, status, due_date, resolution_description,
             resolution_action_updated_date, community_board, council_district, borough,
             open_data_channel_type, latitude, longitude
    HAVING COUNT(*) > 1
)
SELECT
    COUNT(*)                AS groups_found,
    SUM(copies)             AS rows_in_groups,
    SUM(copies) - COUNT(*)  AS extra_rows
FROM groups;
