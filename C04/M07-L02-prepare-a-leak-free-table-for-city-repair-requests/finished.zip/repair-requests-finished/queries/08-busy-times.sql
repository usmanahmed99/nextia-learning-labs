-- The times of day (to the second) that the most requests share.
SELECT
    substr(created_date, 12, 8) AS time_of_day,
    COUNT(*)                    AS requests
FROM requests
GROUP BY time_of_day
ORDER BY requests DESC
LIMIT 5;
