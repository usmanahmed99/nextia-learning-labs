-- How many rows, how many distinct requests, and which dates?
SELECT
    COUNT(*)                   AS row_count,
    COUNT(DISTINCT unique_key) AS distinct_requests,
    MIN(created_date)          AS first_created,
    MAX(created_date)          AS last_created
FROM requests;
