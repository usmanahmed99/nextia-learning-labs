-- Check prior_same_place_30d for request 63774786 (created 2025-01-15 09:11:14)
-- by hand: the pothole requests at the same rounded place in the 30 days before.
-- It runs on nyc311.db, so the times still have the T and the coordinates are text.
WITH target AS (
    SELECT ROUND(CAST(latitude AS REAL), 4)  AS lat,
           ROUND(CAST(longitude AS REAL), 4) AS lon
    FROM requests
    WHERE unique_key = '63774786'
)
SELECT r.unique_key, r.created_date, r.closed_date, r.status
FROM requests AS r, target AS t
WHERE r.complaint_type = 'Street Condition'
  AND r.descriptor = 'Pothole'
  AND ROUND(CAST(r.latitude AS REAL), 4) = t.lat
  AND ROUND(CAST(r.longitude AS REAL), 4) = t.lon
  AND r.created_date >= '2024-12-16T09:11:14'
  AND r.created_date <  '2025-01-15T09:11:14'
ORDER BY r.created_date;
