-- The share of late requests by month of creation (same rules as 10).
WITH labelled AS (
    SELECT
        substr(created_date, 1, 7) AS month,
        CASE WHEN closed_date IS NOT NULL
              AND julianday(closed_date) - julianday(created_date) <= 14
             THEN 0 ELSE 1 END AS late
    FROM requests
    WHERE created_date < '2025-06-17'
      AND (closed_date IS NULL OR closed_date >= created_date)
)
SELECT
    month,
    COUNT(*)                   AS requests,
    ROUND(100.0 * AVG(late), 1) AS pct_late
FROM labelled
GROUP BY month
ORDER BY month;
