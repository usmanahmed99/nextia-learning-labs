-- Four checks on the closing time. julianday() turns a time into a number
-- of days, so a difference of two times is a duration in days.
SELECT
    SUM(closed_date IS NULL)                                     AS still_open,
    SUM(closed_date < created_date)                              AS closed_before_created,
    SUM(closed_date = created_date)                              AS closed_in_same_second,
    SUM(julianday(closed_date) - julianday(created_date) > 365)  AS open_over_a_year
FROM requests;
