-- How many rows have no value in each column that matters for the decision?
-- COUNT(column) counts only the values that are not NULL.
SELECT
    COUNT(*)                           AS row_count,
    COUNT(*) - COUNT(closed_date)      AS no_closed_date,
    COUNT(*) - COUNT(descriptor)       AS no_descriptor,
    COUNT(*) - COUNT(location_type)    AS no_location_type,
    COUNT(*) - COUNT(incident_zip)     AS no_zip,
    COUNT(*) - COUNT(latitude)         AS no_coordinates,
    COUNT(*) - COUNT(council_district) AS no_council_district,
    COUNT(*) - COUNT(due_date)         AS no_due_date
FROM requests;
