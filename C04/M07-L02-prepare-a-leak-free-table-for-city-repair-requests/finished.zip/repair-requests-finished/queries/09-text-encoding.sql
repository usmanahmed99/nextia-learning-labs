-- The resolution texts that start with the same 50 characters, with a
-- part of each text, its length, and how often it appears.
SELECT
    substr(resolution_description, 75, 20) AS part_of_text,
    length(resolution_description)         AS characters,
    COUNT(*)                               AS requests
FROM requests
WHERE resolution_description LIKE 'Service Request status for this request is available%'
GROUP BY resolution_description
ORDER BY requests DESC;
