-- One row per service request in the selection, with plain column names.
-- Times become 'YYYY-MM-DD HH:MM:SS' (New York local time, as published).
-- Nothing is removed or corrected here: the cleaning step does that and
-- counts it. Left out: agency (always DOT), city (repeats the borough),
-- due_date (always empty) and address_type (not used).
SELECT
    CAST(unique_key AS INTEGER)                              AS request_id,
    replace(substr(created_date, 1, 19), 'T', ' ')           AS created_at,
    replace(substr(closed_date, 1, 19), 'T', ' ')            AS closed_at,
    status,
    complaint_type,
    descriptor,
    location_type,
    borough,
    community_board,
    council_district,
    incident_zip,
    open_data_channel_type                                   AS channel,
    latitude,
    longitude,
    resolution_description,
    replace(substr(resolution_action_updated_date, 1, 19), 'T', ' ') AS resolution_updated_at
FROM requests
WHERE agency = 'DOT'
  AND created_date >= :created_from
  AND created_date <  :created_before
ORDER BY request_id;
