-- Does the status agree with the closing time?
-- COUNT(CASE WHEN ... THEN 1 END) counts the rows where the condition is true.
SELECT
    status,
    COUNT(*)                                                AS requests,
    COUNT(CASE WHEN closed_date >= created_date THEN 1 END) AS closed_after_created,
    COUNT(CASE WHEN closed_date <  created_date THEN 1 END) AS closed_before_created,
    COUNT(CASE WHEN closed_date IS NULL THEN 1 END)         AS no_closed_date
FROM requests
GROUP BY status
ORDER BY requests DESC;
