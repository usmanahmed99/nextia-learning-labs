-- The share of late requests for each type of problem.
-- Late = not closed within 14 days of creation (still open counts as late).
-- Only requests created at least 14 days before the snapshot (2025-07-01),
-- and not closed before they were created.
WITH labelled AS (
    SELECT
        complaint_type,
        CASE WHEN closed_date IS NOT NULL
              AND julianday(closed_date) - julianday(created_date) <= 14
             THEN 0 ELSE 1 END AS late
    FROM requests
    WHERE created_date < '2025-06-17'
      AND (closed_date IS NULL OR closed_date >= created_date)
)
SELECT
    complaint_type,
    COUNT(*)                   AS requests,
    ROUND(100.0 * AVG(late), 1) AS pct_late
FROM labelled
GROUP BY complaint_type
HAVING COUNT(*) >= 4000
ORDER BY pct_late DESC;
