-- The share of late requests by channel, and for potholes created at
-- 07:00:00 exactly compared with other potholes (same rules as 10).
WITH labelled AS (
    SELECT
        open_data_channel_type AS channel,
        descriptor,
        substr(created_date, 12, 8) = '07:00:00' AS at_seven,
        CASE WHEN closed_date IS NOT NULL
              AND julianday(closed_date) - julianday(created_date) <= 14
             THEN 0 ELSE 1 END AS late
    FROM requests
    WHERE created_date < '2025-06-17'
      AND (closed_date IS NULL OR closed_date >= created_date)
)
SELECT 'channel ' || channel AS rows_, COUNT(*) AS requests, ROUND(100.0 * AVG(late), 1) AS pct_late
FROM labelled
GROUP BY channel
UNION ALL
SELECT CASE WHEN at_seven THEN 'pothole at 07:00:00' ELSE 'pothole at other times' END,
       COUNT(*), ROUND(100.0 * AVG(late), 1)
FROM labelled
WHERE descriptor = 'Pothole'
GROUP BY at_seven;
