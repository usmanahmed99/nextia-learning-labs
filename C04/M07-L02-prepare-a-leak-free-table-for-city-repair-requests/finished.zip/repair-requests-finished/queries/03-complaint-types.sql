-- The most common types of problem, with their share of all rows.
SELECT
    complaint_type,
    COUNT(*)                                                 AS requests,
    ROUND(100.0 * COUNT(*) / (SELECT COUNT(*) FROM requests), 1) AS pct
FROM requests
GROUP BY complaint_type
ORDER BY requests DESC
LIMIT 8;
