-- For each request with a location: how many requests about the same
-- problem (complaint type and descriptor) were created at the same place
-- in the 30 days BEFORE it. Same place = latitude and longitude rounded
-- to 4 decimals (about 10 metres).
-- The frame ends 1 second before the request, so the request itself and
-- requests created in the same second do not count: at creation time,
-- nobody knows them yet. 2592000 seconds = 30 days.
SELECT
    request_id,
    COUNT(*) OVER (
        PARTITION BY complaint_type, descriptor, ROUND(latitude, 4), ROUND(longitude, 4)
        ORDER BY unixepoch(created_at)
        RANGE BETWEEN 2592000 PRECEDING AND 1 PRECEDING
    ) AS prior_same_place_30d
FROM requests
WHERE latitude IS NOT NULL;
