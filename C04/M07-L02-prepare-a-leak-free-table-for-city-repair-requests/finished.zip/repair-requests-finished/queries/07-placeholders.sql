-- Values that mean "not recorded", although they are not NULL.
SELECT 'borough = Unspecified' AS placeholder, COUNT(*) AS row_count
FROM requests WHERE borough = 'Unspecified'
UNION ALL
SELECT 'community_board contains Unspecified', COUNT(*)
FROM requests WHERE community_board LIKE '%Unspecified%'
UNION ALL
SELECT 'open_data_channel_type = UNKNOWN', COUNT(*)
FROM requests WHERE open_data_channel_type = 'UNKNOWN'
UNION ALL
SELECT 'incident_zip is not five digits', COUNT(*)
FROM requests WHERE incident_zip NOT GLOB '[0-9][0-9][0-9][0-9][0-9]';
