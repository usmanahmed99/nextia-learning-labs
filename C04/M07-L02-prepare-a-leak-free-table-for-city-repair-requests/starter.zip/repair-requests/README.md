# repair-requests (starter)

The starter project of the Nextia Learning case study "Prepare a leak-free
table for city repair requests" (C04 SQL and Data Preparation for AI).

You turn real NYC 311 requests to the Department of Transportation into a
leak-free, validated modelling table. The case-study page gives every step,
from the virtual environment to the delivered dataset.

## Ready to use

- `get_data.py` downloads the frozen data file and builds `nyc311.db`.
- `q.py` runs a `.sql` file and prints a table.
- `scripts/extract.py`, `scripts/build_db.py`, `scripts/validate.py` and
  `scripts/leak_check.py` are finished. Read them; you run them.
- `run_pipeline.py` runs every step in order and writes a manifest.
- `tests/test_validate.py` tests the validation rules.

## You write

- `queries/02-...` to `queries/13-...`: the profile and the checks.
- `queries/extract_requests.sql` and `queries/prior_same_place.sql`.
- `scripts/clean.py`, `scripts/build_features.py`, `scripts/split.py`.
- `scripts/contract.py`: the rules of the delivered dataset.
- `DATASET.md`, and this README as your portfolio README.

The code is MIT-licensed (LICENSE). The data comes from NYC Open Data and
has its own terms; the case study explains them.
