# Dataset card: NYC street-repair requests, late_14d

Fill in each section while you work through the case study. The section
"Document the dataset" on the case-study page lists what goes where.

## What it is

(One row is ... The target is ... The files and their row counts.)

## Provenance

(Source, publisher, terms, version: pull date and query, frozen file and its
checksum, the changes in the frozen file, the snapshot.)

## Transformation order

(One row per step: script, rows in and out, lineage record.)

## Columns of the modelling table

(Column, type, missing allowed, meaning. Then the columns that are never in
the table, and why.)

## Tool versions

## Output checksums (SHA-256)

## Known limitations

## Changes
