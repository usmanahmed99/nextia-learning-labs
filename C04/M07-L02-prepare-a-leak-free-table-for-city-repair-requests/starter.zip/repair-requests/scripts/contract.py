"""The contract of the delivered dataset.

You write this file in the case study, in the section "Write the contract and validate".
Replace everything in this file with the code from that section.
"""

raise NotImplementedError('scripts/contract.py is not written yet. See "Write the contract and validate" in the case study.')
