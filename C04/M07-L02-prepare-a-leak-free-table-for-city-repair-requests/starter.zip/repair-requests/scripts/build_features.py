"""Build the modelling table: the target and the features.

You write this file in the case study, in the section "Build the target and the features".
Replace everything in this file with the code from that section.
"""

import sys

sys.exit('scripts/build_features.py is not written yet. See "Build the target and the features" in the case study.')
