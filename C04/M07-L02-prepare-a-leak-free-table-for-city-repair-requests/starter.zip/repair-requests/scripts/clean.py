"""Clean the extracted requests.

You write this file in the case study, in the section "Clean the requests".
Replace everything in this file with the code from that section.
"""

import sys

sys.exit('scripts/clean.py is not written yet. See "Clean the requests" in the case study.')
