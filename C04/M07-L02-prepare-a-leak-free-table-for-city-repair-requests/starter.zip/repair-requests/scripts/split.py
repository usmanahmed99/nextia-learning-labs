"""Split the modelling table by time.

You write this file in the case study, in the section "Split by time".
Replace everything in this file with the code from that section.
"""

import sys

sys.exit('scripts/split.py is not written yet. See "Split by time" in the case study.')
