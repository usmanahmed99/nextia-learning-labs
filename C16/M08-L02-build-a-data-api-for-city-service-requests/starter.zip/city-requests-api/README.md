# city-requests-api (starter)

The starting point of the case study [Build a data API for city service requests](https://learning.nextia-ai.com/courses/api/m08/build-a-data-api-for-city-service-requests/). The page tells you what to build, step by step.

What is ready:

- `city_api/`: the settings, the API key check, the error shape, the request ID and body limit, and `GET /health`, as in the course.
- `city_api/schema.sql`: the table of the database.
- `scripts/get_db.py`: downloads and checks the database. `scripts/build_db.py`: builds it from the city's data instead.
- `scripts/offset_problem.py` and `scripts/time_pages.py`: two small experiments that the page uses.
- `tests/`: a 30-row test database and the first tests.

## Set up

```sh
python3 -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\Activate.ps1
python -m pip install -r requirements-lock.txt
python scripts/get_db.py
python -m pytest
```

## Data and licence

The code is under the MIT licence (`LICENSE`). The data is from NYC Open Data; `DATASET.md` describes it and every change.
