def test_health(client):
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}
    assert len(response.headers["X-Request-ID"]) == 12


def test_unknown_path_gives_404_in_the_standard_shape(client):
    response = client.get("/v1/nothing-here")
    assert response.status_code == 404
    assert response.json()["error"]["code"] == "not_found"
