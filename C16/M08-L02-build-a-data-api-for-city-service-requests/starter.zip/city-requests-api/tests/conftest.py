import csv
import sqlite3
from dataclasses import replace
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from city_api.config import Settings
from city_api.main import create_app

HERE = Path(__file__).parent
SCHEMA = HERE.parent / "city_api" / "schema.sql"


def build_fixture_db(path: Path) -> None:
    """Make a 30-row database with the real schema, from fixture_rows.csv."""
    con = sqlite3.connect(path)
    con.executescript(SCHEMA.read_text(encoding="utf-8"))
    with (HERE / "fixture_rows.csv").open(newline="", encoding="utf-8") as file:
        rows = [[value or None for value in row.values()] for row in csv.DictReader(file)]
    con.executemany(f"INSERT INTO service_requests VALUES ({', '.join('?' * 15)})", rows)
    con.executemany(
        "INSERT INTO meta VALUES (?, ?)",
        [
            ("source", "Test rows from NYC 311 Service Requests"),
            ("pulled_on", "2026-10-07"),
            ("created_from", "2025-03-01"),
            ("created_to", "2025-03-13"),
            ("rows", str(len(rows))),
            ("rules", "The rules of scripts/build_db.py."),
        ],
    )
    con.execute("PRAGMA user_version = 1")
    con.commit()
    con.close()


@pytest.fixture(scope="session")
def fixture_db(tmp_path_factory) -> Path:
    path = tmp_path_factory.mktemp("data") / "fixture.db"
    build_fixture_db(path)
    return path


@pytest.fixture
def make_client(fixture_db):
    """Return a function that makes a test client with changed settings."""
    settings = Settings(
        api_key=None,
        allowed_origins=[],
        database_path=fixture_db,
        log_level="WARNING",
        show_docs=True,
    )

    def make(**changes) -> TestClient:
        return TestClient(create_app(replace(settings, **changes)))

    return make


@pytest.fixture
def client(make_client) -> TestClient:
    return make_client()
