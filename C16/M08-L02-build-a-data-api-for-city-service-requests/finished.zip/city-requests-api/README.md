# city-requests-api

A read-only web API over New York City's 311 street-repair requests from January to June 2025: 109,915 requests about potholes, traffic signals, street lights, sidewalks and signs. Dashboards use it to list and filter requests page by page, and to get daily numbers: requests opened, the share closed within 14 days, and the median days to close.

Built with FastAPI and SQLite. The database is opened read-only, every query is parameterised, and pages use a keyset cursor, so paging through a filter never repeats or skips a request.

## Requirements

- Python 3.12 or newer.
- For the Postman checks: the Postman CLI (`postman --version`).

## Set up

```sh
python3 -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\Activate.ps1
python -m pip install -r requirements-lock.txt
python scripts/get_db.py             # downloads and checks the database (8 MB)
```

To build the database yourself from the city's data instead: `python scripts/build_db.py`. `DATASET.md` describes the data and every change.

## Run

```sh
API_KEY=local-dev-key fastapi dev    # development, http://127.0.0.1:8000
API_KEY=local-dev-key fastapi run    # production mode, listens on 0.0.0.0:8000
```

The documentation is at `/docs` (Swagger UI) and `/redoc`, unless `SHOW_DOCS=false`. Settings are environment variables; `.env.example` lists them.

| Endpoint | Meaning |
|---|---|
| `GET /v1/service-requests` | Requests, oldest first, filtered by `borough`, `complaint_type`, `status`, `created_from`, `created_to`; `limit` 1 to 200 (default 50); follow `next_cursor` |
| `GET /v1/service-requests/{id}` | One request |
| `GET /v1/complaint-types` | The complaint types, with the number of requests |
| `GET /v1/stats/daily` | Opened, closed within 14 days and median days to close, per day; at most 92 days |
| `GET /v1/dataset` | The source, the snapshot date and the cleaning rules |
| `GET /health`, `GET /ready` | Liveness, and readiness (the database can be read) |

Every `/v1` endpoint needs the `X-API-Key` header when `API_KEY` is set. Every error has the shape `{"error": {"code", "message", "request_id", "fields"}}`. Codes: `invalid_request`, `invalid_range`, `invalid_cursor`, `range_too_large`, `not_found`, `unauthorized`, `database_unavailable`, `internal_error`.

## Check

```sh
python -m pytest
postman collection run postman/city-requests-api.postman_collection.json -e postman/local.postman_environment.json --env-var "apiKey=local-dev-key"
```

The tests use a 30-row database made from `tests/fixture_rows.csv`, so they do not need the download. When the contract test fails, read the difference. If the change is intended, run `python -m city_api.export_contract`, and review `contract/openapi.json`.

## Data and licence

The code is under the MIT licence (`LICENSE`). The data is from NYC Open Data, 311 Service Requests (erm2-nwe9), agency DOT, snapshot of 2026-10-07, cleaned as described in `DATASET.md`. NYC Open Data has no restrictions on use.
