import sqlite3
from pathlib import Path

SCHEMA_VERSION = 1  # scripts/build_db.py writes it with PRAGMA user_version


class DatabaseUnavailable(Exception):
    """The database cannot be read now. The request may work later."""


def connect(path: Path) -> sqlite3.Connection:
    """Open the database read-only.

    mode=ro: SQLite refuses every write, even a wrong one in our code.
    immutable=1: we promise that the file never changes while the API runs,
    so SQLite does not lock it or check it for changes made by others.
    """
    if not path.is_file():
        raise DatabaseUnavailable(f"no database file at {path}")
    uri = f"{path.resolve().as_uri()}?mode=ro&immutable=1"
    try:
        con = sqlite3.connect(uri, uri=True, check_same_thread=False)
        version = con.execute("PRAGMA user_version").fetchone()[0]
    except sqlite3.Error as exc:
        raise DatabaseUnavailable(f"cannot read {path}: {exc}") from None
    if version != SCHEMA_VERSION:
        con.close()
        raise DatabaseUnavailable(
            f"{path} has schema version {version}, expected {SCHEMA_VERSION}"
        )
    con.row_factory = sqlite3.Row
    return con
