-- The database that the API reads. scripts/build_db.py makes it from the
-- NYC 311 file, and tests/conftest.py makes a small copy for the tests.
-- Change it only together with SCHEMA_VERSION in city_api/db.py.

CREATE TABLE service_requests (
    id               INTEGER PRIMARY KEY,  -- the city's unique_key
    created_at       TEXT NOT NULL,        -- New York local time, 2025-03-01T07:00:00
    closed_at        TEXT,                 -- as published; NULL while not closed
    status           TEXT CHECK (status IN ('open', 'assigned', 'in_progress', 'pending', 'closed')),
    complaint_type   TEXT NOT NULL,        -- for example 'Street Condition'
    descriptor       TEXT,                 -- for example 'Pothole'
    location_type    TEXT,                 -- for example 'Street', 'Sidewalk'
    borough          TEXT CHECK (borough IN ('bronx', 'brooklyn', 'manhattan', 'queens', 'staten_island')),
    community_board  TEXT,                 -- for example '07 BROOKLYN'
    council_district INTEGER,
    incident_zip     TEXT,
    channel          TEXT CHECK (channel IN ('online', 'phone', 'mobile', 'other')),
    latitude         REAL,
    longitude        REAL,
    days_to_close    REAL,                 -- closed_at - created_at in days, when closed_at is set
    CHECK (closed_at IS NULL OR closed_at >= created_at),
    CHECK ((closed_at IS NULL) = (days_to_close IS NULL))
);

-- One index for each way the API reads the table. Each one ends with
-- (created_at, id), the order of the pages.
CREATE INDEX ix_created ON service_requests (created_at, id);
CREATE INDEX ix_borough_created ON service_requests (borough, created_at, id);
CREATE INDEX ix_type_created ON service_requests (complaint_type, created_at, id);
CREATE INDEX ix_status_created ON service_requests (status, created_at, id);

-- Facts about the data: its source, its snapshot date and the rules applied.
CREATE TABLE meta (
    name  TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
