import sqlite3
from collections.abc import Iterator
from datetime import datetime
from typing import Annotated

from fastapi import APIRouter, Depends, Path, Query, Request

from city_api import db, queries
from city_api.errors import ApiError
from city_api.models import (
    ComplaintTypeList,
    DailyStats,
    DatasetInfo,
    ErrorResponse,
    ListQuery,
    ServiceRequest,
    ServiceRequestPage,
    StatsQuery,
)
from city_api.pagination import decode_cursor, encode_cursor
from city_api.security import require_api_key

MAX_STATS_DAYS = 92

ERRORS = {
    401: {"model": ErrorResponse, "description": "The API key is missing or wrong."},
    422: {"model": ErrorResponse, "description": "A parameter is not valid."},
    503: {"model": ErrorResponse, "description": "The data is not available."},
}

router = APIRouter(prefix="/v1", dependencies=[Depends(require_api_key)], responses=ERRORS)


def get_db(request: Request) -> Iterator[sqlite3.Connection]:
    """Give the route a read-only connection, and close it after the response."""
    con = db.connect(request.app.state.settings.database_path)
    try:
        yield con
    finally:
        con.close()


Database = Annotated[sqlite3.Connection, Depends(get_db)]


def iso(moment: datetime | None) -> str | None:
    """2025-03-01 00:00 -> '2025-03-01T00:00:00', the format of the database."""
    return moment.isoformat() if moment else None


def check_range(start, end) -> None:
    if start is not None and end is not None and start >= end:
        raise ApiError(
            422,
            "invalid_range",
            "created_from must be before created_to.",
            ["created_from", "created_to"],
        )


@router.get(
    "/service-requests",
    tags=["service requests"],
    summary="List service requests, one page at a time",
    description=(
        "Requests that match every filter, oldest first (by created_at, then id). "
        "Each page has at most `limit` requests. If `next_cursor` is not null, send it "
        "as `cursor`, with the same filters, to get the next page."
    ),
)
def list_service_requests(
    query: Annotated[ListQuery, Query()], con: Database
) -> ServiceRequestPage:
    check_range(query.created_from, query.created_to)
    filters = {
        "borough": query.borough,
        "complaint_type": query.complaint_type,
        "status": query.status,
        "created_from": iso(query.created_from),
        "created_to": iso(query.created_to),
    }
    after = decode_cursor(query.cursor, filters) if query.cursor else None
    rows = queries.list_requests(con, filters, after, query.limit)
    page = rows[: query.limit]
    next_cursor = None
    if len(rows) > query.limit:
        last = page[-1]
        next_cursor = encode_cursor(last["created_at"], last["id"], filters)
    return ServiceRequestPage(items=[dict(row) for row in page], next_cursor=next_cursor)


@router.get(
    "/service-requests/{request_id}",
    tags=["service requests"],
    summary="Get one service request",
    responses={404: {"model": ErrorResponse, "description": "No request has this ID."}},
)
def get_service_request(
    request_id: Annotated[int, Path(ge=1, description="The request's id.")], con: Database
) -> ServiceRequest:
    row = queries.get_request(con, request_id)
    if row is None:
        raise ApiError(404, "not_found", f"No service request has the ID {request_id}.")
    return ServiceRequest(**dict(row))


@router.get(
    "/complaint-types",
    tags=["service requests"],
    summary="List the complaint types, with the number of requests",
)
def list_complaint_types(con: Database) -> ComplaintTypeList:
    return ComplaintTypeList(items=[dict(row) for row in queries.complaint_types(con)])


@router.get(
    "/stats/daily",
    tags=["statistics"],
    summary="Count the requests opened and closed for each day",
    description=(
        "For each day from `created_from` to the day before `created_to`: the requests "
        "opened, how many of them were closed within 14 days, and the median days to "
        f"close. The range is at most {MAX_STATS_DAYS} days. Days without requests are "
        "included, with `opened` 0."
    ),
)
def daily_stats(query: Annotated[StatsQuery, Query()], con: Database) -> DailyStats:
    check_range(query.created_from, query.created_to)
    if (query.created_to - query.created_from).days > MAX_STATS_DAYS:
        raise ApiError(
            422,
            "range_too_large",
            f"The range is longer than {MAX_STATS_DAYS} days. Ask for a shorter one.",
            ["created_from", "created_to"],
        )
    filters = {"borough": query.borough, "complaint_type": query.complaint_type}
    items = queries.daily_stats(con, filters, query.created_from, query.created_to)
    return DailyStats(items=items)


@router.get(
    "/dataset",
    tags=["statistics"],
    summary="Where the data comes from, and its snapshot date",
)
def dataset(con: Database) -> DatasetInfo:
    return DatasetInfo(**queries.dataset_info(con))
