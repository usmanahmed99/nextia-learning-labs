import json
from pathlib import Path

CONTRACT = Path(__file__).parent.parent / "contract" / "openapi.json"


def test_openapi_matches_the_reviewed_contract(client):
    current = json.dumps(client.get("/openapi.json").json(), indent=2) + "\n"
    reviewed = CONTRACT.read_text(encoding="utf-8")
    assert current == reviewed, (
        "The API contract changed. If the change is intended, run "
        "python -m city_api.export_contract and review the difference."
    )


def test_documented_request_is_the_real_one(client):
    schemas = client.get("/openapi.json").json()["components"]["schemas"]
    example = schemas["ServiceRequest"]["examples"][0]
    response = client.get(f"/v1/service-requests/{example['id']}")
    assert response.json() == example


def test_documented_examples_have_the_real_shape(client):
    # The examples show numbers of the full database; the tests have 30 rows.
    # So the test compares the fields, not the values.
    schemas = client.get("/openapi.json").json()["components"]["schemas"]
    page = client.get("/v1/service-requests", params={"limit": 1}).json()
    assert page.keys() == schemas["ServiceRequestPage"]["examples"][0].keys()
    day = client.get(
        "/v1/stats/daily", params={"created_from": "2025-03-03", "created_to": "2025-03-04"}
    ).json()["items"][0]
    assert day.keys() == schemas["DailyStats"]["examples"][0]["items"][0].keys()
