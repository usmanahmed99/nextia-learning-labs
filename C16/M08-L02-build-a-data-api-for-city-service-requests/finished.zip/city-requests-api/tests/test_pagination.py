import base64
import json

import pytest


def walk(client, limit, **filters) -> tuple[list[int], int]:
    """Follow next_cursor to the end. Return every id and the number of pages."""
    ids, pages, cursor = [], 0, None
    while True:
        params = {"limit": limit, **filters}
        if cursor:
            params["cursor"] = cursor
        response = client.get("/v1/service-requests", params=params)
        assert response.status_code == 200, response.text
        body = response.json()
        assert len(body["items"]) <= limit
        ids += [item["id"] for item in body["items"]]
        pages += 1
        cursor = body["next_cursor"]
        if cursor is None:
            return ids, pages


def one_page(client, **filters) -> list[int]:
    response = client.get("/v1/service-requests", params={"limit": 200, **filters})
    return [item["id"] for item in response.json()["items"]]


@pytest.mark.parametrize("limit", [1, 2, 4, 7, 29, 30, 31])
def test_paging_gives_every_request_once(client, limit):
    ids, pages = walk(client, limit)
    assert len(ids) == len(set(ids)) == 30  # no duplicates, no gaps
    assert ids == one_page(client)  # in the same order
    assert pages == -(-30 // limit)  # 30 / limit, rounded up


@pytest.mark.parametrize(
    "filters",
    [
        {"borough": "staten_island"},
        {"complaint_type": "Street Condition"},
        {"created_from": "2025-03-03", "created_to": "2025-03-05"},
    ],
)
def test_paging_with_filters(client, filters):
    ids, _ = walk(client, 2, **filters)
    assert ids == one_page(client, **filters)
    assert len(ids) == len(set(ids))


def test_a_page_can_end_inside_a_group_of_equal_times(client):
    # Six requests have created_at 2025-03-03T07:00:00. Pages of 4 split them.
    params = {"created_from": "2025-03-03T07:00:00", "created_to": "2025-03-03T07:00:01"}
    first = client.get("/v1/service-requests", params={"limit": 4, **params}).json()
    second = client.get(
        "/v1/service-requests",
        params={"limit": 4, "cursor": first["next_cursor"], **params},
    ).json()
    assert len(first["items"]) == 4 and len(second["items"]) == 2
    assert second["next_cursor"] is None


def test_the_limit_may_change_between_pages(client):
    first = client.get("/v1/service-requests", params={"limit": 5}).json()
    rest = client.get(
        "/v1/service-requests", params={"limit": 200, "cursor": first["next_cursor"]}
    ).json()
    ids = [item["id"] for item in first["items"] + rest["items"]]
    assert ids == one_page(client)


def make_cursor(data) -> str:
    return base64.urlsafe_b64encode(json.dumps(data).encode()).decode().rstrip("=")


@pytest.mark.parametrize(
    "cursor",
    [
        "abc",
        "!!!",
        make_cursor({"c": "2025-03-03T07:00:00"}),
        make_cursor({"c": "yesterday", "i": 1, "f": "x"}),
        make_cursor({"c": "2025-03-03T07:00:00", "i": "1", "f": "x"}),
        make_cursor([1, 2]),
    ],
)
def test_broken_cursor_gives_invalid_cursor(client, cursor):
    response = client.get("/v1/service-requests", params={"cursor": cursor})
    assert response.status_code == 422
    assert response.json()["error"]["code"] == "invalid_cursor"
    assert response.json()["error"]["fields"] == ["cursor"]


def test_cursor_from_other_filters_gives_invalid_cursor(client):
    page = client.get("/v1/service-requests", params={"limit": 2, "borough": "bronx"})
    response = client.get(
        "/v1/service-requests",
        params={"limit": 2, "borough": "queens", "cursor": page.json()["next_cursor"]},
    )
    assert response.status_code == 422
    assert response.json()["error"]["code"] == "invalid_cursor"
