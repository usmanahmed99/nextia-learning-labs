import sqlite3

import pytest

from city_api import db
from city_api.models import EXAMPLE_REQUEST


def get_ids(client, **params) -> list[int]:
    response = client.get("/v1/service-requests", params={"limit": 200, **params})
    assert response.status_code == 200, response.text
    return [item["id"] for item in response.json()["items"]]


def test_get_one_request(client):
    response = client.get("/v1/service-requests/64246800")
    assert response.status_code == 200
    assert response.json() == EXAMPLE_REQUEST


def test_unknown_id_gives_404(client):
    response = client.get("/v1/service-requests/1")
    assert response.status_code == 404
    assert response.json()["error"]["code"] == "not_found"


@pytest.mark.parametrize("bad_id", ["0", "abc", "1.5"])
def test_invalid_id_gives_422(client, bad_id):
    response = client.get(f"/v1/service-requests/{bad_id}")
    assert response.status_code == 422
    assert response.json()["error"]["fields"] == ["request_id"]


def test_list_is_oldest_first(client):
    response = client.get("/v1/service-requests")
    body = response.json()
    assert len(body["items"]) == 30
    assert body["next_cursor"] is None
    keys = [(item["created_at"], item["id"]) for item in body["items"]]
    assert keys == sorted(keys)


@pytest.mark.parametrize(
    ("params", "count"),
    [
        ({"borough": "staten_island"}, 7),
        ({"status": "assigned"}, 2),
        ({"complaint_type": "Traffic Signal Condition"}, 7),
        ({"created_from": "2025-03-03", "created_to": "2025-03-04"}, 11),
        ({"created_from": "2025-03-03T07:00:00", "created_to": "2025-03-03T07:00:01"}, 6),
        ({"borough": "bronx", "complaint_type": "Traffic Signal Condition"}, 3),
    ],
)
def test_filters(client, params, count):
    assert len(get_ids(client, **params)) == count


def test_filters_without_a_match_give_an_empty_page(client):
    response = client.get("/v1/service-requests", params={"status": "open"})
    assert response.status_code == 200
    assert response.json() == {"items": [], "next_cursor": None}


@pytest.mark.parametrize(
    ("params", "field"),
    [
        ({"borough": "Queens"}, "borough"),
        ({"borough": "unspecified"}, "borough"),
        ({"status": "done"}, "status"),
        ({"limit": "0"}, "limit"),
        ({"limit": "201"}, "limit"),
        ({"limit": "ten"}, "limit"),
        ({"created_from": "March 3"}, "created_from"),
        ({"created_from": "2025-03-03T07:00:00Z"}, "created_from"),
        ({"complaint_type": "x" * 61}, "complaint_type"),
        ({"boro": "queens"}, "boro"),
    ],
)
def test_invalid_parameters_name_the_field(client, params, field):
    response = client.get("/v1/service-requests", params=params)
    assert response.status_code == 422
    assert response.json()["error"]["code"] == "invalid_request"
    assert response.json()["error"]["fields"] == [field]


@pytest.mark.parametrize("limit", [1, 200])
def test_limit_boundaries_are_accepted(client, limit):
    response = client.get("/v1/service-requests", params={"limit": limit})
    assert response.status_code == 200
    assert len(response.json()["items"]) == min(limit, 30)


@pytest.mark.parametrize(
    ("start", "end"), [("2025-03-04", "2025-03-03"), ("2025-03-03", "2025-03-03")]
)
def test_empty_or_reversed_range_gives_invalid_range(client, start, end):
    response = client.get(
        "/v1/service-requests", params={"created_from": start, "created_to": end}
    )
    assert response.status_code == 422
    assert response.json()["error"]["code"] == "invalid_range"


def test_sql_in_a_filter_is_only_text(client):
    attack = "x' OR '1'='1"
    response = client.get("/v1/service-requests", params={"complaint_type": attack})
    assert response.status_code == 200
    assert response.json()["items"] == []


def test_complaint_types_with_counts(client):
    items = client.get("/v1/complaint-types").json()["items"]
    assert items[0] == {"complaint_type": "Street Condition", "count": 12}
    assert sum(item["count"] for item in items) == 30
    counts = [item["count"] for item in items]
    assert counts == sorted(counts, reverse=True)


def test_dataset_info(client):
    body = client.get("/v1/dataset").json()
    assert body["rows"] == 30
    assert body["pulled_on"] == "2026-10-07"


def test_api_key_is_required_when_set(make_client):
    client = make_client(api_key="test-key")
    assert client.get("/v1/complaint-types").status_code == 401
    assert client.get("/health").status_code == 200
    response = client.get("/v1/complaint-types", headers={"X-API-Key": "test-key"})
    assert response.status_code == 200


def test_the_connection_cannot_write(fixture_db):
    con = db.connect(fixture_db)
    with pytest.raises(sqlite3.OperationalError, match="readonly"):
        con.execute("DELETE FROM service_requests")
    con.close()


def test_cors_allows_only_configured_origins(make_client):
    client = make_client(allowed_origins=["https://dashboards.example"])
    preflight = {"Access-Control-Request-Method": "GET"}
    allowed = client.options(
        "/v1/complaint-types", headers={"Origin": "https://dashboards.example", **preflight}
    )
    other = client.options(
        "/v1/complaint-types", headers={"Origin": "https://evil.example", **preflight}
    )
    assert allowed.headers["access-control-allow-origin"] == "https://dashboards.example"
    assert "access-control-allow-origin" not in other.headers
