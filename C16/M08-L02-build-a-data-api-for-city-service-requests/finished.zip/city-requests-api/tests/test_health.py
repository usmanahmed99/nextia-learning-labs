import sqlite3
from pathlib import Path


def test_health(client):
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}
    assert len(response.headers["X-Request-ID"]) == 12


def test_unknown_path_gives_404_in_the_standard_shape(client):
    response = client.get("/v1/nothing-here")
    assert response.status_code == 404
    assert response.json()["error"]["code"] == "not_found"


def test_ready_with_the_database(client):
    response = client.get("/ready")
    assert response.status_code == 200
    assert response.json() == {"status": "ready"}


def test_not_ready_without_the_database(make_client):
    client = make_client(database_path=Path("no/such/file.db"))
    assert client.get("/health").status_code == 200
    response = client.get("/ready")
    assert response.status_code == 503
    assert response.json()["error"]["code"] == "database_unavailable"
    assert "no/such" not in response.text  # no internal paths for the client
    assert client.get("/v1/complaint-types").status_code == 503


def test_not_ready_with_an_old_schema(make_client, tmp_path):
    old = tmp_path / "old.db"
    sqlite3.connect(old).execute("CREATE TABLE service_requests (id INTEGER)")
    response = make_client(database_path=old).get("/ready")
    assert response.status_code == 503
