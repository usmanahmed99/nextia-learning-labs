"""Time a deep page with OFFSET and with a keyset, on the real database.

    python scripts/time_pages.py
"""

import sqlite3
import time
from pathlib import Path

DB = Path(__file__).resolve().parent.parent / "data" / "service_requests_2025h1.db"
con = sqlite3.connect(f"{DB.resolve().as_uri()}?mode=ro&immutable=1", uri=True)
SELECT = "SELECT * FROM service_requests"


def best_of_five(sql: str, params=()) -> float:
    """The fastest of five runs, in milliseconds."""
    times = []
    for _ in range(5):
        start = time.perf_counter()
        con.execute(sql, params).fetchall()
        times.append((time.perf_counter() - start) * 1000)
    return min(times)


for skip in (0, 10_000, 50_000, 100_000):
    offset = best_of_five(f"{SELECT} ORDER BY created_at, id LIMIT 50 OFFSET {skip}")
    # The keyset page starts after the last row that OFFSET skips.
    last = con.execute(
        "SELECT created_at, id FROM service_requests ORDER BY created_at, id "
        "LIMIT 1 OFFSET ?",
        (skip - 1,),
    ).fetchone() if skip else ("", 0)
    keyset = best_of_five(
        f"{SELECT} WHERE (created_at, id) > (?, ?) ORDER BY created_at, id LIMIT 50", last
    )
    print(f"page after {skip:>7,} rows: OFFSET {offset:5.2f} ms   keyset {keyset:5.2f} ms")
