"""Show why OFFSET pages lose rows when the data changes between two pages.

    python scripts/offset_problem.py

A dashboard reads the open requests, two per page. Between page 1 and page 2,
the city closes request 102. The script reads the pages twice: with OFFSET,
and with a keyset (the position after the last row of the page).
"""

import sqlite3

con = sqlite3.connect(":memory:")
con.execute("CREATE TABLE requests (id INTEGER PRIMARY KEY, created_at TEXT, status TEXT)")
con.executemany(
    "INSERT INTO requests VALUES (?, ?, 'open')",
    [
        (101, "2025-03-03T07:00:00"),
        (102, "2025-03-03T07:00:00"),
        (103, "2025-03-03T08:15:00"),
        (104, "2025-03-03T09:40:00"),
        (105, "2025-03-03T11:05:00"),
        (106, "2025-03-03T12:30:00"),
    ],
)
OPEN = "SELECT id, created_at FROM requests WHERE status = 'open'"


def close_102() -> None:
    con.execute("UPDATE requests SET status = 'closed' WHERE id = 102")


def reopen_102() -> None:
    con.execute("UPDATE requests SET status = 'open' WHERE id = 102")


print("With OFFSET:")
page1 = con.execute(f"{OPEN} ORDER BY created_at, id LIMIT 2 OFFSET 0").fetchall()
print("  page 1:", [row[0] for row in page1])
close_102()
page2 = con.execute(f"{OPEN} ORDER BY created_at, id LIMIT 2 OFFSET 2").fetchall()
print("  request 102 is closed")
print("  page 2:", [row[0] for row in page2])
reopen_102()

print("With a keyset (after the last row of the page):")
page1 = con.execute(f"{OPEN} ORDER BY created_at, id LIMIT 2").fetchall()
print("  page 1:", [row[0] for row in page1])
close_102()
last_id, last_created = page1[-1]
page2 = con.execute(
    f"{OPEN} AND (created_at, id) > (?, ?) ORDER BY created_at, id LIMIT 2",
    (last_created, last_id),
).fetchall()
print("  request 102 is closed")
print("  page 2:", [row[0] for row in page2])
