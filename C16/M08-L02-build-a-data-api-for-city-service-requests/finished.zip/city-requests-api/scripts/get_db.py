"""Download the database of the case study, check it, and unpack it.

    python scripts/get_db.py                  # downloads about 8 MB
    python scripts/get_db.py --file FILE      # uses a .db.gz that you have

It writes data/service_requests_2025h1.db (about 36 MB). To make the same
database yourself from the NYC 311 file, use scripts/build_db.py instead.
"""

import argparse
import gzip
import hashlib
import shutil
import sqlite3
import sys
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
URL = (
    "https://github.com/usmanahmed99/nextia-learning-labs/raw/main/"
    "C16/case-studies/data/service_requests_2025h1.db.gz"
)
SHA256 = "26492959add9a514ffe9f31648279282cb411e1720500f270dd6098fcaeab209"
GZ = ROOT / "data" / "service_requests_2025h1.db.gz"
DB = ROOT / "data" / "service_requests_2025h1.db"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as file:
        for block in iter(lambda: file.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--file", help="a local copy of service_requests_2025h1.db.gz")
    args = parser.parse_args()

    GZ.parent.mkdir(exist_ok=True)
    if args.file:
        shutil.copyfile(args.file, GZ)
    elif not GZ.exists():
        print(f"Downloading {URL}")
        urllib.request.urlretrieve(URL, GZ)
    if sha256(GZ) != SHA256:
        GZ.unlink()
        sys.exit("The download is not the expected file (SHA-256 differs). Run the script again.")
    print(f"Checked {GZ.name}: SHA-256 {SHA256[:12]}... is correct")

    with gzip.open(GZ, "rb") as source, DB.open("wb") as target:
        shutil.copyfileobj(source, target)
    con = sqlite3.connect(f"{DB.resolve().as_uri()}?mode=ro", uri=True)
    rows = con.execute("SELECT COUNT(*) FROM service_requests").fetchone()[0]
    con.close()
    print(f"Wrote {DB.relative_to(ROOT)}: {rows:,} service requests")


if __name__ == "__main__":
    main()
