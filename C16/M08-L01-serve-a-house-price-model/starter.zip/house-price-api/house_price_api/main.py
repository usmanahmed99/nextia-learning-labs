import logging
import time
import uuid

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware

from house_price_api.config import Settings, load_settings
from house_price_api.errors import add_error_handlers, error_response
from house_price_api.models import Health

MAX_BODY_BYTES = 16_384

logger = logging.getLogger("house_price_api")

DESCRIPTION = """
First estimates of the sale price of houses in King County, Washington, at
2014-15 prices, for a valuation team before a human appraisal.

**Not for lending, underwriting or insurance decisions.** The model card is at
`/v1/model`. Every error has the same shape:
`{"error": {"code": ..., "message": ..., "request_id": ..., "fields": [...]}}`.
"""


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or load_settings()
    logging.basicConfig(
        level=settings.log_level, format="%(levelname)s %(name)s: %(message)s"
    )

    app = FastAPI(
        title="House Price Estimate API",
        version="1.0.0",
        description=DESCRIPTION,
        license_info={"name": "MIT", "identifier": "MIT"},
        openapi_tags=[
            {"name": "estimates", "description": "Estimate house prices."},
            {"name": "health", "description": "Check that the service runs."},
        ],
        docs_url="/docs" if settings.show_docs else None,
        redoc_url="/redoc" if settings.show_docs else None,
        openapi_url="/openapi.json" if settings.show_docs else None,
    )
    app.state.settings = settings
    if settings.api_key is None:
        logger.warning("API_KEY is not set: /v1/estimates accepts requests without a key")

    @app.middleware("http")
    async def request_id_and_limits(request: Request, call_next):
        request.state.request_id = uuid.uuid4().hex[:12]
        started = time.perf_counter()
        length = request.headers.get("content-length")
        if length and int(length) > MAX_BODY_BYTES:
            response = error_response(
                request,
                413,
                "body_too_large",
                f"The body is larger than {MAX_BODY_BYTES} bytes.",
            )
        else:
            response = await call_next(request)
        response.headers["X-Request-ID"] = request.state.request_id
        logger.info(
            "%s %s %d %.0fms id=%s",
            request.method,
            request.url.path,
            response.status_code,
            (time.perf_counter() - started) * 1000,
            request.state.request_id,
        )
        return response

    if settings.allowed_origins:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=settings.allowed_origins,
            allow_methods=["GET", "POST"],
            allow_headers=["Content-Type", "X-API-Key"],
        )

    add_error_handlers(app)

    @app.get("/health", tags=["health"], summary="Check that the service runs")
    def health() -> Health:
        return Health(status="ok")

    return app


app = create_app()
