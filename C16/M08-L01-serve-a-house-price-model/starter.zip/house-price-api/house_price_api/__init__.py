"""First price estimates for houses in King County, Washington."""
