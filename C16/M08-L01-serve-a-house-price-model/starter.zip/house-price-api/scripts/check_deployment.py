"""Check a running House Price Estimate API, and measure how fast it answers.

Run it from the project folder. Set the API key first, without typing it into
the command:

    read -s HOUSE_API_KEY && export HOUSE_API_KEY          # macOS and Linux
    $env:HOUSE_API_KEY = Read-Host "API key"               # Windows PowerShell

    python scripts/check_deployment.py https://house-price-api.fastapicloud.dev
    python scripts/check_deployment.py http://127.0.0.1:8000

It needs only the packages of the project (httpx comes with FastAPI). It checks that the API answers,
that it runs the reviewed model (the same SHA-256 as model/model_card.json),
that the golden houses get their expected estimates, and that wrong requests
get the right errors. Then it measures the time of 50 single estimates and of
3 batches of 100 houses. The exit code is 0 if every check passed, 1 if one
failed, and 2 if the key is missing.
"""

import json
import os
import statistics
import sys
import time
from pathlib import Path

import httpx

PROJECT = Path(__file__).resolve().parent.parent
GOLDEN = json.loads((PROJECT / "tests" / "golden_houses.json").read_text("utf-8"))
CARD = json.loads((PROJECT / "model" / "model_card.json").read_text("utf-8"))


class Api:
    """One connection to the API, kept open like a real client does."""

    def __init__(self, base_url: str, key: str):
        self.client = httpx.Client(base_url=base_url.rstrip("/"), timeout=60)
        self.key = key

    def send(self, method: str, path: str, body=None, key=True) -> tuple[int, dict, float]:
        headers = {"X-API-Key": self.key} if key else {}
        started = time.perf_counter()
        response = self.client.request(method, path, json=body, headers=headers)
        ms = (time.perf_counter() - started) * 1000
        try:
            payload = response.json()
        except ValueError:
            payload = {}
        return response.status_code, payload, ms


failures = []


def check(name: str, passed: bool, detail: str = "") -> None:
    print(f"  {'PASS' if passed else 'FAIL'}  {name}{'  (' + detail + ')' if detail else ''}")
    if not passed:
        failures.append(name)


def main() -> int:
    if len(sys.argv) != 2:
        print(__doc__)
        return 2
    key = os.environ.get("HOUSE_API_KEY", "")
    if not key:
        print("Set HOUSE_API_KEY first (see the top of this file).", file=sys.stderr)
        return 2
    api = Api(sys.argv[1], key)
    typical = GOLDEN[0]["house"]

    print("1. The first request (includes the start of a sleeping app)")
    status, _, first_ms = api.send("GET", "/health", key=False)
    check("GET /health is 200", status == 200, f"{first_ms:.0f} ms")

    print("2. Readiness and the model")
    status, body, _ = api.send("GET", "/ready", key=False)
    check("GET /ready is 200", status == 200, json.dumps(body))
    status, card, _ = api.send("GET", "/v1/model", key=False)
    check("GET /v1/model is 200", status == 200)
    check("the server runs the reviewed model file", card.get("sha256") == CARD["sha256"], card.get("model_version", "?"))

    print("3. Golden houses")
    for golden in GOLDEN:
        status, body, ms = api.send("POST", "/v1/estimates", golden["house"])
        expected = golden["expected"]
        same = (
            status == 200
            and body.get("estimate_usd") == expected["estimate_usd"]
            and body.get("range_usd") == expected["range_usd"]
            and [w["code"] for w in body.get("warnings", [])] == expected["warnings"]
        )
        check(f"{golden['name']}: {expected['estimate_usd']:,} USD", same, f"got {body.get('estimate_usd')}, {ms:.0f} ms")

    print("4. Wrong requests")
    status, body, _ = api.send("POST", "/v1/estimates", typical, key=False)
    check("no key gives 401", status == 401, body.get("error", {}).get("code", ""))
    status, body, _ = api.send("POST", "/v1/estimates", {**typical, "lat": 40.7128, "long": -74.006})
    check("New York gives 422 outside_model_area", status == 422 and body["error"]["code"] == "outside_model_area")
    status, body, _ = api.send("POST", "/v1/estimates", {**typical, "bedrooms": "three"})
    check("bedrooms as text gives 422 invalid_request", status == 422 and body["error"]["fields"] == ["bedrooms"])
    status, _, _ = api.send("POST", "/v1/estimates/batch", {"houses": [typical] * 101})
    check("101 houses give 422", status == 422)
    status, _, _ = api.send("GET", "/docs", key=False)
    print(f"  INFO  GET /docs is {status} (404 when SHOW_DOCS=false)")

    print("5. Speed (one connection, kept open)")
    times = [api.send("POST", "/v1/estimates", typical)[2] for _ in range(50)]
    times.sort()
    print(
        f"  50 single estimates: median {statistics.median(times):.0f} ms, "
        f"90th percentile {times[44]:.0f} ms, slowest {times[-1]:.0f} ms"
    )
    batch = {"houses": [typical] * 100}
    batch_times = []
    for _ in range(3):
        status, body, ms = api.send("POST", "/v1/estimates/batch", batch)
        batch_times.append(ms)
    check("a batch of 100 gives 100 estimates", status == 200 and len(body.get("estimates", [])) == 100)
    print(f"  3 batches of 100 houses: median {statistics.median(batch_times):.0f} ms")

    print()
    print("All checks passed." if not failures else f"{len(failures)} check(s) failed: {failures}")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
