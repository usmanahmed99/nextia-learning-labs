# house-price-api (starter)

The starter project of the Nextia Learning case study *Serve a house-price model*
(course C16, *Build and Deploy Your First API*). The case study page guides you
step by step, from the virtual environment to a deployed API.

What is here:

- `model/`: a ready-made, trained model (`house_price.joblib`) and its card
  (`model_card.json`). Read `MODEL_CARD.md` first.
- `training/train.py`: the script that made the model. You do not need to run it.
- `house_price_api/`: an API with the parts that you know from the course:
  settings, the API key, the error shape, request IDs, the body limit and
  `/health`. You add the model and the endpoints.
- `tests/`: the first tests, and `golden_houses.json`: three real houses and the
  estimates that the finished API must give.
- `requests/`, `postman/`, `scripts/`: request bodies, a Postman collection to
  extend, and a check for the deployed API.

## Set up

```sh
python3 -m venv .venv                # Windows: python -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\Activate.ps1
python -m pip install -r requirements-lock.txt
python -m pytest                     # 2 passed
```

## Run

```sh
fastapi dev                          # http://127.0.0.1:8000/health
```

The code is under the MIT licence (`LICENSE`). The data behind the model is
*House Sales in King County, USA* (harlfoxem, Kaggle 2016; OpenML 42092), CC0 1.0.
