# Model card: king-county-house-price, version kc-hgb-2015-02

The machine-readable copy is `model/model_card.json`, which the API serves at `GET /v1/model`.

## Intended use

A **first estimate** of the sale price of a house in King County, Washington (the county of Seattle), before a human appraisal. A valuation team uses it to decide which appraisals to look at first, and to see early when an agreed price is far above the estimate.

**Users:** a valuation team and its intake tool, through this API.

## Not for

- **Lending, underwriting or insurance decisions** about a person: approving or refusing a loan, a rate, a premium or a limit.
- Setting a loan amount or a price. The appraisal stays the valuation.
- Houses outside King County. The API refuses them (`outside_model_area`).
- Today's prices. The model learned from sales between May 2014 and February 2015.

## Data

- **Source:** *House Sales in King County, USA* (harlfoxem, Kaggle 2016), via [OpenML dataset 42092](https://www.openml.org/d/42092), version 2. Public sale records of King County.
- **Licence:** [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) (public domain). Checked on 2026-10-07.
- **File:** `king_county_house_sales.csv.gz` from the Nextia labs repository, SHA-256 `0e2fd1937fbc724622e00fefebe060e28587882725663050c5c25fef74ce193c`. 21,613 sales, 2014-05-02 to 2015-05-27.
- **One fix:** one house with 33 bedrooms and 1,620 sq ft is set to 3 bedrooms (a typing error).
- **Split by time, with each house in one part:** the model learned from the 16,959 sales of houses first sold before 2015-03-01. The test set is the 4,654 sales of houses first sold from 2015-03-01 to 2015-05-27.

## Model

Gradient boosting (`HistGradientBoostingRegressor`, scikit-learn 1.9.1) on the logarithm of the price, learning rate 0.05, at most 600 trees (early stopping kept 332), `random_state=0`. 17 inputs: the description of the house, its latitude and longitude, and the size of its 15 nearest neighbours. The zip code is not an input.

`training/train.py` builds it again from the data in about 2 seconds, and gives the same file, byte for byte, with the same package versions.

## Results on the test set (used once)

| Measure | Value |
|---|---|
| Mean absolute percentage error (MAPE) | 12.8% |
| Estimates within 10% of the sale price | 50.2% |
| Estimates 10% or more too high | 12.6% |
| Median error (positive: the estimate is too low) | +6.4% |
| A quick valuer's method (zip-code price per sq ft), MAPE | 18.5% |

**The range.** In the test months, 80% of houses sold between 0.884 and 1.279 times their estimate. The API gives this range with every estimate. It is wider above the estimate, because the market rose in spring 2015 and the model did not see it.

## Known limits

- **The model lags the market.** In spring 2015, its estimates were about 6% too low for the typical house.
- **Estimates of 1 million dollars or more are weak.** Only about 4 in 10 were within 10% (validation months). The API adds the warning `high_estimate`.
- **It cannot see inside the house.** A new kitchen, damp or a recent renovation are invisible to it.
- **Sales that are not normal market sales** (inside a family, forced sales) are not marked in the data.
- **Location can stand in for protected characteristics.** In the United States, where a house is correlates with the income and race of the people who live there. Errors were similar across three large areas of the county, but that is not a fairness review. Any real use needs a review by the lender's compliance team, under rules such as the Fair Housing Act and the Equal Credit Opportunity Act.

## Owner and review

The valuation team's analyst owns the model. Retrain it every month with the latest sales. Each new model gets a new `model_version` and a new SHA-256 in `house_price_api/config.py`, in one reviewed change. Stop using the estimates if fewer than 45% of last month's estimates were within 10% of the sale price.

Source of the analysis: the Nextia case study *Estimate house prices* (C05).
