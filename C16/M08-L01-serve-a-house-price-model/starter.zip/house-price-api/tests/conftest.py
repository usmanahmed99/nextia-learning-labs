from dataclasses import replace

import pytest
from fastapi.testclient import TestClient

from house_price_api.config import Settings
from house_price_api.main import create_app

TEST_SETTINGS = Settings(
    api_key=None,
    allowed_origins=[],
    log_level="WARNING",
    show_docs=True,
)


@pytest.fixture
def make_client():
    """Return a function that makes a test client with changed settings."""

    def make(**changes) -> TestClient:
        return TestClient(create_app(replace(TEST_SETTINGS, **changes)))

    return make


@pytest.fixture
def client(make_client) -> TestClient:
    return make_client()
