def test_health(client):
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


def test_every_response_has_a_request_id(client):
    assert len(client.get("/health").headers["X-Request-ID"]) == 12
