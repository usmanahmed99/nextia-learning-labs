"""Train the house-price model again, and write model/house_price.joblib and
model/model_card.json.

Run it from the project folder, with the training packages installed
(requirements.txt):

    python training/train.py

It downloads the data (0.7 MB) into data/ the first time, and checks its
SHA-256. Training takes a few seconds. The model is the one from the
Nextia case study "Estimate house prices" (C05): gradient boosting on the
log of the price, with latitude and longitude for the place.

After a run, the script prints the new model file's SHA-256. If it differs
from MODEL_SHA256 in house_price_api/config.py, the API refuses the new
file until you change that line, and the model_version, in a reviewed change.
"""

import hashlib
import json
import platform
import time
from pathlib import Path

import httpx
import joblib
import numpy as np
import pandas as pd
import sklearn
from sklearn.compose import TransformedTargetRegressor
from sklearn.ensemble import HistGradientBoostingRegressor

PROJECT = Path(__file__).resolve().parent.parent
DATA_URL = (
    "https://github.com/usmanahmed99/nextia-learning-labs/raw/main/"
    "C05/case-studies/data/king_county_house_sales.csv.gz"
)
DATA_FILE = PROJECT / "data" / "king_county_house_sales.csv.gz"
DATA_SHA256 = "0e2fd1937fbc724622e00fefebe060e28587882725663050c5c25fef74ce193c"
MODEL_FILE = PROJECT / "model" / "house_price.joblib"
CARD_FILE = PROJECT / "model" / "model_card.json"

MODEL_VERSION = "kc-hgb-2015-02"
VALID_FROM = "2015-01-01"  # C05's validation months, January and February 2015
TEST_FROM = "2015-03-01"  # houses first sold from this day on are the test set
FEATURES = [
    "bedrooms", "bathrooms", "sqft_living", "sqft_lot", "floors", "waterfront",
    "view", "condition", "grade", "sqft_above", "sqft_basement", "yr_built",
    "yr_renovated", "lat", "long", "sqft_living15", "sqft_lot15",
]
# Inputs whose unusual values get a "rare_value" warning in the API.
RARE_CHECKED = [
    "bedrooms", "bathrooms", "sqft_living", "sqft_lot", "sqft_basement",
    "sqft_living15", "sqft_lot15",
]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_data() -> pd.DataFrame:
    if not DATA_FILE.exists():
        DATA_FILE.parent.mkdir(exist_ok=True)
        print("Downloading", DATA_URL)
        response = httpx.get(DATA_URL, follow_redirects=True, timeout=60)
        response.raise_for_status()
        DATA_FILE.write_bytes(response.content)
    if sha256(DATA_FILE) != DATA_SHA256:
        raise SystemExit(f"{DATA_FILE} is not the expected file. Delete it and run again.")
    houses = pd.read_csv(DATA_FILE, parse_dates=["date"])
    houses.loc[houses["bedrooms"] == 33, "bedrooms"] = 3  # 1,620 sq ft: a typing error for 3
    return houses


def report(real: pd.Series, estimate: np.ndarray) -> dict:
    """Errors as percentages of the real price (positive = the estimate is too low)."""
    pct = 100 * (real - estimate) / real
    return {
        "median_error_pct": round(float(np.median(pct)), 1),
        "mape_pct": round(float(np.mean(np.abs(pct))), 1),
        "within_10pct": round(float(np.mean(np.abs(pct) <= 10)), 3),
        "over_by_10pct_or_more": round(float(np.mean(pct < -10)), 3),
    }


def main() -> None:
    houses = load_data()
    # Every sale of a house goes where its first sale goes.
    first_sale = houses.groupby("id")["date"].transform("min")
    # The C05 case study's train part, then its validation part, in this
    # order: the order decides which rows boosting keeps aside to stop early.
    train = pd.concat([
        houses[first_sale < VALID_FROM],
        houses[(first_sale >= VALID_FROM) & (first_sale < TEST_FROM)],
    ])
    test = houses[first_sale >= TEST_FROM]
    print(f"train {len(train)} sales | test {len(test)} sales")

    model = TransformedTargetRegressor(
        regressor=HistGradientBoostingRegressor(
            learning_rate=0.05, max_iter=600, random_state=0
        ),
        func=np.log,
        inverse_func=np.exp,
    )
    started = time.perf_counter()
    model.fit(train[FEATURES].to_numpy(dtype=float), train["price"].to_numpy())
    print(f"trained in {time.perf_counter() - started:.1f} s")

    estimate = model.predict(test[FEATURES].to_numpy(dtype=float))
    test_result = report(test["price"], estimate)
    print("test:", test_result)

    # The range: 80% of the test sales sold between these two multiples of
    # their estimate.
    ratio = test["price"].to_numpy() / estimate
    low, high = np.quantile(ratio, [0.10, 0.90])
    inside = float(np.mean((ratio >= low) & (ratio <= high)))
    print(f"range: {low:.3f} to {high:.3f} times the estimate ({inside:.0%} of test sales inside)")

    MODEL_FILE.parent.mkdir(exist_ok=True)
    joblib.dump(model, MODEL_FILE, compress=3)
    digest = sha256(MODEL_FILE)

    usual = train[RARE_CHECKED].quantile([0.01, 0.99])
    card = {
        "name": "king-county-house-price",
        "model_version": MODEL_VERSION,
        "sha256": digest,
        "prices_as_of": str(train.loc[train["date"] < TEST_FROM, "date"].max().date()),
        "intended_use": (
            "A first estimate of the sale price of a house in King County, Washington, "
            "before a human appraisal."
        ),
        "not_for": [
            "lending, underwriting or insurance decisions about a person",
            "setting a loan amount or a price",
            "houses outside King County, Washington",
            "today's prices: the model knows sales from May 2014 to February 2015",
        ],
        "training_data": {
            "source": "House Sales in King County, USA (harlfoxem, Kaggle 2016; OpenML 42092)",
            "licence": "CC0 1.0",
            "file_sha256": DATA_SHA256,
            "sales": len(train),
            "first_sales": f"{train['date'].min().date()} to 2015-02-28",
        },
        "test": {
            "sales": len(test),
            "first_sales": f"{TEST_FROM} to {test['date'].max().date()}",
            **test_result,
        },
        "range": {"coverage": 0.8, "low_factor": round(float(low), 3), "high_factor": round(float(high), 3)},
        "usual_values": {
            column: [round(float(usual.loc[q, column]), 2) for q in (0.01, 0.99)]
            for column in RARE_CHECKED
        },
        "model": (
            "HistGradientBoostingRegressor on the log of the price, learning rate 0.05, "
            f"at most 600 trees (early stopping kept {model.regressor_.n_iter_})"
        ),
        "features": FEATURES,
        "trained_with": {
            "python": platform.python_version(),
            "scikit-learn": sklearn.__version__,
            "numpy": np.__version__,
            "joblib": joblib.__version__,
        },
    }
    CARD_FILE.write_text(json.dumps(card, indent=2) + "\n", encoding="utf-8")
    size_mb = MODEL_FILE.stat().st_size / 1e6
    print(f"wrote {MODEL_FILE.relative_to(PROJECT)} ({size_mb:.2f} MB) and {CARD_FILE.relative_to(PROJECT)}")
    print("sha256", digest)


if __name__ == "__main__":
    main()
