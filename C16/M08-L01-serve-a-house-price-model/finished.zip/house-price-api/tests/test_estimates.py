import json
from pathlib import Path

import pytest

GOLDEN = json.loads((Path(__file__).parent / "golden_houses.json").read_text("utf-8"))


@pytest.mark.parametrize("golden", GOLDEN, ids=[g["name"] for g in GOLDEN])
def test_golden_houses(client, golden):
    response = client.post("/v1/estimates", json=golden["house"])
    assert response.status_code == 200
    body = response.json()
    expected = golden["expected"]
    assert body["estimate_usd"] == expected["estimate_usd"]
    assert body["range_usd"] == expected["range_usd"]
    assert [w["code"] for w in body["warnings"]] == expected["warnings"]
    assert body["model_version"] == "kc-hgb-2015-02"
    assert body["prices_as_of"] == "2015-02-28"


def test_rare_value_names_the_fields(client):
    large_lot = GOLDEN[2]["house"]
    [warning] = client.post("/v1/estimates", json=large_lot).json()["warnings"]
    assert warning["fields"] == ["sqft_lot", "sqft_lot15"]


@pytest.mark.parametrize(
    ("field", "value"),
    [
        ("bedrooms", 0),
        ("bedrooms", 11),
        ("sqft_living", 14_000),
        ("yr_built", 1900),
        ("yr_built", 2015),
        ("floors", 3.5),
        ("bathrooms", 0.25),
    ],
)
def test_limits_are_accepted(client, house, field, value):
    house[field] = value
    assert client.post("/v1/estimates", json=house).status_code == 200


@pytest.mark.parametrize(
    ("field", "value"),
    [
        ("bedrooms", -1),
        ("bedrooms", 12),
        ("sqft_living", 14_001),
        ("yr_built", 1899),
        ("yr_built", 2016),
        ("floors", 1.25),
        ("bathrooms", 0.3),
        ("bedrooms", "three"),
        ("bedrooms", "3"),
        ("bedrooms", 2.5),
        ("waterfront", "no"),
        ("waterfront", 0),
        ("yr_renovated", 1950),
        ("sqft_basement", 1560),
    ],
)
def test_invalid_value_names_the_field(client, house, field, value):
    house[field] = value
    response = client.post("/v1/estimates", json=house)
    assert response.status_code == 422
    assert response.json()["error"]["code"] == "invalid_request"
    assert response.json()["error"]["fields"] == [field]


def test_missing_and_unknown_fields(client, house):
    del house["grade"]
    house["zipcode"] = 98006
    response = client.post("/v1/estimates", json=house)
    assert response.status_code == 422
    assert sorted(response.json()["error"]["fields"]) == ["grade", "zipcode"]


@pytest.mark.parametrize(
    ("changes", "fields"),
    [
        ({"lat": 40.71, "long": -74.0}, ["lat", "long"]),
        ({"lat": 47.9}, ["lat"]),
        ({"long": -121.2}, ["long"]),
    ],
)
def test_outside_model_area(client, house, changes, fields):
    response = client.post("/v1/estimates", json={**house, **changes})
    assert response.status_code == 422
    assert response.json()["error"]["code"] == "outside_model_area"
    assert response.json()["error"]["fields"] == fields


def test_batch_keeps_the_order(client):
    houses = [g["house"] for g in reversed(GOLDEN)]
    response = client.post("/v1/estimates/batch", json={"houses": houses})
    assert response.status_code == 200
    estimates = [e["estimate_usd"] for e in response.json()["estimates"]]
    assert estimates == [g["expected"]["estimate_usd"] for g in reversed(GOLDEN)]


@pytest.mark.parametrize("count", [0, 101])
def test_batch_size_limits(client, house, count):
    response = client.post("/v1/estimates/batch", json={"houses": [house] * count})
    assert response.status_code == 422
    assert response.json()["error"]["fields"] == ["houses"]


def test_batch_of_100_is_accepted(client, house):
    response = client.post("/v1/estimates/batch", json={"houses": [house] * 100})
    assert response.status_code == 200
    assert len(response.json()["estimates"]) == 100


def test_batch_names_the_house_and_the_field(client, house):
    wrong = {**house, "grade": 14}
    away = {**house, "lat": 40.71}
    response = client.post("/v1/estimates/batch", json={"houses": [house, wrong]})
    assert response.json()["error"]["fields"] == ["houses.1.grade"]
    response = client.post("/v1/estimates/batch", json={"houses": [house, house, away]})
    assert response.json()["error"]["code"] == "outside_model_area"
    assert response.json()["error"]["fields"] == ["houses.2.lat"]


def test_body_too_large(client, house):
    response = client.post(
        "/v1/estimates/batch",
        json={"houses": [house], "note": "x" * 70_000},
    )
    assert response.status_code == 413
    assert response.json()["error"]["code"] == "body_too_large"


def test_api_key_is_required_when_set(make_client, house):
    client = make_client(api_key="test-key")
    assert client.post("/v1/estimates", json=house).status_code == 401
    assert client.post("/v1/estimates/batch", json={"houses": [house]}).status_code == 401
    response = client.post("/v1/estimates", json=house, headers={"X-API-Key": "test-key"})
    assert response.status_code == 200
    assert client.get("/v1/model").status_code == 200, "the card needs no key"


def test_no_model_gives_503_everywhere_but_health(make_client, tmp_path, house):
    client = make_client(model_path=tmp_path / "house_price.joblib")
    for response in (
        client.post("/v1/estimates", json=house),
        client.post("/v1/estimates/batch", json={"houses": [house]}),
        client.get("/v1/model"),
    ):
        assert response.status_code == 503
        assert response.json()["error"]["code"] == "model_unavailable"


def test_model_card(client):
    card = client.get("/v1/model").json()
    assert card["model_version"] == "kc-hgb-2015-02"
    assert card["test"]["mape_pct"] == 12.8
    assert "lending, underwriting or insurance decisions about a person" in card["not_for"]


def test_an_error_has_the_request_id(client, house):
    error = client.post("/v1/estimates", json={**house, "lat": 40.71})
    assert error.json()["error"]["request_id"] == error.headers["X-Request-ID"]
