import json
import shutil

import joblib
import sklearn.base
from sklearn.dummy import DummyRegressor

from house_price_api.config import MODEL_SHA256, PROJECT
from house_price_api.estimator import file_sha256

MODEL = PROJECT / "model" / "house_price.joblib"


def assert_not_ready(client):
    """Liveness stays 200; readiness gives 503, without internals."""
    assert client.get("/health").status_code == 200
    response = client.get("/ready")
    assert response.status_code == 503
    assert response.json()["error"]["code"] == "model_unavailable"
    assert "Traceback" not in response.text


def test_ready(client):
    assert client.get("/ready").json() == {"status": "ready"}


def test_the_reviewed_hash_matches_the_file_and_the_card():
    card = json.loads((PROJECT / "model" / "model_card.json").read_text("utf-8"))
    assert file_sha256(MODEL) == MODEL_SHA256 == card["sha256"]


def test_missing_model_file(make_client, tmp_path):
    assert_not_ready(make_client(model_path=tmp_path / "house_price.joblib"))


def test_wrong_hash(make_client):
    assert_not_ready(make_client(model_sha256="0" * 64))


def test_card_of_another_model(make_client, tmp_path):
    shutil.copy(MODEL, tmp_path / "house_price.joblib")
    card = json.loads((PROJECT / "model" / "model_card.json").read_text("utf-8"))
    card["sha256"] = "0" * 64
    (tmp_path / "model_card.json").write_text(json.dumps(card), "utf-8")
    assert_not_ready(make_client(model_path=tmp_path / "house_price.joblib"))


def test_other_scikit_learn_version(make_client, tmp_path, monkeypatch):
    # Save a small model as if an older scikit-learn had made it.
    path = tmp_path / "house_price.joblib"
    monkeypatch.setattr(sklearn.base, "__version__", "1.0.0")
    joblib.dump(DummyRegressor().fit([[0]], [0]), path)
    monkeypatch.undo()
    digest = file_sha256(path)
    card = {"sha256": digest}
    (tmp_path / "model_card.json").write_text(json.dumps(card), "utf-8")
    assert_not_ready(make_client(model_path=path, model_sha256=digest))
