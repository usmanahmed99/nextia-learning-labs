"""First price estimates for houses in King County, Washington."""

import os

# The model predicts with one thread. This must happen before scikit-learn
# starts: on a small server, more threads make each prediction slower.
os.environ.setdefault("OMP_NUM_THREADS", "1")
