import logging
import sys
import time
import uuid

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware

from house_price_api.config import Settings, load_settings
from house_price_api.errors import add_error_handlers, error_response
from house_price_api.estimator import READY_CHECK_HOUSE, ModelUnavailable, load_estimator
from house_price_api.models import ErrorResponse, Health, Readiness
from house_price_api.routes import router

# A batch of 100 houses is 25 to 39 KB of JSON, with or without spaces and
# indentation. 64 KB leaves room for the largest valid request, and no more.
MAX_BODY_BYTES = 65_536

logger = logging.getLogger("house_price_api")

DESCRIPTION = """
First estimates of the sale price of houses in King County, Washington, at
2014-15 prices, for a valuation team before a human appraisal.

**Not for lending, underwriting or insurance decisions.** The model card is at
`/v1/model`. Every error has the same shape:
`{"error": {"code": ..., "message": ..., "request_id": ..., "fields": [...]}}`.
"""


def memory_mb() -> str:
    """The most memory that this process has used so far, in MB."""
    try:
        import resource  # not on Windows
    except ImportError:
        return "unknown"
    peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    return f"{peak / (1e6 if sys.platform == 'darwin' else 1e3):.0f}"


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or load_settings()
    logging.basicConfig(
        level=settings.log_level, format="%(levelname)s %(name)s: %(message)s"
    )

    app = FastAPI(
        title="House Price Estimate API",
        version="1.0.0",
        description=DESCRIPTION,
        license_info={"name": "MIT", "identifier": "MIT"},
        openapi_tags=[
            {"name": "estimates", "description": "Estimate house prices."},
            {"name": "health", "description": "Check that the service runs."},
        ],
        docs_url="/docs" if settings.show_docs else None,
        redoc_url="/redoc" if settings.show_docs else None,
        openapi_url="/openapi.json" if settings.show_docs else None,
    )
    app.state.settings = settings
    if settings.api_key is None:
        logger.warning("API_KEY is not set: /v1/estimates accepts requests without a key")

    started = time.perf_counter()
    try:
        app.state.estimator = load_estimator(settings.model_path, settings.model_sha256)
        app.state.model_problem = None
        logger.info(
            "model %s loaded in %.0f ms, memory %s MB",
            app.state.estimator.version,
            (time.perf_counter() - started) * 1000,
            memory_mb(),
        )
    except ModelUnavailable as problem:
        app.state.estimator = None
        app.state.model_problem = str(problem)
        logger.error("model not loaded: %s", problem)

    @app.middleware("http")
    async def request_id_and_limits(request: Request, call_next):
        request.state.request_id = uuid.uuid4().hex[:12]
        started = time.perf_counter()
        length = request.headers.get("content-length")
        if length and int(length) > MAX_BODY_BYTES:
            response = error_response(
                request,
                413,
                "body_too_large",
                f"The body is larger than {MAX_BODY_BYTES} bytes.",
            )
        else:
            response = await call_next(request)
        response.headers["X-Request-ID"] = request.state.request_id
        logger.info(
            "%s %s %d %.0fms id=%s",
            request.method,
            request.url.path,
            response.status_code,
            (time.perf_counter() - started) * 1000,
            request.state.request_id,
        )
        return response

    if settings.allowed_origins:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=settings.allowed_origins,
            allow_methods=["GET", "POST"],
            allow_headers=["Content-Type", "X-API-Key"],
        )

    add_error_handlers(app)
    app.include_router(router)

    @app.get("/health", tags=["health"], summary="Check that the service runs")
    def health() -> Health:
        return Health(status="ok")

    @app.get(
        "/ready",
        tags=["health"],
        summary="Check that the model can estimate prices",
        responses={503: {"model": ErrorResponse, "description": "Not ready."}},
    )
    def ready() -> Readiness:
        if app.state.estimator is None:
            raise ModelUnavailable(app.state.model_problem)
        app.state.estimator.estimate([READY_CHECK_HOUSE])
        return Readiness(status="ready")

    return app


app = create_app()
