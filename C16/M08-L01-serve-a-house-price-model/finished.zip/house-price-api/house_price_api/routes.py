import asyncio
from typing import Annotated

from fastapi import APIRouter, Depends, Request
from fastapi.concurrency import run_in_threadpool

from house_price_api.errors import OutsideModelArea
from house_price_api.estimator import HouseEstimator, ModelUnavailable
from house_price_api.models import (
    ErrorResponse,
    EstimateBatchOut,
    EstimateOut,
    EstimateWarning,
    HouseBatchIn,
    HouseIn,
    ModelInfo,
    PriceRange,
)
from house_price_api.security import require_api_key

router = APIRouter(prefix="/v1", tags=["estimates"])

HIGH_ESTIMATE_USD = 1_000_000

ERRORS = {
    401: {"model": ErrorResponse, "description": "The API key is missing or wrong."},
    413: {"model": ErrorResponse, "description": "The request body is too large."},
    422: {
        "model": ErrorResponse,
        "description": (
            "invalid_request: a field is missing or not valid. "
            "outside_model_area: the house is outside King County."
        ),
    },
    503: {"model": ErrorResponse, "description": "The model is not available."},
}


def to_thousand(dollars: float) -> int:
    return int(round(dollars, -3))


def get_estimator(request: Request) -> HouseEstimator:
    estimator = request.app.state.estimator
    if estimator is None:
        raise ModelUnavailable(request.app.state.model_problem)
    return estimator


def check_area(houses: list[HouseIn], prefix: str = "") -> None:
    fields = [
        f"{prefix}{index}.{name}" if prefix else name
        for index, house in enumerate(houses)
        for name in house.outside_model_area()
    ]
    if fields:
        raise OutsideModelArea(fields)


def warnings_for(
    estimator: HouseEstimator, inputs: dict[str, float], estimate: float
) -> list[EstimateWarning]:
    warnings = []
    if estimate >= HIGH_ESTIMATE_USD:
        warnings.append(
            EstimateWarning(
                code="high_estimate",
                message=(
                    "Estimates of 1,000,000 USD or more were within 10% of the "
                    "sale price only 4 times in 10. Ask for an appraisal first."
                ),
            )
        )
    rare = estimator.rare_values(inputs)
    if rare:
        warnings.append(
            EstimateWarning(
                code="rare_value",
                message=(
                    "Fewer than 1 in 100 training houses had a value this small "
                    "or this large. The estimate is less certain."
                ),
                fields=rare,
            )
        )
    return warnings


async def estimate_houses(
    request: Request, estimator: HouseEstimator, houses: list[HouseIn]
) -> list[EstimateOut]:
    rows = [house.model_inputs() for house in houses]
    timeout = request.app.state.settings.estimate_timeout
    try:
        estimates = await asyncio.wait_for(
            run_in_threadpool(estimator.estimate, rows), timeout
        )
    except TimeoutError:
        raise ModelUnavailable(f"no answer within {timeout} seconds") from None
    return [
        EstimateOut(
            estimate_usd=to_thousand(estimate.value),
            range_usd=PriceRange(
                low=to_thousand(estimate.low), high=to_thousand(estimate.high)
            ),
            model_version=estimator.version,
            prices_as_of=estimator.prices_as_of,
            warnings=warnings_for(estimator, row, estimate.value),
        )
        for row, estimate in zip(rows, estimates)
    ]


@router.get(
    "/model",
    summary="Describe the model",
    description="The model card: its version, intended use, limits and test results.",
    responses={503: ERRORS[503]},
)
def model_card(
    estimator: Annotated[HouseEstimator, Depends(get_estimator)],
) -> ModelInfo:
    return ModelInfo.model_validate(estimator.card)


@router.post(
    "/estimates",
    summary="Estimate the price of one house",
    description=(
        "A first estimate of the sale price, at 2014-15 prices, with a range "
        "and warnings. Not for lending, underwriting or insurance decisions."
    ),
    response_description="The estimate, its range and its warnings",
    responses=ERRORS,
    dependencies=[Depends(require_api_key)],
)
async def estimate_one(
    house: HouseIn,
    request: Request,
    estimator: Annotated[HouseEstimator, Depends(get_estimator)],
) -> EstimateOut:
    check_area([house])
    [result] = await estimate_houses(request, estimator, [house])
    return result


@router.post(
    "/estimates/batch",
    summary="Estimate the prices of 1 to 100 houses",
    description="The same as /v1/estimates for each house. The estimates keep the order of the houses.",
    response_description="One estimate per house, in order",
    responses=ERRORS,
    dependencies=[Depends(require_api_key)],
)
async def estimate_batch(
    batch: HouseBatchIn,
    request: Request,
    estimator: Annotated[HouseEstimator, Depends(get_estimator)],
) -> EstimateBatchOut:
    check_area(batch.houses, prefix="houses.")
    return EstimateBatchOut(estimates=await estimate_houses(request, estimator, batch.houses))
