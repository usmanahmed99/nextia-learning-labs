import os
from dataclasses import dataclass, field
from pathlib import Path

PROJECT = Path(__file__).resolve().parent.parent

# The SHA-256 of the reviewed model file. A new model file needs a new value
# here, and a new model_version, in one reviewed change.
MODEL_SHA256 = "8d0483d05cfca4752118c5c6ef4c47a9531c7230981cc880c27d85def9dbfdec"


@dataclass(frozen=True)
class Settings:
    api_key: str | None = field(repr=False)
    allowed_origins: list[str]
    model_path: Path
    model_sha256: str
    estimate_timeout: float
    log_level: str
    show_docs: bool


def load_settings() -> Settings:
    """Read the settings from environment variables, with safe defaults."""
    origins = os.environ.get("ALLOWED_ORIGINS", "")
    return Settings(
        api_key=os.environ.get("API_KEY") or None,
        allowed_origins=[o.strip() for o in origins.split(",") if o.strip()],
        model_path=Path(
            os.environ.get("MODEL_PATH", PROJECT / "model" / "house_price.joblib")
        ),
        model_sha256=MODEL_SHA256,
        estimate_timeout=float(os.environ.get("ESTIMATE_TIMEOUT", "2.0")),
        log_level=os.environ.get("LOG_LEVEL", "INFO").upper(),
        show_docs=os.environ.get("SHOW_DOCS", "true").lower() == "true",
    )
