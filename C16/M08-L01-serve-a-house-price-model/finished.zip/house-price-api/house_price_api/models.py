from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, ValidationInfo, field_validator

# The area that the model knows: the smallest box around every training house.
MODEL_AREA = {"lat": (47.15, 47.78), "long": (-122.52, -121.31)}

TYPICAL_HOUSE = {
    "bedrooms": 3,
    "bathrooms": 1.75,
    "sqft_living": 1560,
    "sqft_lot": 9452,
    "floors": 1.0,
    "waterfront": False,
    "view": 0,
    "condition": 4,
    "grade": 8,
    "sqft_basement": 0,
    "yr_built": 1974,
    "yr_renovated": None,
    "lat": 47.5197,
    "long": -122.18,
    "sqft_living15": 2200,
    "sqft_lot15": 9985,
}


class HouseIn(BaseModel):
    """The description of one house in King County, Washington."""

    model_config = ConfigDict(
        extra="forbid", strict=True, json_schema_extra={"examples": [TYPICAL_HOUSE]}
    )

    bedrooms: int = Field(ge=0, le=11, description="Number of bedrooms.")
    bathrooms: float = Field(
        ge=0,
        le=8,
        multiple_of=0.25,
        description="Number of bathrooms. 0.5 is a toilet without a shower.",
    )
    sqft_living: int = Field(
        ge=250, le=14_000, description="Living area in square feet, basement included."
    )
    sqft_lot: int = Field(ge=500, le=1_100_000, description="Land area in square feet.")
    floors: float = Field(
        ge=1, le=3.5, multiple_of=0.5, description="Floors. 1.5 is a partial upper floor."
    )
    waterfront: bool = Field(description="True if the house is on the water.")
    view: int = Field(ge=0, le=4, description="Quality of the view, 0 (none) to 4.")
    condition: int = Field(ge=1, le=5, description="Condition, 1 (poor) to 5 (very good).")
    grade: int = Field(
        ge=1, le=13, description="King County building grade, 1 to 13. 7 is average."
    )
    sqft_basement: int = Field(
        ge=0, le=5_000, description="Basement area in square feet. 0 = no basement."
    )
    yr_built: int = Field(ge=1900, le=2015, description="Year built.")
    yr_renovated: int | None = Field(
        default=None,
        ge=1900,
        le=2015,
        description="Year of the last renovation. null = never renovated.",
    )
    lat: float = Field(ge=-90, le=90, description="Latitude.")
    long: float = Field(ge=-180, le=180, description="Longitude.")
    sqft_living15: int = Field(
        ge=400, le=6_500, description="Average living area of the 15 nearest houses."
    )
    sqft_lot15: int = Field(
        ge=600, le=900_000, description="Average land area of the 15 nearest houses."
    )

    @field_validator("sqft_basement")
    @classmethod
    def basement_is_part_of_living_area(cls, value: int, info: ValidationInfo) -> int:
        living = info.data.get("sqft_living")
        if living is not None and value >= living:
            raise ValueError("must be smaller than sqft_living")
        return value

    @field_validator("yr_renovated")
    @classmethod
    def renovated_after_built(cls, value: int | None, info: ValidationInfo):
        built = info.data.get("yr_built")
        if value is not None and built is not None and value < built:
            raise ValueError("must not be before yr_built")
        return value

    def outside_model_area(self) -> list[str]:
        """The location fields outside the area that the model knows."""
        return [
            name
            for name, (low, high) in MODEL_AREA.items()
            if not low <= getattr(self, name) <= high
        ]

    def model_inputs(self) -> dict[str, float]:
        """The 17 numbers that the model expects, with its own codes."""
        values = self.model_dump()
        values["waterfront"] = int(self.waterfront)
        values["sqft_above"] = self.sqft_living - self.sqft_basement
        values["yr_renovated"] = self.yr_renovated or 0  # the model's code for "never"
        return values


class HouseBatchIn(BaseModel):
    """1 to 100 houses, estimated in one request."""

    model_config = ConfigDict(extra="forbid")

    houses: list[HouseIn] = Field(min_length=1, max_length=100)


class PriceRange(BaseModel):
    low: int = Field(description="Lower end, US dollars.")
    high: int = Field(description="Upper end, US dollars.")


class EstimateWarning(BaseModel):
    code: Literal["high_estimate", "rare_value"] = Field(
        description="A stable code that a program can check."
    )
    message: str = Field(description="A short explanation for a person.")
    fields: list[str] = Field(
        default=[], description="The inputs that the warning is about, if any."
    )


class EstimateOut(BaseModel):
    """A first estimate of the sale price, before an appraisal."""

    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "estimate_usd": 422000,
                    "range_usd": {"low": 373000, "high": 540000},
                    "model_version": "kc-hgb-2015-02",
                    "prices_as_of": "2015-02-28",
                    "warnings": [],
                }
            ]
        }
    )

    estimate_usd: int = Field(
        description="The estimated sale price, US dollars, rounded to 1,000."
    )
    range_usd: PriceRange = Field(
        description=(
            "8 in 10 test sales sold inside this range around their estimate. "
            "It is wider above the estimate, because the model lags a rising market."
        )
    )
    model_version: str = Field(description="The model that made the estimate.")
    prices_as_of: str = Field(
        description="The last sale date that the model learned from: prices of that time."
    )
    warnings: list[EstimateWarning] = Field(
        description="Reasons to trust this estimate less. Empty if there are none."
    )


class EstimateBatchOut(BaseModel):
    estimates: list[EstimateOut] = Field(description="One estimate per house, in order.")


class Evaluation(BaseModel):
    sales: int
    first_sales: str
    median_error_pct: float
    mape_pct: float
    within_10pct: float
    over_by_10pct_or_more: float


class RangeInfo(BaseModel):
    coverage: float
    low_factor: float
    high_factor: float


class ModelInfo(BaseModel):
    """The model card: what the model is for, and how well it did."""

    name: str
    model_version: str
    sha256: str
    prices_as_of: str
    intended_use: str
    not_for: list[str]
    test: Evaluation
    range: RangeInfo
    model: str
    features: list[str]


class Health(BaseModel):
    status: Literal["ok"]


class Readiness(BaseModel):
    status: Literal["ready"]


class ErrorDetail(BaseModel):
    code: str = Field(description="A stable code that a program can check.")
    message: str = Field(description="A short explanation for a person.")
    request_id: str | None = Field(
        default=None, description="Give this ID when you report a problem."
    )
    fields: list[str] = Field(
        default=[], description="The request fields that are not valid, if any."
    )


class ErrorResponse(BaseModel):
    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "error": {
                        "code": "invalid_request",
                        "message": "The request is not valid.",
                        "fields": ["bedrooms"],
                    }
                }
            ]
        }
    )

    error: ErrorDetail
