import hashlib
import json
import warnings
from dataclasses import dataclass
from pathlib import Path

import joblib
import numpy as np
from sklearn.exceptions import InconsistentVersionWarning

# The model's inputs, in the order that it was trained with.
FEATURES = [
    "bedrooms", "bathrooms", "sqft_living", "sqft_lot", "floors", "waterfront",
    "view", "condition", "grade", "sqft_above", "sqft_basement", "yr_built",
    "yr_renovated", "lat", "long", "sqft_living15", "sqft_lot15",
]

# The typical house of the documentation, in the model's own terms, for the
# readiness check: sqft_above is a column, and 0 means "never renovated".
READY_CHECK_HOUSE = {
    "bedrooms": 3, "bathrooms": 1.75, "sqft_living": 1560, "sqft_lot": 9452,
    "floors": 1, "waterfront": 0, "view": 0, "condition": 4, "grade": 8,
    "sqft_above": 1560, "sqft_basement": 0, "yr_built": 1974, "yr_renovated": 0,
    "lat": 47.5197, "long": -122.18, "sqft_living15": 2200, "sqft_lot15": 9985,
}


class ModelUnavailable(Exception):
    """The model cannot answer now. The request may work later."""


@dataclass(frozen=True)
class Estimate:
    value: float
    low: float
    high: float


def file_sha256(path: Path) -> str:
    """The SHA-256 of a file, read in blocks of 1 MB."""
    digest = hashlib.sha256()
    with path.open("rb") as file:
        for block in iter(lambda: file.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


class HouseEstimator:
    """The loaded model and its card."""

    def __init__(self, model, card: dict):
        self.model = model
        self.card = card
        self.version: str = card["model_version"]
        self.prices_as_of: str = card["prices_as_of"]
        self.low_factor: float = card["range"]["low_factor"]
        self.high_factor: float = card["range"]["high_factor"]
        self.usual_values: dict[str, list[float]] = card["usual_values"]

    def estimate(self, rows: list[dict[str, float]]) -> list[Estimate]:
        """Estimate the price of each house, with the range around it."""
        x = np.array([[row[name] for name in FEATURES] for row in rows], dtype=float)
        return [
            Estimate(value, value * self.low_factor, value * self.high_factor)
            for value in self.model.predict(x).tolist()
        ]

    def rare_values(self, row: dict[str, float]) -> list[str]:
        """The inputs outside the values of 98% of the training houses."""
        return [
            name
            for name, (low, high) in self.usual_values.items()
            if not low <= row[name] <= high
        ]


def load_estimator(model_path: Path, expected_sha256: str) -> HouseEstimator:
    """Check the model file, then load it. Raise ModelUnavailable if anything is wrong."""
    if not model_path.is_file():
        raise ModelUnavailable(f"no model file at {model_path}")
    actual = file_sha256(model_path)
    if actual != expected_sha256:
        raise ModelUnavailable(
            f"{model_path.name} has SHA-256 {actual[:12]}..., "
            f"expected {expected_sha256[:12]}..."
        )
    try:
        card = json.loads(model_path.with_name("model_card.json").read_text("utf-8"))
    except (OSError, ValueError) as error:
        raise ModelUnavailable(f"cannot read model_card.json: {error}") from None
    if card.get("sha256") != actual:
        raise ModelUnavailable("model_card.json describes a different model file")
    # The hash matches, so this is the file that we reviewed. Only now is it
    # safe to load it: joblib uses pickle, which can run code from the file.
    with warnings.catch_warnings():
        warnings.simplefilter("error", InconsistentVersionWarning)
        try:
            model = joblib.load(model_path)
        except InconsistentVersionWarning as warning:
            raise ModelUnavailable(
                f"the model was saved with scikit-learn "
                f"{warning.original_sklearn_version}, this server has "
                f"{warning.current_sklearn_version}"
            ) from None
    return HouseEstimator(model, card)
