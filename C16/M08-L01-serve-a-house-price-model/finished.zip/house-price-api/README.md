# house-price-api

A web API that gives a **first estimate** of the sale price of a house in King County, Washington, with a range and warnings. A valuation team calls it from its intake tool before a human appraisal. The model is gradient boosting, trained on public sales from 2014 and 2015.

**Not for lending, underwriting or insurance decisions.** Read [MODEL_CARD.md](MODEL_CARD.md) first.

## Requirements

- Python 3.12 or newer.
- For the Postman checks: the Postman CLI (`postman --version`).

## Set up

```sh
python3 -m venv .venv                # Windows: python -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\Activate.ps1
python -m pip install -r requirements-lock.txt
```

## Run

```sh
API_KEY=local-dev-key fastapi dev    # development, http://127.0.0.1:8000
API_KEY=local-dev-key fastapi run    # production mode, listens on 0.0.0.0:8000
```

On Windows PowerShell, set the key first: `$env:API_KEY = "local-dev-key"`.

The documentation is at `/docs` (Swagger UI) and `/redoc`, unless `SHOW_DOCS=false`. Settings are environment variables; `.env.example` lists them.

| Endpoint | Key | Meaning |
|---|---|---|
| `POST /v1/estimates` | `X-API-Key` | Estimate one house |
| `POST /v1/estimates/batch` | `X-API-Key` | Estimate 1 to 100 houses, in order |
| `GET /v1/model` | no | The model card |
| `GET /health` | no | Liveness: the process runs |
| `GET /ready` | no | Readiness: the model is loaded and answers |

Every error has the shape `{"error": {"code", "message", "request_id", "fields"}}`. The codes are `invalid_request` and `outside_model_area` (422), `unauthorized` (401), `body_too_large` (413), `model_unavailable` (503) and `internal_error` (500).

## The model file

`model/house_price.joblib` is loaded only if its SHA-256 equals `MODEL_SHA256` in `house_price_api/config.py`, and if `model/model_card.json` names the same SHA-256. joblib files use Python's pickle format, which can run code when it is loaded, so never load a model file that you did not check.

To train the model again (about 5 seconds, downloads 0.7 MB of data):

```sh
python training/train.py
```

With the same package versions, it writes the same file, byte for byte. A new model needs a new `model_version` (in `training/train.py`) and a new `MODEL_SHA256`, in one reviewed change. The API contract does not change.

## Check

```sh
python -m pytest
postman collection run postman/house-price-api.postman_collection.json -e postman/local.postman_environment.json --env-var "apiKey=local-dev-key"
python scripts/check_deployment.py http://127.0.0.1:8000     # needs HOUSE_API_KEY, see the script
```

When the contract test fails, read the difference. If the change is intended, run `python -m house_price_api.export_contract`, and review `contract/openapi.json`.

## Deploy

FastAPI Cloud builds the project as a package and installs the pinned versions from `pyproject.toml` (its `[tool.setuptools]` section names the one package, `house_price_api`), then runs `house_price_api.main:app`. `.fastapicloudignore` keeps the tests, the training code and the data on your computer. Create the app and its secret key before the first deployment. `apps create` asks you to choose a team (or pass `--team-id` from `fastapi cloud teams list`):

```sh
fastapi login
fastapi cloud apps create --name house-price-api --link
KEY=$(python -c "import secrets; print(secrets.token_urlsafe(32))")
printf %s "$KEY" | fastapi cloud env set API_KEY --secret --value-stdin --no-redeploy
fastapi cloud env set SHOW_DOCS false --no-redeploy
echo "$KEY"
fastapi deploy
```

## Data and licence

The code is under the MIT licence ([LICENSE](LICENSE)). The data is *House Sales in King County, USA* (harlfoxem, Kaggle 2016; OpenML 42092), CC0 1.0 (public domain). The data is not in this project: `training/train.py` downloads it.
