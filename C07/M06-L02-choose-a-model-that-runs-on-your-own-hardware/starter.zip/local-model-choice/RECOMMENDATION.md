# Recommendation: a local model for the visit-note handover form

Date of the runs:
Computer (model, memory, operating system):
Ollama version:

## The rule and the task

(One or two sentences: why only local models, and what the model must do.)

## What we compared

| Configuration | Model | Quantization | Licence |
|---|---|---|---|
| | | | |

## Results

(Paste the table from results.md. Say how busy the computer was.)

## Recommendation

(One configuration. Why this one, in two or three sentences, with numbers.)

## Hardware it needs

(Memory, disk, the slowest computer that you tested or expect to work.)

## Limits

(What it gets wrong on the test set; what the test set does not cover.)

## Fallback

(What to use if the first choice does not fit or fails, and what it costs.)

## Look again when

(The events that start a new comparison.)
