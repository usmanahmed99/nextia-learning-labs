"""Score the answers of pass 1 with the rubric.

    python score.py

The script checks what a program can check: the format, the four labels, and
whether the model wrote "not stated" or null where the note says nothing. A
person must read the summaries: the script copies each one into
scores/reading.csv, and you fill in two columns there. Run the script again
after that, and it writes scores/rubric.csv with the four rubric scores.

Rubric (0, 1 or 2 points per note and criterion):
  correctness   2: the four labels are right and the summary says nothing false.
                1: one label is wrong, or the summary has a small false detail.
                0: two or more labels are wrong, an urgent note is not "urgent",
                   or the summary has a false fact that could change the care.
  completeness  2: the summary has every fact of must_mention (from reading).
                1: some of them. 0: none, or no summary.
  format        2: the text is exactly one JSON object with the five keys and
                   allowed values, and a summary of at most 30 words.
                1: a program must clean it first (a ``` fence or text around
                   it), or one value is not allowed. 0: no usable JSON object.
  abstention    only for notes where the answer key has "not stated" or null.
                2: every such field is "not stated" or null. 1: one is
                invented. 0: two or more are invented.
"""

import csv
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).parent
NOTES = {n["id"]: n for n in map(json.loads, (HERE / "data" / "notes.jsonl").read_text(encoding="utf-8").splitlines()) if n}
KEYS = ["fall", "medication", "pain_score", "urgency", "summary"]
ALLOWED = {"fall": {"yes", "no", "not stated"}, "medication": {"taken", "missed", "refused", "not stated"},
           "urgency": {"urgent", "follow_up", "routine"}}
LEVEL = {"routine": 0, "follow_up": 1, "urgent": 2}
READING = HERE / "scores" / "reading.csv"
READING_COLUMNS = ["model", "id", "summary", "must_mention", "completeness", "false_fact", "comment"]


def parse(text: str) -> tuple[dict | None, str]:
    """Returns the JSON object and how it was found: exact, cleaned or none."""
    try:
        value = json.loads(text)
        return (value, "exact") if isinstance(value, dict) else (None, "none")
    except json.JSONDecodeError:
        pass
    match = re.search(r"\{.*\}", text, re.DOTALL)
    if match:
        try:
            return json.loads(match.group(0)), "cleaned"
        except json.JSONDecodeError:
            pass
    return None, "none"


def label_errors(answer: dict, key: dict) -> list[str]:
    errors = []
    for field in ("fall", "medication", "pain_score"):
        if answer.get(field) != key[field]:
            errors.append(field)
    if answer.get("urgency") not in key["urgency_ok"]:
        errors.append("urgency")
    return errors


def automatic(model: str, item: dict) -> dict:
    note = NOTES[item["id"]]
    key = note["key"]
    answer, found = parse(item["text"])
    row = {"model": model, "id": item["id"], "kind": note["kind"], "found": found}
    if answer is None:
        return {**row, "format": 0, "errors": "no JSON", "missed_urgent": key["urgency"] == "urgent",
                "abstention": 0 if needs_abstention(key) else "", "summary": ""}
    allowed = (set(answer) == set(KEYS) and all(answer.get(k) in v for k, v in ALLOWED.items())
               and (answer.get("pain_score") is None or isinstance(answer.get("pain_score"), int))
               and isinstance(answer.get("summary"), str) and len(answer["summary"].split()) <= 30)
    fmt = 2 if found == "exact" and allowed else (0 if not set(KEYS) <= set(answer) else 1)
    errors = label_errors(answer, key)
    missed_urgent = key["urgency"] == "urgent" and answer.get("urgency") != "urgent"
    abstention = ""
    if needs_abstention(key):
        invented = sum(1 for f in ("fall", "medication", "pain_score")
                       if key[f] in ("not stated", None) and answer.get(f) not in ("not stated", None))
        abstention = 2 if invented == 0 else (1 if invented == 1 else 0)
    return {**row, "format": fmt, "errors": " ".join(errors), "missed_urgent": missed_urgent,
            "abstention": abstention, "summary": str(answer.get("summary", ""))}


def needs_abstention(key: dict) -> bool:
    return any(key[f] in ("not stated", None) for f in ("fall", "medication", "pain_score"))


def main() -> None:
    rows = []
    for path in sorted((HERE / "runs").glob("*.jsonl")):
        lines = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]
        model = lines[0]["model"] + lines[0].get("variant", "")
        items = [x for x in lines if x.get("type") == "item"]
        first = [x for x in items if x["pass"] == 1]
        changed = sum(1 for x in items if x["pass"] > 1 and x["text"] != next(y["text"] for y in first if y["id"] == x["id"]))
        print(f"{model}: {len(first)} answers in pass 1; answers that changed in later passes: {changed}")
        rows += [automatic(model, x) for x in first]
    if not rows:
        sys.exit("No runs yet. Run measure.py first.")
    (HERE / "scores").mkdir(exist_ok=True)
    with (HERE / "scores" / "auto.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

    # The reading sheet: keep what a person already filled in, add new rows.
    filled = {}
    if READING.exists():
        with READING.open(encoding="utf-8") as f:
            filled = {(r["model"], r["id"]): r for r in csv.DictReader(f)}
    sheet = []
    for r in rows:
        old = filled.get((r["model"], r["id"]), {})
        sheet.append({"model": r["model"], "id": r["id"], "summary": r["summary"],
                      "must_mention": "; ".join(NOTES[r["id"]]["key"]["must_mention"]),
                      "completeness": old.get("completeness", ""), "false_fact": old.get("false_fact", ""),
                      "comment": old.get("comment", "")})
    with READING.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=READING_COLUMNS)
        writer.writeheader()
        writer.writerows(sheet)
    empty = [s for s in sheet if s["completeness"] == "" or s["false_fact"] == ""]
    if empty:
        print(f"\nRead the summaries: {len(empty)} rows of scores/reading.csv need completeness (0, 1 or 2)"
              " and false_fact (none, minor or serious). Then run this script again.")
        return

    reading = {(s["model"], s["id"]): s for s in sheet}
    rubric = []
    for r in rows:
        s = reading[(r["model"], r["id"])]
        wrong = len(r["errors"].split()) if r["errors"] != "no JSON" else 4
        if r["missed_urgent"] or wrong >= 2 or s["false_fact"] == "serious":
            correctness = 0
        elif wrong == 1 or s["false_fact"] == "minor":
            correctness = 1
        else:
            correctness = 2
        rubric.append({"model": r["model"], "id": r["id"], "kind": r["kind"], "correctness": correctness,
                       "completeness": int(s["completeness"]), "format": r["format"], "abstention": r["abstention"],
                       "missed_urgent": int(r["missed_urgent"]), "errors": r["errors"], "false_fact": s["false_fact"]})
    with (HERE / "scores" / "rubric.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rubric[0]))
        writer.writeheader()
        writer.writerows(rubric)
    print(f"\n{'model':34} correct complete format abstain  urgent missed")
    for model in dict.fromkeys(r["model"] for r in rubric):
        mine = [r for r in rubric if r["model"] == model]
        ab = [r["abstention"] for r in mine if r["abstention"] != ""]
        print(f"{model:34} {sum(r['correctness'] for r in mine):3}/{2 * len(mine)}"
              f" {sum(r['completeness'] for r in mine):5}/{2 * len(mine)}"
              f" {sum(r['format'] for r in mine):4}/{2 * len(mine)}"
              f" {sum(ab):4}/{2 * len(ab)}"
              f" {sum(r['missed_urgent'] for r in mine):6} of {sum(1 for r in mine if NOTES[r['id']]['key']['urgency'] == 'urgent')}")
    print("Wrote scores/auto.csv, scores/reading.csv and scores/rubric.csv")


if __name__ == "__main__":
    main()
