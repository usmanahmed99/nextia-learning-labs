# The visit notes (synthetic)

`notes.jsonl` holds 18 short home-care visit notes and an answer key for each one.

**Every note is synthetic.** The notes were written for this case study by Nextia Learning on 2026-10-08. The clients, the care workers, the client codes (for example C-1041) and the events are invented. No note comes from a real person or a real care agency. A resemblance to a real person is a coincidence.

**Licence:** CC0 1.0 Universal (public domain dedication), <https://creativecommons.org/publicdomain/zero/1.0/>. You can copy, change and share the notes for any purpose, without asking.

## What is in a line

| Field | Meaning |
|---|---|
| `id` | R01–R08 routine, D01–D04 difficult, M01–M03 missing information, X01 not a visit note, F01–F02 French |
| `kind` | `routine`, `difficult`, `missing`, `not_a_note`, `french` |
| `language` | `en` or `fr` |
| `text` | the note, as a care worker would write it |
| `key.fall` | `yes`, `no` or `not stated` |
| `key.medication` | `taken`, `missed`, `refused` or `not stated` |
| `key.pain_score` | 0–10, or `null` when the note gives no number |
| `key.urgency` | the expected urgency from the rules in `task_prompt.md` |
| `key.urgency_ok` | the urgencies that are acceptable (for a note with nothing to report, `follow_up` is also acceptable, because the rules say "anything you are not sure about") |
| `key.must_mention` | the facts that a complete summary contains, for the person who reads the summaries |

## The five kinds of note

- **Routine (8):** clear notes, with every field stated. Four urgencies are `follow_up`, two `urgent`, two `routine`.
- **Difficult (4):** an old fall that is not new (D01), a near slip and a refused dose with two pain scores (D02), pain in words and no number (D03), new confusion that is easy to miss (D04).
- **Missing information (3):** the note leaves out the fall, the medication or the pain score. The right answer is `not stated` or `null`, not a guess.
- **Not a visit note (1):** a message about a shift swap.
- **French (2):** notes from a bilingual team. The French was written by the author and has not been checked by a second fluent reader.

18 notes are a start, not proof. A difference of one or two notes between two models is noise.
