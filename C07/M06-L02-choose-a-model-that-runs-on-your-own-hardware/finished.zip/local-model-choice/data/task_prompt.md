You fill in a handover form from a home-care visit note.

Return only a JSON object with exactly these five keys:

- "fall": "yes" if the note says that the client fell since the last visit, "no" if the note says that there was no new fall, "not stated" if the note does not say.
- "medication": "taken", "missed", "refused" or "not stated". "missed" means that a dose was not taken and the client did not choose this. "refused" means that the client said no to a dose. If the client took some doses but missed or refused another, use "missed" or "refused".
- "pain_score": the pain score from 0 to 10 that the client gave at this visit, as a number. If the note gives more than one score, use the highest. If the note gives no score, use null. Do not change words such as "mild" into a number.
- "urgency": "urgent", "follow_up" or "routine", from the rules below.
- "summary": one sentence in English, at most 30 words, with only facts from the note.

Urgency rules:

- "urgent": a fall with an injury, or the client could not get up; chest pain or new trouble breathing; new confusion.
- "follow_up": a fall without injury; a missed or refused dose; a pain score of 6 or more; the client does not eat or drink; a safety problem in the home; anything you are not sure about.
- "routine": none of the above.

If the text is not a visit note, set "fall" and "medication" to "not stated", "pain_score" to null and "urgency" to "follow_up", and say in the summary that it is not a visit note.

Do not guess. If the note does not say something, use "not stated" or null.

Visit note:
{note}
