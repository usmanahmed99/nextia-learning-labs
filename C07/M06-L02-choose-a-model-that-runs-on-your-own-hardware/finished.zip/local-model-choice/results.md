| | gemma3:4b+structured | gemma3:4b-it-q8_0 | gemma3:4b | mistral:7b+structured | mistral:7b-instruct-v0.3-q8_0 | mistral:7b |
|---|---|---|---|---|---|---|
| Size on disk (GB) | 3.35 | 4.98 | 3.35 | 4.37 | 7.7 | 4.37 |
| Memory while loaded (GB) | 2.89 | 4.53 | 2.89 | 4.94 | 8.21 | 4.94 |
| Load time (s) | 3.0 | 3.49 | 2.75 | 2.21 | 4.21 | 2.49 |
| Time to first token (s) | 1.17 | 1.1 | 1.16 | 0.32 | 0.3 | 0.32 |
| Tokens per second | 36.15 | 23.0 | 34.65 | 22.6 | 12.2 | 21.6 |
| Total time per note (s) | 3.11 | 4.32 | 3.29 | 3.93 | 6.9 | 4.1 |
| Of which the model worked (s) | 3.1 | 4.31 | 3.28 | 3.92 | 6.89 | 4.09 |
| Slowest note (s) | 3.393 | 4.73 | 3.546 | 6.674 | 9.191 | 6.374 |
| Correctness | 28 / 36 | 28 / 36 | 28 / 36 | 28 / 36 | 28 / 36 | 28 / 36 |
| Completeness | 29 / 36 | 28 / 36 | 25 / 36 | 35 / 36 | 33 / 36 | 35 / 36 |
| Format | 36 / 36 | 18 / 36 | 18 / 36 | 36 / 36 | 36 / 36 | 36 / 36 |
| Abstention | 8 / 10 | 9 / 10 | 9 / 10 | 10 / 10 | 10 / 10 | 10 / 10 |
| Urgent notes missed | 1 | 2 | 1 | 1 | 1 | 1 |

Times are medians over all passes and notes. "Of which the model worked" is Ollama's own time to read the prompt and write the answer: the rest of the total is waiting, for example for another program's request. Answers that had to load the model again, or waited in a queue, are left out: gemma3:4b+structured 0, gemma3:4b-it-q8_0 0, gemma3:4b 0, mistral:7b+structured 0, mistral:7b-instruct-v0.3-q8_0 0, mistral:7b 0. Load average (how busy the computer was) during the runs: gemma3:4b+structured 2.87, gemma3:4b-it-q8_0 2.45, gemma3:4b 2.55, mistral:7b+structured 2.63, mistral:7b-instruct-v0.3-q8_0 4.61, mistral:7b 2.54.
