"""Check that everything is ready, before you measure anything.

    python check_setup.py

Checks the Python version, that Ollama answers on this computer, and which
of the four models of the case study are on the disk. Sends no note.
"""

import json
import os
import platform
import sys
import urllib.request
from urllib.error import URLError

OLLAMA = os.environ.get("OLLAMA_URL", "http://127.0.0.1:11434")
MODELS = ["gemma3:4b", "gemma3:4b-it-q8_0", "mistral:7b", "mistral:7b-instruct-v0.3-q8_0"]


def memory_gb() -> float | None:
    try:
        return os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES") / 2**30  # as on the label
    except (AttributeError, ValueError, OSError):  # not available on Windows
        return None


def main() -> None:
    ok = True
    print(f"Python {platform.python_version()} on {platform.system()} {platform.machine()}")
    if sys.version_info < (3, 12):
        print("  Problem: this project needs Python 3.12 or newer.")
        ok = False
    memory = memory_gb()
    print(f"Memory: {memory:.0f} GB" if memory else "Memory: unknown on this system (see the lesson)")
    try:
        with urllib.request.urlopen(OLLAMA + "/api/version", timeout=5) as response:
            print("Ollama", json.loads(response.read())["version"], "answers at", OLLAMA)
        with urllib.request.urlopen(OLLAMA + "/api/tags", timeout=5) as response:
            here = {m["name"]: m["size"] for m in json.loads(response.read())["models"]}
    except URLError:
        print(f"  Problem: Ollama does not answer at {OLLAMA}. Start the Ollama app, or run: ollama serve")
        sys.exit(1)
    for model in MODELS:
        if model in here:
            print(f"  ready    {model:32} {here[model] / 1e9:.1f} GB on disk")
        else:
            print(f"  missing  {model:32} to get it: ollama pull {model}")
    print("Ready." if ok else "Fix the problem above first.")


if __name__ == "__main__":
    main()
