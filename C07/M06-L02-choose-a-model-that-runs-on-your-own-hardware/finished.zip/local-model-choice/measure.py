"""Run every visit note through local models and measure them, on this computer only.

    python measure.py gemma3:4b gemma3:4b-it-q8_0 --passes 3

For each pass and each model: unload the model, load it again and time the
load, read its memory from Ollama, then send the 18 notes one by one and time
each answer. The passes take turns between the models, so a busy minute on
the computer does not hit only one model. Writes runs/<model>.jsonl.

Only the Python standard library is used. The script refuses any Ollama
address that is not this computer: the notes must never leave it.
"""

import argparse
import json
import os
import platform
import re
import subprocess
import sys
import time
import urllib.request
from pathlib import Path
from urllib.parse import urlparse

HERE = Path(__file__).parent
OLLAMA = os.environ.get("OLLAMA_URL", "http://127.0.0.1:11434")
# The same settings for every model: no randomness, the same context size
# (it changes the memory), and a limit on the answer length.
OPTIONS = {"temperature": 0, "seed": 1, "num_ctx": 4096, "num_predict": 300}
PROMPT = (HERE / "data" / "task_prompt.md").read_text(encoding="utf-8")
# For --structured: Ollama makes the model follow this JSON schema.
SCHEMA = {"type": "object", "required": ["fall", "medication", "pain_score", "urgency", "summary"],
          "properties": {"fall": {"enum": ["yes", "no", "not stated"]},
                         "medication": {"enum": ["taken", "missed", "refused", "not stated"]},
                         "pain_score": {"type": ["integer", "null"], "minimum": 0, "maximum": 10},
                         "urgency": {"enum": ["urgent", "follow_up", "routine"]},
                         "summary": {"type": "string"}}}
STRUCTURED = []  # [True] when --structured is used
NOTES = [json.loads(line) for line in (HERE / "data" / "notes.jsonl").read_text(encoding="utf-8").splitlines() if line]


def local_only(url: str) -> None:
    host = urlparse(url).hostname
    if host not in ("127.0.0.1", "localhost", "::1"):
        sys.exit(f"Refused: {host} is not this computer. The notes must not leave it.")


def api(path: str, body: dict | None = None) -> dict:
    data = None if body is None else json.dumps(body).encode()
    request = urllib.request.Request(OLLAMA + path, data=data, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(request, timeout=900) as response:
        return json.loads(response.read())


def loaded() -> list[dict]:
    return api("/api/ps")["models"]


def load_average() -> float | None:
    try:
        return round(os.getloadavg()[0], 2)
    except (AttributeError, OSError):  # Windows has no load average
        return None


def free_memory_percent() -> int | None:
    """macOS only: the share of the computer's memory that is free (memory_pressure)."""
    if platform.system() != "Darwin":
        return None
    try:
        out = subprocess.run(["memory_pressure", "-Q"], capture_output=True, text=True, timeout=10).stdout
        return int(re.search(r"free percentage: (\d+)%", out).group(1))
    except (OSError, subprocess.SubprocessError, AttributeError):
        return None


def memory(model: str) -> dict | None:
    """Ollama's entry for the model while it is loaded: size is the memory it uses."""
    return next((m for m in loaded() if m["name"] == model), None)


def wait_for_quiet(model: str, minutes: float) -> None:
    """Wait until Ollama has no other model in memory, for at most `minutes`."""
    end = time.time() + minutes * 60
    while time.time() < end:
        others = [m["name"] for m in loaded() if m["name"] != model]
        if not others:
            return
        print(f"  waiting: another program uses {', '.join(others)}", flush=True)
        time.sleep(15)


def cold_load(model: str) -> dict:
    """Unload the model, then load it again. Returns the times and the memory."""
    api("/api/generate", {"model": model, "keep_alive": 0})
    for _ in range(60):
        if not any(m["name"] == model for m in loaded()):
            break
        time.sleep(0.5)
    others = [m["name"] for m in loaded()]
    for _ in range(3):  # another program can unload the model at once: then load it again
        started = time.perf_counter()
        # A one-word prompt and a one-token answer: almost all the time is the load.
        reply = api("/api/generate", {"model": model, "prompt": "Hi", "stream": False,
                                      "options": {**OPTIONS, "num_predict": 1}})
        wall = time.perf_counter() - started
        entry = memory(model)
        if entry:
            break
    else:
        print(f"  {model} did not stay loaded: another program uses Ollama too. The memory is read later.")
        entry = {}
    return {"type": "load", "load_s": round(wall, 2), "ollama_load_s": round(reply.get("load_duration", 0) / 1e9, 2),
            "memory_bytes": entry.get("size"), "memory_gpu_bytes": entry.get("size_vram"),
            "context": entry.get("context_length"), "runner": entry.get("runner"),
            "other_models_loaded": others, "load_average": load_average(), "free_memory_percent": free_memory_percent()}


def answer(model: str, note: dict) -> dict:
    """Send one note, stream the answer, and time it."""
    body = {"model": model, "prompt": PROMPT.replace("{note}", note["text"]), "stream": True,
            "options": OPTIONS}
    if STRUCTURED:
        body["format"] = SCHEMA
    request = urllib.request.Request(OLLAMA + "/api/generate", data=json.dumps(body).encode(),
                                     headers={"Content-Type": "application/json"})
    load = load_average()
    started = time.perf_counter()
    first = None
    text = []
    with urllib.request.urlopen(request, timeout=900) as response:
        for line in response:
            chunk = json.loads(line)
            if chunk.get("response"):
                if first is None:
                    first = time.perf_counter() - started
                text.append(chunk["response"])
            if chunk.get("done"):
                final = chunk
    total = time.perf_counter() - started
    others = [m["name"] for m in loaded() if m["name"] != model]
    eval_s = final.get("eval_duration", 0) / 1e9
    # Ollama's own times (seconds) leave out any wait in Ollama's queue,
    # for example while another program's request runs.
    return {"type": "item", "id": note["id"], "total_s": round(total, 3), "first_token_s": round(first or total, 3),
            "input_tokens": final.get("prompt_eval_count", 0), "output_tokens": final.get("eval_count", 0),
            "tokens_per_s": round(final.get("eval_count", 0) / eval_s, 1) if eval_s else None,
            "ollama_total_s": round(final.get("total_duration", 0) / 1e9, 3),
            "ollama_load_s": round(final.get("load_duration", 0) / 1e9, 3),
            "ollama_prompt_s": round(final.get("prompt_eval_duration", 0) / 1e9, 3),
            "ollama_answer_s": round(eval_s, 3), "load_average": load, "other_models_loaded": others,
            "free_memory_percent": free_memory_percent(),
            "done_reason": final.get("done_reason"), "text": "".join(text)}


def file_for(model: str) -> Path:
    variant = "+structured" if STRUCTURED else ""
    return HERE / "runs" / (model.replace(":", "_").replace("/", "_") + variant + ".jsonl")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("models", nargs="+", help="Ollama model names, for example gemma3:4b")
    parser.add_argument("--passes", type=int, default=3, help="how many times to run every note (default 3)")
    parser.add_argument("--notes", help="only these note IDs, for a quick test, for example R01,R02")
    parser.add_argument("--wait", type=float, default=0, metavar="MINUTES",
                        help="on a shared computer: before each model, wait up to MINUTES until no other model is loaded")
    parser.add_argument("--structured", action="store_true", help="make the answer follow the JSON schema (Ollama format)")
    args = parser.parse_args()
    local_only(OLLAMA)
    if args.structured:
        STRUCTURED.append(True)
    notes = [n for n in NOTES if not args.notes or n["id"] in args.notes.split(",")]

    sizes = {m["name"]: m["size"] for m in api("/api/tags")["models"]}
    missing = [m for m in args.models if m not in sizes]
    if missing:
        sys.exit(f"Not on this computer: {', '.join(missing)}. Run: ollama pull {missing[0]}")
    computer = {"system": platform.system(), "machine": platform.machine(), "python": platform.python_version(),
                "ollama": api("/api/version")["version"], "options": OPTIONS,
                "date": time.strftime("%Y-%m-%d %H:%M")}
    (HERE / "runs").mkdir(exist_ok=True)
    for model in args.models:
        with file_for(model).open("w", encoding="utf-8") as f:
            f.write(json.dumps({"type": "model", "model": model, "variant": "+structured" if STRUCTURED else "", "disk_bytes": sizes[model], **computer}) + "\n")

    for p in range(1, args.passes + 1):
        for model in args.models:
            with file_for(model).open("a", encoding="utf-8") as f:
                if args.wait:
                    wait_for_quiet(model, args.wait)
                load = cold_load(model)
                f.write(json.dumps({"pass": p, **load}) + "\n")
                f.flush()
                print(f"pass {p} {model}: loaded in {load['load_s']} s", flush=True)
                for note in notes:
                    item = answer(model, note)
                    if load["memory_bytes"] is None and (entry := memory(model)):
                        item["memory_bytes"] = entry["size"]  # the load was disturbed: read it now
                    f.write(json.dumps({"pass": p, **item}, ensure_ascii=False) + "\n")
                    f.flush()
                    print(f"  {note['id']} {item['total_s']:6.2f} s  first token {item['first_token_s']:5.2f} s"
                          f"  {item['tokens_per_s']} tokens/s", flush=True)
            api("/api/generate", {"model": model, "keep_alive": 0})  # free the memory for the next model
    print("Wrote", ", ".join(str(file_for(m).relative_to(HERE)) for m in args.models))


if __name__ == "__main__":
    main()
