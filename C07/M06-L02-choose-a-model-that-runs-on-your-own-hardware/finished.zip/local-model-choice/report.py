"""Put the measurements and the rubric scores in one table.

    python report.py

Reads runs/*.jsonl and scores/rubric.csv (from score.py). Uses the median of
all passes for each time, so one slow moment does not decide. Writes
results.md (a table to read) and results.json (the same numbers for charts).
"""

import csv
import json
import statistics
from pathlib import Path

HERE = Path(__file__).parent
GB = 1e9


def median(values: list) -> float | None:
    values = [v for v in values if v is not None]
    return round(statistics.median(values), 2) if values else None


def main() -> None:
    rubric = []
    if (HERE / "scores" / "rubric.csv").exists():
        with (HERE / "scores" / "rubric.csv").open(encoding="utf-8") as f:
            rubric = list(csv.DictReader(f))
    results = []
    for path in sorted((HERE / "runs").glob("*.jsonl")):
        lines = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]
        head = lines[0]
        name = head["model"] + head.get("variant", "")
        loads = [x for x in lines if x.get("type") == "load"]
        every = [x for x in lines if x.get("type") == "item"]
        # Leave out an answer that had to load the model again (another program
        # unloaded it): its time is a load, not an answer.
        items = [x for x in every if x["ollama_load_s"] < 0.5]
        memory = [x["memory_bytes"] for x in loads + every if x.get("memory_bytes")]
        mine = [r for r in rubric if r["model"] == name]
        abstention = [int(r["abstention"]) for r in mine if r["abstention"] != ""]
        results.append({
            "model": name,
            "disk_gb": round(head["disk_bytes"] / GB, 2),
            "memory_gb": median([m / GB for m in memory]),
            "load_s": median([x["load_s"] for x in loads]),
            "first_token_s": median([x["first_token_s"] for x in items]),
            "tokens_per_s": median([x["tokens_per_s"] for x in items]),
            "total_s": median([x["total_s"] for x in items]),
            "work_s": median([x["ollama_prompt_s"] + x["ollama_answer_s"] for x in items]),
            "slowest_s": max((x["total_s"] for x in items), default=None),
            "reloaded": len(every) - len(items),
            "output_tokens": median([x["output_tokens"] for x in items]),
            "load_average": median([x["load_average"] for x in items]),
            "passes": len(loads), "answers": len(items),
            "correctness": sum(int(r["correctness"]) for r in mine) if mine else None,
            "completeness": sum(int(r["completeness"]) for r in mine) if mine else None,
            "format": sum(int(r["format"]) for r in mine) if mine else None,
            "abstention": sum(abstention) if mine else None,
            "max_points": 2 * len(mine), "max_abstention": 2 * len(abstention),
            "missed_urgent": sum(int(r["missed_urgent"]) for r in mine) if mine else None,
        })
    (HERE / "results.json").write_text(json.dumps(results, indent=1) + "\n", encoding="utf-8")

    rows = [
        ("Size on disk (GB)", "disk_gb"), ("Memory while loaded (GB)", "memory_gb"), ("Load time (s)", "load_s"),
        ("Time to first token (s)", "first_token_s"), ("Tokens per second", "tokens_per_s"),
        ("Total time per note (s)", "total_s"), ("Of which the model worked (s)", "work_s"),
        ("Slowest note (s)", "slowest_s"),
        ("Correctness", "correctness"), ("Completeness", "completeness"), ("Format", "format"),
        ("Abstention", "abstention"), ("Urgent notes missed", "missed_urgent"),
    ]
    out = ["| | " + " | ".join(r["model"] for r in results) + " |", "|---" * (len(results) + 1) + "|"]
    for label, key in rows:
        cells = []
        for r in results:
            value = r[key]
            if key in ("correctness", "completeness", "format") and value is not None:
                value = f"{value} / {r['max_points']}"
            elif key == "abstention" and value is not None:
                value = f"{value} / {r['max_abstention']}"
            cells.append("–" if value is None else str(value))
        out.append(f"| {label} | " + " | ".join(cells) + " |")
    out.append("")
    out.append("Times are medians over all passes and notes. \"Of which the model worked\" is Ollama's own time"
               " to read the prompt and write the answer: the rest of the total is waiting, for example for"
               " another program's request. Answers that had to load the model again are left out: "
               + ", ".join(f"{r['model']} {r['reloaded']}" for r in results) + ". Load average (how busy the"
               " computer was) during the runs: " + ", ".join(f"{r['model']} {r['load_average']}" for r in results) + ".")
    (HERE / "results.md").write_text("\n".join(out) + "\n", encoding="utf-8")
    print("\n".join(out))


if __name__ == "__main__":
    main()
