# Recommendation: a local model for the visit-note handover form

Date of the runs: 2026-10-08
Computer: Mac mini M4, 16 GB of memory, macOS (shared with other work during the runs)
Ollama version: 0.40.1
Test set: 18 synthetic visit notes with an answer key (`data/notes.jsonl`)

## The rule and the task

The privacy officer's rule: visit notes never leave the agency's computers, so only open-weight models on our own hardware are allowed. The model turns one note into a handover form (fall, medication, pain score, urgency, a one-sentence summary). The coordinator reads every note and every form, and decides.

## What we compared

| Set-up | Model | Quantization | Licence |
|---|---|---|---|
| `gemma3:4b` | Gemma 3 4B | Q4_K_M | Gemma Terms of Use (no automated decisions in healthcare) |
| `gemma3:4b-it-q8_0` | Gemma 3 4B | Q8_0 | Gemma Terms of Use |
| `mistral:7b` | Mistral 7B Instruct v0.3 | Q4_K_M | Apache License 2.0 |
| `mistral:7b-instruct-v0.3-q8_0` | Mistral 7B Instruct v0.3 | Q8_0 | Apache License 2.0; measured once, then dropped for memory |

And `gemma3:4b` and `mistral:7b` again with structured output (`measure.py --structured`: Ollama makes the answer follow the JSON schema).

## Results

| | Gemma Q4 | Gemma Q8 | Mistral Q4 | Mistral Q8 (1 pass) | Gemma Q4 + schema | Mistral Q4 + schema |
|---|---|---|---|---|---|---|
| Size on disk (GB) | 3.35 | 4.98 | 4.37 | 7.70 | 3.35 | 4.37 |
| Memory while loaded (GB) | 2.89 | 4.53 | 4.94 | 8.21 | 2.89 | 4.94 |
| Load time (s) | 2.8 | 3.5 | 2.5 | 4.2 | 3.0 | 2.2 |
| Time to first token (s) | 1.16 | 1.10 | 0.32 | 0.30 | 1.17 | 0.32 |
| Tokens per second | 34.7 | 23.0 | 21.6 | 12.2 | 36.2 | 22.6 |
| Total time per note (s) | 3.29 | 4.32 | 4.10 | 6.90 | 3.11 | 3.93 |
| Correctness (of 36) | 28 | 28 | 28 | 28 | 28 | 28 |
| Completeness (of 36) | 25 | 28 | 35 | 33 | 29 | 35 |
| Format (of 36) | 18 | 18 | 36 | 36 | 36 | 36 |
| Abstention (of 10) | 9 | 9 | 10 | 10 | 8 | 10 |
| Urgent notes missed (of 4) | 1 | 2 | 1 | 1 | 1 | 1 |

Times: medians over 3 passes of 18 notes (Mistral Q8: 1 pass), only answers that did not wait for another program (none had to be left out in the final runs). Loads are from the computer's file cache: after a restart, the first load reads the disk and is slower. The computer was shared with other work: we checked `ollama ps` before each run, and `report.py` leaves out any answer that waited in Ollama's queue or had to reload the model.

## Recommendation

**`mistral:7b` (Mistral 7B Instruct v0.3, Q4_K_M) with structured output**, as a reading aid that sorts the notes, not as triage.

It had the most complete summaries (35 of 36), a perfect format and abstention, and about 4 seconds per note. The Q8 file of the same model gave no better answers on our notes, at 1.7 times the memory and 1.7 times the time per note. Its licence (Apache 2.0) adds no use conditions.

## Hardware it needs

- About 5 GB of memory for the model (4.94 GB at a context of 4,096 tokens), plus the operating system and other programs: a computer with 16 GB. With 8 GB, use the fallback.
- 4.4 GB of disk for the model file.
- One note at a time: about 4 seconds per note, so 300 notes in about 20 minutes. Two notes sent together wait for each other.

## Limits

- **No set-up met the must-have "miss no urgent note".** All missed D04 (new confusion after a hospital stay). Mistral's summary said "unusual confusion", but the urgency was `follow_up`, not `urgent`. Gemma Q8 also missed R06 (new shortness of breath).
- Mistral marked a missed lunchtime dose as `taken` and `routine` (R02), and wrote `not stated` for "No fall" in three notes.
- Summaries often have several short sentences, not one.
- 18 invented notes, 2 in French; not checked by a second reader. Real notes are longer and use the agency's abbreviations.

So: the form must never lower the priority of a note. The coordinator reads every note.

## Fallback

- If the computer has only 8 GB, or Mistral is not available: `gemma3:4b` (Q4_K_M) with structured output. 2.9 GB of memory, 3.1 seconds per note, format 36 of 36, but less complete summaries (29 of 36), and twice an invented "no fall" where the note says nothing (M01, X01). Its licence forbids automated decisions in healthcare: a person must decide, as in our design.
- If the local computer is down: the coordinator reads the notes without forms, as today. No note goes to a hosted model.

## Look again when

- The agency has a test set of its own notes (inside its systems, approved by the privacy officer).
- The urgency rule for confusion is changed in the prompt: re-run all set-ups.
- A new version of a model, or of Ollama, arrives (pin the digest from `ollama show`).
- More than one worker sends notes at the same time, or a new computer is bought.
- Any urgent case is missed in real use.
