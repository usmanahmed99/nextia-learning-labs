# Choose a local model for visit notes

A home-care agency wants a model to fill in a handover form from a care worker's visit note. The privacy rule: **the notes never leave the agency's computers**. So only open-weight models that run on our own hardware are allowed.

This project compares two models and two quantizations with [Ollama](https://ollama.com) on one computer (a Mac mini M4 with 16 GB, shared with other work):

| Set-up | Model | Quantization | Licence |
|---|---|---|---|
| `gemma3:4b` | Gemma 3 4B (Google) | Q4_K_M | Gemma Terms of Use |
| `gemma3:4b-it-q8_0` | Gemma 3 4B (Google) | Q8_0 | Gemma Terms of Use |
| `mistral:7b` | Mistral 7B Instruct v0.3 (Mistral AI) | Q4_K_M | Apache License 2.0 |

A fourth set-up, `mistral:7b-instruct-v0.3-q8_0` (7.7 GB on disk), was measured once and then dropped: it needs about 8 GB of memory, too much next to other work on a 16 GB computer. Its one pass is in `runs/`.

It measures size on disk, memory while loaded, load time, time to first token, tokens per second and total time per note, and scores the answers with a rubric (correctness, completeness, format, abstention).

The notes are **synthetic** (written for this project, CC0): see `data/DATASET.md`.

## Run it

Needs Python 3.12 or newer and Ollama. No Python packages to install.

```
python check_setup.py
ollama pull gemma3:4b            # and the other two, see the lesson
python measure.py gemma3:4b gemma3:4b-it-q8_0 mistral:7b
python score.py                  # then fill in scores/reading.csv
python score.py
python report.py
```

`measure.py` only talks to Ollama on this computer (127.0.0.1). It refuses any other address.

## Files

| File | What it is |
|---|---|
| `data/notes.jsonl` | 18 visit notes and their answer key |
| `data/task_prompt.md` | the instructions that every model gets |
| `measure.py` | runs the notes, times the answers, reads the memory |
| `score.py` | the rubric: automatic checks + the reading sheet |
| `report.py` | one table of all the numbers: `results.md`, `results.json` |
| `runs/` | one file per configuration: every answer and its times |
| `scores/` | `auto.csv`, `reading.csv` (a person reads the summaries), `rubric.csv` |
| `RECOMMENDATION.md` | the choice, the hardware it needs, its limits and the fallback |

## Licence

Code: MIT (`LICENSE`). Notes: CC0 1.0. The models are not included; each has its own licence.
