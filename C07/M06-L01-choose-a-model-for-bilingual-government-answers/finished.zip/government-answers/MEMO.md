# Decision memo: the model for the bilingual information desk

**To:** Hélène Tremblay, director · **From:** Ana Lima, volunteer data analyst · **Date:** 2026-10-08

## 1. Decision asked for

Which model should draft the desk's answers to English and French questions from official Government of Canada pages, before the board meeting.

## 2. Recommendation

Use **Claude Sonnet 5.5** (hosted, Anthropic) to draft answers, with a person on the desk checking every draft before it is sent. Use **Gemini 3.5 Flash** (hosted, Google, paid tier) as the fallback. Do not use the two local models for this task.

## 3. Requirements

Must-haves (an option that fails one is out, whatever its score):

1. No critical error: no false or invented fact that could change what a person does.
2. French as good as English: the French score is not more than 0.5 points (of 8) below the English score, and every French answer is in French.
3. Data terms: questions may contain personal details, so no provider tier that uses the content to improve its products.

Then, in order: quality on the rubric, cost per question, time per question.

## 4. Evidence

24 questions (12 in English, the same 12 in French), two Health Canada pages, runs of 2026-10-08, scored blind on four criteria (0–2 each, 8 = perfect).

| Model | Score /8 | English | French | Full marks (95% interval) | Ready | Critical errors | Median s | p95 s | US$ per 1,000 questions |
|---|---|---|---|---|---|---|---|---|---|
| Claude Sonnet 5.5 | 7.75 | 7.58 | 7.92 | 20/24 (64–93%) | 22 | 0 | 2.5 | 3.9 | 10.17 |
| Gemini 3.5 Flash | 7.88 | 7.92 | 7.83 | 21/24 (69–96%) | 24 | 0 | 4.9 | 8.4 | 16.27 |
| Gemma 3 4B (local) | 5.88 | 6.50 | 5.25 | 4/24 (7–36%) | 8 | 0 | 9.4 | 19.3 | 0 |
| Mistral 7B (local) | 4.71 | 5.17 | 4.25 | 3/24 (4–31%) | 9 | 7 | 8.2 | 21.8 | 0 |

"Ready": ready to send after a light check (Module 4: correctness 2 and no criterion at 0).

- Mistral 7B fails must-have 1: it invented a phone number for the RAMQ and a lead limit (both languages), said that lake water is safe after an NSF 53 filter (both languages), and said a doctor's visit for pneumonia is uninsured.
- Gemma 3 4B fails must-have 2: it answered 9 of the 12 French questions in English, and its French score is 1.25 points below its English score.
- The two hosted models pass all must-haves. Their scores are within one answer of each other; the intervals overlap almost completely. On this test, they are equal in quality.
- Sonnet is cheaper per question (US$0.010 against 0.016) and faster (median 2.5 s against 4.9 s). Gemini's lower price per token is outweighed by about 1,300 hidden reasoning tokens per question, billed as output.
- Sonnet's weak point is format: 2 of 24 answers (1 of 24 in a second run) were two JSON objects, after the model corrected itself in the text. The desk's tool must check the JSON and ask again once when it is not valid.

## 5. Limits of this evidence

- 24 questions on two topics. "0 critical errors in 24" is compatible with a true rate of up to about 14%. The check by a person stays necessary.
- One scorer, who also ran the models: the blinding was partial. A second scorer (Samir, for French) should score a sample of 20 answers to measure agreement.
- One run per model for the scores; hosted answers changed between two runs (Sonnet: 23 of 24 texts different; Gemini: 9 of 24).
- Prices of 2026-10-08. Local times were measured while other programs used the same computer.
- Data terms: Google's pricing page (2026-10-07) says free-tier content is used to improve its products and paid-tier content is not. Anthropic's commercial data terms were not re-read for this memo; read them before the contract (see Licensing and data terms).
- The pages are the reference: the water page (2023) still names "Industry Canada".

## 6. Fallback

- **Sonnet unavailable** (errors or more than 10 s for 5 minutes): switch to Gemini 3.5 Flash, same prompt, paid tier only. Tested in this comparison; about 60% more per question.
- **Both unavailable:** the desk answers by hand from the pages, as today. A local model is not a fallback: neither local model passed the must-haves.
- **Invalid JSON:** ask the same model once more; if it fails again, the person writes the answer.
- **"answerable": false:** the draft goes to a person first, flagged.

## 7. When to test again

- A new model version, a retirement notice, or a change of price for Sonnet or Gemini.
- A new topic or page (rerun the test with questions on that page).
- Any critical error found by the desk in a real draft.
- Every six months in any case, with this project (`scripts/run_models.py`, the same 24 questions, plus new ones).

## 8. Assumptions

- About 1,000 questions a month: about US$10 a month with Sonnet, US$16 with Gemini.
- Every draft is read by a person on the desk before it is sent.
- Questions are sent with only the page text needed; no names or file numbers are pasted in.
