# Rubric: one answer, four criteria, 0 to 2 points each

Score each answer against the official page and the key answer in `data/questions.csv`. Read the whole answer. Score blind: use `scoring/blind_answers.csv`, and open `scoring/blind_key.csv` only after you finish. Write one short note for every score below 2.

The four criteria and the meaning of each score are the course's rubric (Module 4, *Score outputs consistently*): correctness, completeness, format compliance and appropriate abstention. Only the examples change: the official page takes the place of the shop's policy, and "holding back" means saying that the page does not answer. A total of 8 is a perfect answer.

## Correctness: is everything it says true, according to the page?

| Score | Anchor |
|---|---|
| 2 | Every statement agrees with the page. Nothing is added from outside the page. |
| 1 | One small error or added detail that would not change what the person does (for example, a softer or stronger wording than the page). |
| 0 | A statement that is false according to the page, or a fact that is not on the page (a number, a phone number, a rule), that could change what the person does. **This is a critical error.** |

## Completeness: does it give what the person needs?

| Score | Anchor |
|---|---|
| 2 | All the points of the key answer that matter for the person's next step. |
| 1 | One needed point is missing (for example, the deadline but not the action, or one of two cases). |
| 0 | The main answer is missing, or there is no answer. |

For an unanswerable question, "complete" means: it says the page does not answer, and names the place to ask if the page names one.

## Format: can the desk use it as it is?

| Score | Anchor |
|---|---|
| 2 | Valid JSON with the four fields; in the language of the question; 2 to 5 sentences; the quote is copied from the page (or empty when the page does not answer). |
| 1 | Usable after a small fix: a quote that is not word for word, one sentence or more than 5, the JSON wrapped in a code fence, a few words in the other language, or a grammar error that a French reader notices. |
| 0 | The desk's tool cannot use it: not valid JSON, a missing field, no answer, or an answer mostly in the wrong language. |

## Abstention: does it hold back exactly when it should?

Holding back: the answer says that the page does not answer (and sets `answerable` to false), or, when the answer depends on something the question does not say, it says what it depends on.

| Score | Anchor |
|---|---|
| 2 | Holds back exactly when it should, and answers the rest. The `answerable` flag and the text agree. |
| 1 | Too cautious: holds back on a question, or a part of one, that the page answers (it costs the desk time, but does not mislead the person); or the flag and the text disagree in the safe direction (`answerable` is false on a good answer, so a person checks it first). |
| 0 | Not cautious enough: answers as if the page said something that it does not say (an unanswerable question answered from memory, or a question that depends on missing information answered for one case only); or gives no answer at all. |

When the flag and the text disagree in the unsafe direction (`answerable` is true, but the text says that the page does not answer), score 1, not 0: the text still holds back, so the person is not misled, but the desk's tool does not send the draft to a person first.

## Rules that keep scores consistent

- Score each criterion on its own. A wrong fact costs correctness; it does not also cost completeness unless a needed point is missing.
- A critical error (correctness 0) fails the answer for this use, whatever the total. Count critical errors separately.
- The page is the reference, even when you know it is out of date (for example, it names Industry Canada). The model must answer from the page.
- When you are unsure between two scores, give the lower one and write why in the note.
