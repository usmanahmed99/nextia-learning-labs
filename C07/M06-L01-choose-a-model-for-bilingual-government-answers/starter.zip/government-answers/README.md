# Choose a model for bilingual government answers

A model comparison for an assistant that answers questions from the public in English and French, using only the text of an official Government of Canada page. Four models, 24 questions, a blind rubric, measured latency and cost, and a decision memo.

This is the project of the case study C07-M06-L01 of Nextia Learning: <https://learning.nextia-ai.com/courses/llms/m06/choose-a-model-for-bilingual-government-answers/>. The page explains each step.

## What is in the folder

| Path | What it is |
|---|---|
| `data/pages/` | The text of two Health Canada pages, each in English and French (OGL – Canada; see `dataset.md`) |
| `data/questions.csv` | 24 questions (12 pairs, English and French) with a key answer each |
| `data/prompt.md` | The instructions that every model gets |
| `data/prices.json` | The prices used for the cost, with their source and date |
| `runs/` | The recorded answers of four models, 2026-10-08. `*_run2.jsonl`: a second run of the hosted models |
| `RUBRIC.md` | The four criteria and their anchors |
| `scoring/blind_answers.csv` | Every answer without the model's name: the sheet to score |
| `scoring/blind_key.csv` | Which answer is which model. Open it only after you score |
| `scripts/` | `run_models.py` (ask a model), `check.py` (automatic checks), `make_blind.py` (the blind sheet), `summarise.py` (the comparison table) |
| `MEMO.md` | The decision memo |
| `dataset.md` | Sources, licence check, attribution, known gaps |

## Without Python

Open `scoring/blind_answers.csv` in a spreadsheet (LibreOffice Calc, Excel, Google Sheets). Save a copy as `scoring/scores.csv`, and score each answer with `RUBRIC.md`. Then open `scoring/blind_key.csv` and compare the models. Write the memo in `MEMO.md`.

## With Python (3.12 or newer)

```sh
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python scripts/check.py          # automatic checks of the recorded runs
python scripts/make_blind.py     # the blind sheet (the same one as in the folder)
# score scoring/scores.csv, then:
python scripts/summarise.py      # the comparison table
```

To run a model yourself: a local model needs [Ollama](https://ollama.com) (`ollama pull gemma3:4b`, then `python scripts/run_models.py ollama:gemma3:4b`). A hosted model needs your own API key in the environment (`ANTHROPIC_API_KEY` or `GEMINI_API_KEY`); 24 questions cost a few cents. Use `RUN_SUFFIX=_mine` to keep the recorded runs. Never put a key in a file of this folder.

## Licence

Code and the files written for this case study: MIT (`LICENSE`). Page text: Open Government Licence – Canada. Contains information licensed under the Open Government Licence – Canada. This project is not affiliated with, or endorsed by, the Government of Canada.
