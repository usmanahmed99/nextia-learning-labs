# Rubric: one answer, four criteria, 0 to 2 points each

Score each answer against the official page and the key answer in `data/questions.csv`. Read the whole answer. Score blind: use `scoring/blind_answers.csv`, and open `scoring/blind_key.csv` only after you finish. Write one short note for every score below 2.

The four criteria are the course's rubric (Module 4): correctness, completeness, format compliance and appropriate abstention. A total of 8 is a perfect answer.

## Correctness: is everything it says true, according to the page?

| Score | Anchor |
|---|---|
| 2 | Every statement agrees with the page. Nothing is added from outside the page. |
| 1 | A small inaccuracy or an added detail that would not change what the person does (for example, a softer or stronger wording than the page). |
| 0 | A statement that is false according to the page, or a fact that is not on the page (a number, a phone number, a rule), that could change what the person does. **This is a critical error.** |

## Completeness: does it give what the person needs?

| Score | Anchor |
|---|---|
| 2 | All the points of the key answer that matter for the person's next step. |
| 1 | The main point, but a needed part is missing (for example, the deadline but not the action, or one of two cases). |
| 0 | The main point is missing. |

For an unanswerable question, "complete" means: it says the page does not answer, and names the place to ask if the page names one.

## Format: can the desk use it as it is?

| Score | Anchor |
|---|---|
| 2 | Valid JSON with the four fields; in the language of the question; 2 to 5 sentences; the quote is copied from the page (or empty when the page does not answer). |
| 1 | Usable, with one problem: a quote that is not word for word, too long or too short, the JSON wrapped in a code fence, or a few words in the other language. |
| 0 | Not usable without rework: not valid JSON, or the answer is in the wrong language. |

## Abstention: does it hold back exactly when it should?

| Score | Anchor |
|---|---|
| 2 | Answers what the page answers; says "the page does not say" when it does not; for an answer that depends on missing information, says what it depends on. The `answerable` flag is right. |
| 1 | Partly: the right flag but a guess in the text, or a refusal or heavy hedge on part of an answerable question. |
| 0 | Answers an unanswerable question as if the page said it, or refuses a question that the page answers. |

## Rules that keep scores consistent

- Score each criterion on its own. A wrong fact costs correctness; it does not also cost completeness unless a needed point is missing.
- A critical error (correctness 0) fails the answer for this use, whatever the total. Count critical errors separately.
- The page is the reference, even when you know it is out of date (for example, it names Industry Canada). The model must answer from the page.
- When you are unsure between two scores, give the lower one and write why in the note.
