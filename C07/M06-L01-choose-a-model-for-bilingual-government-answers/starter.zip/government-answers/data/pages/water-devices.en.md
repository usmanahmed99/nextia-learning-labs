# Questions And Answers On Drinking Water Treatment Devices

Source: https://www.canada.ca/en/health-canada/services/environmental-workplace-health/water-quality/questions-answers-drinking-water-treatment-devices.html
Date modified (on the page): 2023-05-30
Retrieved: 2026-10-08

---

- What are drinking water treatment devices?

- Should I purchase a drinking water treatment device?

- What drinking water treatment devices does Health Canada recommend?

- Are there devices that are certified for the removal or destruction of microbes?

- I have a reverse osmosis system in my home. I understand that some people are recommending that mineral supplements be taken in such a case. Is there any harm in using a reverse osmosis system and not taking mineral supplements?

- We have a well at our cottage. The water has a very strong sulphur smell. Is it dangerous?

- Are drinking water treatment devices regulated?

- Where can I get additional information on drinking water treatment devices?

## What are drinking water treatment devices?

Drinking water treatment devices are usually purchased by people wanting to treat their home water (from either a community water system or an individual source such as a well, lake, or river) or the water they will drink during outdoor recreational activities. Consumers may use these devices to modify the taste and appearance of water (as a matter of personal choice) or to make it fit for human consumption.

## Should I purchase a drinking water treatment device?

The need for a treatment device depends on your individual situation.

In general, the provinces and territories, along with their respective municipalities, are responsible for providing safe drinking water to Canadians. They establish and apply their own enforceable guidelines, objectives, or regulations for water quality, generally based on the Guidelines for Canadian Drinking Water Quality. These guidelines are developed by Health Canada in close collaboration with the provinces and territories. Drinking water that meets these guidelines does not usually require additional treatment for health-related reasons. For specific information on the quality of the water in your community, contact your local water supplier or municipality.

If you use an individual water supply (i.e., well, lake, river), you should have your drinking water tested regularly; your local public health services can advise you on which contaminants (microbial or chemical) to test for. If your drinking water does not comply with the Guidelines for Canadian Drinking Water Quality, you would then be in a position to take appropriate corrective measures (disinfect the well, drill a new well, install point-of-use or point-of-entry treatment devices, use bottled water, etc.). In such cases, a qualified water treatment specialist should be consulted for proper advice.

## What drinking water treatment devices does Health Canada recommend?

Health Canada does not recommend specific brands of drinking water treatment devices.

However, Health Canada strongly recommends that consumers wanting to purchase a drinking water treatment device purchase one that is certified as meeting the applicable ANSI/NSF performance standard. To figure out if a device has been certified, consumers should look for a certification mark and a statement that the device conforms to one or more of these six standards for drinking water treatment devices:

- ANSI/NSF standard 42 - Drinking Water Treatment Units - Aesthetic Effects

- ANSI/NSF standard 44 - Cation Exchange Water Softeners

- ANSI/NSF standard 53 - Drinking Water Treatment Units - Health Effects

- ANSI/NSF standard 55 - Ultraviolet Microbiological Water Treatment Systems

- ANSI/NSF standard 58 - Reverse Osmosis Drinking Water Treatment Systems

- ANSI/NSF standard 62 - Drinking Water Distillation Systems

Before a device is certified, it is tested by a certification body against one or more of these standards to ensure it complies with the stipulated requirements.

Certification bodies are authorized by the Standards Council of Canada to certify devices against these above-mentioned standards. Consumers can visit the websites of these certification bodies for further information. Each certification body maintains its own on-line databases of certified devices:

- CSA Group

- NSF International

- Water Quality Association

- UL LLC

- Bureau de normalisation du Québec (available in French only)

- Truesdail Laboratories

- International Association of Plumbing & Mechanical Officials

An up-to-date list of accredited certification organizations can be obtained directly from the Standards Council of Canada.

When a device is certified as meeting one of the above-mentioned standards, it means the device does not add anything harmful to the water, and the performance claims made by the manufacturer (those claims covered by the standard only) have been verified as being true. It should be noted that manufacturers may also make claims about their devices which fall "outside" the standards. Consumers are strongly advised to attentively review all packaging and promotional literature to identify which performance claims have actually been verified by the certification body.

Most treatment technologies are covered by one or more of the above-mentioned standards. However, some types are not. For example, no health-based performance standards are yet in place for either ozonators or microbial purifiers.

Finally, consumers are reminded that they should carefully follow the maintenance instructions included with the device; maintenance of these devices, although sometimes burdensome, is very important to ensure their continued efficacy.

## Are there devices that are certified for the removal or destruction of microbes?

Viruses, bacteria and protozoa are the three types of microorganism that can be found in water. Drinking water that complies with the Guidelines for Canadian Drinking Water Quality is considered microbiologically safe. However, in outdoor recreational settings or when supplied with water of unknown microbiological quality, consumers may consider using a treatment device as one of their options (other options include boiling the water, chemically disinfecting it, or using bottled water). It is recommended that consumers seek advice from a water treatment specialist before selecting a treatment device for this purpose.

Several treatment devices on the market have been certified as meeting ANSI/NSF standard 53 for parasitic cyst reduction. These devices can safely be used where drinking water is contaminated with Cryptosporidium, Giardia or other types of protozoa. These devices will not remove viruses or bacteria from water.

ANSI/NSF standard 55 separates UV systems into two classes for determining their disinfection performance. Certified Class B systems are suitable for supplemental bactericidal treatment of drinking water which is already deemed acceptable for human consumption. Systems certified as Class A are suitable for disinfection of contaminated water (though not to the level of raw sewage).

Distillation systems can have their microbial reduction claims certified against ANSI/NSF standard 62.

Some types of treatment devices cannot have their microbial reduction claims certified, because no health-based performance standards exist yet for them. Ozonators and microbial purifiers fall into this category. Health Canada representatives, together with academic and industry representatives, are currently working under the auspices of NSF International to develop standards that would eventually be used to verify microbial reduction claims.

## I have a reverse osmosis system in my home. I understand that some people are recommending that mineral supplements be taken in such a case. Is there any harm in using a reverse osmosis system and not taking mineral supplements?

Reverse osmosis systems remove minerals like calcium and magnesium from drinking water. In Canada, water is a minor source of such minerals when compared to foods.

If you consume a reasonably balanced diet, you do not need to take a mineral supplement when drinking water treated with a reverse osmosis system. Low levels of minerals in drinking water may only be concern for people living in countries with very hot climates.

## We have a well at our cottage. The water has a very strong sulphur smell. Is it dangerous?

The smell of sulphur does not indicate a health hazard. Rather, the smell is considered an aesthetic inconvenience.

Technologies, such as greensand filters, are available to remove sulphur odour. These filters are designed primarily to remove iron, manganese, and hydrogen sulfide from water. You may wish to contact a qualified water treatment specialist to discuss your options.

## Are drinking water treatment devices regulated?

Drinking water treatment devices generally fall under the scope of the Consumer Product Safety Act . and products that are a “danger to human health or safety” are subject to recall. However, no regulations under this Act are specific to these treatment devices . False or misleading claims about devices are prohibited under the Consumer Packaging and Labelling Act and the Competition Act, both administered by Industry Canada. Treatment devices that carry medical claims are regulated under the Medical Devices Regulations of the Food and Drugs Act.

## Where can I get additional information on drinking water treatment devices?

Find more information about choosing a drinking water filter.

For more information about drinking water materials, including treatment devices, e-mail us at water_eau@hc-sc.gc.ca
