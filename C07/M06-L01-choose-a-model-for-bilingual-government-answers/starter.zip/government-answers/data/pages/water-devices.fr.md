# Questions et réponses sur les dispositifs de traitement de l'eau de consommation

Source: https://www.canada.ca/fr/sante-canada/services/sante-environnement-milieu-travail/qualite-eau/questions-reponses-dispositifs-traitement-eau-consommation.html
Date modified (on the page): 2023-05-30
Retrieved: 2026-10-08

---

- Qu'est-ce qu'un dispositif de traitement de l'eau de consommation?

- Devrais-je me procurer un dispositif de traitement de l'eau?

- Quels types de dispositif de traitement de l'eau recommande Santé Canada?

- Y a-t-il des dispositifs certifiés pour l'enlèvement ou la destruction des microbes?

- Je possède un système d'osmose inverse à la maison. Certaines personnes recommandent de prendre des suppléments minéraux dans de tels cas. Y a-t-il un danger si je continue à boire de l'eau traitée par osmose inverse sans prendre de ces suppléments?

- J'ai un puits au chalet. L'eau qu'on en tire a une forte odeur de soufre. Est-ce dangereux pour la santé?

- Est-ce que les dispositifs de traitement de l'eau sont réglementés?

- Où puis-je trouver plus de renseignements?

## Qu'est-ce qu'un dispositif de traitement de l'eau de consommation?

Les dispositifs de traitement sont le plus souvent achetés par les consommateur qui désirent traiter l'eau qu'il boivent à la maison (provenant d'un réseau d'adduction soit collectif, soit individuel, tel que puits, lac ou rivière) ou durant leurs activités de plein air. Les consommateurs les utilisent pour modifier le goût ou l'apparence de l'eau (par choix personnel) ou pour rendre celle-ci potable.

## Devrais-je me procurer un dispositif de traitement de l'eau?

Cela dépend de votre situation propre.

Les provinces et les territoires, ainsi que leurs gouvernements municipaux respectifs, ont généralement la responsabilité de fournir une eau potable et saine aux Canadiennes et aux Canadiens. Ils établissent et font respecter leurs propres lignes directrices, objectifs ou règlements sur la qualité de l'eau, qui s'appuient habituellement sur les Recommandations pour la qualité de l'eau potable au Canada. Ces recommandations sont élaborées par Santé Canada en étroite collaboration avec les provinces et les territoires. Une eau de consommation qui est conforme à ces recommandations n'a pas généralement à subir d'autres traitements pour la rendre sans danger pour la santé. Pour obtenir des renseignements sur la qualité de l'eau provenant de votre réseau d'adduction collectif, communiquez avec le responsable du réseau ou votre municipalité.

Si vous êtes branchés sur un réseau individuel (p. ex., un puits, un lac ou une rivière), vous devriez faire analyser votre eau régulièrement. Votre service local de santé publique pourra vous informer sur la nature des contaminants (chimiques ou microbiens) à faire examiner. Si l'analyse révèle que votre eau n'est pas conforme aux Recommandations pour la qualité de l'eau potable au Canada, vous pourrez ensuite prendre les mesures correctrices qui s'imposent (désinfecter le puits, creuser un nouveau puits, installer un dispositif de traitement, utiliser de l'eau embouteillée). Le cas échéant, vous devriez voir un spécialiste en traitement de l'eau afin d'obtenir des conseils pertinents.

## Quels types de dispositif de traitement de l'eau recommande Santé Canada?

Santé Canada ne recommande aucune marque particulière de dispositifs de traitement de l'eau.

Toutefois, Santé Canada recommande fortement aux consommateurs qui désirent se procurer un dispositif de traitement de l'eau, d'acheter un dispositif certifié conforme à une des normes ANSI/NSF. Pour vérifier si un dispositif a bel et bien été certifié, on doit examiner le dispositif ou son emballage : une marque de certification et une indication que le dispositif satisfait à une ou plusieurs des six normes pour les dispositifs de traitement :

- ANSI/NSF standard 42 - Drinking Water Treatment Units--Aesthetic Effects (Dispositifs de traitement de l'eau potable--Effets organoleptiques)

- ANSI/NSF standard 44 - Cation Exchange Water Softeners (Adoucisseurs d'eau à échange de cations)

- ANSI/NSF standard 53 - Drinking Water Treatment Units--Health Effects (Dispositifs de traitement de l'eau potable--Effets sur la santé)

- ANSI/NSF standard 55 - Ultraviolet Microbiological Water Treatment Systems (Systèmes de traitement microbiologique de l'eau par les ultraviolets)

- ANSI/NSF standard 58 - Reverse Osmosis Drinking Water Treatment Systems (Systèmes de traitement de l'eau potable par osmose inverse)

- ANSI/NSF standard 62 - Drinking Water Distillation Systems (Systèmes de distillation de l'eau potable)

Pour qu'un dispositif soit certifié, un organisme de certification doit s'assurer que le dispositif rencontre les exigences prescrites dans la norme ou les normes qui s'appliquent.

Les organismes de certification sont autorisés par le Conseil canadien des normes à certifier les dispositifs de traitement aux normes applicables. Les consommateurs qui désirent obtenir de plus amples renseignements sont invités à visiter les sites Internet de ces organismes. Chaque organisme permet l'accès à leur base de données interactive sur les dispositifs de traitement :

- Groupe CSA

- NSF International

- Water Quality Association (en anglais seulement)

- UL LLC (en anglais seulement)

- Bureau de normalisation du Québec

- Truesdail Laboratories, Inc (en anglais seulement)

- International Association of Plumbing and Mechanical Officials (en anglais seulement)

On peut obtenir une liste à jour des organismes de certification accrédités auprès du CCN.

Pour un dispositif de traitement de l'eau, la certification de sa conformité à une des normes susmentionnées signifie qu'il n'ajoute rien qui soit dangereux pour la santé à l'eau qu'il traite, et que les allégations faites quant à sa performance ont été vérifiées (seulement les allégations prévues par la norme, toutefois). Il importe de noter que les fabricants peuvent faire des allégations "hors normes" quant à la performance de leurs dispositifs, et ce même pour un dispositif certifié. Le consommateur averti examinera attentivement le matériel d'emballage et de promotion afin de bien identifier les allégations vérifiées par l'organisme de certification et celles qui n'ont pas fait l'objet de certification.

Les normes susmentionnées couvrent la majorité des technologies couramment utilisées pour le traitement de l'eau. Toutefois, il n'existe toujours pas de normes de rendement en matière de santé pour les ozonateurs et les filtres antimicrobiens.

Enfin, les consommateurs devraient suivre de très près les instructions d'entretien fournies avec leur dispositif. Bien que parfois déplaisant, l'entretien du dispositif est très important afin d'assurer l'efficacité continue de ce dernier.

## Ya-t-il des dispositifs certifiés pour l'enlèvement ou la destruction des microbes?

Les virus, les bactéries et les protozoaires sont les trois types de microorganismes que l'on trouve dans l'eau. L'eau potable qui est conforme aux Recommandations pour la qualité de l'eau potable au Ca nada, est généralement jugée salubre du point de vue microbiologique. Toutefois, lors d'activités de plein air ou lorsque l'eau est de qualité microbiologique douteuse, potabiliser l'eau à l'aide d'un dispositif a est une des options qui s'offrent au consommateur (on peut aussi faire bouillir l'eau, la disinfecter chimiquement, ou boire de l'eau embouteillée). On recommande aux consommateurs de demander l'avis d'un spécialiste en traitement de l'eau avant d'arrêter leur choix.

Il existe de nombreux dispositifs sur le marché qui ont été certifiés conformes à la norme ANSI/NSF 53 pour la réduction des kystes parasitiques. On peut utiliser ces dispositifs en toute confiance afin de traiter l'eau contaminée par Cryptosporidium, Giardia ou autres protozoaires. Ces dispositifs n'enlèveront ni les virus ni les bactéries.

La norme ANSI/NSF 55 reconnaît deux classes de système UV en matière de performance de désinfection. La classe B regroupe les systèmes qui fournissent un traitement bactéricide d'appoint lorsque l'eau à traiter a déjà une qualité microbiologique jugée acceptable. Les systèmes de classe A quant à eux peuvent être utilisés pour désinfecter une eau contaminée (mais pas autant que les eaux d'égout brutes).

Les sytèmes de distillation qui revendiquent pouvoir réduire la charge microbienne de l'eau peuvent, en vertu de la norme ANSI/NSF 62, faire l'objet d'essais de certification afin de vérifier la véracité de telles allégations.

Actuellement, il demeure impossible de certifier certains types de dispositifs sur lesquels figurent des allégations en matière de réduction microbienne, puisqu'il n'existe pas de normes de rendement en matière de santé pour ceux-ci. Les ozonateurs et les filtres antimicrobiens font partie de cette catégorie. Des représentants de Santé Canada, des universitaires et des experts de l'industrie travaillent présentement ensemble, sous l'égide de NSF International, à élaborer des normes pour pallier ces lacunes.

## Je possède un système d'osmose inverse à la maison. Certaines personnes recommandent de prendre des suppléments minéraux dans de tels cas. Y a-t-il un danger si je continue à boire de l'eau traitée par osmose inverse sans prendre de ces suppléments?

Les systèmes à osmose inverse enlèvent des minéraux comme le calcium et le magnesium de l'eau potable. Au Canada, l'eau potable est une faible source de minéraux en comparaison des aliments.

Si vous avez un régime alimentaire équilibré, il vous est inutile de prendre des suppléments minéraux lorsque vous buvez de l'eau traitée par osmose inverse. Par contre, un faible taux de minéraux dans l'eau potable pourrait être un sujet d'inquiétude dans les pays très chauds.

## J'ai un puits au chalet. L'eau qu'on en tire a une forte odeur de soufre. Est-ce dangereux pour la santé?

L'odeur du soufre n'est pas indicatrice de dangers à la santé. Elle équivaut plutôt à un désagrément organoleptique.

Il existe des technologies, telles que les filtres au sable vert, qui permettent d'enlever l'odeur de soufre. Ces filtres sont principalement conçus pour enlever le fer, le manganèse et l'hydrogène sulfurée de l'eau potable. Pour discuter des diverses options disponibles, communiquez avec un spécialiste en traitement de l'eau.

## Est-ce que les dispositifs de traitement de l'eau sont réglementés?

Les dispositifs de traitement de l'eau potable tombent en règle générale sous la portée de la Loi canadienne sur la sécurité des produits de consommation et les produits qui « présentent un danger pour la santé ou la sécurité humaine » font l'objet d'un ordre de rappel. Toutefois, aucun règlement afférent ne vise en particulier les dispositifs de traitement. La Loi sur l'emballage et l'étiquetage des produits de consommation et la Loi sur la concurrence, toutes les deux administrées par Industrie Canada, interdisent que l'on fasses des allégations fausses ou trompeuses au sujet des dispositifs. Les dispositifs de traitement pour lesquels on fait des revendications de nature médicale sont réglementés en vertu du Règlement sur les instruments médicaux de la Loi sur les aliments et drogues.

## Où puis-je trouver plus de renseignements?

Trouver plus d'information sur comment choisir un filtre à eau potable.

Pour de plus amples renseignements sur les produits liés à l'eau potable, y compris les dispositifs de traitement de l'eau, vous pouvez communiquer avec nousà water_eau@hc-sc.gc.ca.
