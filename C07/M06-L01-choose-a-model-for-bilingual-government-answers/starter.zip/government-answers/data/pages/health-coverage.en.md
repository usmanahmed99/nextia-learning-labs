# How publicly funded health care coverage works

Source: https://www.canada.ca/en/health-canada/services/health-care-system/canada-health-care-system-medicare/canada-health-act-frequently-asked-questions.html
Date modified (on the page): 2025-07-16
Retrieved: 2026-10-08

---

## On this page

- Provinces and territories manage public health insurance plans

- Who is eligible for health care coverage

- Health services insured by public health insurance plans

- Provinces and territories decide which medical conditions they will insure

- Health services not insured by public health insurance plans

- Patient charges and the cost of publicly funded health care

- The role of the private sector in providing health services

- Moving to another province or territory

- Travelling outside your province or territory, or outside Canada

- Resuming health care coverage when you return to Canada

## Provinces and territories manage public health insurance plans

In Canada, each province and territory has its own publicly funded health insurance plan. The provinces and territories receive a cash contribution from the Government of Canada to administer their plan. This contribution is done through an arrangement called the Canada Health Transfer.

Every public health insurance plan shares common features and basic standards of coverage in accordance with the Canada Health Act. This federal law sets out the conditions for services that the plans insure.

Public health insurance plans must meet the following conditions to receive their full federal cash contribution:

- operate on a non-profit basis

- provide coverage to all eligible Canadian residents

- ensure portable coverage of medically necessary services

- cover all medically necessary hospital, physician and certain surgical-dental services

- ensure access to medically necessary services on uniform terms and conditions, without patient charges

## Who is eligible for health care coverage

All eligible residents of a province or territory can apply for publicly funded health care coverage. The provinces and territories decide who is an eligible resident for health care coverage.

To obtain and keep your health care coverage, you must:

- have registered for coverage in your province or territory

- continue to renew your coverage in your province or territory and

- remain in your province or territory for a certain number of days each year, as determined by the province or territory

You may temporarily leave your home province or territory for school, work or other reasons and keep your health care coverage. However, you must inform your provincial or territorial health care insurance plan when you will be away for extended periods.

Learn more about the eligibility requirements for health care coverage in each province and territory. Visit About health insurance cards.

## Health services insured by public health insurance plans

Under the Canada Health Act, public health insurance plans must provide coverage for medically necessary hospital, physician and certain surgical-dental services. These are called insured health services.

The Canada Health Act does not define medical necessity. It's up to the provinces and territories to determine which services are medically necessary. They usually consult with medical professionals to help them determine this.

Along with these insured health services, the provinces and territories also fund and deliver other health services. Each province and territory determines what services it will cover and whether it will fund them in part or in full. Examples of these types of services include prescription drugs, dental care, optometric, chiropractic and ambulance services.

Often, these types of services are targeted to certain population groups, such as children, seniors and people who receive social assistance.

## Provinces and territories decide which medical conditions they will insure

The Canada Health Act is a short piece of legislation. It lays out overall standards for providing medically necessary hospital, physician services and certain surgical-dental services (insured health services).

The act doesn't list specific medical conditions. Instead, it requires provincial and territorial health care insurance plans to cover insured health services.

The provinces and territories are responsible for delivering insured health services. They decide, in consultation with medical professionals, which services are insured health services and will be covered.

## Health services not insured by public health insurance plans

Services provided in a hospital or by a doctor that are not considered medically necessary are not covered by a public health insurance plan. These are known as uninsured health services.

Patients pay for uninsured health services.

Examples of uninsured health services include:

- cosmetic procedures

- medical testimony in court

- private duty nursing services

- telephones and televisions in the hospital room

- preferred hospital accommodation unless prescribed by a doctor

- medical certificates required for work, school, insurance purposes and fitness clubs

## Patient charges and the cost of publicly funded health care coverage

Eligible Canadian residents do not pay for medically necessary services. These are insured under your provincial or territorial health insurance plan.

However, health care in Canada isn't free. Health care in Canada is funded through tax revenues collected by the federal government and the provinces and territories. Spreading the cost of providing medically necessary services across the entire population means everyone can receive the care they need without having to worry about large medical bills.

There may be patient charges for services that are not considered medically necessary and not covered by your provincial or territorial health insurance plan.

You should contact your provincial or territorial ministry of health if you believe you have been charged for a medically necessary service.

Visit About health insurance cards for links to provincial and territorial ministries of health or contact the Canada Health Act Division:

- Telephone: 1-800-465-7735 (Service Canada)

- Email: medicare.spb.chad-dlcs.dgps.assurance.maladie@hc-sc.gc.ca

## The role of the private sector in providing health services

Many health services are delivered by private providers. The Canada Health Act doesn't forbid private providers from delivering health services, as long as they don't charge for medically necessary services. Medically necessary services are insured by your provincial or territorial health care insurance plan.

Many aspects of health care in Canada are delivered privately. For example:

- Hospitals are often incorporated private foundations.

- Many aspects of hospital care, such as lab services, housekeeping and linens, are carried out privately.

- Family doctors mostly bill their provincial or territorial health care insurance plan as private contractors.

- In many provinces and territories, private facilities are contracted to provide services under the health care insurance plan.

## Moving to another province or territory

If you are moving to another province or territory, you must:

- let your provincial or territorial health insurance plan know that you are moving

- register with the health insurance plan of your new province or territory

You will continue to be covered by your home province or territory for 3 months. Provided you have registered in the new province or territory, coverage will begin after this period.

## Travelling outside your province or territory, or outside Canada

### Travelling outside your province or territory

You will continue to be covered for emergency hospital and physician services if you leave your province or territory for a few hours, days or weeks.

You may not be covered for services that are not considered medically necessary. These include costs for prescription drugs and ambulance services, for example. These extra services are highly subsidized for residents of a province or territory but not for visitors.

Be sure to have adequate coverage, which may include private health insurance, whenever you travel or move within Canada.

For non-emergency care, you usually need approval from your provincial or territorial health insurance plan before they will pay for services delivered elsewhere in or outside Canada.

### Travelling outside Canada

Your provincial or territorial health insurance plan will cover some of the costs for emergency health services if you become ill suddenly or are in an accident.

The cost that's covered is based on the amount the province or territory would have paid for similar services if you were home. You will have to pay the balance if the cost of the services you receive outside Canada are greater than this amount.

You should purchase private health insurance before travelling outside Canada to protect yourself.

## Resuming health care coverage when you return to Canada

When you return to Canada after being away for some time, you must register with your province or territory to establish or re-establish health care coverage. You may have to wait up to 3 months before coverage starts.

Contact your province's or territory's ministry of health as soon as you return to register for health care coverage.

For links to provincial and territorial ministries of health, visit About health insurance cards.

## Related links

- About the Canada Health Act

- About health insurance cards
