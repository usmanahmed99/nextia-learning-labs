# Comment fonctionne la couverture de soins de santé financés par des fonds publics

Source: https://www.canada.ca/fr/sante-canada/services/systeme-soins-sante/systeme-sante-canadien-assurance-sante/loi-canadienne-sante-foire-questions.html
Date modified (on the page): 2025-07-16
Retrieved: 2026-10-08

---

## Sur cette page

- Gestion des régimes publics d'assurance maladie par les provinces et les territoires

- Personnes admissibles à la couverture de soins de santé

- Services de santé assurés par les régimes publics d'assurance maladie

- Les provinces et les territoires déterminent les problèmes médicaux qui seront assurés

- Services de santé non assurés par les régimes publics d'assurance maladie

- Frais imposés aux patients et coût de la couverture de soins de santé financés par des fonds publics

- Le rôle du secteur privé dans la prestation de services de santé

- Déménagement dans une autre province ou un autre territoire

- Voyager à l'extérieur de votre province ou territoire, ou du Canada

- Rétablissement de votre couverture de soins de santé à votre retour au Canada

## Gestion des régimes publics d'assurance maladie par les provinces et les territoires

Au Canada, chaque province et territoire a son propre régime public d'assurance maladie. Les provinces et les territoires reçoivent une contribution financière du gouvernement du Canada pour administrer leur régime. Cette contribution est possible grâce à une entente appelée le Transfert canadien en matière de santé.

Tout régime public d'assurance maladie partage des caractéristiques communes et des normes de couverture de base conformément à la Loi canadienne sur la santé. Cette loi fédérale établit les conditions pour les services assurés par les régimes.

Les régimes publics d'assurance maladie doivent satisfaire aux conditions suivantes pour recevoir la pleine contribution financière fédérale :

- Être gérés sans but lucratif

- Fournir la couverture à tous les résidents canadiens admissibles

- Garantir une couverture transférable des services médicalement nécessaires

- Couvrir tous les services hospitaliers, médicaux et certains services de chirurgie dentaire médicalement nécessaires

- Assurer l'accès aux services médicalement nécessaires selon des modalités uniformes, sans frais pour les patients

## Personnes admissibles à la couverture de soins de santé

Tous les résidents admissibles d'une province ou d'un territoire peuvent faire une demande pour obtenir la couverture de soins de santé financés par des fonds publics. Les provinces et les territoires déterminent les résidents admissibles à cette couverture.

Pour obtenir et maintenir votre couverture de soins de santé, vous devez :

- être inscrit à la couverture de votre province ou territoire

- continuer à renouveler votre couverture dans votre province ou territoire

- et demeurer dans votre province ou territoire pendant un certain nombre de jours par année, comme déterminé par la province ou le territoire

Vous pouvez quitter de manière temporaire votre province ou territoire d'origine pour étudier, travailler ou d'autres raisons et maintenir votre couverture de soins de santé. Cependant, vous devez informer votre régime provincial ou territorial d'assurance maladie si vous vous absentez pendant une période prolongée.

Apprenez-en plus sur les critères d'admissibilité à la couverture de soins de santé dans chaque province et territoire. Visitez À propos des cartes d'assurance maladie.

## Services de santé assurés par les régimes publics d'assurance maladie

En vertu de la Loi canadienne sur la santé, les régimes publics d'assurance maladie doivent couvrir les services hospitaliers et médicaux et certains services de chirurgie dentaire médicalement nécessaires, qui se nomment les services de santé assurés.

La Loi canadienne sur la santé ne définit pas la nécessité médicale. Les provinces et les territoires doivent déterminer les services qui sont médicalement nécessaires. Ils le font habituellement en consultation avec des professionnels de la santé.

En plus de ces services de santé assurés, les provinces et les territoires financent et fournissent également d'autres services de santé. Chaque province et territoire détermine les services qui seront couverts et s'ils seront financés en totalité ou en partie. Des exemples de ces types de services comprennent les médicaments sur ordonnance, les services de soins dentaires, ainsi que les services optométriques, chiropratiques et ambulanciers.

Souvent, ces types de services s'adressent à certains groupes de population, tels que les enfants, les personnes âgées et les bénéficiaires de l'aide sociale.

## Les provinces et les territoires déterminent les problèmes médicaux qui seront assurés

La Loi canadienne sur la santé est un texte législatif assez court. Elle établit les normes générales pour la prestation de services hospitaliers, médicaux et certains services de chirurgie dentaire médicalement nécessaires (services de santé assurés).

La loi ne précise pas les problèmes médicaux. Elle exige plutôt que les régimes provinciaux et territoriaux d'assurance maladie couvrent les services de santé assurés.

Les provinces et les territoires ont la responsabilité de la prestation de services de santé assurés. Ils déterminent, en consultation avec les professionnels de la santé, les services qui constituent des services de santé assurés et qui seront couverts.

## Services de santé non assurés par les régimes publics d'assurance maladie

Le régime public d'assurance maladie ne couvre pas les services fournis dans un hôpital ou par un médecin qui ne sont pas considérés comme médicalement nécessaires. Ce sont des services de santé non assurés.

Les patients doivent assumer le coût des services de santé non assurés.

Voici des exemples de services de santé non assurés :

- Chirurgies esthétiques

- Témoignages médicaux en cour

- Soins infirmiers privés

- Téléphones et télévisions dans la chambre d'hôpital

- Hospitalisation en chambre à un ou deux lits, sauf si elle est prescrite par un médecin

- Certificats médicaux nécessaires pour l'employeur, l'école, les assurances et les centres de conditionnement physique

## Frais imposés aux patients et coût de la couverture de soins de santé financés par des fonds publics

Les résidents canadiens admissibles ne paient pas les frais médicalement nécessaires, car ils sont assurés par le régime provincial ou territorial d'assurance maladie.

Toutefois, les soins de santé au Canada ne sont pas gratuits. Ces soins sont financés par les recettes fiscales des provinces, des territoires et du gouvernement fédéral. En répartissant le coût des services médicalement nécessaires parmi l'ensemble de la population, chacun peut recevoir les soins dont il a besoin, sans devoir payer des frais médicaux élevés.

Il pourrait y avoir des frais imposés aux patients pour les services qui ne sont pas considérés comme médicalement nécessaires et qui ne sont pas couverts par votre régime provincial ou territorial d'assurance maladie.

Vous devriez communiquer avec votre ministère de la Santé provincial ou territorial si vous croyez qu'un service médicalement nécessaire vous a été facturé.

Visitez À propos des cartes d'assurance maladie pour des liens vers les ministères provinciaux et territoriaux de la Santé ou communiquez avec la Division de la Loi canadienne sur la santé :

- Téléphone : 1-800-465-7735 (Service Canada)

- Courriel : medicare.spb.chad-dlcs.dgps.assurance.maladie@hc-sc.gc.ca

## Le rôle du secteur privé dans la prestation de services de santé

De nombreux services de santé sont fournis par des prestataires privés. La Loi canadienne sur la santé n'interdit pas aux prestataires privés de fournir ces services, à condition qu'ils ne facturent pas les services médicalement nécessaires. Ces services sont assurés par votre régime provincial ou territorial d'assurance maladie.

Bien des aspects des soins de santé au Canada sont pris en charge par le secteur privé, notamment les suivants :

- Les hôpitaux qui sont souvent constitués en fondations privées.

- De nombreux aspects des soins hospitaliers (par exemple, les services de laboratoire, l'entretien ménager et la literie).

- Les médecins de famille qui facturent le plus souvent le régime d'assurance maladie provincial ou territorial en tant qu'entrepreneurs privés.

- Dans nombre de provinces et territoires, des établissements privés sont engagés par contrat afin de fournir des services dans le cadre du régime d'assurance maladie.

## Déménagement dans une autre province ou un autre territoire

Si vous déménagez dans une autre province ou un autre territoire, vous devez :

- informer votre régime provincial ou territorial d'assurance maladie de votre déménagement

- vous inscrire auprès du régime d'assurance maladie de votre nouvelle province ou nouveau territoire

Vous continuerez à bénéficier de la couverture dans votre province ou territoire d'origine pendant 3 mois. Si vous êtes inscrit à la couverture dans votre nouvelle province ou nouveau territoire, elle débutera après cette période.

## Voyager à l'extérieur de votre province ou territoire, ou du Canada

### Voyager à l'extérieur de votre province ou territoire

Vous continuerez à bénéficier de la couverture pour les services hospitaliers et médicaux d'urgence si vous quittez votre province ou territoire pendant quelques heures, jours ou semaines.

Il se peut que les services qui ne sont pas considérés comme médicalement nécessaires ne soient pas couverts. Ces services comprennent les coûts pour les médicaments sur ordonnance et les services ambulanciers, par exemple. Ces services supplémentaires sont fortement subventionnés pour les résidents, mais pas pour les visiteurs.

C'est la raison pour laquelle vous devez vous assurer que vous disposez d'une couverture adéquate lorsque vous voyagez ou déménagez à l'intérieur du pays.

Pour les soins non urgents, vous avez habituellement besoin de l'approbation de votre régime provincial ou territorial d'assurance maladie avant qu'il couvre les services fournis ailleurs au Canada ou à l'extérieur du Canada.

### Voyager à l'extérieur du Canada

Votre régime provincial ou territorial d'assurance maladie couvrira certains coûts des services de santé d'urgence si vous êtes soudainement malade ou avez un accident.

Les frais couverts sont fondés sur le montant que la province ou le territoire aurait versé pour des services semblables si vous étiez à domicile. Vous devrez payer le montant restant si le coût des services que vous recevez à l'extérieur du Canada est plus élevé que ce montant.

Vous devriez souscrire une assurance maladie privée avant de voyager à l'extérieur du Canada pour assurer votre protection.

## Rétablissement de votre couverture de soins de santé à votre retour au Canada

À votre retour au Canada après une absence durant quelque temps, vous devez vous inscrire auprès de votre province ou territoire pour établir ou rétablir votre couverture de soins de santé. Vous devrez peut-être attendre jusqu'à 3 mois avant le début de la couverture.

Communiquez avec le ministère de la Santé de votre province ou territoire dès votre retour pour vous inscrire à la couverture de soins de santé.

Pour des liens vers les ministères de la Santé provinciaux et territoriaux, visitez À propos des cartes d'assurance maladie.

## Liens connexes

- À propos des cartes d'assurance maladie

- À propos de la Loi canadienne sur la santé
