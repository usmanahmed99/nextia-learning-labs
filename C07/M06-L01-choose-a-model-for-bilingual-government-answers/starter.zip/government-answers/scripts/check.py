"""Automatic checks on every recorded run: the parts of the rubric a script can see.

    python scripts/check.py

For each answer: is it valid JSON with the four fields, is it in the language
of the question, is the "answerable" flag right, is the quote really on the
page (word for word), how many sentences, and which key phrases it contains or
must not contain. Writes results/checks.csv and prints one line per run.

These checks help a person score; they do not replace reading the answer. A
key phrase can be present in a wrong sentence, and a correct answer can use
other words.
"""

import csv
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
QUESTIONS = {q["id"]: q for q in csv.DictReader((ROOT / "data" / "questions.csv").open(encoding="utf-8"))}
EN = {"the", "and", "is", "you", "your", "of", "to", "for", "not", "does", "can", "with", "this", "page", "are", "if"}
FR = {"le", "la", "les", "des", "est", "vous", "votre", "pas", "une", "pour", "que", "du", "ne", "cette", "avec", "si"}


def normalise(text: str) -> str:
    text = text.replace("’", "'").replace(" ", " ").replace(" ", " ")
    text = text.replace("“", '"').replace("”", '"').replace("**", "")
    text = re.sub(r"(^|\s)- ", " ", text)  # the list markers of the saved page text
    return re.sub(r"\s+", " ", text).strip().strip('"').strip().lower()


PAGES = {}
for path in (ROOT / "data" / "pages").glob("*.md"):
    body = path.read_text(encoding="utf-8").partition("\n---\n")[2]
    PAGES[path.stem] = normalise(re.sub(r"^#+ |^- ", "", body, flags=re.M))


def language_of(text: str) -> str:
    words = re.findall(r"[a-zà-ÿ]+", text.lower())
    en, fr = sum(w in EN for w in words), sum(w in FR for w in words)
    return "en" if en > fr else "fr" if fr > en else "?"


def sentences(text: str) -> int:
    return len([s for s in re.split(r"(?<=[.!?])\s+", text.strip()) if s])


def phrases(text: str, spec: str) -> tuple[int, int]:
    """How many of the ';'-separated phrases (each with '|' alternatives) are in the text."""
    groups = [g for g in spec.split(";") if g.strip()]
    low = normalise(text)
    return sum(any(alt.strip().lower() in low for alt in g.split("|")) for g in groups), len(groups)


def check(record: dict) -> dict:
    q = QUESTIONS[record["id"]]
    p = record["parsed"] or {}
    answer = str(p.get("answer", "")) if p else ""
    quote = str(p.get("quote", "")) if p else ""
    expect_answerable = q["answerable"] == "true"
    quote_ok = (normalise(quote).rstrip(".") in PAGES[f"{q['page']}.{q['language']}"]) if quote.strip() else not expect_answerable
    hits, total = phrases(answer, q["must_include"])
    bad, _ = phrases(answer, q["must_not_include"])
    return {
        "id": q["id"], "language": q["language"], "kind": q["kind"],
        "valid_json": bool(record["parsed"]),
        "fields_ok": bool(p) and {"language", "answerable", "answer", "quote"} <= set(p),
        "answer_language": language_of(answer) if answer else "",
        "language_ok": bool(answer) and language_of(answer) == q["language"],
        "answerable_ok": bool(p) and p.get("answerable") is expect_answerable,
        "quote_ok": bool(p) and quote_ok,
        "sentences": sentences(answer) if answer else 0,
        "must_include": f"{hits}/{total}" if total else "",
        "must_not_hits": bad,
        "stop_reason": record.get("stop_reason"),
    }


def main() -> None:
    rows = []
    for path in sorted((ROOT / "runs").glob("*.jsonl")):
        records = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
        checked = [{"run": path.stem, **check(r)} for r in records]
        rows += checked
        n = len(checked)
        count = lambda key: sum(bool(c[key]) for c in checked)
        print(f"{path.stem:42} {n:2} answers | JSON {count('valid_json'):2} | language {count('language_ok'):2} | "
              f"answerable {count('answerable_ok'):2} | quote on page {count('quote_ok'):2} | "
              f"forbidden phrase {sum(c['must_not_hits'] > 0 for c in checked)}")
    out = ROOT / "results" / "checks.csv"
    out.parent.mkdir(exist_ok=True)
    with out.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(f"Wrote {out.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
