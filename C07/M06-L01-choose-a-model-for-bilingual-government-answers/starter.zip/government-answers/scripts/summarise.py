"""Join the scores, the runs and the prices into one comparison table.

    python scripts/summarise.py

Reads scoring/scores.csv (your filled copy of the blind sheet) and
scoring/blind_key.csv, the runs and data/prices.json. Prints, for each model:
the rubric scores (all, English, French), the answers with full marks and a
95% interval for that share, the critical errors (correctness 0), the
latency, the tokens and the cost per question. Writes results/summary.csv and
results/by_kind.csv.
"""

import csv
import json
import math
import statistics
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CRITERIA = ["correctness", "completeness", "format", "abstention"]
NAMES = {
    "anthropic_claude-sonnet-5-5": ("Claude Sonnet 5.5", "anthropic:claude-sonnet-5-5"),
    "gemini_gemini-3.5-flash": ("Gemini 3.5 Flash", "gemini:gemini-3.5-flash"),
    "ollama_gemma3-4b": ("Gemma 3 4B (local)", "ollama:gemma3:4b"),
    "ollama_mistral-7b": ("Mistral 7B (local)", "ollama:mistral:7b"),
}


def wilson(k: int, n: int, z: float = 1.96) -> tuple[float, float]:
    """A 95% interval for a share k/n (Wilson's method; good for small n)."""
    p = k / n
    centre = (p + z * z / (2 * n)) / (1 + z * z / n)
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / (1 + z * z / n)
    return max(0.0, centre - half), min(1.0, centre + half)


def p95(values: list[float]) -> float:
    ordered = sorted(values)
    return ordered[math.ceil(0.95 * len(ordered)) - 1]


def main() -> None:
    prices = json.loads((ROOT / "data" / "prices.json").read_text(encoding="utf-8"))["models"]
    key = {(r["id"], r["label"]): r["run"] for r in csv.DictReader((ROOT / "scoring" / "blind_key.csv").open(encoding="utf-8"))}
    scores = defaultdict(list)
    for row in csv.DictReader((ROOT / "scoring" / "scores.csv").open(encoding="utf-8")):
        if all(row[c].strip() for c in CRITERIA):
            row = {**row, **{c: int(row[c]) for c in CRITERIA}, "total": sum(int(row[c]) for c in CRITERIA)}
            scores[key[(row["id"], row["label"])]].append(row)

    summary, by_kind = [], []
    for run, (name, price_key) in NAMES.items():
        rows = scores.get(run, [])
        records = [json.loads(line) for line in (ROOT / "runs" / f"{run}.jsonl").read_text(encoding="utf-8").splitlines()]
        price = prices[price_key]
        cost = [(r["input_tokens"] * price["input"] + (r["output_tokens"] + r["reasoning_tokens"]) * price["output"]) / 1e6
                for r in records]
        seconds = [r["seconds"] for r in records]
        # Local models: the time inside Ollama without loading the model (a request can
        # wait in Ollama's queue, or for a model load, when another program uses it).
        warm = [r.get("server_seconds", r["seconds"]) - r.get("load_seconds", 0) for r in records]
        full = sum(r["total"] == 8 for r in rows)
        low, high = wilson(full, len(rows)) if rows else (0, 0)
        mean = lambda xs: round(statistics.mean(xs), 2) if xs else ""
        summary.append({
            "model": name, "scored": len(rows),
            "score_of_8": mean([r["total"] for r in rows]),
            **{c: mean([r[c] for r in rows]) for c in CRITERIA},
            "score_en": mean([r["total"] for r in rows if r["language"] == "en"]),
            "score_fr": mean([r["total"] for r in rows if r["language"] == "fr"]),
            "full_marks": full, "full_marks_95_low": round(low, 2), "full_marks_95_high": round(high, 2),
            "critical_errors": sum(r["correctness"] == 0 for r in rows),
            "median_s": round(statistics.median(seconds), 1), "p95_s": round(p95(seconds), 1),
            "median_s_model_only": round(statistics.median(warm), 1),
            "tokens_in": round(statistics.mean(r["input_tokens"] for r in records)),
            "tokens_out": round(statistics.mean(r["output_tokens"] for r in records)),
            "tokens_reasoning": round(statistics.mean(r["reasoning_tokens"] for r in records)),
            "usd_per_question": round(statistics.mean(cost), 5),
            "usd_per_1000_questions": round(1000 * statistics.mean(cost), 2),
        })
        for kind in ("routine", "difficult", "ambiguous", "unanswerable"):
            k_rows = [r for r in rows if r["kind"] == kind]
            by_kind.append({"model": name, "kind": kind, "answers": len(k_rows),
                            "score_of_8": mean([r["total"] for r in k_rows]),
                            "critical_errors": sum(r["correctness"] == 0 for r in k_rows)})

    out = ROOT / "results"
    out.mkdir(exist_ok=True)
    for name, rows in (("summary.csv", summary), ("by_kind.csv", by_kind)):
        with (out / name).open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)

    print(f"{'Model':20} {'Score/8':>7} {'EN':>5} {'FR':>5} {'Full marks (95%)':>18} {'Critical':>8} "
          f"{'Median s':>8} {'p95 s':>6} {'US$/1,000':>9}")
    for s in summary:
        marks = f"{s['full_marks']}/{s['scored']} ({s['full_marks_95_low']:.0%}-{s['full_marks_95_high']:.0%})"
        print(f"{s['model']:20} {s['score_of_8']:>7} {s['score_en']:>5} {s['score_fr']:>5} {marks:>18} "
              f"{s['critical_errors']:>8} {s['median_s']:>8} {s['p95_s']:>6} {s['usd_per_1000_questions']:>9}")
    print("Wrote results/summary.csv and results/by_kind.csv")


if __name__ == "__main__":
    main()
