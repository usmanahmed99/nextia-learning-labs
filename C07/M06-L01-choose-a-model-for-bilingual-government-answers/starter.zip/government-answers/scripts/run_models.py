"""Ask one model every question of the test set, and record each answer.

    python scripts/run_models.py ollama:gemma3:4b
    python scripts/run_models.py anthropic:claude-sonnet-5-5   (needs ANTHROPIC_API_KEY)
    python scripts/run_models.py gemini:gemini-3.5-flash       (needs GEMINI_API_KEY)

Each question goes to the model with the official page in the question's
language. The script writes runs/<provider>_<model><suffix>.jsonl: one line
per question with the raw text, the parsed JSON (or the parse error), the
seconds, and the tokens that the provider reports.

API keys come only from the environment. The script never prints or writes
them. Settings (environment variables): MAX_TOKENS (default 8000 for hosted
models, which reason before they answer; 1000 for local models), RUN_SUFFIX
(added to the file name, for example "_run2"), ONLY (a comma-separated list
of question ids, to test one or two questions first), RESUME=1 (keep the
answers already in the file, and ask only the missing questions).
"""

import csv
import datetime
import json
import os
import sys
import time
from pathlib import Path

try:  # use the operating system's certificates (some networks inspect TLS)
    import truststore

    truststore.inject_into_ssl()
except ImportError:
    pass

import httpx

ROOT = Path(__file__).resolve().parents[1]
PROMPT = (ROOT / "data" / "prompt.md").read_text(encoding="utf-8")
QUESTIONS = list(csv.DictReader((ROOT / "data" / "questions.csv").open(encoding="utf-8")))
SUFFIX = os.environ.get("RUN_SUFFIX", "")


def page_text(page: str, language: str) -> str:
    """The page as the model sees it: the saved text without the source header."""
    text = (ROOT / "data" / "pages" / f"{page}.{language}.md").read_text(encoding="utf-8")
    title, _, body = text.partition("\n---\n")
    return title.splitlines()[0].lstrip("# ") + "\n\n" + body.strip()


def call(provider: str, model: str, prompt: str, max_tokens: int) -> dict:
    """One request. Returns the text, the token counts and the stop reason."""
    if provider == "ollama":
        # No time limit: when other programs use Ollama, a request can wait a long time.
        r = httpx.post("http://localhost:11434/api/generate", timeout=None, json={
            "model": model, "prompt": prompt, "stream": False, "think": False,
            "options": {"temperature": 0, "num_predict": max_tokens, "num_ctx": 8192}})
        d = r.raise_for_status().json()
        return {"text": d["response"], "input_tokens": d.get("prompt_eval_count", 0),
                "output_tokens": d.get("eval_count", 0), "reasoning_tokens": 0,
                "stop_reason": d.get("done_reason"),
                # Time inside Ollama, and the part of it spent loading the model into memory.
                # A request can also wait in Ollama's queue before this, when another program uses it.
                "server_seconds": round(d.get("total_duration", 0) / 1e9, 3),
                "load_seconds": round(d.get("load_duration", 0) / 1e9, 3)}
    if provider == "anthropic":
        r = httpx.post("https://api.anthropic.com/v1/messages", timeout=180, headers={
            "x-api-key": os.environ["ANTHROPIC_API_KEY"], "anthropic-version": "2023-06-01"}, json={
            # Current Claude models reject "temperature"; they think before they answer,
            # and the thinking tokens are counted in output_tokens.
            "model": model, "max_tokens": max_tokens,
            "messages": [{"role": "user", "content": prompt}]})
        if r.status_code >= 400:
            raise SystemExit(f"{r.status_code}: {r.text[:300]}")
        d = r.json()
        return {"text": "".join(b.get("text", "") for b in d["content"] if b.get("type") == "text"),
                "input_tokens": d["usage"]["input_tokens"], "output_tokens": d["usage"]["output_tokens"],
                "reasoning_tokens": 0, "stop_reason": d.get("stop_reason")}
    if provider == "gemini":
        r = httpx.post(f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",
                       timeout=180, headers={"x-goog-api-key": os.environ["GEMINI_API_KEY"]}, json={
            "contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": {"temperature": 0, "maxOutputTokens": max_tokens}})
        if r.status_code >= 400:
            raise SystemExit(f"{r.status_code}: {r.text[:300]}")
        d = r.json()
        candidate = d["candidates"][0]
        parts = candidate.get("content", {}).get("parts", [])
        u = d["usageMetadata"]
        # Hidden reasoning ("thoughts") is billed as output but is not in the text.
        return {"text": "".join(p.get("text", "") for p in parts if not p.get("thought")),
                "input_tokens": u["promptTokenCount"], "output_tokens": u.get("candidatesTokenCount", 0),
                "reasoning_tokens": u.get("thoughtsTokenCount", 0), "stop_reason": candidate.get("finishReason")}
    raise SystemExit(f"Unknown provider {provider!r}: use ollama, anthropic or gemini.")


def parse(text: str):
    """The JSON object in the answer, or the reason why there is none."""
    t = text.strip()
    if t.startswith("```"):
        t = t.strip("`").removeprefix("json").strip()
    try:
        value = json.loads(t)
    except json.JSONDecodeError as error:
        return None, str(error)
    if not isinstance(value, dict):
        return None, "not a JSON object"
    return value, None


def main() -> None:
    if len(sys.argv) != 2 or ":" not in sys.argv[1]:
        raise SystemExit(__doc__)
    provider, model = sys.argv[1].split(":", 1)
    max_tokens = int(os.environ.get("MAX_TOKENS", "1000" if provider == "ollama" else "8000"))
    only = {q for q in os.environ.get("ONLY", "").split(",") if q}
    questions = [q for q in QUESTIONS if not only or q["id"] in only]
    out = ROOT / "runs" / f"{provider}_{model.replace(':', '-').replace('/', '-')}{SUFFIX}.jsonl"
    out.parent.mkdir(exist_ok=True)
    # RESUME=1 keeps the answers already in the file and asks only the missing questions.
    done = set()
    if os.environ.get("RESUME") and out.exists():
        done = {json.loads(line)["id"] for line in out.read_text(encoding="utf-8").splitlines() if line.strip()}
    with out.open("a" if done else "w", encoding="utf-8") as f:
        for q in [q for q in questions if q["id"] not in done]:
            prompt = PROMPT.replace("{page}", page_text(q["page"], q["language"])).replace("{question}", q["question"])
            started = time.perf_counter()
            result = call(provider, model, prompt, max_tokens)
            seconds = round(time.perf_counter() - started, 3)
            parsed, error = parse(result["text"])
            record = {"id": q["id"], "provider": provider, "model": model, "seconds": seconds,
                      "at": datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds"),
                      "max_tokens": max_tokens, **result, "parsed": parsed, "parse_error": error}
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
            print(f"{q['id']:6} {seconds:6.2f}s in={result['input_tokens']} out={result['output_tokens']} "
                  f"reasoning={result['reasoning_tokens']} {'OK' if parsed else 'NOT JSON'}", flush=True)
    print(f"Wrote {out.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
