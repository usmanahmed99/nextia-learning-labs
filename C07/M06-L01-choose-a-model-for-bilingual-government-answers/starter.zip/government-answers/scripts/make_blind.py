"""Make a blind scoring sheet: every answer, without the model's name.

    python scripts/make_blind.py

For each question, the answers of the compared runs get the labels A, B, C, D
in a random order (a different order per question, the same each time you run
the script). Writes:

  scoring/blind_answers.csv  the sheet to score: question, key answer, the
                             answer, what the checks found, and four empty
                             score columns (0, 1 or 2 each; see RUBRIC.md)
  scoring/blind_key.csv      which label is which run. Do not open it before
                             you finish scoring.

Copy blind_answers.csv to scores.csv and fill the scores there, so that
running this script again never overwrites your work.
"""

import csv
import json
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from check import QUESTIONS, check  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
RUNS = ["anthropic_claude-sonnet-5-5", "gemini_gemini-3.5-flash", "ollama_gemma3-4b", "ollama_mistral-7b"]


def main() -> None:
    answers = {}
    for run in RUNS:
        for line in (ROOT / "runs" / f"{run}.jsonl").read_text(encoding="utf-8").splitlines():
            r = json.loads(line)
            answers[(r["id"], run)] = r
    rng = random.Random(2026)
    sheet, key = [], []
    for qid, q in QUESTIONS.items():
        order = RUNS[:]
        rng.shuffle(order)
        for label, run in zip("ABCD", order):
            r = answers[(qid, run)]
            c = check(r)
            p = r["parsed"] or {}
            notes = []
            if not c["valid_json"]:
                notes.append("not valid JSON")
            if c["answer_language"] and not c["language_ok"]:
                notes.append(f"answer looks {c['answer_language']}")
            if p and not c["answerable_ok"]:
                notes.append("answerable flag wrong")
            if p and not c["quote_ok"]:
                notes.append("quote not on the page")
            if c["sentences"] and not 2 <= c["sentences"] <= 5:
                notes.append(f"{c['sentences']} sentences")
            if c["must_not_hits"]:
                notes.append("contains a forbidden phrase")
            sheet.append({
                "id": qid, "label": label, "language": q["language"], "kind": q["kind"],
                "question": q["question"], "key_answer": q["key_answer"],
                "answerable": p.get("answerable", "") if p else "",
                "answer": p.get("answer", "") if p else r["text"],
                "quote": p.get("quote", "") if p else "",
                "checks": "; ".join(notes) or "ok",
                "correctness": "", "completeness": "", "format": "", "abstention": "", "note": "",
            })
            key.append({"id": qid, "label": label, "run": run})
    out = ROOT / "scoring"
    out.mkdir(exist_ok=True)
    for name, rows in (("blind_answers.csv", sheet), ("blind_key.csv", key)):
        with (out / name).open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
    print(f"Wrote scoring/blind_answers.csv ({len(sheet)} answers) and scoring/blind_key.csv")


if __name__ == "__main__":
    main()
