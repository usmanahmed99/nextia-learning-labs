# Decision memo: the model for the bilingual information desk

**To:** (who decides) · **From:** (you) · **Date:** (date)

## 1. Decision asked for

(One sentence: what must be decided, and by when.)

## 2. Recommendation

(One or two sentences: the model, how it is used, and the condition.)

## 3. Requirements

Must-haves (an option that fails one is out, whatever its score):

- (for example: no critical error in either language)
- …

Then what matters most, in order:

1. …

## 4. Evidence

(The comparison table from `results/summary.csv`: score, English and French, critical errors, full marks with the interval, median and p95 seconds, US$ per 1,000 questions.)

What the evidence says, in three to five sentences.

## 5. Limits of this evidence

- (the size of the test set, the topics, one scorer, the date of the runs, …)

## 6. Fallback

(What the desk does when the chosen model is down, retired, or fails a check.)

## 7. When to test again

- (triggers: a new model version, a price change, a new topic, a complaint, …)

## 8. Assumptions

- (volume of questions, who checks the answers, …)
