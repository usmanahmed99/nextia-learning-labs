"""Shared test helpers. The tests use the real data (data/recalls.db) and never need a key."""

import pytest

from recalls_mcp.store import DB, Store


def pytest_sessionstart(session):
    if not DB.exists():
        pytest.exit("data/recalls.db is missing: run  python -m scripts.get_data  first", returncode=1)


@pytest.fixture(scope="session")
def store():
    return Store()
