# food-recalls (starter)

The starter project of the case study *An MCP server over a real open dataset* (course *MCP: Connect AI Applications to Tools and Data*, Nextia Learning).
It has the data and its checks, the business service (`recalls_mcp/store.py`, no MCP yet), the course's host with a mock model, and the measuring scripts.
You add the capability catalog, the contracts, the MCP server and its tests. The steps are on the case study's page.

This project uses **MCP specification revision 2026-07-28** with the **official MCP Python SDK 2.3.0**. Tested with Python 3.12 on macOS.

## Set up (once)

macOS or Linux:

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements-dev.txt
python -m scripts.get_data
python -m pytest -q
```

Windows (PowerShell):

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements-dev.txt
python -m scripts.get_data
python -m pytest -q
```

`scripts.get_data` downloads the course's copy of the openFDA file (5.9 MB), checks its SHA-256 checksum and builds `data/recalls.db`.

## Data and licence

openFDA food enforcement reports, export of 2026-10-06, public domain under CC0 1.0 (`DATASET.md`). The code: MIT (`LICENSE`).
