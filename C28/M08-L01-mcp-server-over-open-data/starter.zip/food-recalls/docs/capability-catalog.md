# Capability catalog: food-recalls

Write this before the server. Each row starts from a person's need, not from the data's columns.
The data is FDA's food recall enforcement reports (see `DATASET.md`).

## The people and their needs

| Who | Need, in their words | How often |
|---|---|---|
| A help desk agent | "A customer asks if the peanut butter crackers she bought are recalled." | many times a day |
| A help desk agent | "A customer read recall F-0123-2025 in the news. What is it about?" | daily |
| The food-safety lead | "Show me the serious recalls that are still open, so I can check our shelves." | weekly |
| The food-safety lead | "Give the agents one way to answer about a recall: plain words, the source, no medical advice." | once, then reused |

## The catalog

| Need | Capability | Kind (tool, resource, prompt) | Who chooses | Bounds (measure them) |
|---|---|---|---|---|
| | | | | |

## Ideas we rejected

| Idea | Why not (measured on this data) |
|---|---|
| | |
