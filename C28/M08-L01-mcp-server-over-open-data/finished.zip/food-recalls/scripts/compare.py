"""Compare three shapes of the search result under one measure, with the same host and questions.

    python -m scripts.compare                  the table; --json PATH also writes every row

The designs (RECALLS_DESIGN in recalls_mcp/server.py):
  everything  every matching recall, whole (a thin wrapper of the data, no limit)
  full        the 5 newest matching recalls, whole
  summary     the 5 newest as short summaries; the model reads one with get_recall (this server)

For each design and each question of questions/eval.jsonl, the course's host asks the mock
model (the same rules every time) through an MCP client. The host keeps its own limit: a result
longer than 4,000 characters is cut, and cut JSON can no longer be read.

The measure: is the answer right (it names a recall of the expected recall event, or says
"no recall" when none matches), and how many characters of tool results did the model read?
"""

import argparse
import json
import re
import statistics
import sys
import time
from pathlib import Path

import anyio
from mcp import Client

from host import app
from host.models import MockModel
from recalls_mcp.server import build_server
from recalls_mcp.store import Store

ORDER = ("everything", "full", "summary")  # the baseline first
QUESTIONS = Path(__file__).resolve().parent.parent / "questions" / "eval.jsonl"
CITED = re.compile(r"\b[A-Z]-\d{4}-\d{4}\b")


def questions(path: Path = QUESTIONS) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def correct(q: dict, answer: str, store: Store) -> bool:
    cited = CITED.findall(answer)
    if q["expect_event"] is None:
        return not cited and "found no" in answer
    return any(store.get(n)["event_id"] == q["expect_event"] for n in cited if _exists(store, n))


def _exists(store: Store, number: str) -> bool:
    try:
        store.get(number)
        return True
    except Exception:
        return False


async def run_design(design: str, qs: list[dict], store: Store) -> list[dict]:
    rows = []
    async with Client(build_server(store, design=design)) as client:
        for q in qs:
            started = time.perf_counter()
            run = await app.ask(client, MockModel(), q["question"], confirm=lambda *_: False)
            seconds = time.perf_counter() - started
            server_chars = [s.data.get("chars", 0) for s in run.steps if s.who == "server"]
            read = [len(m) for m in run.read]
            rows.append(
                {
                    "design": design,
                    "id": q["id"],
                    "kind": q["kind"],
                    "correct": correct(q, run.answer, store),
                    "tool_calls": len(read),
                    "server_chars": sum(server_chars),
                    "model_read_chars": sum(read),
                    "cut": any(s.data.get("clipped") for s in run.steps if s.who == "server"),
                    "ms": round(seconds * 1000, 1),
                    "answer": run.answer,
                }
            )
    return rows


def summarize(rows: list[dict]) -> dict:
    out = {}
    for d in ORDER:
        r = [x for x in rows if x["design"] == d]
        out[d] = {
            "questions": len(r),
            "correct": sum(x["correct"] for x in r),
            "cut": sum(x["cut"] for x in r),
            "model_read_median": statistics.median(x["model_read_chars"] for x in r),
            "model_read_max": max(x["model_read_chars"] for x in r),
            "server_median": statistics.median(x["server_chars"] for x in r),
            "server_max": max(x["server_chars"] for x in r),
            "tool_calls": sum(x["tool_calls"] for x in r),
        }
    return out


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="python -m scripts.compare")
    p.add_argument("--json", type=Path, help="write every row and the summary here")
    p.add_argument("--host-limit", type=int, help="change the host's limit per result (default 4000)")
    a = p.parse_args(argv)
    if a.host_limit:
        app.MAX_RESULT_CHARS = a.host_limit
    store, qs = Store(), questions()

    async def go():
        rows = []
        for d in ORDER:
            rows += await run_design(d, qs, store)
        return rows

    rows = anyio.run(go)
    s = summarize(rows)
    print(f"{len(qs)} questions, mock model, host limit {app.MAX_RESULT_CHARS:,} characters per result\n")
    print(
        f"{'design':<11} {'right':>6} {'cut':>4} {'model read (median / max)':>27} {'server sent (median / max)':>29}"
    )
    for d, v in s.items():
        print(
            f"{d:<11} {v['correct']:>3}/{v['questions']:<2} {v['cut']:>4} "
            f"{v['model_read_median']:>12,.0f} / {v['model_read_max']:>9,} {v['server_median']:>14,.0f} / {v['server_max']:>11,}"
        )
    if a.json:
        a.json.parent.mkdir(parents=True, exist_ok=True)
        a.json.write_text(
            json.dumps({"summary": s, "rows": rows}, indent=1, ensure_ascii=False) + "\n", encoding="utf-8"
        )
    return 0


if __name__ == "__main__":
    sys.exit(main())
