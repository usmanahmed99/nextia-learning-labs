"""Measure the bounds: the largest answer of each capability, over every recall in the data.

    python -m scripts.sizes                     the table (about a minute)
    python -m scripts.sizes --json PATH         also write the numbers

Through a real MCP client (in the same process, the same messages as stdio), it reads every
recall with get_recall and as a resource, and runs search_recalls with limit 5 for every
question of questions/eval.jsonl. It compares each answer with the record as openFDA gives it
(one JSON object, without the "openfda" field). Sizes are characters of the text the client
receives (content[0].text), the text a host hands to a model.
"""

import argparse
import json
import sys
import zipfile
from pathlib import Path

import anyio
from mcp import Client

from recalls_mcp import contracts, store
from recalls_mcp.server import build_server
from scripts.compare import questions
from scripts.get_data import FILE


def pct(values: list[int], p: float) -> int:
    values = sorted(values)
    return values[min(len(values) - 1, int(round(p / 100 * (len(values) - 1))))]


def stats(values: list[int]) -> dict:
    return {
        "n": len(values),
        "p50": pct(values, 50),
        "p95": pct(values, 95),
        "p99": pct(values, 99),
        "max": max(values),
    }


def raw_records() -> list[int]:
    with zipfile.ZipFile(store.DATA / FILE) as z:
        doc = json.loads(z.read(z.namelist()[0]))
    return [len(json.dumps({k: v for k, v in r.items() if k != "openfda"}, ensure_ascii=False)) for r in doc["results"]]


async def measure() -> dict:
    s = store.Store()
    numbers = s.all_numbers()
    tool, resource, search, biggest = [], [], [], ("", 0)
    async with Client(build_server(s)) as c:
        for n in numbers:
            r = await c.call_tool("get_recall", {"recall_number": n})
            tool.append(len(r.content[0].text))
            text = (await c.read_resource(contracts.recall_uri(n))).contents[0].text
            resource.append(len(text))
            if len(text) > biggest[1]:
                biggest = (n, len(text))
        for q in questions():
            if q["kind"] != "number":
                words = q["question"].split('"')[1]
                r = await c.call_tool("search_recalls", {"query": words, "limit": contracts.MAX_RESULTS})
                search.append(len(r.content[0].text))
        listed = await c.list_resources()
    return {
        "raw_record": stats(raw_records()),
        "get_recall": stats(tool),
        "resource": stats(resource) | {"largest": biggest[0]},
        "search_max_limit": stats(search),
        "resources_listed": len(listed.resources),
    }


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="python -m scripts.sizes")
    p.add_argument("--json", type=Path)
    a = p.parse_args(argv)
    m = anyio.run(measure)
    print(f"{'answer':<26} {'count':>7} {'median':>8} {'p95':>8} {'p99':>8} {'max':>8}  (characters)")
    for name, label in (("raw_record", "openFDA record (no bound)"), ("get_recall", "get_recall result"),
                        ("resource", "recall resource text"), ("search_max_limit", "search_recalls, limit 5")):  # fmt: skip
        v = m[name]
        print(f"{label:<26} {v['n']:>7,} {v['p50']:>8,} {v['p95']:>8,} {v['p99']:>8,} {v['max']:>8,}")
    print(f"resources/list: {m['resources_listed']} recalls (bound {contracts.MAX_LISTED})")
    if a.json:
        a.json.parent.mkdir(parents=True, exist_ok=True)
        a.json.write_text(json.dumps(m, indent=1) + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    sys.exit(main())
