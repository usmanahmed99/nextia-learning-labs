"""Download the data, check its SHA-256 checksum, and build data/recalls.db.

    python -m scripts.get_data                  the course's copy of the openFDA file (checked)
    python -m scripts.get_data --file PATH      a copy you already have (checked the same way)
    python -m scripts.get_data --latest         openFDA's current file (newer data: a new checksum)

The course's copy is openFDA's food enforcement file as it was exported on 2026-10-06. openFDA
publishes a new file every week under the same name, so the original link cannot have a fixed
checksum. The file is public domain (CC0 1.0), so the course keeps the exact copy it used.
"""

import argparse
import hashlib
import shutil
import sys
import urllib.request
from pathlib import Path

from recalls_mcp import store

FILE = "food-enforcement-2026-10-06.json.zip"
COURSE_COPY = (
    f"https://github.com/usmanahmed99/nextia-learning-labs/raw/main/C28/M08-L01-mcp-server-over-open-data/data/{FILE}"
)
OPENFDA = "https://download.open.fda.gov/food/enforcement/food-enforcement-0001-of-0001.json.zip"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def expected() -> str:
    for line in (store.DATA / "SHA256SUMS").read_text().splitlines():
        digest, name = line.split()
        if name == FILE:
            return digest
    raise SystemExit(f"{FILE} is not in data/SHA256SUMS")


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="python -m scripts.get_data")
    src = p.add_mutually_exclusive_group()
    src.add_argument("--file", type=Path, help="use a local copy of the zip")
    src.add_argument("--latest", action="store_true", help="download openFDA's current file (not checked)")
    a = p.parse_args(argv)
    store.DATA.mkdir(exist_ok=True)
    target = store.DATA / ("food-enforcement-latest.json.zip" if a.latest else FILE)
    if a.file:
        shutil.copyfile(a.file, target)
        print(f"Copied {a.file}")
    elif not target.exists() or a.latest:
        url = OPENFDA if a.latest else COURSE_COPY
        print(f"Downloading {url}")
        with urllib.request.urlopen(url, timeout=120) as r, target.open("wb") as f:
            shutil.copyfileobj(r, f)
    digest = sha256(target)
    if a.latest:
        print(f"SHA-256 {digest} (openFDA's current file: new data, so no fixed checksum to compare)")
    elif digest != expected():
        target.unlink()
        print(f"Checksum mismatch: got {digest[:12]}..., expected {expected()[:12]}... The file was removed.")
        return 1
    else:
        print(f"Checked {target.name}: SHA-256 {digest[:12]}... is correct")
    meta = store.build(target, store.DB, digest)
    print(f"Wrote data/recalls.db: {int(meta['records']):,} recalls (openFDA export of {meta['last_updated']})")
    print(f"Left out {meta['left_out']} records whose recall number is not in FDA's form: data/excluded.jsonl")
    return 0


if __name__ == "__main__":
    sys.exit(main())
