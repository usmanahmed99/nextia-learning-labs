# Capability catalog: food-recalls

Written before the server. Each row starts from a person's need, not from the data's columns.
The data is FDA's food recall enforcement reports (29,424 recalls after the checks; see `DATASET.md`).

## The people and their needs

| Who | Need, in their words | How often |
|---|---|---|
| A help desk agent | "A customer asks if the peanut butter crackers she bought are recalled." | many times a day |
| A help desk agent | "A customer read recall F-0123-2025 in the news. What is it about?" | daily |
| The food-safety lead | "Show me the serious recalls that are still open, so I can check our shelves." | weekly |
| The food-safety lead | "Give the agents one way to answer about a recall: plain words, the source, no medical advice." | once, then reused |

## The catalog

| Need | Capability | Kind | Who chooses | Bounds |
|---|---|---|---|---|
| Is this product recalled? | `search_recalls(query, status, classification, limit)` | tool | the model | query 3–100 characters, every word must match; at most 5 results, newest first; product and reason cut to 200 characters; the number of matches is given |
| What is recall X about? | `get_recall(recall_number)` | tool | the model | recall number `^[A-Z]-\d{4}-\d{4}$`; one record; each long text cut (product 1,000, reason 500, codes 1,000, distribution 500, quantity 200) |
| Read or cite the whole report | `recall://fda-food/{recall_number}` | resource template | the application or the person | one report as Markdown; only the lot codes are cut, at 3,000 characters |
| The open serious recalls | `resources/list` | resource list | the application | the newest ongoing Class I recalls, at most 50 |
| One way to answer a customer | `customer_answer(recall_number)` | prompt | the person | the recall number is checked; the text tells the model to name the source and give no medical advice |

All tools are read-only (`readOnlyHint: true`). The data is public, so there is no sign-in and no organization: every caller sees the same data. A server with private data would need the checks of the course's Module 5.

## Ideas we rejected

| Idea | Why not (measured on this data) |
|---|---|
| `list_all_recalls()` | 29,424 records, about 40 MB of JSON. No model can read it, and no host should pass it on. |
| `search_recalls` that returns every match, whole | "listeria" matches 7,487 recalls: 8,345,314 characters. Even "infant formula" is 94,611 characters. |
| `search_recalls` that returns the 5 newest whole records | 12 of our 22 test questions gave more than 4,000 characters, so the course's host cut the JSON and the model could not read it. |
| `get_event(event_id)`: every recall of one recall event | One event has 409 recalls. `get_recall` says how many recalls share its event instead. |
| A tool that runs SQL | The model would write queries against our tables: no bounds, no contract, and a new way to break the server. |
| Free FTS5 query syntax in `query` | `NEAR`, `*` and `OR` would let a query cost much more. The server quotes every word. |
| A resource for every recall in `resources/list` | 29,424 entries. The template describes all of them; the list holds the 50 that matter this week. |
