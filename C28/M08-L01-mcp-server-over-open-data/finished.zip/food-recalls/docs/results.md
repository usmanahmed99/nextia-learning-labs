# Results

The course author's run: Apple M4, 16 GB, macOS, Python 3.12.13, mcp 2.3.0, data `food-enforcement-2026-10-06.json.zip`.
Character counts do not depend on the computer; times do. Replace these with your own numbers.

## Bounds, over every recall (`python -m scripts.sizes`)

| Answer | Count | Median | p95 | p99 | Max (characters) |
|---|---|---|---|---|---|
| openFDA record (no bound) | 29,471 | 1,100 | 1,636 | 2,451 | 44,645 |
| `get_recall` result | 29,424 | 1,098 | 1,627 | 2,105 | 3,590 |
| recall resource text | 29,424 | 831 | 1,369 | 2,184 | 7,713 |
| `search_recalls`, limit 5 (20 questions) | 20 | 2,423 | 2,711 | 2,820 | 2,820 |

`resources/list`: 50 recalls (the bound). The host's limit per result is 4,000 characters, so every tool answer fits.

## A bound found too large by a real model

The first version allowed `limit` up to 10. The optional real-model run asked for 10 infant formula recalls: 5,531 characters, which the host cut at 4,000. The model still answered, from cut JSON.
We lowered the maximum to 5 and added a test: the largest search answer of the 20 questions is now 2,820 characters.

## Three result designs, one measure (`python -m scripts.compare`)

22 questions (`questions/eval.jsonl`), the mock model, the course's host with its 4,000-character limit per result.
"Right" means the answer names a recall of the expected recall event, or says "no recall" when none matches.

| Design | Right | Results cut | Model read, median / max | Server sent, median / max |
|---|---|---|---|---|
| everything (every match, whole) | 10/22 | 12 | 4,256 / 4,456 | 4,278 / 8,345,314 |
| full (5 newest, whole) | 10/22 | 12 | 4,256 / 4,456 | 4,278 / 8,278 |
| summary (5 summaries, then `get_recall`) | 22/22 | 0 | 2,868 / 4,464 | 3,096 / 4,720 |

With the host's limit raised to 10,000,000 characters (`--host-limit 10000000`), all three designs are right 22 times; "everything" then hands the model up to 8,345,360 characters, and "full" up to 8,324.

## The optional real model

Azure `chat-small` (an OpenAI-compatible deployment), 4 new questions, after the fix: 10 model calls, US$0.0013 at US$0.10 / 0.50 per 1M tokens in / out.
Every answer named the right recalls and matched the data. One run proves nothing about another model or another day.
