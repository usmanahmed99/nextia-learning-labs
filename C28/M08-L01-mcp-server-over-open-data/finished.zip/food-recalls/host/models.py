"""The model side of the host. The host talks to every model through one small interface:

    decide(messages, tools) -> Decision   (tool calls to make, or a final answer)

- MockModel: scripted, no network, no account. It chooses tools with simple rules, so every run
  gives the same messages.
- OpenAICompatibleModel: a real model through any OpenAI-compatible chat completions API (your own
  key, or a local model server). Optional.
Provider-specific code stays in this file; the host and the MCP client do not change.
"""

import json
import os
import re
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field

RECALL_NUMBER = re.compile(r"\b[A-Z]-\d{4}-\d{4}\b")
QUOTED = re.compile(r'"([^"]{3,100})"')
# Question words the mock leaves out when the question has no words in double quotes.
STOP = set(
    "is are was were there a an the any under recall recalls recalled for of on what about has have been "
    "this that it my our does do please check".split()
)


@dataclass
class ToolCall:
    id: str
    name: str
    arguments: dict


@dataclass
class Decision:
    tool_calls: list[ToolCall] = field(default_factory=list)
    answer: str | None = None
    usage: dict = field(default_factory=dict)
    raw: dict | None = None


def _tool_results(messages: list[dict]) -> list[dict]:
    """The tool results so far: [{"name", "data"}] (data parsed from the host's JSON wrapper)."""
    out = []
    for m in messages:
        if m["role"] == "tool":
            try:
                out.append(json.loads(m["content"]))
            except json.JSONDecodeError:
                out.append({"tool": "?", "error": m["content"]})
    return out


def _parse(r: dict):
    """The data of one tool result, or None if the host cut it (cut JSON is no longer JSON)."""
    data = r.get("untrusted_data")
    return data if isinstance(data, dict) else None


def _short(text: str, limit: int) -> str:
    text = " ".join(text.split()).rstrip(".")
    return text if len(text) <= limit else text[:limit].rsplit(" ", 1)[0] + " …"


class MockModel:
    """Rules (no network, no account, the same messages every time):
    1) a recall number in the question -> get_recall;
    2) no search yet -> search_recalls with the words in double quotes (else the question
       without question words such as "is", "there", "recall");
    3) a search gave short summaries -> get_recall for the first (the newest) one;
    4) else answer from the results, and name the recall number and its URI."""

    name = "mock"

    def decide(self, messages: list[dict], tools: list[dict]) -> Decision:
        names = {t["function"]["name"] for t in tools}
        question = next(m["content"] for m in messages if m["role"] == "user")
        results = _tool_results(messages)
        done = [r.get("tool") for r in results]
        n = len(results)
        number = RECALL_NUMBER.search(question)
        if number and "get_recall" in names and "get_recall" not in done:
            return Decision([ToolCall(f"call_{n + 1}", "get_recall", {"recall_number": number.group(0)})])
        if not number and "search_recalls" in names and "search_recalls" not in done:
            quoted = QUOTED.search(question)
            words = [w for w in re.findall(r"[A-Za-z0-9']+", question) if w.lower() not in STOP]
            query = quoted.group(1) if quoted else " ".join(words)[:100]
            return Decision([ToolCall(f"call_{n + 1}", "search_recalls", {"query": query})])
        search = next((_parse(r) for r in results if r.get("tool") == "search_recalls"), None)
        hits = (search or {}).get("results") or []
        if hits and "product" in hits[0] and "get_recall" in names and "get_recall" not in done:
            return Decision([ToolCall(f"call_{n + 1}", "get_recall", {"recall_number": hits[0]["recall_number"]})])
        return Decision(answer=self._answer(results))

    @staticmethod
    def _answer(results: list[dict]) -> str:
        search = next((_parse(r) for r in results if r.get("tool") == "search_recalls"), None)
        for r in reversed(results):
            if r.get("error"):
                return f"I could not use {r.get('tool')}: {str(r['error'])[:200]}"
            data = _parse(r)
            if data is None:
                return f"I could not read the result of {r.get('tool')}: {r.get('note', 'it is not valid JSON')}."
            if r.get("tool") == "get_recall" or "product_description" in data:
                return MockModel._recall(data, search)
            if r.get("tool") == "search_recalls":
                if not data.get("results"):
                    return f'I found no FDA food recall that matches "{data.get("query")}" in the data.'
                return MockModel._recall(data["results"][0], data)
        return "I have no information to answer this."

    @staticmethod
    def _recall(r: dict, search: dict | None) -> str:
        product = _short(r.get("product_description") or r.get("product", ""), 120)
        reason = _short(r.get("reason_for_recall") or r.get("reason", ""), 160)
        uri = r.get("uri") or f"recall://fda-food/{r['recall_number']}"
        line = (
            f"Recall {r['recall_number']} ({r['classification']}, {r['status']}, reported {r['report_date']}): "
            f"{r.get('firm') or r.get('recalling_firm')}, {product}{' ' if product.endswith('…') else '. '}"
            f"Reason: {reason}. Source: {uri}."
        )
        if search:
            line += f" {search['total_matches']} recalls match; this is the newest."
        return line


class OpenAICompatibleModel:
    """Chat completions with tools. Settings (environment): MODEL_BASE_URL (ends with /v1 or
    /openai/v1), MODEL_API_KEY (never printed), MODEL_NAME, MODEL_REASONING_EFFORT (optional; some
    models need "none" to use tools), MODEL_TIMEOUT (seconds, 60)."""

    def __init__(self):
        self.base = os.environ["MODEL_BASE_URL"].rstrip("/")
        self.key = os.environ.get("MODEL_API_KEY", "")
        self.name = os.environ.get("MODEL_NAME", "chat-small")
        self.effort = os.environ.get("MODEL_REASONING_EFFORT")
        self.timeout = float(os.environ.get("MODEL_TIMEOUT", "60"))

    def decide(self, messages: list[dict], tools: list[dict]) -> Decision:
        body = {"model": self.name, "messages": messages, "tools": tools, "max_completion_tokens": 800}
        if self.effort:
            body["reasoning_effort"] = self.effort
        req = urllib.request.Request(
            f"{self.base}/chat/completions",
            data=json.dumps(body).encode(),
            method="POST",
            headers={"Content-Type": "application/json", "api-key": self.key, "Authorization": f"Bearer {self.key}"},
        )
        started = time.perf_counter()
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                data = json.loads(r.read())
        except urllib.error.HTTPError as e:
            raise RuntimeError(f"model error HTTP {e.code}: {e.read()[:300].decode(errors='replace')}") from None
        msg = data["choices"][0]["message"]
        usage = dict(data.get("usage") or {}) | {"ms": round((time.perf_counter() - started) * 1000)}
        calls = [
            ToolCall(c["id"], c["function"]["name"], json.loads(c["function"]["arguments"] or "{}"))
            for c in msg.get("tool_calls") or []
        ]
        return Decision(calls, None if calls else (msg.get("content") or ""), usage, data)


def make_model(name: str):
    if name == "mock":
        return MockModel()
    if name == "openai":
        return OpenAICompatibleModel()
    raise ValueError(f"unknown model {name!r}: use mock or openai")
