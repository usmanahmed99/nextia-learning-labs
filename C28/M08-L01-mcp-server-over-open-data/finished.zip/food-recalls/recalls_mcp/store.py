"""The business service: FDA food recall enforcement reports in SQLite. No MCP here.

    python -m recalls_mcp.store                          counts
    python -m recalls_mcp.store search "peanut butter"   the newest matching recalls
    python -m recalls_mcp.store get H-1393-2026          one recall

The data is openFDA's food enforcement file (public domain, CC0 1.0; see DATASET.md).
scripts/get_data.py downloads it, checks its SHA-256 checksum and calls build() once.
Every function here reads only; the MCP server adds the contract and the bounds.
"""

import json
import re
import sqlite3
import sys
import zipfile
from pathlib import Path

DATA = Path(__file__).resolve().parent.parent / "data"
DB = DATA / "recalls.db"

RECALL_NUMBER = r"^[A-Z]-\d{4}-\d{4}$"  # for example F-0123-2025 (the letter is FDA's centre)
MAX_QUERY_WORDS = 8
STATUSES = ("Ongoing", "Completed", "Terminated")
CLASSES = ("Class I", "Class II", "Class III")

# The columns we keep. We drop the street address and postal code of each firm (not needed to
# answer "is this product recalled?"), and openFDA's empty "openfda" field.
COLUMNS = (
    "recall_number", "event_id", "report_date", "recall_initiation_date", "center_classification_date",
    "termination_date", "classification", "status", "voluntary_mandated", "initial_firm_notification",
    "firm", "city", "state", "country", "product_description", "product_quantity", "reason_for_recall",
    "code_info", "distribution_pattern",
)  # fmt: skip


class NotFound(Exception):
    pass


def _date(value: str | None) -> str | None:
    """openFDA writes dates as 20260930; we store 2026-09-30."""
    return f"{value[:4]}-{value[4:6]}-{value[6:8]}" if value and len(value) == 8 else None


def _row(r: dict) -> tuple:
    code = " ".join(x for x in (r.get("code_info", ""), r.get("more_code_info", "")) if x).strip()
    return (
        r["recall_number"], r["event_id"], _date(r.get("report_date")), _date(r.get("recall_initiation_date")),
        _date(r.get("center_classification_date")), _date(r.get("termination_date")), r.get("classification", ""),
        r.get("status", ""), r.get("voluntary_mandated", ""), r.get("initial_firm_notification", ""),
        r.get("recalling_firm", ""), r.get("city", ""), r.get("state", ""), r.get("country", ""),
        r.get("product_description", ""), r.get("product_quantity", ""), r.get("reason_for_recall", ""), code,
        r.get("distribution_pattern", ""),
    )  # fmt: skip


def build(zip_path: Path, db_path: Path = DB, sha256: str = "") -> dict:
    """Load the openFDA zip into a new SQLite file with a full-text index. Returns the counts."""
    with zipfile.ZipFile(zip_path) as z:
        doc = json.loads(z.read(z.namelist()[0]))
    # A stable URI needs a valid, unique ID. A few records have a recall number that is not in
    # FDA's form (empty, or a typing error). We keep FDA's numbers exactly as they are, so we
    # leave those records out of the server and list them in data/excluded.jsonl.
    kept = [r for r in doc["results"] if re.match(RECALL_NUMBER, r.get("recall_number", ""))]
    left_out = [r for r in doc["results"] if not re.match(RECALL_NUMBER, r.get("recall_number", ""))]
    with (db_path.parent / "excluded.jsonl").open("w", encoding="utf-8") as f:
        for r in left_out:
            keep = ("recall_number", "event_id", "report_date", "recalling_firm", "product_description")
            f.write(json.dumps({k: r.get(k, "") for k in keep}, ensure_ascii=False) + "\n")
    tmp = db_path.with_suffix(".tmp")
    tmp.unlink(missing_ok=True)
    con = sqlite3.connect(tmp)
    con.execute(
        f"CREATE TABLE recalls ({', '.join(c + (' PRIMARY KEY' if c == 'recall_number' else '') for c in COLUMNS)})"
    )
    con.executemany(f"INSERT INTO recalls VALUES ({', '.join('?' * len(COLUMNS))})", map(_row, kept))
    con.execute(
        "CREATE VIRTUAL TABLE recalls_fts USING fts5(product_description, reason_for_recall, firm,"
        " content='recalls', content_rowid='rowid', tokenize='porter unicode61')"
    )
    con.execute("INSERT INTO recalls_fts(recalls_fts) VALUES ('rebuild')")
    con.execute("CREATE INDEX recalls_by_date ON recalls (report_date DESC, recall_number)")
    con.execute("CREATE INDEX recalls_by_event ON recalls (event_id)")
    con.execute("CREATE TABLE meta (key PRIMARY KEY, value)")
    meta = {
        "source": "openFDA food enforcement reports",
        "last_updated": doc["meta"]["last_updated"],
        "sha256": sha256,
        "records": len(kept),
        "left_out": len(left_out),
    }
    con.executemany("INSERT INTO meta VALUES (?, ?)", [(k, str(v)) for k, v in meta.items()])
    con.commit()
    con.close()
    tmp.replace(db_path)
    return meta


def fts_query(text: str) -> str:
    """Words to an FTS5 query: every word must appear (AND), as a quoted term (no FTS5 syntax)."""
    words = re.findall(r"[A-Za-z0-9]+", text.lower())[:MAX_QUERY_WORDS]
    if not words:
        raise ValueError("the query has no words")
    return " AND ".join(f'"{w}"' for w in words)


class Store:
    def __init__(self, db_path: Path = DB):
        if not Path(db_path).exists():
            raise FileNotFoundError(f"{db_path} is missing: run  python -m scripts.get_data")
        self.con = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True, check_same_thread=False)
        self.con.row_factory = sqlite3.Row

    def meta(self) -> dict:
        return {r["key"]: r["value"] for r in self.con.execute("SELECT key, value FROM meta")}

    def counts(self) -> dict:
        total = self.con.execute("SELECT count(*) FROM recalls").fetchone()[0]

        def by(col: str) -> dict:
            sql = f"SELECT {col}, count(*) FROM recalls GROUP BY {col} ORDER BY 2 DESC"
            return dict(self.con.execute(sql).fetchall())

        first, last = self.con.execute("SELECT min(report_date), max(report_date) FROM recalls").fetchone()
        events = self.con.execute("SELECT count(DISTINCT event_id) FROM recalls").fetchone()[0]
        return {"recalls": total, "events": events, "first_report": first, "last_report": last,
                "status": by("status"), "classification": by("classification")}  # fmt: skip

    def search(self, query: str, status: str | None = None, classification: str | None = None, limit: int | None = 5):
        """Recalls whose product, reason or firm contain every word, newest report first.
        Returns (number of matches, rows). limit=None returns every match (only for comparisons)."""
        where, args = ["recalls_fts MATCH ?"], [fts_query(query)]
        if status:
            where.append("r.status = ?")
            args.append(status)
        if classification:
            where.append("r.classification = ?")
            args.append(classification)
        sql = f"FROM recalls_fts JOIN recalls r ON r.rowid = recalls_fts.rowid WHERE {' AND '.join(where)}"
        total = self.con.execute(f"SELECT count(*) {sql}", args).fetchone()[0]
        page = "" if limit is None else f" LIMIT {int(limit)}"
        rows = self.con.execute(f"SELECT r.* {sql} ORDER BY r.report_date DESC, r.recall_number{page}", args)
        return total, [dict(r) for r in rows]

    def get(self, recall_number: str) -> dict:
        row = self.con.execute("SELECT * FROM recalls WHERE recall_number = ?", (recall_number,)).fetchone()
        if row is None:
            raise NotFound(recall_number)
        return dict(row)

    def event_size(self, event_id: str) -> int:
        return self.con.execute("SELECT count(*) FROM recalls WHERE event_id = ?", (event_id,)).fetchone()[0]

    def newest(self, classification: str, status: str, limit: int) -> list[dict]:
        rows = self.con.execute(
            "SELECT * FROM recalls WHERE classification = ? AND status = ?"
            " ORDER BY report_date DESC, recall_number LIMIT ?",
            (classification, status, limit),
        )
        return [dict(r) for r in rows]

    def all_numbers(self) -> list[str]:
        return [r[0] for r in self.con.execute("SELECT recall_number FROM recalls ORDER BY recall_number")]


def main(argv: list[str]) -> int:
    s = Store()
    if not argv:
        c = s.counts()
        print(f"{c['recalls']:,} recalls in {c['events']:,} events, reported {c['first_report']} to {c['last_report']}")
        print("status:", ", ".join(f"{k} {v:,}" for k, v in c["status"].items()))
        print("classification:", ", ".join(f"{k} {v:,}" for k, v in c["classification"].items()))
        return 0
    if argv[0] == "search" and len(argv) == 2:
        total, rows = s.search(argv[1])
        print(f"{total:,} matches; the newest {len(rows)}:")
        for r in rows:
            print(
                f"{r['report_date']}  {r['recall_number']}  {r['classification']:<9}  {r['status']:<10}  {r['product_description'][:60]}"
            )
        return 0
    if argv[0] == "get" and len(argv) == 2:
        try:
            r = s.get(argv[1])
        except NotFound:
            print("Not found.")
            return 1
        for k in (
            "recall_number",
            "event_id",
            "report_date",
            "classification",
            "status",
            "firm",
            "product_description",
            "reason_for_recall",
        ):
            print(f"{k}: {r[k]}")
        return 0
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
