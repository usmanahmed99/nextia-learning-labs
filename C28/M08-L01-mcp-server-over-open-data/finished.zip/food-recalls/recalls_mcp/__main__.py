"""Start the server on stdio:  python -m recalls_mcp

An AI application (a host, Inspector, the tests) starts this process and talks MCP on its
stdin/stdout. Run by hand, it waits silently for messages: press Ctrl+C to stop it.
"""

import sys

from recalls_mcp.server import build_server


def main() -> int:
    build_server().run("stdio")
    return 0


if __name__ == "__main__":
    sys.exit(main())
