"""The capability contracts: what each tool takes and gives back, the resource URIs and the prompt.

Written from docs/capability-catalog.md, before the server. Every result is bounded: a fixed
maximum number of items and a fixed maximum length for every text field. scripts/sizes.py
measures the largest result over all 29,471 recalls.
"""

import re
from typing import Annotated, Literal

from pydantic import BaseModel, Field

from recalls_mcp.store import RECALL_NUMBER

# Bounds. The data has a product description of 4,000 characters and a record of 44,660.
MAX_QUERY_CHARS = 100
MAX_RESULTS = 5  # was 10: 10 summaries reached 5,531 characters, over the host's 4,000 (docs/results.md)
DEFAULT_RESULTS = 5
SUMMARY_CHARS = 200  # product and reason in a search result
DETAIL_CHARS = {  # each text field of get_recall
    "product_description": 1000,
    "reason_for_recall": 500,
    "product_quantity": 200,
    "code_info": 1000,
    "distribution_pattern": 500,
}
RESOURCE_CODE_CHARS = 3000  # the lot codes in the resource text (the only very long field)
MAX_LISTED = 50  # resources/list: the newest ongoing Class I recalls, at most 50

# Stable resource URIs: recall://fda-food/<recall number>. FDA never reuses a recall number.
RECALL_URI_TEMPLATE = "recall://fda-food/{recall_number}"
RECALL_URI = re.compile(r"^recall://fda-food/(?P<recall_number>[A-Z]-\d{4}-\d{4})$")

# Inputs (the SDK builds each tool's JSON Schema from these annotations).
Query = Annotated[
    str,
    Field(
        min_length=3,
        max_length=MAX_QUERY_CHARS,
        description="Product, ingredient, reason or firm words. Every word must appear, for example: romaine lettuce.",
    ),
]
Status = Literal["any", "Ongoing", "Completed", "Terminated"]
Classification = Literal["any", "Class I", "Class II", "Class III"]
Limit = Annotated[int, Field(ge=1, le=MAX_RESULTS, description=f"How many recalls to return (1-{MAX_RESULTS}).")]
RecallNumber = Annotated[
    str, Field(pattern=RECALL_NUMBER, description="An FDA recall number, for example F-0123-2025.")
]


# Outputs (structured content; the SDK also sends them as JSON text).
class RecallSummary(BaseModel):
    recall_number: str
    uri: str = Field(description="The recall resource to read for the whole report.")
    report_date: str
    classification: str
    status: str
    firm: str
    product: str = Field(max_length=SUMMARY_CHARS + 1)
    reason: str = Field(max_length=SUMMARY_CHARS + 1)


class SearchResult(BaseModel):
    query: str
    total_matches: int = Field(description="How many recalls match; only the newest are listed.")
    results: list[RecallSummary] = Field(max_length=MAX_RESULTS)


class Recall(BaseModel):
    recall_number: str
    uri: str
    event_id: str
    recalls_in_same_event: int = Field(description="One recall event can cover many products.")
    report_date: str
    recall_initiation_date: str | None
    termination_date: str | None
    classification: str
    status: str
    voluntary_mandated: str
    firm: str
    city: str
    state: str
    country: str
    product_description: str = Field(max_length=DETAIL_CHARS["product_description"] + 1)
    reason_for_recall: str = Field(max_length=DETAIL_CHARS["reason_for_recall"] + 1)
    product_quantity: str = Field(max_length=DETAIL_CHARS["product_quantity"] + 1)
    code_info: str = Field(max_length=DETAIL_CHARS["code_info"] + 1)
    distribution_pattern: str = Field(max_length=DETAIL_CHARS["distribution_pattern"] + 1)
    source: str


SOURCE = "U.S. FDA enforcement report, via openFDA (public domain). Unvalidated data: check fda.gov before you act."


def clip(text: str | None, limit: int) -> str:
    """Shorten a text to `limit` characters and say so with an ellipsis."""
    text = (text or "").strip()
    return text if len(text) <= limit else text[: limit - 1].rstrip() + "…"


def recall_uri(recall_number: str) -> str:
    return RECALL_URI_TEMPLATE.format(recall_number=recall_number)


# The prompt: a user-invoked template. The person picks it; the model does not run it on its own.
CUSTOMER_ANSWER_PROMPT = """A customer asks about FDA recall {recall_number}. Draft a short answer for the store's help desk.

Steps:
1. Read the recall with the get_recall tool (or the resource {uri}).
2. Say which product it is, the reason, the classification and the status, in plain English.
3. Say where the information comes from: the FDA enforcement report {recall_number}.
4. Do not give medical advice. If the customer feels unwell, tell them to contact a doctor.
5. If the product or the lot is not clearly the same as the customer's, say so. Do not guess."""
