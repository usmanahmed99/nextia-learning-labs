"""Food recalls as a read-only MCP server."""

__version__ = "1.0.0"
SERVER_NAME = "food-recalls"

# Versions are part of the design: MCP changes fast. Built and tested with:
SPEC_REVISION = "2026-07-28"  # the MCP specification revision
SDK_VERSION = "2.3.0"  # the official MCP Python SDK (pip package "mcp")
