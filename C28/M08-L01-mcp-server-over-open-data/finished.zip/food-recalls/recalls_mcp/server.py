"""food-recalls: FDA food recall enforcement reports as a read-only MCP server.

Capabilities (contracts in contracts.py, design in docs/capability-catalog.md):
- tools (the model may call them): search_recalls, get_recall (read-only, bounded)
- resources (the application reads them): recall://fda-food/{recall_number}; the list holds the
  newest ongoing Class I recalls (at most 50)
- prompts (the person picks them): customer_answer

Logs go to stderr as JSON lines: on stdio, stdout carries only protocol messages.

RECALLS_DESIGN chooses the search result's shape, only for the comparison in docs/results.md:
"summary" (this server's design), "full" (the 5 newest whole records) or "everything" (every
matching whole record, no limit). Never run the last two for real users.
"""

import json
import os
import re
import time

from mcp.server.mcpserver import MCPServer
from mcp.server.mcpserver.exceptions import ResourceNotFoundError, ToolError
from mcp.types import ListResourcesResult, Resource, ToolAnnotations

from recalls_mcp import SERVER_NAME, __version__, contracts, logs
from recalls_mcp.store import RECALL_NUMBER, NotFound, Store

INSTRUCTIONS = (
    "FDA food recall enforcement reports (public data, read-only). Search before you answer, "
    "and name the recall number you used. Search results are short: read one recall with "
    "get_recall for its details. The data is not validated by FDA and is not medical advice."
)
READ_ONLY = ToolAnnotations(read_only_hint=True, destructive_hint=False, idempotent_hint=True, open_world_hint=False)
DESIGNS = ("summary", "full", "everything")


def summary(r: dict) -> contracts.RecallSummary:
    return contracts.RecallSummary(
        recall_number=r["recall_number"],
        uri=contracts.recall_uri(r["recall_number"]),
        report_date=r["report_date"],
        classification=r["classification"],
        status=r["status"],
        firm=r["firm"],
        product=contracts.clip(r["product_description"], contracts.SUMMARY_CHARS),
        reason=contracts.clip(r["reason_for_recall"], contracts.SUMMARY_CHARS),
    )


def detail(r: dict, same_event: int) -> contracts.Recall:
    clipped = {k: contracts.clip(r[k], n) for k, n in contracts.DETAIL_CHARS.items()}
    return contracts.Recall(
        recall_number=r["recall_number"],
        uri=contracts.recall_uri(r["recall_number"]),
        event_id=r["event_id"],
        recalls_in_same_event=same_event,
        report_date=r["report_date"],
        recall_initiation_date=r["recall_initiation_date"],
        termination_date=r["termination_date"],
        classification=r["classification"],
        status=r["status"],
        voluntary_mandated=r["voluntary_mandated"],
        firm=r["firm"],
        city=r["city"],
        state=r["state"],
        country=r["country"],
        source=contracts.SOURCE,
        **clipped,
    )


def markdown(r: dict, same_event: int) -> str:
    """The resource text: the whole report, with only the lot codes cut (they can be 40,000 characters)."""
    code = r["code_info"] or "(none)"
    if len(code) > contracts.RESOURCE_CODE_CHARS:
        more = len(code) - contracts.RESOURCE_CODE_CHARS
        code = code[: contracts.RESOURCE_CODE_CHARS] + f" … [{more:,} more characters: see the FDA report]"
    return (
        f"# FDA recall {r['recall_number']}\n\n"
        f"- Classification: {r['classification']}\n- Status: {r['status']}\n"
        f"- Reported: {r['report_date']} (initiated {r['recall_initiation_date']}; terminated {r['termination_date'] or '-'})\n"
        f"- Firm: {r['firm']}, {r['city']}, {r['state']}, {r['country']}\n"
        f"- Recall event: {r['event_id']} ({same_event} recall{'' if same_event == 1 else 's'})\n- {r['voluntary_mandated']}\n\n"
        f"## Product\n{r['product_description']}\n\nQuantity: {r['product_quantity']}\n\n"
        f"## Reason\n{r['reason_for_recall']}\n\n## Distribution\n{r['distribution_pattern']}\n\n"
        f"## Codes\n{code}\n\n---\n{contracts.SOURCE}\n"
    )


class RecallsServer(MCPServer):
    """MCPServer, with a bounded resource list: the newest ongoing Class I recalls."""

    async def _handle_list_resources(self, ctx, params):
        rows = self.store.newest("Class I", "Ongoing", contracts.MAX_LISTED)
        return ListResourcesResult(
            resources=[
                Resource(
                    uri=contracts.recall_uri(r["recall_number"]),
                    name=r["recall_number"],
                    title=contracts.clip(f"{r['firm']}: {r['product_description']}", 80),
                    mime_type="text/markdown",
                    description=f"Class I, ongoing, reported {r['report_date']}",
                )
                for r in rows
            ]
        )


def build_server(store: Store | None = None, design: str | None = None) -> RecallsServer:
    store = store or Store()
    design = design or os.environ.get("RECALLS_DESIGN", "summary")
    if design not in DESIGNS:
        raise ValueError(f"RECALLS_DESIGN must be one of {DESIGNS}")
    mcp = RecallsServer(SERVER_NAME, version=__version__, instructions=INSTRUCTIONS)
    mcp.store = store
    log = logs.get_logger()

    if design == "summary":

        @mcp.tool(annotations=READ_ONLY)
        def search_recalls(
            query: contracts.Query,
            status: contracts.Status = "any",
            classification: contracts.Classification = "any",
            limit: contracts.Limit = contracts.DEFAULT_RESULTS,
        ) -> contracts.SearchResult:
            """Search FDA food recall enforcement reports, newest first. Returns at most 5 short summaries and the number of matches. Read one with get_recall."""
            started = time.perf_counter()
            try:
                total, rows = store.search(
                    query,
                    None if status == "any" else status,
                    None if classification == "any" else classification,
                    limit,
                )
            except ValueError as e:
                raise ToolError(f"invalid_query: {e}") from None
            log.event("tool_call", tool="search_recalls", matches=total, returned=len(rows), ms=logs.ms_since(started))
            return contracts.SearchResult(query=query, total_matches=total, results=[summary(r) for r in rows])

    else:  # the two alternatives of the comparison: whole records as JSON text

        @mcp.tool(annotations=READ_ONLY)
        def search_recalls(query: contracts.Query) -> str:
            """Search FDA food recall enforcement reports, newest first. Returns the whole records."""
            started = time.perf_counter()
            try:
                total, rows = store.search(query, limit=None if design == "everything" else contracts.DEFAULT_RESULTS)
            except ValueError as e:
                raise ToolError(f"invalid_query: {e}") from None
            log.event(
                "tool_call",
                tool="search_recalls",
                design=design,
                matches=total,
                returned=len(rows),
                ms=logs.ms_since(started),
            )
            return json.dumps({"query": query, "total_matches": total, "results": rows}, ensure_ascii=False)

    @mcp.tool(annotations=READ_ONLY)
    def get_recall(recall_number: contracts.RecallNumber) -> contracts.Recall:
        """Get one FDA food recall by its recall number (for example F-0123-2025): product, reason, class, status, dates, firm, codes and distribution. Long texts are cut."""
        started = time.perf_counter()
        try:
            r = store.get(recall_number)
        except NotFound:
            log.event("tool_call", tool="get_recall", outcome="not_found", ms=logs.ms_since(started))
            raise ToolError(f"not_found: there is no recall {recall_number} in the data") from None
        log.event("tool_call", tool="get_recall", outcome="ok", ms=logs.ms_since(started))
        return detail(r, store.event_size(r["event_id"]))

    @mcp.resource(
        contracts.RECALL_URI_TEMPLATE,
        name="recall",
        title="FDA food recall",
        mime_type="text/markdown",
        description="The whole enforcement report of one recall, by its recall number.",
    )
    def recall(recall_number: str) -> str:
        uri = contracts.recall_uri(recall_number)
        try:
            if not contracts.RECALL_URI.match(uri):
                raise NotFound(recall_number)
            r = store.get(recall_number)
        except NotFound:
            log.event("resource_read", uri=uri, outcome="not_found")
            raise ResourceNotFoundError(f"Resource not found: {uri}") from None
        log.event("resource_read", uri=uri, outcome="ok")
        return markdown(r, store.event_size(r["event_id"]))

    @mcp.prompt(title="Answer a customer about a recall")
    def customer_answer(recall_number: str) -> str:
        """Draft a short help-desk answer to a customer who asks about one FDA food recall."""
        if not re.match(RECALL_NUMBER, recall_number):
            raise ValueError("recall_number must look like F-0123-2025")
        return contracts.CUSTOMER_ANSWER_PROMPT.format(
            recall_number=recall_number, uri=contracts.recall_uri(recall_number)
        )

    return mcp
