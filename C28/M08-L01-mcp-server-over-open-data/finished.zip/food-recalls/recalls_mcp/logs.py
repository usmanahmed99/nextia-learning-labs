"""Structured logs: one JSON object per line, on stderr.

On a stdio server, stdout belongs to the protocol: one stray print() there breaks the client.
The data is public, so the logs hold no secrets; they still never hold a whole query result.
"""

import json
import sys
import time
from datetime import UTC, datetime


def ms_since(started: float) -> float:
    return round((time.perf_counter() - started) * 1000, 2)


class Logger:
    def event(self, name: str, **fields) -> dict:
        record = {"ts": datetime.now(UTC).isoformat(timespec="milliseconds"), "event": name} | fields
        print(json.dumps(record, ensure_ascii=False), file=sys.stderr, flush=True)
        return record


_LOGGER = Logger()


def get_logger() -> Logger:
    return _LOGGER
