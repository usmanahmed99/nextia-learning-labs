# food-recalls

A read-only MCP server over a real open dataset: the U.S. FDA's **food recall enforcement reports** (openFDA, public domain).
Any AI application with an MCP client can ask it "is this product recalled?" and "what is recall F-0123-2025 about?", and get bounded answers that name their source.
A small AI application (a *host*) with a mock model is included, so you need no account and no key.

This project is the case study *An MCP server over a real open dataset* of the course *MCP: Connect AI Applications to Tools and Data* on Nextia Learning.
The people in the case study are made up; the recalls are real public records.

## Versions

This project uses **MCP specification revision 2026-07-28** with the **official MCP Python SDK 2.3.0** (`pip` package `mcp`).
The SDK also accepts older clients that use the `initialize` handshake (revision 2025-11-25 and older).
Tested with Python 3.12 on macOS (Apple silicon). Windows and Linux commands are written but not tested.

## What it offers

| Kind | Name | Who chooses it | What it does |
|---|---|---|---|
| Tool | `search_recalls` | the model | The newest recalls whose product, reason or firm contain every word: at most 5 short summaries, and the number of matches. Read-only. |
| Tool | `get_recall` | the model | One recall by its number, with every long text cut. Read-only. |
| Resource | `recall://fda-food/{recall_number}` | the application | The whole report of one recall, as Markdown. |
| Resource list | `resources/list` | the application | The newest ongoing Class I recalls (at most 50). |
| Prompt | `customer_answer` | you | "Draft a short answer to a customer about this recall": the source named, no medical advice. |

The design and the rejected ideas are in `docs/capability-catalog.md`; the measurements in `docs/results.md`.

## Set up (once)

macOS or Linux:

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements-dev.txt
python -m scripts.get_data
python -m pytest -q
```

Windows (PowerShell):

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements-dev.txt
python -m scripts.get_data
python -m pytest -q
```

`scripts.get_data` downloads the course's copy of the openFDA file (5.9 MB), checks its SHA-256 checksum, and builds `data/recalls.db` (about 30 MB).
It leaves out 47 records whose recall number is not in FDA's form, and lists them in `data/excluded.jsonl`.

## Use it

```sh
python -m recalls_mcp.store search "romaine lettuce"           # the data alone, no MCP
python -m host "Is american ginseng under a recall?"           # the host with the mock model
python -m host "What is recall H-1393-2026 about?"
python -m scripts.contract                                     # does the server still match contract/capabilities.json?
python -m scripts.sizes                                        # the largest answers, over every recall (about 20 s)
python -m scripts.compare                                      # three result designs, 22 questions, one measure
```

The mock model searches for the question's words without question words such as "is", "there" and "recall" (or for the words in double quotes, if there are any).

Inspect the server with MCP Inspector (needs Node.js 22.19 or later; `npx` downloads it the first time). Use the current protocol era:

```sh
npx @modelcontextprotocol/inspector@2.10.1 --cli python -m recalls_mcp -- --protocol-era modern --method tools/list
```

### A real model (optional)

Any OpenAI-compatible chat completions API with tool calls. Set these in your shell (never in a file you commit):
`MODEL_BASE_URL` (ends with `/v1`), `MODEL_API_KEY`, `MODEL_NAME`, and `MODEL_REASONING_EFFORT` if your model needs it. Then:

```sh
python -m host "Has any infant formula been recalled recently?" --model openai
```

The host never passes the key to the server: it starts the server with an allow-list of settings.

## Data and licence

The data: openFDA food enforcement reports, export of 2026-10-06, public domain under CC0 1.0 (`DATASET.md`).
FDA says the data is not validated: check fda.gov before you act, and never treat "no recall found" as "safe".
The code: MIT (`LICENSE`).
