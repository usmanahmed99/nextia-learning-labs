"""Shared test helpers. The tests use the real data (data/recalls.db) and never need a key."""

import anyio
import pytest
from mcp import Client

from recalls_mcp.server import build_server
from recalls_mcp.store import DB, Store


def pytest_sessionstart(session):
    if not DB.exists():
        pytest.exit("data/recalls.db is missing: run  python -m scripts.get_data  first", returncode=1)


@pytest.fixture(scope="session")
def store():
    return Store()


@pytest.fixture
def call(store):
    """call(fn): run `await fn(client)` with an MCP client connected to the server in this process."""

    def run(fn, design="summary"):
        async def go():
            async with Client(build_server(store, design=design)) as client:
                return await fn(client)

        return anyio.run(go)

    return run
