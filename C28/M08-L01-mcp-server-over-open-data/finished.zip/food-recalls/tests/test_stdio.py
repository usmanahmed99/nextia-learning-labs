"""The real local transport: the server as a child process, MCP on stdout, logs on stderr."""

import anyio
from mcp import Client

from host.app import server_params


def test_the_sdk_client_starts_the_server_and_calls_a_tool():
    async def go():
        async with Client(server_params()) as client:
            names = sorted(t.name for t in (await client.list_tools()).tools)
            r = await client.call_tool("get_recall", {"recall_number": "H-1393-2026"})
            return client.protocol_version, names, r.structured_content["firm"]

    assert anyio.run(go) == ("2026-07-28", ["get_recall", "search_recalls"], "Kwok Shing, Inc.")


def test_an_older_client_still_works_with_the_initialize_handshake():
    async def go():
        async with Client(server_params(), mode="legacy") as client:
            r = await client.call_tool("search_recalls", {"query": "american ginseng"})
            return client.protocol_version, r.structured_content["total_matches"]

    assert anyio.run(go) == ("2025-11-25", 3)
