"""The course's host with the mock model, against this server."""

import anyio
from mcp import Client

from host import app
from host.models import MockModel
from recalls_mcp.server import build_server


def ask(store, question, design="summary"):
    async def go():
        async with Client(build_server(store, design=design)) as client:
            return await app.ask(client, MockModel(), question, confirm=lambda *_: False)

    return anyio.run(go)


def test_a_product_question_searches_then_reads_one_recall(store):
    run = ask(store, 'Is "american ginseng" under a recall?')
    wanted = [s.text for s in run.steps if s.who == "model"]
    assert wanted == ["wants search_recalls", "wants get_recall", "final answer"]
    assert "H-1393-2026" in run.answer and "recall://fda-food/H-1393-2026" in run.answer


def test_no_match_says_so(store):
    assert "found no FDA food recall" in ask(store, 'Is "dragon fruit gummies" under a recall?').answer


def test_whole_records_are_cut_by_the_host_and_cannot_be_read(store):
    run = ask(store, 'Is "listeria" under a recall?', design="full")
    assert "could not read" in run.answer and any(s.data.get("clipped") for s in run.steps)


def test_the_host_passes_only_its_allow_list_to_the_server(monkeypatch):
    monkeypatch.setenv("MODEL_API_KEY", "not-for-the-server")
    monkeypatch.setenv("RECALLS_DESIGN", "summary")
    env = app.server_params().env
    assert "MODEL_API_KEY" not in env and env["RECALLS_DESIGN"] == "summary"
