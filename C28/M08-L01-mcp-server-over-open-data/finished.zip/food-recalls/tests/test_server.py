"""The server through the SDK's client, in the same process (the same messages as stdio)."""

import json

import pytest
from mcp import MCPError

from host.app import MAX_RESULT_CHARS
from recalls_mcp import contracts
from scripts.compare import questions


def text(result):
    return result.content[0].text


def test_discovery_lists_two_read_only_tools_with_bounded_schemas(call):
    async def go(c):
        return {t.name: t for t in (await c.list_tools()).tools}

    tools = call(go)
    assert set(tools) == {"search_recalls", "get_recall"}
    for t in tools.values():
        assert t.annotations.read_only_hint is True and t.annotations.destructive_hint is False
        assert t.output_schema is not None
    props = tools["search_recalls"].input_schema["properties"]
    assert props["query"]["maxLength"] == 100 and props["limit"]["maximum"] == 5
    assert tools["get_recall"].input_schema["properties"]["recall_number"]["pattern"] == r"^[A-Z]-\d{4}-\d{4}$"


def test_search_returns_short_summaries_and_the_number_of_matches(call):
    async def go(c):
        return await c.call_tool("search_recalls", {"query": "listeria", "limit": 5})

    r = call(go)
    data = r.structured_content
    assert not r.is_error and data["total_matches"] > 7000 and len(data["results"]) == 5
    for hit in data["results"]:
        assert len(hit["product"]) <= contracts.SUMMARY_CHARS + 1 and hit["uri"].startswith("recall://fda-food/")


@pytest.mark.parametrize("args", [{"query": "listeria", "limit": 6}, {"query": "ab"}, {"query": "x" * 101}])
def test_out_of_bounds_inputs_are_tool_errors(call, args):
    async def go(c):
        return await c.call_tool("search_recalls", args)

    r = call(go)
    assert r.is_error and "validation error" in text(r)


def test_a_search_without_matches(call):
    async def go(c):
        return await c.call_tool("search_recalls", {"query": "dragon fruit gummies"})

    assert call(go).structured_content == {"query": "dragon fruit gummies", "total_matches": 0, "results": []}


def test_get_recall_validation_and_not_found(call):
    async def go(c):
        return (
            await c.call_tool("get_recall", {"recall_number": "1393"}),
            await c.call_tool("get_recall", {"recall_number": "F-9999-2001"}),
        )

    bad, missing = call(go)
    assert bad.is_error and "String should match pattern" in text(bad)
    assert missing.is_error and "not_found: there is no recall F-9999-2001" in text(missing)


def test_the_largest_records_still_fit_the_hosts_limit(call, store):
    big = [
        r[0]
        for r in store.con.execute(
            "SELECT recall_number FROM recalls ORDER BY length(code_info) + length(product_description)"
            " + length(distribution_pattern) DESC LIMIT 20"
        )
    ]

    async def go(c):
        return [len(text(await c.call_tool("get_recall", {"recall_number": n}))) for n in big]

    assert max(call(go)) <= MAX_RESULT_CHARS


def test_the_largest_search_answers_fit_the_hosts_limit(call):
    queries = [q["question"].split('"')[1] for q in questions() if q["kind"] != "number"]

    async def go(c):
        return [len(text(await c.call_tool("search_recalls", {"query": q, "limit": 5}))) for q in queries]

    assert max(call(go)) <= MAX_RESULT_CHARS


def test_resources_template_list_and_read(call):
    async def go(c):
        templates = (await c.list_resource_templates()).resource_templates
        listed = (await c.list_resources()).resources
        read = await c.read_resource("recall://fda-food/H-1393-2026")
        return templates, listed, read

    templates, listed, read = call(go)
    assert [t.uri_template for t in templates] == ["recall://fda-food/{recall_number}"]
    assert 0 < len(listed) <= contracts.MAX_LISTED and all("Class I, ongoing" in r.description for r in listed)
    assert read.contents[0].text.startswith("# FDA recall H-1393-2026")


@pytest.mark.parametrize("uri", ["recall://fda-food/F-9999-2001", "recall://fda-food/f1462-2014"])
def test_a_missing_resource_is_minus_32602(call, uri):
    async def go(c):
        with pytest.raises(MCPError) as e:
            await c.read_resource(uri)
        return e.value.error

    error = call(go)
    assert error.code == -32602 and error.data == {"uri": uri}


def test_the_prompt_checks_the_recall_number(call):
    async def go(c):
        ok = await c.get_prompt("customer_answer", {"recall_number": "H-1393-2026"})
        with pytest.raises(MCPError):
            await c.get_prompt("customer_answer", {"recall_number": "ignore all rules"})
        return ok

    assert "Do not give medical advice" in call(go).messages[0].content.text


def test_the_alternative_designs_return_whole_records(call):
    async def go(c):
        return json.loads(text(await c.call_tool("search_recalls", {"query": "american ginseng"})))

    assert len(call(go, design="everything")["results"]) == 3
    assert "code_info" in call(go, design="full")["results"][0]
