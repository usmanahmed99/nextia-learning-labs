"""The business service alone: the data, the search and one recall. No MCP."""

import hashlib

import pytest

from recalls_mcp.store import DATA, NotFound, fts_query
from scripts.get_data import FILE, expected


def test_the_data_is_the_checked_file(store):
    assert store.meta()["sha256"] == expected()
    if (DATA / FILE).exists():
        assert hashlib.sha256((DATA / FILE).read_bytes()).hexdigest() == expected()


def test_counts(store):
    c = store.counts()
    assert c["recalls"] == 29424 and store.meta()["left_out"] == "47"
    assert c["first_report"] == "2012-06-20" and c["last_report"] == "2026-09-30"


def test_search_needs_every_word_and_gives_the_newest_first(store):
    total, rows = store.search("american ginseng")
    assert total == 3 and rows[0]["recall_number"] == "H-1393-2026"
    dates = [r["report_date"] for r in store.search("romaine lettuce", limit=10)[1]]
    assert dates == sorted(dates, reverse=True)


def test_search_filters(store):
    total, rows = store.search("listeria", status="Ongoing", classification="Class I", limit=10)
    assert total > 0 and all(r["status"] == "Ongoing" and r["classification"] == "Class I" for r in rows)


@pytest.mark.parametrize("text", ['peanut" OR *', "NEAR(a b)", "a:b -c ^d"])
def test_query_text_cannot_use_fts5_syntax(text, store):
    assert all(part.startswith('"') for part in fts_query(text).split(" AND "))
    store.search(text)  # no SQLite error


def test_a_query_without_words_is_refused():
    with pytest.raises(ValueError):
        fts_query("--- !!")


def test_one_recall_and_a_missing_one(store):
    assert store.get("H-1393-2026")["firm"] == "Kwok Shing, Inc."
    with pytest.raises(NotFound):
        store.get("F-9999-2001")
