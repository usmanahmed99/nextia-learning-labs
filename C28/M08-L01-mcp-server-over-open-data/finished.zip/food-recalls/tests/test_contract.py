"""Contract: the server still offers what clients were promised (contract/capabilities.json)."""

import json

import anyio

from scripts import contract


def test_the_server_matches_the_recorded_contract():
    now = json.loads(json.dumps(anyio.run(contract.current), sort_keys=True))
    assert now == json.loads(contract.OUT.read_text(encoding="utf-8")), "run: python -m scripts.contract"


def test_every_tool_is_read_only_with_a_description_and_bounded_inputs():
    data = json.loads(contract.OUT.read_text(encoding="utf-8"))
    for tool in data["tools"]:
        assert tool["description"] and tool["outputSchema"] and tool["annotations"]["readOnlyHint"] is True
        for prop in tool["inputSchema"]["properties"].values():
            assert any(k in json.dumps(prop) for k in ("maxLength", "maximum", "pattern", "enum")), (tool["name"], prop)


def test_the_resource_uri_template_never_changes():
    data = json.loads(contract.OUT.read_text(encoding="utf-8"))
    assert [t["uriTemplate"] for t in data["resourceTemplates"]] == ["recall://fda-food/{recall_number}"]
