"""The client of Larkfield's ticket API (the downstream service; ticket_api/ is a local stub of it).

The MCP server reads tickets here. It calls the ticket API with its OWN credential: an access token
for the audience "ticket-api", issued to the client "helpdesk-mcp" (setting HELPDESK_SERVICE_TOKEN).
It never sends on the token that a person gave to the MCP server (no token passthrough). It names
the person in X-On-Behalf-Of, so that the ticket API's log says who asked.
"""

import os

import httpx2

from helpdesk.knowledge import NotFound


class TicketApiError(Exception):
    pass


def base_url() -> str:
    return os.environ.get("TICKET_API_URL", "http://127.0.0.1:8500").rstrip("/")


def service_credential() -> str:
    """The server's own token for the ticket API, from its settings. In production the server would
    get it from the provider with its own client credentials, and renew it before it expires."""
    token = os.environ.get("HELPDESK_SERVICE_TOKEN", "")
    if not token:
        raise TicketApiError("the server has no credential for the ticket API (HELPDESK_SERVICE_TOKEN)")
    return token


def fetch(tenant: str, ticket_id: str, credential: str, on_behalf_of: str | None = None) -> dict:
    headers = {"Authorization": f"Bearer {credential}"}
    if on_behalf_of:
        headers["X-On-Behalf-Of"] = on_behalf_of
    try:
        r = httpx2.get(f"{base_url()}/tenants/{tenant}/tickets/{ticket_id}", headers=headers, timeout=5)
    except httpx2.HTTPError as e:
        raise TicketApiError(f"the ticket API cannot be reached ({type(e).__name__})") from None
    if r.status_code == 404:
        raise NotFound("Not found.")
    if r.status_code != 200:
        raise TicketApiError(f"the ticket API answered {r.status_code}")
    return r.json()
