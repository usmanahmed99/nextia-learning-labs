# helpdesk-mcp (after the security review)

An MCP server for Larkfield's help desk, with a small AI application (a *host*), a practice identity provider and a stand-in for Larkfield's ticket API. This is the **finished** project of the case study *Security review of an MCP integration* in the course *MCP: Connect AI Applications to Tools and Data* on Nextia Learning.

The starter project is the prototype before the review. It was **constructed with weaknesses on purpose**, for practice on your own computer. Every person, ticket and shop is made up. No money moves: refunds are rows in a local SQLite file.

## Versions

MCP specification revision **2026-07-28**, the official MCP Python SDK **2.3.0** (`mcp`), PyJWT 2.15.1, Python 3.12. Tested on macOS only.

## Set up (once)

macOS or Linux:

```sh
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements-dev.txt
python -m idp init
python -m pytest -q
```

Windows (PowerShell):

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements-dev.txt
python -m idp init
python -m pytest -q
```

You need no account, no key and no money. The tests start every part themselves, on free ports of 127.0.0.1.

## The review's tools

```sh
python -m review.describe                    # what a client receives at discovery (read every word)
python -m review.describe --write            # after a reviewed change: pin the descriptions
python -m review.attacks                     # the attempts table: 13 attacks, 5 normal requests
python -m review.attacks --tenant bramble    # the same checks for Bramble Books
```

## Run it with real processes

Three terminals in the project folder, each with the virtual environment active.

Terminal 1, Larkfield's ticket API (a local stub):

```sh
python -m ticket_api
```

Terminal 2, the server's own credential for the ticket API, then the MCP server over Streamable HTTP:

```sh
export HELPDESK_SERVICE_TOKEN=$(python -m idp token --user svc-helpdesk-mcp --audience ticket-api --scope tickets:read --client-id helpdesk-mcp --seconds 3600)
python -m helpdesk --http
```

Windows: `$env:HELPDESK_SERVICE_TOKEN = python -m idp token --user svc-helpdesk-mcp --audience ticket-api --scope tickets:read --client-id helpdesk-mcp --seconds 3600`

Terminal 3, a person's token for the MCP server, then the host:

```sh
TOKEN=$(python -m idp token --user usr-sam)
python -m host "Please check ticket T-30002." --http http://127.0.0.1:8000/mcp --token "$TOKEN" --tenant larkfield
```

`python -m idp token` is a practice shortcut: it signs a token without a sign-in. In production, the server gets its own credential from the identity provider (the client credentials grant) and renews it.

The host can also start the server itself (stdio). Set `HELPDESK_SERVICE_TOKEN` in that terminal first, and keep the ticket API running:

```sh
python -m host "Please check ticket T-30201." --model mock-obedient --yes --scopes "knowledge:read tickets:read refunds:propose"
```

`--model mock-obedient` is a constructed model that obeys any text; `--yes` plays a careless person who says yes to every question. A real model is optional: set `MODEL_BASE_URL`, `MODEL_API_KEY` and `MODEL_NAME` (see `.env.example`) and add `--model openai`.

## Refunds

```sh
python -m helpdesk.approvals list
python -m helpdesk.approvals approve OP-0001 --user usr-grace
python -m helpdesk.approvals refunds
```

An owner of the organization who did not propose the refund decides. Delete `.support/` to remove every proposal and refund; delete `.idp/` and run `python -m idp init` for a new practice key.

## Files

| Path | What it is |
|---|---|
| `helpdesk/server.py` | The MCP server: `search_knowledge`, `get_ticket`, `propose_refund` |
| `helpdesk/http.py` | Streamable HTTP and the access-token check (audience: the server's own URL) |
| `helpdesk/tickets.py` | The ticket API client, with the server's own credential |
| `helpdesk/identity.py` | Who is the caller, in which organization, with which role and scopes |
| `helpdesk/writes.py`, `approvals.py` | The refund proposal and the owner's decision |
| `helpdesk/knowledge.py`, `contracts.py`, `logs.py` | Policy search, the bounded inputs and outputs, structured logs |
| `ticket_api/` | A stand-in for Larkfield's ticket API (another team's service) |
| `host/` | A minimal AI application with one MCP client and mock models |
| `idp/` | Practice tokens, signed with a key made on your computer |
| `review/` | The review's tools: `describe`, `attacks`, and the test bench (`harness.py`) |
| `contract/descriptions.json` | The reviewed tool descriptions |
| `tests/` | The prototype's tests and the review's tests |
| `data/` | The course's synthetic data (CC0) and its dataset card |

## Licence

Code: MIT (see `LICENSE`). Data: CC0 1.0 (see `data/dataset.md`).
