"""The security review: one test per weakness. Each test attacks the way the review's table does
(python -m review.attacks), and fails while the weakness is there.
ObedientMockModel is constructed: it obeys any text. The person who says yes to every question is
constructed too (h.ask_local answers yes)."""

import json
from pathlib import Path

from helpdesk import writes
from host.models import ObedientMockModel, ToolCall
from review import harness as h
from review.attacks import ORDERS

KEY = "practice-not-a-real-key"
CONTRACT = Path(__file__).resolve().parent.parent / "contract" / "descriptions.json"


# 1. Tool poisoning: the descriptions that reach the model


def test_no_tool_description_gives_orders():
    for tool in h.list_tools():
        assert not ORDERS.search(tool.description), tool.name


def test_descriptions_match_the_reviewed_contract():
    reviewed = json.loads(CONTRACT.read_text(encoding="utf-8"))
    assert {t.name: t.description for t in h.list_tools()} == reviewed


# 2. Token passthrough: one audience per hop


def test_a_token_for_another_api_is_refused(bench):
    said = h.list_remote(bench, h.token(bench, "usr-sam", audience="ticket-api"), "larkfield")
    assert said.startswith("refused"), said


def test_the_ticket_api_never_sees_the_persons_token(bench):
    outcome, text = h.call(bench, h.token(bench, "usr-sam"), "larkfield", "get_ticket", {"ticket_id": "T-30002"})
    assert outcome == "ok", text
    assert h.people_tokens_seen(bench) == []
    assert [(s["sub"], s["on_behalf_of"]) for s in bench.seen] == [("svc-helpdesk-mcp", "usr-sam")]


# 3. Cross-tenant read: the organization comes from the connection


def test_the_model_cannot_choose_the_organization(bench):
    call = ToolCall("c1", "get_ticket", {"ticket_id": "T-40003", "organization": "bramble"})
    said = h.server_says(h.ask_local(h.Asks(call), "practice", "usr-sam", "larkfield"))
    assert "not_found: there is no ticket T-40003 in this organization" in said[0]
    get_ticket = next(t for t in h.list_tools() if t.name == "get_ticket")
    assert "organization" not in get_ticket.input_schema["properties"]


# 4. Unapproved write: server gates, then a person outside the application


def test_an_injected_refund_is_never_recorded(bench):
    run = h.ask_local(ObedientMockModel(), "Please check ticket T-30201.", "usr-sam", "larkfield")
    assert any("over_limit" in s for s in h.server_says(run))
    assert writes.refunds() == []


def test_a_read_only_person_cannot_ask_for_a_refund(bench):
    call = ToolCall("c1", "propose_refund", {"ticket_id": "T-30002", "amount": "25", "reason": "Charged twice"})
    said = h.server_says(h.ask_local(h.Asks(call), "practice", "usr-omar", "larkfield"))
    assert said == ["protocol error -32003: forbidden: the role read_only cannot propose a refund"]


def test_a_refund_waits_for_an_owner_who_did_not_propose_it(bench, capsys):
    from helpdesk.approvals import main as approvals  # the approval step, outside the AI application

    call = ToolCall("c1", "propose_refund", {"ticket_id": "T-30002", "amount": "25", "reason": "Charged twice"})
    h.ask_local(h.Asks(call), "practice", "usr-sam", "larkfield")
    assert writes.refunds() == []
    assert approvals(["approve", "OP-0001", "--user", "usr-sam"]) == 1
    assert approvals(["approve", "OP-0001", "--user", "usr-grace"]) == 0
    assert [r["amount"] for r in writes.refunds()] == ["25.00"]


def test_the_write_tool_does_not_claim_to_be_read_only():
    tool = next(t for t in h.list_tools() if "refund" in t.name)
    assert tool.annotations.read_only_hint is False


# 5. The host's environment: the server gets its own settings only


def test_the_server_never_gets_the_hosts_secrets():
    env = h.server_environment(MODEL_API_KEY=KEY, OPENAI_API_KEY=KEY)
    assert "MODEL_API_KEY" not in env and "OPENAI_API_KEY" not in env


def test_the_server_never_logs_a_setting_value():
    log = h.server_start_log(direct=True, MODEL_API_KEY=KEY)
    assert "server_start" in log and KEY not in log
