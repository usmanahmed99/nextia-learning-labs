# helpdesk-mcp (prototype, before the security review)

> **Constructed for a security review.** This prototype has weaknesses on purpose. Run it only on your own computer, and do not copy its code. It belongs to the case study *Security review of an MCP integration* in the course *MCP: Connect AI Applications to Tools and Data* on Nextia Learning. Every person, ticket and shop is made up. No money moves: refunds are rows in a local SQLite file.

An MCP server for Larkfield's help desk. The tickets now live behind Larkfield's ticket API (`ticket_api/`, a local stand-in), and the server can refund customers.

## Versions

MCP specification revision **2026-07-28**, the official MCP Python SDK **2.3.0** (`mcp`), PyJWT 2.15.1, Python 3.12. Tested on macOS only.

## Set up (once)

macOS or Linux:

```sh
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements-dev.txt
python -m idp init
python -m pytest -q
```

Windows (PowerShell):

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements-dev.txt
python -m idp init
python -m pytest -q
```

## Run it

Terminal 1: `python -m ticket_api`

Terminal 2:

```sh
export HELPDESK_SERVICE_TOKEN=$(python -m idp token --user svc-helpdesk-mcp --audience ticket-api --scope tickets:read --client-id helpdesk-mcp --seconds 3600)
python -m helpdesk --http
```

Terminal 3. One token works for everything: make it for the ticket API.

```sh
TOKEN=$(python -m idp token --user usr-sam --audience ticket-api)
python -m host "Please check ticket T-30002." --http http://127.0.0.1:8000/mcp --token "$TOKEN" --tenant larkfield
```

## The review's tools

```sh
python -m review.describe      # what a client receives at discovery
python -m review.attacks       # the attempts table
```

## Licence

Code: MIT (see `LICENSE`). Data: CC0 1.0 (see `data/dataset.md`).
