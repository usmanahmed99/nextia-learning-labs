"""Larkfield's ticket API: a local stand-in (a stub) for the ticket service that another team owns.

    GET /tenants/{tenant}/tickets/{ticket_id}     one ticket, as JSON (404 if there is none)

It accepts a request only with an access token that is:
- signed (RS256) by the practice identity provider, with its issuer, not expired;
- made for this API: audience "ticket-api";
- allowed to read tickets: scope "tickets:read".
It is an internal API: it trusts its caller to name the organization in the path. So the service that
calls it must decide the organization itself, from who the person is.

It writes one log line per request (on stderr) and keeps the same facts in `app.state.seen`, so that a
review can see which token arrived here: whose (sub), from which client, on behalf of whom, and a
fingerprint of the token (the first 12 characters of its SHA-256), never the token itself.
The data is the course's synthetic data (data/tickets.jsonl). Nothing here is real.
"""

import hashlib
import json
import sys
from datetime import UTC, datetime

import jwt
from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Route

from helpdesk.knowledge import Knowledge, NotFound
from idp import keys

AUDIENCE = "ticket-api"


def fingerprint(token: str) -> str:
    """A short, one-way label of a token: enough to recognise it, useless to use it."""
    return hashlib.sha256(token.encode()).hexdigest()[:12]


def build_app(jwks: dict | None = None, knowledge: Knowledge | None = None) -> Starlette:
    key_set = jwt.PyJWKSet.from_dict(jwks or keys.jwks())  # practice: the provider's public key from .idp/
    knowledge = knowledge or Knowledge()

    def check(header: str) -> dict:
        if not header.lower().startswith("bearer "):
            raise jwt.InvalidTokenError("no token")
        token = header[7:]
        kid = jwt.get_unverified_header(token).get("kid")
        key = next((k.key for k in key_set.keys if k.key_id == kid), None)
        if key is None:
            raise jwt.InvalidTokenError("unknown key")
        return jwt.decode(
            token, key, algorithms=["RS256"], audience=AUDIENCE, issuer=keys.ISSUER, options={"require": ["exp", "sub"]}
        )

    async def ticket(request: Request) -> JSONResponse:
        tenant, ticket_id = request.path_params["tenant"], request.path_params["ticket_id"]
        header = request.headers.get("authorization", "")
        seen = {
            "tenant": tenant,
            "ticket_id": ticket_id,
            "on_behalf_of": request.headers.get("x-on-behalf-of"),
            "token_fp": fingerprint(header[7:]) if header else None,
        }
        try:
            claims = check(header)
        except jwt.InvalidTokenError as e:
            return record(request, seen | {"status": 401, "reason": type(e).__name__}, {"error": "invalid_token"}, 401)
        seen |= {"sub": claims["sub"], "client_id": claims.get("client_id", ""), "jti": claims.get("jti", "")}
        if "tickets:read" not in claims.get("scope", "").split():
            return record(request, seen | {"status": 403}, {"error": "insufficient_scope"}, 403)
        try:
            data = knowledge.ticket(tenant, ticket_id)
        except NotFound:
            return record(request, seen | {"status": 404}, {"error": "not_found"}, 404)
        return record(request, seen | {"status": 200}, data, 200)

    def record(request: Request, seen: dict, body: dict, status: int) -> JSONResponse:
        request.app.state.seen.append(seen)
        line = {"ts": datetime.now(UTC).isoformat(timespec="milliseconds"), "event": "ticket_api_request"} | seen
        line.pop("jti", None)
        print(json.dumps(line, ensure_ascii=False), file=sys.stderr, flush=True)
        return JSONResponse(body, status_code=status)

    app = Starlette(routes=[Route("/tenants/{tenant}/tickets/{ticket_id}", ticket)])
    app.state.seen = []
    return app
