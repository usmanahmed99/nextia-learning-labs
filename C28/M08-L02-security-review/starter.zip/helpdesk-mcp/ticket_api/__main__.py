"""python -m ticket_api    Larkfield's ticket API (a local stub) on http://127.0.0.1:8500"""

import os
import sys

import uvicorn

from idp import keys
from ticket_api.app import build_app


def main() -> int:
    keys.init()
    port = int(os.environ.get("TICKET_API_PORT", "8500"))
    print(f"Ticket API (a local stub) on http://127.0.0.1:{port}", file=sys.stderr, flush=True)
    uvicorn.run(build_app(), host="127.0.0.1", port=port, log_level="warning")
    return 0


if __name__ == "__main__":
    sys.exit(main())
