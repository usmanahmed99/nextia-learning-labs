"""Larkfield's ticket API: a local stand-in (a stub) for a service that another team owns."""
