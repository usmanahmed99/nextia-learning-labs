"""Shared test helpers. The tests never touch the network outside 127.0.0.1 and never need a key."""

import pytest

from review import harness


@pytest.fixture(autouse=True)
def isolated(tmp_path, monkeypatch):
    """Each test gets its own practice key folder and its own refunds database."""
    monkeypatch.setenv("IDP_DIR", str(tmp_path / "idp"))
    monkeypatch.setenv("SUPPORT_STATE", str(tmp_path / "state.db"))


@pytest.fixture
def bench():
    """The ticket API (a stub) and the MCP server over HTTP, on free ports of 127.0.0.1."""
    with harness.bench() as b:
        yield b
