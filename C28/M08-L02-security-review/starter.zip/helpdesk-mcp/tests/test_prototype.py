"""The prototype's own tests: what the help desk needs it to do."""

from helpdesk import writes
from host import app as host_app
from host.models import ToolCall
from review import harness as h


def ask(call: ToolCall, user="usr-sam", tenant="larkfield"):
    return h.server_says(h.ask_local(h.Asks(call), "practice", user, tenant))


def test_search_finds_the_return_policy(bench):
    said = ask(ToolCall("c1", "search_knowledge", {"query": "return window"}))
    assert said[0].startswith("result:")


def test_get_ticket_returns_the_ticket(bench):
    said = ask(ToolCall("c1", "get_ticket", {"ticket_id": "T-30002"}))
    assert said[0].startswith("result:")


def test_get_ticket_over_http(bench):
    tok = h.token(bench, "usr-sam", audience="ticket-api")  # one token for both: see README
    outcome, text = h.call(bench, tok, "larkfield", "get_ticket", {"ticket_id": "T-30002"})
    assert outcome == "ok" and "Charged twice" in text


def test_issue_refund_records_a_refund(bench):
    said = ask(ToolCall("c1", "issue_refund", {"ticket_id": "T-30002", "amount": "25", "reason": "Charged twice"}))
    assert said[0].startswith("result:")
    assert [r["amount"] for r in writes.refunds()] == ["25.00"]


def test_the_host_starts_the_server():
    params = host_app.server_params("usr-sam", "larkfield")
    assert params.args == ["-m", "helpdesk"] and params.env["SUPPORT_USER"] == "usr-sam"
