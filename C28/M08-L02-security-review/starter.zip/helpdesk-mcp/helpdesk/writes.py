"""The one write: issue a refund. A mock: no money moves, ever.

CONSTRUCTED FOR A SECURITY REVIEW: this version has weaknesses on purpose. Do not copy it.

issue_refund records the refund at once. The tool is marked read-only: "it only writes to our own
database".
"""

import os
import sqlite3
from contextlib import closing
from datetime import UTC, datetime
from decimal import Decimal
from pathlib import Path
from typing import Annotated

from mcp.server.mcpserver import Context
from mcp.types import ToolAnnotations
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parent.parent
READ_ONLY = ToolAnnotations(read_only_hint=True, destructive_hint=False, idempotent_hint=True, open_world_hint=False)

Amount = Annotated[
    Decimal, Field(gt=0, le=10000, decimal_places=2, description="Amount in dollars, for example 25.00.")
]
Reason = Annotated[str, Field(min_length=3, max_length=200, description="Why the customer should get the refund.")]


class Refund(BaseModel):
    operation_id: str
    status: str
    ticket_id: str
    amount: str
    message: str


def state_path() -> Path:
    return Path(os.environ.get("SUPPORT_STATE", ROOT / ".support" / "state.db"))


def connect() -> sqlite3.Connection:
    path = state_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(path)
    db.row_factory = sqlite3.Row
    db.executescript(
        """CREATE TABLE IF NOT EXISTS refunds (
               operation_id TEXT PRIMARY KEY, tenant TEXT, ticket_id TEXT, amount TEXT, recorded_at TEXT);"""
    )
    return db


def register(mcp, read_ticket, caller, log) -> None:
    @mcp.tool(annotations=READ_ONLY)
    def issue_refund(
        ticket_id: Annotated[str, Field(pattern=r"^T-\d{5}$")], amount: Amount, reason: Reason, ctx: Context
    ) -> Refund:
        """Refund a customer for a ticket. Records the refund at once."""
        who = caller(ctx)
        amount_text = f"{amount:.2f}"
        with closing(connect()) as db, db:
            n = db.execute("SELECT count(*) FROM refunds").fetchone()[0] + 1
            op = f"OP-{n:04d}"
            now = datetime.now(UTC).isoformat(timespec="seconds")
            db.execute("INSERT INTO refunds VALUES (?,?,?,?,?)", (op, who.tenant, ticket_id, amount_text, now))
        log.event(
            "tool_call",
            caller=who,
            tool="issue_refund",
            outcome="refunded",
            operation_id=op,
            ticket_id=ticket_id,
            amount=amount_text,
        )
        return Refund(
            operation_id=op,
            status="refunded",
            ticket_id=ticket_id,
            amount=amount_text,
            message=f"Refund of {amount_text} USD recorded (mock: no money moved).",
        )


def refunds() -> list[dict]:
    with closing(connect()) as db:
        return [dict(r) for r in db.execute("SELECT * FROM refunds ORDER BY operation_id")]
