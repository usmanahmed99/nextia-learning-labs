"""helpdesk-mcp: a prototype MCP server for Larkfield's help desk, written for a security review.

The tickets live behind Larkfield's ticket API (ticket_api/, a local stub); the policy documents are
searched locally. Every person, ticket and shop in it is made up.
"""

__version__ = "0.3.0"
SERVER_NAME = "helpdesk-mcp"

SPEC_REVISION = "2026-07-28"  # the MCP specification revision
SDK_VERSION = "2.3.0"  # the official MCP Python SDK (pip package "mcp")
