"""A practice identity provider: it signs RS256 access tokens with a key made on your computer.

This is the token part of the MCP course's practice provider (`python -m idp init`, `python -m idp token`).
It has no sign-in pages: the review only needs tokens for made-up people and for the server itself.
Never use it for real accounts. Signing uses PyJWT and cryptography; there is no hand-written cryptography.
"""
