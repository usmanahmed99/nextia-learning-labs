"""python -m idp [init | token | users]

python -m idp init                    make the signing key in .idp/ (once)
python -m idp token --user usr-sam    print an access token (a practice shortcut: no sign-in)
    [--scope "knowledge:read tickets:read"] [--audience http://127.0.0.1:8000/mcp]
    [--client-id support-host] [--seconds 600]
python -m idp users                   the made-up people
"""

import argparse
import csv
import os
import sys

from idp import keys


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="python -m idp")
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("init")
    sub.add_parser("users")
    t = sub.add_parser("token")
    t.add_argument("--user", required=True)
    t.add_argument("--scope", default="knowledge:read tickets:read")
    t.add_argument("--audience", default=os.environ.get("MCP_RESOURCE_URL", "http://127.0.0.1:8000/mcp"))
    t.add_argument("--client-id", default="support-host")
    t.add_argument("--seconds", type=int, default=None)
    a = p.parse_args(argv)
    if a.cmd == "init":
        print(f"Signing key {keys.init()} in {keys.key_dir()}")
        return 0
    if a.cmd == "users":
        with (keys.ROOT / "data" / "users.csv").open(encoding="utf-8", newline="") as f:
            for r in csv.DictReader(f):
                print(f"{r['user_id']}  {r['name']}")
        return 0
    print(keys.access_token(a.user, a.scope, a.audience, client_id=a.client_id, seconds=a.seconds))
    return 0


if __name__ == "__main__":
    sys.exit(main())
