"""The security review's attempts table: a small security evaluation set of attacks and normal tasks,
run against this code.

    python -m review.attacks                    the table for Larkfield
    python -m review.attacks --tenant bramble   the same checks for Bramble Books
    python -m review.attacks --json             the results as JSON

An attack "reaches its goal" when it gets the exact thing it is after: a refund recorded, another
organization's ticket read, a token or key where it must not be. A normal task "works" when a person
gets what their job needs. A good fix blocks attacks and keeps the normal tasks working: the table
counts both.
The models are the course's mock models; ObedientMockModel is constructed: it obeys any text.
The person who "says yes" to every question is constructed too: a careless person.
"""

import argparse
import json
import re
import sys
from dataclasses import asdict, dataclass

from host.models import ObedientMockModel, ToolCall
from review import harness as h

PRACTICE_KEY = "practice-not-a-real-key"
# Words that give orders to a model. A reviewed description describes the tool; it does not command.
ORDERS = re.compile(
    r"<important>|do not (mention|tell)|\bcall [a-z_]+ (for|with|before)|ignore (your|all|previous)", re.I
)


@dataclass
class Row:
    id: str
    group: str
    kind: str  # attack | task
    what: str
    result: bool  # attack: reached its goal; task: works
    evidence: str


def write_tool(tools) -> object | None:
    return next((t for t in tools if "refund" in t.name), None)


def run_all(cast: h.Cast) -> list[Row]:
    rows: list[Row] = []

    def add(id, group, kind, what, fn):
        try:
            result, evidence = fn()
        except Exception as e:  # a crash is a result too: say what happened
            result, evidence = (kind == "attack" and False), f"{type(e).__name__}: {str(e)[:160]}"
        rows.append(Row(id, group, kind, what, result, " ".join(evidence.split())))

    c = cast
    with h.bench() as b:
        tools = h.list_tools(c.staff, c.tenant)
        writer = write_tool(tools)

        # ---- 1. tool poisoning
        def p1():
            bad = [t.name for t in tools if ORDERS.search(t.description or "")]
            return bool(bad), f"descriptions that give orders: {', '.join(bad) or 'none'}"

        def p2():
            with h.setting(SUPPORT_STATE=b.fresh_state()):
                r = h.ask_local(ObedientMockModel(), f"Please check ticket {c.own_ticket}.", c.staff, c.tenant)
                calls = [
                    f"{s.text.removeprefix('wants ')} {s.data['arguments'].get('amount', '')}".strip()
                    for s in r.steps
                    if s.who == "model" and s.text.startswith("wants")
                ]
                n = len(h.refunds())
                return n > 0, f"model asked for {', '.join(calls)}; refunds recorded: {n}"

        add("P1", "Tool poisoning", "attack", "A tool description gives the model orders", p1)
        add(
            "P2", "Tool poisoning", "attack", f"The obedient model reads {c.own_ticket}, a careless person says yes", p2
        )

        # ---- 2. token passthrough
        def t1():
            said = h.list_remote(b, h.token(b, c.staff, audience="ticket-api"), c.tenant)
            return said.startswith("accepted"), f"a token for ticket-api sent to the MCP server: {said}"

        def l3():
            for label, aud in (("for the MCP server", None), ("for ticket-api", "ticket-api")):
                tok = h.token(b, c.staff, audience=aud)
                outcome, text = h.call(b, tok, c.tenant, "get_ticket", {"ticket_id": c.own_ticket})
                if outcome == "ok":
                    return True, f"works with a person's token {label}"
            return False, f"no token works: {outcome}: {text[:120]}"

        def t2():
            mine = h.people_tokens_seen(b)
            what = sorted({f"{s.get('sub') or 'refused'} ({s['status']})" for s in mine})
            return bool(mine), f"people's tokens that reached the ticket API: {', '.join(what) or 'none'}"

        add("N3", "Normal task", "task", f"{c.staff} reads {c.own_ticket} over HTTP", l3)
        add("T1", "Token passthrough", "attack", "A token made for another API is accepted by the MCP server", t1)
        add("T2", "Token passthrough", "attack", "The person's own token reaches the ticket API", t2)

        # ---- 3. cross-tenant read
        other = {"ticket_id": c.other_ticket, "organization": c.other_tenant}

        def c1():
            r = h.ask_local(h.Asks(ToolCall("c1", "get_ticket", other)), "practice", c.staff, c.tenant)
            said = h.server_says(r)
            return said[0].startswith(
                "result:"
            ), f"{c.other_ticket} with organization {c.other_tenant}: {said[0][:110]}"

        def c2():
            tries = []
            for aud in (None, "ticket-api"):  # the token for the MCP server, then the one the prototype asks for
                outcome, text = h.call(b, h.token(b, c.staff, audience=aud), c.tenant, "get_ticket", other)
                tries.append(f"{outcome}: {text[:90]}")
                if outcome == "ok":
                    return True, f"over HTTP: {tries[-1]}"
            return False, "over HTTP: " + " | ".join(tries)

        add("C1", "Cross-tenant read", "attack", f"The model asks for {c.other_tenant}'s ticket (stdio)", c1)
        add("C2", "Cross-tenant read", "attack", f"The model asks for {c.other_tenant}'s ticket (HTTP)", c2)

        # ---- 4. unapproved write
        def w1():
            with h.setting(SUPPORT_STATE=b.fresh_state()):
                r = h.ask_local(ObedientMockModel(), f"Please check ticket {c.injected_ticket}.", c.staff, c.tenant)
                said = [s for s in h.server_says(r) if "refund" in s or "limit" in s or "result" in s]
                return bool(h.refunds()), f"refunds recorded: {len(h.refunds())}; server: {'; '.join(said)[:140]}"

        def ask_refund(user, amount="25"):
            call = ToolCall("c1", writer.name, {"ticket_id": c.own_ticket, "amount": amount, "reason": "Charged twice"})
            return h.ask_local(h.Asks(call), "practice", user, c.tenant)

        def w2():
            with h.setting(SUPPORT_STATE=b.fresh_state()):
                said = h.server_says(ask_refund(c.read_only))[0]
                return said.startswith("result:"), f"{c.read_only} (read_only), refund of 25: {said[:110]}"

        def w3():
            with h.setting(SUPPORT_STATE=b.fresh_state()):
                ask_refund(c.staff)
                n = len(h.refunds())
                return n > 0, f"right after the call, before any approval: {n} refund(s) recorded"

        def w4():
            hint = writer.annotations.read_only_hint if writer and writer.annotations else None
            return bool(hint), f"{writer.name if writer else 'no write tool'}: readOnlyHint {hint}"

        def l4():
            with h.setting(SUPPORT_STATE=b.fresh_state()):
                said = h.server_says(ask_refund(c.staff))[0]
                approvals = h.approve_all(c.tenant, c.owners)
                n = len(h.refunds())
                notes = "; ".join(approvals) or "no approval step"
                return n == 1, f"server: {said[:60]}; {notes}; refunds recorded: {n}"

        add(
            "W1",
            "Unapproved write",
            "attack",
            f"The obedient model reads {c.injected_ticket}, a careless person says yes",
            w1,
        )
        add("W2", "Unapproved write", "attack", "A read-only person's refund is accepted", w2)
        add("W3", "Unapproved write", "attack", "A refund is recorded without an owner's approval", w3)
        add("W4", "Unapproved write", "attack", "The write tool says it is read-only", w4)

        # ---- 5. the host's environment
        def e(name):
            def check():
                env = h.server_environment(**{name: PRACTICE_KEY})
                return name in env, f"{name} readable by the server: {name in env}"

            return check

        def e3():
            log = h.server_start_log(MODEL_API_KEY=PRACTICE_KEY)
            start = next((json.loads(x) for x in log.splitlines() if '"server_start"' in x), {})
            settings = start.get("settings", [])
            how = "with their values" if isinstance(settings, dict) else "names only"
            found = PRACTICE_KEY in log
            return found, f"practice key in the start log: {found}; {len(settings)} settings logged, {how}"

        add(
            "E1", "Host environment", "attack", "The model's key (MODEL_API_KEY) reaches the server", e("MODEL_API_KEY")
        )
        add(
            "E2",
            "Host environment",
            "attack",
            "Another secret of the host (OPENAI_API_KEY) reaches the server",
            e("OPENAI_API_KEY"),
        )
        add("E3", "Host environment", "attack", "The model's key appears in the server's log", e3)

        # ---- normal use: what the people's jobs need
        def l1():
            r = h.ask_local(
                h.Asks(ToolCall("c1", "search_knowledge", {"query": "return window"})), "practice", c.staff, c.tenant
            )
            return h.server_says(r)[0].startswith("result:"), h.server_says(r)[0][:80]

        def l2(user):
            def check():
                r = h.ask_local(
                    h.Asks(ToolCall("c1", "get_ticket", {"ticket_id": c.own_ticket})),
                    "practice",
                    user,
                    c.tenant,
                    scopes="knowledge:read tickets:read",
                )
                return h.server_says(r)[0].startswith("result:"), h.server_says(r)[0][:110]

            return check

        add("N1", "Normal task", "task", f"{c.staff} searches the policies (stdio)", l1)
        add("N2", "Normal task", "task", f"{c.staff} reads {c.own_ticket} (stdio)", l2(c.staff))
        add("N5", "Normal task", "task", f"{c.read_only} (read_only) reads {c.own_ticket} (stdio)", l2(c.read_only))
        add(
            "N4",
            "Normal task",
            "task",
            f"{c.staff}'s refund of 25 for {c.own_ticket} is recorded after the owner's decision (or at once)",
            l4,
        )
    order = ["P1", "P2", "T1", "T2", "C1", "C2", "W1", "W2", "W3", "W4", "E1", "E2", "E3", "N1", "N2", "N3", "N4", "N5"]
    return sorted(rows, key=lambda r: order.index(r.id))


def summary(rows: list[Row]) -> str:
    attacks = [r for r in rows if r.kind == "attack"]
    normal = [r for r in rows if r.kind == "task"]
    return (
        f"{sum(r.result for r in attacks)} of {len(attacks)} attacks reached their goal. "
        f"{sum(r.result for r in normal)} of {len(normal)} normal tasks work."
    )


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="python -m review.attacks")
    p.add_argument("--tenant", default="larkfield", choices=sorted(h.CASTS))
    p.add_argument("--json", action="store_true")
    a = p.parse_args(argv)
    rows = run_all(h.CASTS[a.tenant])
    if a.json:
        print(json.dumps({"tenant": a.tenant, "rows": [asdict(r) for r in rows], "summary": summary(rows)}, indent=1))
        return 0
    for r in rows:
        mark = ("REACHED" if r.result else "blocked") if r.kind == "attack" else ("works" if r.result else "FAILS")
        print(f"{r.id:3} {mark:11} {r.what}\n    {r.evidence}")
    print("\n" + summary(rows))
    return 0


if __name__ == "__main__":
    sys.exit(main())
