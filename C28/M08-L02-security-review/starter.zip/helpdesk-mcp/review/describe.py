"""What an AI application receives at discovery: each tool's name, annotations, inputs and description.

    python -m review.describe            read them, as the model will (a reviewer's first step)
    python -m review.describe --write    after a review: pin the descriptions in contract/descriptions.json

The descriptions go to the model as they are, so a reviewer reads every word.
"""

import json
import sys
import textwrap
from pathlib import Path

from review import harness as h

CONTRACT = Path(__file__).resolve().parent.parent / "contract" / "descriptions.json"


def main(argv: list[str]) -> int:
    tools = h.list_tools()
    if "--write" in argv:
        CONTRACT.parent.mkdir(exist_ok=True)
        CONTRACT.write_text(json.dumps({t.name: t.description for t in tools}, indent=1) + "\n", encoding="utf-8")
        print(f"Wrote {len(tools)} reviewed descriptions to {CONTRACT.relative_to(Path.cwd())}")
        return 0
    for t in tools:
        a = t.annotations
        hints = f"readOnlyHint={a.read_only_hint}" if a else "no annotations"
        params = ", ".join(t.input_schema.get("properties", {}))
        print(f"{t.name}({params})  [{hints}]")
        print(textwrap.indent(textwrap.fill(t.description or "", 96), "    "))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
