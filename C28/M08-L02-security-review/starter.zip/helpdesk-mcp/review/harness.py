"""The review's test bench. It runs every part on your own computer, on free ports of 127.0.0.1:
the ticket API (a stub), the MCP server over Streamable HTTP, and the in-process server for stdio.

Each check gets fresh practice keys and a fresh state database, so the checks do not depend on
each other or on anything you did before. Tokens come from the practice provider's key (idp/).
Nothing here needs a network, an account or a model: the models are the course's mock models.
"""

import io
import os
import socket
import subprocess
import sys
import tempfile
import threading
import time
from contextlib import contextmanager, redirect_stderr
from dataclasses import dataclass, field

import anyio
import uvicorn
from mcp import Client, MCPError
from mcp.client.stdio import get_default_environment

from helpdesk import writes
from helpdesk.http import JwtVerifier, build_app
from helpdesk.server import build_server
from host import app as host_app
from host.models import Decision, ToolCall
from idp import keys
from ticket_api.app import build_app as ticket_api_app
from ticket_api.app import fingerprint

SERVICE = {"sub": "svc-helpdesk-mcp", "client_id": "helpdesk-mcp"}  # the server's own identity at the ticket API


@dataclass(frozen=True)
class Cast:
    """The people and tickets of one organization, for the checks."""

    tenant: str
    other_tenant: str
    staff: str  # may propose refunds
    read_only: str
    owners: tuple[str, ...]
    own_ticket: str
    other_ticket: str  # a ticket of the other organization
    injected_ticket: str  # a ticket whose text asks for a refund


CASTS = {
    "larkfield": Cast("larkfield", "bramble", "usr-sam", "usr-omar", ("usr-grace",), "T-30002", "T-40003", "T-30201"),
    # Bramble Books has no staff member: its owner Ines is the one who proposes.
    "bramble": Cast("bramble", "larkfield", "usr-ines", "usr-camille", ("usr-ines",), "T-40001", "T-30002", "T-40001"),
}
WRITE_SCOPES = "knowledge:read tickets:read refunds:propose"


class Asks:
    """A scripted model: it asks for the given calls, one per turn, then answers."""

    name = "scripted"

    def __init__(self, *calls: ToolCall):
        self.calls = list(calls)

    def decide(self, messages, tools):
        return Decision([self.calls.pop(0)]) if self.calls else Decision(answer="done")


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@contextmanager
def served(app):
    port = free_port()
    server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning"))
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()
    deadline = time.time() + 10
    while not server.started and time.time() < deadline:
        time.sleep(0.02)
    try:
        yield f"http://127.0.0.1:{port}"
    finally:
        server.should_exit = True
        thread.join(timeout=10)


@contextmanager
def setting(**values):
    """Set environment variables for a moment (None removes one)."""
    old = {k: os.environ.get(k) for k in values}
    try:
        for k, v in values.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        yield
    finally:
        for k, v in old.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v


@dataclass
class Bench:
    ticket_api: str
    mcp_url: str
    seen: list = field(default_factory=list)  # what the ticket API received
    logs: io.StringIO = field(default_factory=io.StringIO)
    tmp: str = ""
    states: int = 0
    issued: list = field(default_factory=list)  # every person's token made with token()

    def fresh_state(self) -> str:
        """A new, empty state database (refund proposals and refunds) for one check."""
        self.states += 1
        return os.path.join(self.tmp, f"state-{self.states}.db")


@contextmanager
def bench():
    """Fresh keys and state, the ticket API and the MCP server (HTTP). The server reads tickets with the
    service token in HELPDESK_SERVICE_TOKEN; the in-process stdio server uses the same settings."""
    with tempfile.TemporaryDirectory() as tmp, setting(IDP_DIR=f"{tmp}/idp", SUPPORT_STATE=f"{tmp}/state.db"):
        keys.init()
        api = ticket_api_app()
        service = keys.access_token(
            SERVICE["sub"], "tickets:read", "ticket-api", client_id=SERVICE["client_id"], seconds=3600
        )
        logs = io.StringIO()
        with (
            redirect_stderr(logs),
            served(api) as api_url,
            setting(TICKET_API_URL=api_url, HELPDESK_SERVICE_TOKEN=service),
        ):
            port = free_port()
            url = f"http://127.0.0.1:{port}/mcp"
            mcp_app = build_app(JwtVerifier(keys.ISSUER, url, jwks=keys.jwks()), issuer=keys.ISSUER, resource_url=url)
            server = uvicorn.Server(uvicorn.Config(mcp_app, host="127.0.0.1", port=port, log_level="warning"))
            thread = threading.Thread(target=server.run, daemon=True)
            thread.start()
            deadline = time.time() + 10
            while not server.started and time.time() < deadline:
                time.sleep(0.02)
            try:
                yield Bench(api_url, url, api.state.seen, logs, tmp)
            finally:
                server.should_exit = True
                thread.join(timeout=10)


def token(b: Bench, user: str, scope: str = "knowledge:read tickets:read", audience: str | None = None) -> str:
    """A person's access token. By default for the MCP server (its URL is the audience)."""
    tok = keys.access_token(user, scope, audience or b.mcp_url)
    b.issued.append(tok)
    return tok


def people_tokens_seen(b: Bench) -> list[dict]:
    """The ticket API's records of requests that carried one of the people's own tokens."""
    mine = {fingerprint(t) for t in b.issued}
    return [s for s in b.seen if s.get("token_fp") in mine]


def ask_local(model, question: str, user: str, tenant: str, scopes: str = WRITE_SCOPES, yes: bool = True):
    """The host and a model, with the server in process (stdio rules: the caller from the environment)."""

    async def go():
        async with Client(build_server()) as client:
            return await host_app.ask(client, model, question, lambda name, args: yes)

    with setting(SUPPORT_USER=user, SUPPORT_TENANT=tenant, SUPPORT_SCOPES=scopes):
        return anyio.run(go)


def ask_remote(b: Bench, tok: str, tenant: str, model, question: str, yes: bool = True):
    """The host and a model, with the server over Streamable HTTP."""

    async def go():
        http, target = host_app.http_target(b.mcp_url, tok, tenant)
        async with http, Client(target) as client:
            return await host_app.ask(client, model, question, lambda name, args: yes)

    return anyio.run(go)


def list_tools(user: str = "usr-sam", tenant: str = "larkfield"):
    async def go():
        async with Client(build_server()) as client:
            return (await client.list_tools()).tools

    with setting(SUPPORT_USER=user, SUPPORT_TENANT=tenant, SUPPORT_SCOPES=WRITE_SCOPES), redirect_stderr(io.StringIO()):
        return anyio.run(go)


def list_remote(b: Bench, tok: str, tenant: str) -> str:
    """Discovery over HTTP with this token, through the SDK's client: "accepted" or why not."""

    async def go():
        http, target = host_app.http_target(b.mcp_url, tok, tenant)
        async with http, Client(target) as client:
            return f"accepted: {len((await client.list_tools()).tools)} tools listed"

    try:
        return anyio.run(go)
    except Exception as e:  # the SDK raises when the server answers 401
        return f"refused: {_root(e)}"


def _root(e: BaseException) -> str:
    while isinstance(e, BaseExceptionGroup) and e.exceptions:
        e = e.exceptions[0]
    return f"{type(e).__name__}: {str(e)[:80]}"


def server_says(run) -> list[str]:
    return [s.text for s in run.steps if s.who == "server"]


def refunds() -> list[dict]:
    return writes.refunds()


def approve_all(tenant: str, owners: tuple[str, ...]) -> list[str]:
    """Each owner in turn tries to approve each pending proposal, if the server has proposals (the
    prototype has none). Returns what happened, refusals included."""
    if not hasattr(writes, "decide"):
        return []
    done = []
    for p in writes.pending(tenant):
        for owner in owners:
            try:
                writes.decide(p["operation_id"], owner, approve=True)
                done.append(f"{p['operation_id']} approved by {owner}")
                break
            except writes.ApprovalError as e:
                done.append(f"refused: {e}")
    return done


def server_environment(**host_env) -> dict:
    """What a local server started by the host can read: the host's settings plus the SDK's defaults."""
    with setting(**host_env):
        params = host_app.server_params("usr-sam", "larkfield")
        return get_default_environment() | (params.env or {})


def server_start_log(direct: bool = False, **host_env) -> str:
    """Start the real stdio server with no client, and return what it logs at start. As the host would
    start it, or (direct=True) with these settings given to the server itself."""
    if direct:
        env = get_default_environment() | host_env
    else:
        env = server_environment(**host_env)
    out = subprocess.run(
        [sys.executable, "-m", "helpdesk"],
        input="",
        env=env,
        capture_output=True,
        text=True,
        timeout=30,
        cwd=os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    )
    return out.stderr


def call(b: Bench, tok: str, tenant: str, name: str, args: dict) -> tuple[str, str]:
    """One tool call over HTTP: ("ok" | "error" | "refused", text)."""

    async def go():
        http, target = host_app.http_target(b.mcp_url, tok, tenant)
        async with http, Client(target) as client:
            try:
                r = await client.call_tool(name, args)
                return ("error" if r.is_error else "ok"), r.content[0].text
            except MCPError as e:
                return "refused", e.error.message

    try:
        return anyio.run(go)
    except Exception as e:  # the SDK raises when the server answers 401 or 403
        return "refused", _root(e)
