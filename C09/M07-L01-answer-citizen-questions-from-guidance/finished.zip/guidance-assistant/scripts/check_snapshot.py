"""Check the snapshot against its checksums and print what it holds.

    python scripts/check_snapshot.py
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from guidance_assistant.snapshot import GUIDANCE, SnapshotChanged, load_pages  # noqa: E402

try:
    pages = load_pages()
except SnapshotChanged as e:
    raise SystemExit(f"Changed: {e}")
for line in (GUIDANCE / "SHA256SUMS").read_text().splitlines():
    digest, name = line.split()
    print(f"OK  {name}  SHA-256 {digest[:12]}…")
fetched = sorted({p.retrieved_at[:10] for p in pages.values()})
print(f"{len(pages)} pages from {len({p.guide_title for p in pages.values()})} GOV.UK guides, fetched {', '.join(fetched)}")
