"""Fetch a fixed list of GOV.UK pages once, politely, from the GOV.UK Content API.

How the case study's snapshot was made (2026-10-09). You do not need to run it: the project
includes the snapshot. If you run it, you get today's pages, which may differ from the snapshot,
so the questions' relevant passages and the recorded answers may no longer match.

    python fetch_snapshot.py OUT_DIR [--paths paths.txt]

For each base path (one per line in paths.txt, for example /holiday-entitlement-rights),
it requests https://www.gov.uk/api/content<base_path> and writes the exact response
bytes to OUT_DIR/<name>.json, plus OUT_DIR/fetch_log.csv with the URL, HTTP status,
retrieval time (UTC) and the SHA-256 of the bytes.

Politeness: robots.txt of www.gov.uk (checked 2026-10-09) disallows only /*/print and
/search/all*; the API is allowed. One request per 1.2 seconds, a User-Agent that names
the course, no retries in a loop (a failed page is logged and skipped).

Downloads are untrusted data: OUT_DIR must be a new, empty folder, outside this one.
"""

import argparse
import csv
import hashlib
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

API = "https://www.gov.uk/api/content"
UA = "NextiaLearning-course-snapshot/1.0 (+https://learning.nextia-ai.com)"
PAUSE_S = 1.2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("out_dir", type=Path)
    parser.add_argument("--paths", type=Path, default=Path(__file__).with_name("paths.txt"))
    args = parser.parse_args()
    out = args.out_dir
    out.mkdir(parents=True, exist_ok=True)
    paths = [p.strip() for p in args.paths.read_text().splitlines() if p.strip() and not p.startswith("#")]
    rows = []
    for i, base_path in enumerate(paths):
        url = API + base_path
        request = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/json"})
        retrieved = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        try:
            with urllib.request.urlopen(request, timeout=30) as response:
                body, status = response.read(), response.status
        except urllib.error.HTTPError as error:
            body, status = b"", error.code
        name = base_path.strip("/").replace("/", "__") + ".json"
        if body:
            (out / name).write_bytes(body)
        rows.append({"base_path": base_path, "api_url": url, "status": status, "retrieved_at": retrieved,
                     "file": name if body else "", "sha256": hashlib.sha256(body).hexdigest() if body else "",
                     "bytes": len(body)})
        print(f"{i + 1}/{len(paths)} {status} {base_path}", file=sys.stderr)
        time.sleep(PAUSE_S)
    with open(out / "fetch_log.csv", "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


if __name__ == "__main__":
    main()
