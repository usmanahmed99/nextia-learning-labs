"""Turn the raw GOV.UK Content API responses into the case study's snapshot.

    python -I build_snapshot.py RAW_DIR OUT_DIR

RAW_DIR: the folder written by fetch_snapshot.py (one JSON per content item, fetch_log.csv).
OUT_DIR: a new folder (the project keeps its own in guidance/). It gets:
  pages.jsonl   one line per page (a part of a guide, or a whole answer page): its URL, titles,
                GOV.UK dates, the retrieval time, the SHA-256 of the API response it came from,
                and the body HTML exactly as the API gave it
  sources.csv   the same without the bodies (one row per page), for people
  SHA256SUMS    checksums of pages.jsonl and sources.csv

Only the base paths in paths.txt are kept, in that order. Nothing in the bodies is changed: the
licence (OGL v3.0) allows adaptation, but the project's parser does the cleaning, in the open.
"""

import csv
import hashlib
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
FIELDS = ["page_id", "url", "guide_title", "part_title", "format", "content_id", "first_published_at",
          "public_updated_at", "updated_at", "retrieved_at", "api_url", "api_sha256", "body_sha256"]


def main(raw: Path, out: Path) -> None:
    log = {r["base_path"]: r for r in csv.DictReader(open(raw / "fetch_log.csv"))}
    selected = [l.strip() for l in (HERE / "paths.txt").read_text().splitlines() if l.strip() and not l.startswith("#")]
    pages = []
    for base_path in selected:
        entry = log[base_path]
        data_bytes = (raw / entry["file"]).read_bytes()
        assert hashlib.sha256(data_bytes).hexdigest() == entry["sha256"], base_path
        item = json.loads(data_bytes)
        assert item["base_path"] == base_path and item["locale"] == "en" and item["phase"] == "live"
        assert not item.get("withdrawn_notice"), base_path
        details = item["details"]
        parts = details.get("parts") or [{"slug": "", "title": item["title"], "body": details.get("body", "")}]
        for i, part in enumerate(parts):
            # The first part of a guide is also served at the guide's own address.
            path = base_path if (i == 0 or not part["slug"]) else f"{base_path}/{part['slug']}"
            body = part["body"]
            pages.append({
                "page_id": path.strip("/"),
                "url": "https://www.gov.uk" + path,
                "guide_title": item["title"].strip(),
                "part_title": part["title"].strip(),
                "format": item["document_type"],
                "content_id": item["content_id"],
                "first_published_at": item.get("first_published_at", ""),
                "public_updated_at": item.get("public_updated_at", ""),
                "updated_at": item.get("updated_at", ""),
                "retrieved_at": entry["retrieved_at"],
                "api_url": entry["api_url"],
                "api_sha256": entry["sha256"],
                "body_sha256": hashlib.sha256(body.encode("utf-8")).hexdigest(),
                "body_html": body,
            })
    ids = [p["page_id"] for p in pages]
    assert len(ids) == len(set(ids)), "duplicate page IDs"
    out.mkdir(parents=True, exist_ok=True)
    with open(out / "pages.jsonl", "w", encoding="utf-8", newline="\n") as f:
        for p in pages:
            f.write(json.dumps(p, ensure_ascii=False, sort_keys=False) + "\n")
    with open(out / "sources.csv", "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS, lineterminator="\n")
        writer.writeheader()
        writer.writerows({k: p[k] for k in FIELDS} for p in pages)
    sums = [f"{hashlib.sha256((out / n).read_bytes()).hexdigest()}  {n}" for n in ("pages.jsonl", "sources.csv")]
    (out / "SHA256SUMS").write_text("\n".join(sums) + "\n")
    print(f"{len(pages)} pages from {len(selected)} GOV.UK content items -> {out}")
    print("\n".join(sums))


if __name__ == "__main__":
    main(Path(sys.argv[1]), Path(sys.argv[2]))
