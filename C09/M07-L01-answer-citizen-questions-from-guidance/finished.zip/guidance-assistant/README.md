# guidance-assistant

A cited question-answering assistant over a fixed snapshot of 137 GOV.UK pages about rights at work (England, Scotland and Wales), fetched on 2026-10-09. A volunteer adviser asks a question in plain words; the assistant finds the passages, answers in claims that each cite a passage, checks the citations in code, and shows every source with its address and dates. When the pages do not answer the question, it says so.

It is the project of the case study *Answer questions from public guidance* in the course *RAG: Building AI That Uses Your Data* (Nextia Learning). It reuses the patterns of the course's `policy-assistant`.

**What it is not.** It is not legal advice and not an official or government service. GOV.UK does not endorse it. Its answers describe the pages as they were on 2026-10-09; check the live page before you rely on one.

You need no account and no key. Search runs on your computer (SQLite full-text search, a small open embedding model and a small open reranker). Answers come from recorded model responses (the mock provider) unless you choose a live model.

## The pipeline

```text
guidance/pages.jsonl  ->  parse (blocks, section, anchor)  ->  chunk (stable IDs, URL#anchor, dates)
                      ->  index.sqlite (chunks, BM25, e5 vectors)
question  ->  BM25 + vectors  ->  fusion (RRF)  ->  rerank  ->  top 5  ->  context (budget, no near-duplicates)
          ->  model (claims + passage IDs)  ->  citation checks  ->  answer with numbered sources and dates
```

## Files

| Path | What it does |
|---|---|
| `guidance/` | The snapshot: `pages.jsonl`, `sources.csv`, `SHA256SUMS` (see `DATASET.md`) |
| `guidance_assistant/snapshot.py` | Loads the pages after checking their checksums |
| `guidance_assistant/parse.py` | GOV.UK body HTML into clean blocks with their section, anchor and position |
| `guidance_assistant/chunk.py` | Structure-aware chunks with stable IDs, the page address with `#anchor`, and the dates |
| `guidance_assistant/store.py` | The index file: chunks, FTS5 keyword index, vectors, how it was built |
| `guidance_assistant/lexical.py`, `dense.py`, `hybrid.py`, `rerank.py`, `embed.py`, `search.py` | BM25, vector search, RRF, the cross-encoder, the e5 model, one `Retriever` (from the course) |
| `guidance_assistant/context.py` | The token budget, near-duplicates, the passage header (page, section, fetch date, address) |
| `guidance_assistant/answer.py`, `prompts/` | The answer schema (claims with passage IDs), the request, the closed-book baseline |
| `guidance_assistant/cite.py` | Citation checks in code, and their limits |
| `guidance_assistant/sources.py` | The answer as a person sees it: numbered sources, addresses, dates, the notice |
| `guidance_assistant/assistant.py` | `ask()`: search, context, model, parse, checks |
| `guidance_assistant/evaluate.py` | hit@k, recall@k, precision@k, MRR; automatic answer checks; cost |
| `guidance_assistant/providers.py`, `config.py` | The adapter: the mock (recordings) or a live OpenAI-compatible provider |
| `questions/questions.jsonl` | 44 questions with reference answers, keys and relevant passages |
| `recordings/` | The recorded model responses that the mock replays |
| `scripts/` | `check_snapshot.py`; `fetch_snapshot.py` and `build_snapshot.py` (how the snapshot was made) |
| `tests/` | `pytest` tests |

## Set up

You need Python 3.12 or later and about 2 GB of disk space: about 0.9 GB for the Python packages (PyTorch is most of it) and about 1 GB for the two local models, which are downloaded once, on first use, into the Hugging Face cache (`~/.cache/huggingface`). If you did the course, they are already there.

macOS and Linux:

```sh
cd guidance-assistant
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

On Linux, install the CPU-only PyTorch first (`python -m pip install torch==2.14.1 --index-url https://download.pytorch.org/whl/cpu`).

Windows (PowerShell):

```powershell
cd guidance-assistant
py -3.12 -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

## Run

```sh
python -m pytest                                    # the tests (no model download needed)
python scripts/check_snapshot.py                    # the snapshot is the tested one
python -m guidance_assistant pages                  # the 38 guides and their dates
python -m guidance_assistant parse statutory-sick-pay/eligibility
python -m guidance_assistant ingest                 # index.sqlite: 504 chunks, e5 vectors
python -m guidance_assistant search "Can I carry over unused holiday?"
python -m guidance_assistant ask Q02                # a recorded answer, its checks and its sources
python -m guidance_assistant eval                   # retrieval measures on the 36 questions with passages
python -m guidance_assistant eval --answers         # and the recorded answers
```

### Recorded answers and live models

The mock replays real answers recorded on Azure: chat-small (gpt-6-luna) for the 44 questions with `--method rerank` and `--method bm25`, chat-strong (gpt-6.1-sol) for the 22 even-numbered questions with `--method rerank`, prompt `answer_v1`, top 5; and chat-small without passages (`ask --closed-book`). If your passages differ from the recorded ones, the mock still replays the answer of that question, prompt and model, prints `Note: Recorded with passages …; yours: …`, and checks the citations against **your** passages. Any other question needs a live model: copy `.env.example` to `.env` and choose Ollama (free, local) or your own key. Never commit `.env`.

## Licence

Code: MIT (see `LICENSE`). The GOV.UK text in `guidance/` and inside `recordings/` (the passages in the recorded requests) is Crown copyright under the Open Government Licence v3.0: Contains public sector information licensed under the Open Government Licence v3.0. The questions and the rest of the recordings: CC0.

## Tested

2026-10-09, Python 3.12.13, macOS (Apple silicon), in a new virtual environment. Windows and Linux are not tested.
