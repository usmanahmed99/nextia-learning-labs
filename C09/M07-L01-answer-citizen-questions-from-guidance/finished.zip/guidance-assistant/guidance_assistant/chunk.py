"""Structure-aware chunks with stable IDs, as in the course's policy assistant.

One chunk per section (from a heading to the next heading; the text before the first heading is a
section too). A section longer than MAX_WORDS is split between blocks, never inside a table.
Each chunk starts with the page title (and the section heading when a part does not start with it),
so a chunk keeps its context: "Exceptions" alone does not say which guide.

The chunk ID is the first 12 hexadecimal characters of SHA-256 over "page_id|updated_at|start|end":
the same text of the same page gives the same ID every time, a changed page (a new updated_at)
gives new IDs, and adding a page changes no other ID.
"""

import hashlib
from dataclasses import asdict, dataclass

from .parse import ParsedPage

MAX_WORDS = 200


def chunk_id(page_id: str, updated_at: str, start: int, end: int) -> str:
    return hashlib.sha256(f"{page_id}|{updated_at}|{start}|{end}".encode("utf-8")).hexdigest()[:12]


@dataclass(frozen=True)
class Chunk:
    chunk_id: str
    page_id: str
    title: str              # the page title: "Guide: Part"
    section: str            # the heading ("" = the top of the page)
    anchor: str             # the heading's id on GOV.UK
    position: int
    start: int
    end: int
    text: str               # what is indexed and shown to the model
    url: str                # the page, with #anchor when the section has one
    public_updated_at: str
    updated_at: str
    retrieved_at: str

    def to_dict(self) -> dict:
        return asdict(self)


def structure(parsed: ParsedPage, page, max_words: int = MAX_WORDS) -> list[Chunk]:
    sections: list[list] = []
    for b in parsed.blocks:
        if b.kind == "heading" or not sections:
            sections.append([])
        sections[-1].append(b)
    chunks: list[Chunk] = []
    for blocks in sections:
        part: list = []
        for b in blocks:
            words = sum(len(x.text.split()) for x in part)
            if part and words + len(b.text.split()) > max_words:
                chunks.append(_make(parsed, page, part, len(chunks)))
                part = []
            part.append(b)
        if part:
            chunks.append(_make(parsed, page, part, len(chunks)))
    return chunks


def _make(parsed: ParsedPage, page, blocks: list, position: int) -> Chunk:
    start, end = blocks[0].start, blocks[-1].end
    section, anchor = blocks[0].section, blocks[0].anchor
    prefix = page.title if blocks[0].kind == "heading" or not section else f"{page.title}\n{section}"
    return Chunk(
        chunk_id=chunk_id(page.page_id, page.updated_at, start, end), page_id=page.page_id, title=page.title,
        section=section, anchor=anchor, position=position, start=start, end=end,
        text=f"{prefix}\n{parsed.text[start:end]}", url=page.url + (f"#{anchor}" if anchor else ""),
        public_updated_at=page.public_updated_at[:10], updated_at=page.updated_at[:10],
        retrieved_at=page.retrieved_at[:10])
