"""The command line of the guidance assistant.

    python -m guidance_assistant pages                      the snapshot: pages, guides, dates, checksums
    python -m guidance_assistant questions [--kind KIND]    the 44 questions
    python -m guidance_assistant parse PAGE_ID              the clean blocks of one page, with positions
    python -m guidance_assistant ingest [--embedder none]   build index.sqlite (chunks, BM25, e5 vectors)
    python -m guidance_assistant chunks PAGE_ID             the chunks of one page and their addresses
    python -m guidance_assistant search "QUESTION" [--method rerank] [--k 5]
    python -m guidance_assistant ask Q01 | "QUESTION" [--model chat-small] [--method rerank] [--prompt answer_v1] [--closed-book]
    python -m guidance_assistant eval [--method rerank] [--k 5] [--answers --model chat-small] [--ids Q01,Q02]
"""

import argparse
import statistics
from collections import Counter
from pathlib import Path

from .snapshot import PROJECT, load_pages

INDEX = PROJECT / "index.sqlite"


def short(text: str, n: int = 90) -> str:
    text = " ".join(text.split())
    return text if len(text) <= n else text[: n - 1] + "…"


def cmd_pages(args) -> None:
    pages = load_pages()
    guides = Counter(p.guide_title for p in pages.values())
    fetched = sorted({p.retrieved_at[:10] for p in pages.values()})
    for title, n in guides.items():
        first = next(p for p in pages.values() if p.guide_title == title)
        print(f"{n:2} {'page ' if n == 1 else 'pages'}  {first.updated_at[:10]}  {title}")
    print(f"{len(pages)} pages from {len(guides)} GOV.UK guides | fetched {', '.join(fetched)} | checksums OK")


def cmd_questions(args) -> None:
    from .evaluate import load_questions

    qs = [q for q in load_questions().values() if not args.kind or q.kind == args.kind]
    for q in qs:
        print(f"{q.id} {q.kind:12} {short(q.question, 95)}")
    print(f"{len(qs)} questions")


def cmd_parse(args) -> None:
    from .parse import parse_page

    page = load_pages()[args.page_id]
    parsed = parse_page(page)
    print(f"{page.title} | {page.url}")
    for b in parsed.blocks:
        print(f"[{b.start:>5}-{b.end:<5}] {b.kind:9} {short(b.section, 26):26} | {short(b.text, 60)}")
    for text in parsed.dropped:
        print(f"dropped: {short(text, 80)}")
    print(f"{len(parsed.blocks)} blocks, {len(parsed.text)} characters")


def open_store(args):
    from .store import Store

    path = Path(args.index)
    if not path.exists():
        raise SystemExit(f"No index at {path}. Run: python -m guidance_assistant ingest")
    return Store(path)


def cmd_ingest(args) -> None:
    import time

    from .store import Store

    path = Path(args.index)
    if path.exists():
        path.unlink()
    embedder = None
    if args.embedder != "none":
        from .embed import LocalEmbedder

        embedder = LocalEmbedder()
    start = time.monotonic()
    pages = load_pages()
    n = Store(path).build(pages, embedder)
    print(f"index {path.name}: {n} chunks from {len(pages)} pages | embeddings {embedder.name if embedder else 'none'} | "
          f"{time.monotonic() - start:.1f} s")


def cmd_chunks(args) -> None:
    store = open_store(args)
    chunks = [c for c in store.chunks() if c.page_id == args.page_id]
    if not chunks:
        raise SystemExit(f"No chunks for {args.page_id}. Page IDs: python -m guidance_assistant pages")
    for c in chunks:
        print(f"{c.chunk_id} #{c.position} chars {c.start}-{c.end} | {len(c.text.split()):3} words | {c.url}")
    print(f"{len(chunks)} chunks")


def make_retriever(args, store):
    from .search import Retriever

    embedder = reranker = None
    if args.method in ("dense", "hybrid", "rerank"):
        from .embed import LocalEmbedder

        embedder = LocalEmbedder()
    if args.method == "rerank":
        from .rerank import Reranker

        reranker = Reranker()
    return Retriever(store, embedder, reranker)


def cmd_search(args) -> None:
    store = open_store(args)
    for r in make_retriever(args, store).search(args.query, args.method, args.k):
        c = r.chunk
        print(f"{r.rank}. {r.score:>8.4f}  [{c.chunk_id}] {short(c.title, 45)} | {short(c.section or '(top)', 30)}")
    print(f"{args.method}, top {args.k}")


def make_provider():
    from .config import Settings, make_provider as make

    return make(Settings.from_env())


def cmd_ask(args) -> None:
    from .assistant import ask
    from .config import Settings
    from .evaluate import load_questions
    from .sources import render

    qs = load_questions()
    question = qs[args.question].question if args.question in qs else args.question
    model = args.model or Settings.from_env().model
    if args.closed_book:
        from .answer import build_closed_book_request

        c = make_provider().complete(build_closed_book_request(question, model))
        print(f"Question: {question}\nThe model alone, without the guidance:\n{c.text}")
        print(f"\n{c.model} | {c.input_tokens} tokens in, {c.output_tokens} out | {c.latency_s} s")
        return
    store = open_store(args)
    result = ask(question, make_retriever(args, store), make_provider(), model, args.method, args.k, args.prompt)
    print(f"Question: {question}")
    print(f"Passages: {', '.join(result.context.ids) or 'none'} ({result.context.tokens} tokens, estimated)")
    for cid, reason in result.context.dropped:
        print(f"  dropped {cid}: {reason}")
    if result.completion is not None and result.completion.note:
        print(f"Note: {result.completion.note}")
    if result.problem:
        print(f"No answer: {result.problem}")
        return
    print()
    print(render(result.answer, result.checks, store))
    c = result.completion
    print(f"\n{c.model} | {c.input_tokens} tokens in, {c.output_tokens} out | {c.latency_s} s")


def cmd_eval(args) -> None:
    from .evaluate import answer_scores, cost, load_questions, percentile, retrieval_scores, summarise

    store = open_store(args)
    retriever = make_retriever(args, store)
    qs = list(load_questions().values())
    if args.ids:
        wanted = set(args.ids.split(","))
        qs = [q for q in qs if q.id in wanted]
    if not args.answers:
        rows = [retrieval_scores(q, [r.chunk for r in retriever.search(q.question, args.method, args.k)], args.k)
                for q in qs]
        s = summarise(rows)
        print(f"{args.method}, top {args.k}: hit@{args.k} {s['hit']:.3f} | recall@{args.k} {s['recall']:.3f} | "
              f"precision@{args.k} {s['precision']:.3f} | MRR {s['mrr']:.3f} ({s['questions']} questions with relevant passages)")
        return
    from .assistant import ask

    provider = make_provider()
    scores, completions, flagged, claims, replayed = [], [], 0, 0, []
    for q in qs:
        res = ask(q.question, retriever, provider, args.model, args.method, args.k, args.prompt)
        scores.append(answer_scores(q, res.answer))
        if res.completion is not None:
            completions.append(res.completion)
            if res.completion.note:
                replayed.append(q.id)
        claims += len(res.checks)
        flagged += sum(1 for c in res.checks if not c.ok)
    answerable = [s for s in scores if not load_questions()[s["id"]].abstain]
    uncovered = [s for s in scores if load_questions()[s["id"]].abstain]
    print(f"{args.model}, {args.method}, top {args.k}, {args.prompt}: {len(scores)} questions")
    print(f"  answerable, correct:          {sum(s['correct'] for s in answerable)}/{len(answerable)}")
    print(f"  answerable, abstained:        {sum(s['abstained'] for s in answerable)}/{len(answerable)}")
    print(f"  not covered, abstained:       {sum(s['correct'] for s in uncovered)}/{len(uncovered)}")
    print(f"  shown but wrong:              {sum(s['shown_wrong'] for s in scores)}  "
          f"({', '.join(s['id'] for s in scores if s['shown_wrong']) or 'none'})")
    print(f"  claims flagged by the checks: {flagged} of {claims}")
    if completions:
        tin = [c.input_tokens for c in completions]
        tout = [c.output_tokens for c in completions]
        lat = [c.latency_s for c in completions]
        each = statistics.median(cost(args.model, i, o) for i, o in zip(tin, tout))
        print(f"  tokens in / out (median):     {statistics.median(tin):.0f} / {statistics.median(tout):.0f}")
        print(f"  latency median / p95:         {statistics.median(lat):.2f} / {percentile(lat, 95):.2f} s (recorded)")
        print(f"  cost per question (median):   US${each:.5f}")
    if replayed:
        print(f"  replayed with other passages: {', '.join(replayed)} (these answer measures describe the recorded search)")


def main(argv=None) -> None:
    parser = argparse.ArgumentParser(prog="python -m guidance_assistant", description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--index", default=str(INDEX), help="the index file (default: index.sqlite)")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("pages").set_defaults(func=cmd_pages)
    p = sub.add_parser("questions")
    p.add_argument("--kind")
    p.set_defaults(func=cmd_questions)
    p = sub.add_parser("parse")
    p.add_argument("page_id")
    p.set_defaults(func=cmd_parse)
    p = sub.add_parser("ingest")
    p.add_argument("--embedder", default="e5", choices=["e5", "none"])
    p.set_defaults(func=cmd_ingest)
    p = sub.add_parser("chunks")
    p.add_argument("page_id")
    p.set_defaults(func=cmd_chunks)
    for name, func in (("search", cmd_search), ("ask", cmd_ask), ("eval", cmd_eval)):
        p = sub.add_parser(name)
        if name == "search":
            p.add_argument("query")
        if name == "ask":
            p.add_argument("question", help="a question ID (Q01) or a question in quotes")
        p.add_argument("--method", default="rerank", choices=["bm25", "dense", "hybrid", "rerank"])
        p.add_argument("--k", type=int, default=5)
        if name in ("ask", "eval"):
            p.add_argument("--model", default=None if name == "ask" else "chat-small")
            p.add_argument("--prompt", default="answer_v1")
        if name == "ask":
            p.add_argument("--closed-book", action="store_true", help="the model alone, without the pages")
        if name == "eval":
            p.add_argument("--answers", action="store_true", help="also ask the model (recorded answers by default)")
            p.add_argument("--ids", help="only these question IDs, for example Q01,Q02")
        p.set_defaults(func=func)
    args = parser.parse_args(argv)
    args.func(args)


if __name__ == "__main__":
    main()
