"""Parse a GOV.UK page body (HTML) into clean blocks that remember where they came from.

A block is a heading, a paragraph, a list item, a table or a notice. Each block keeps:
- section: the heading it is under ("" before the first heading),
- anchor:  that heading's id, so a citation can link to https://www.gov.uk/<page>#<anchor>,
- start, end: its character positions in the page's clean text.

What the parser removes, and why:
- tags (links keep their words, abbreviations their short form: "SSP");
- the line "This guide (or page) is also available in Welsh (Cymraeg)": it repeats on many
  pages, says nothing about the question, and makes those pages look alike to a search.
Tables become one block with one line per row ("cell | cell | cell"): a table is never split.
"""

import html
import re
from dataclasses import dataclass, field
from html.parser import HTMLParser

DROP = re.compile(r"^This (guide|page) is also available in Welsh", re.I)
BLOCK_TAGS = {"p": "paragraph", "li": "item", "h2": "heading", "h3": "heading", "h4": "heading"}


@dataclass(frozen=True)
class Block:
    kind: str        # heading, paragraph, item, table, notice
    text: str
    section: str
    anchor: str
    start: int = 0
    end: int = 0


@dataclass
class ParsedPage:
    page_id: str
    title: str
    blocks: list = field(default_factory=list)
    text: str = ""
    dropped: list = field(default_factory=list)   # texts removed as boilerplate


def clean(text: str) -> str:
    return re.sub(r"\s+", " ", html.unescape(text)).strip()


class _Reader(HTMLParser):
    """Collects (kind, text, heading id) in reading order."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.out: list[tuple[str, str, str]] = []
        self.buffer: list[str] | None = None
        self.kind = ""
        self.heading_id = ""
        self.notice_depth = 0          # inside <div role="note"> (info and help notices)
        self.table: list[list[str]] | None = None
        self.cell: list[str] | None = None

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == "div" and a.get("role") == "note":
            self.notice_depth += 1
        if tag == "table":
            self.table = []
        elif self.table is not None:
            if tag == "tr":
                self.table.append([])
            elif tag in ("td", "th"):
                self.cell = []
            return
        if tag in BLOCK_TAGS and self.buffer is None:
            self.buffer, self.kind = [], BLOCK_TAGS[tag]
            if self.kind == "heading":
                self.heading_id = a.get("id", "")
        elif tag == "li" and self.buffer is not None:
            self.buffer.append(" ")    # a nested list item continues its parent item
        if tag == "br" and self.buffer is not None:
            self.buffer.append(" ")

    def handle_endtag(self, tag):
        if self.table is not None:
            if tag in ("td", "th") and self.cell is not None:
                self.table[-1].append(clean("".join(self.cell)))
                self.cell = None
            elif tag == "table":
                rows = [" | ".join(r) for r in self.table if any(r)]
                self.out.append(("table", "\n".join(rows), ""))
                self.table = None
            return
        if tag in BLOCK_TAGS and self.buffer is not None and BLOCK_TAGS[tag] == self.kind:
            text = clean("".join(self.buffer))
            if text:
                kind = "notice" if self.notice_depth and self.kind == "paragraph" else self.kind
                self.out.append((kind, text, self.heading_id if kind == "heading" else ""))
            self.buffer = None
        if tag == "div" and self.notice_depth:
            self.notice_depth -= 1

    def handle_data(self, data):
        if self.cell is not None:
            self.cell.append(data)
        elif self.buffer is not None:
            self.buffer.append(data)


def parse_page(page) -> ParsedPage:
    """page: a snapshot.Page. Returns its blocks and clean text, with positions."""
    reader = _Reader()
    reader.feed(page.body_html)
    reader.close()
    out = ParsedPage(page.page_id, page.title)
    section, anchor, parts, pos = "", "", [], 0
    for kind, text, heading_id in reader.out:
        if DROP.search(text):
            out.dropped.append(text)
            continue
        if kind == "heading":
            section, anchor = text, heading_id
        shown = f"- {text}" if kind == "item" else text
        start = pos
        parts.append(shown)
        pos += len(shown)
        out.blocks.append(Block(kind, shown, section, anchor, start, pos))
        parts.append("\n")
        pos += 1
    out.text = "".join(parts)
    return out
