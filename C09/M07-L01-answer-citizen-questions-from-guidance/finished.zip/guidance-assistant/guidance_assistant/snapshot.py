"""The snapshot: 137 GOV.UK pages about rights at work, fetched once on 2026-10-09.

guidance/pages.jsonl has one line per page (a part of a guide, or a whole answer page), with its URL,
titles, GOV.UK dates, the time it was fetched, and its body HTML as the GOV.UK Content API gave it.
`load_pages()` first compares the files with guidance/SHA256SUMS: a changed or cut file stops
the program, so every result in the case study comes from the same pages.

GOV.UK content is Crown copyright, published under the Open Government Licence v3.0. See DATASET.md.
"""

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path

PROJECT = Path(__file__).resolve().parent.parent
GUIDANCE = PROJECT / "guidance"
ATTRIBUTION = "Contains public sector information licensed under the Open Government Licence v3.0."


class SnapshotChanged(Exception):
    """A snapshot file does not match its checksum."""


@dataclass(frozen=True)
class Page:
    page_id: str            # the GOV.UK path without the first slash, e.g. statutory-sick-pay/eligibility
    url: str
    guide_title: str        # e.g. Statutory Sick Pay (SSP)
    part_title: str         # e.g. Eligibility (the guide title again for a one-page answer)
    format: str             # guide or answer
    public_updated_at: str  # GOV.UK's date of the last major change
    updated_at: str         # GOV.UK's date of the last change of any size
    retrieved_at: str       # when we fetched it (UTC)
    body_html: str

    @property
    def title(self) -> str:
        if self.part_title == self.guide_title:
            return self.guide_title
        return f"{self.guide_title}: {self.part_title}"


def check_files(folder: Path = GUIDANCE) -> None:
    for line in (folder / "SHA256SUMS").read_text().splitlines():
        expected, name = line.split()
        actual = hashlib.sha256((folder / name).read_bytes()).hexdigest()
        if actual != expected:
            raise SnapshotChanged(f"{name} has SHA-256 {actual[:12]}…, expected {expected[:12]}…. "
                                  "Unzip the project again, or run: python scripts/check_snapshot.py")


def load_pages(folder: Path = GUIDANCE, check: bool = True) -> dict[str, Page]:
    if check:
        check_files(folder)
    pages = {}
    for line in (folder / "pages.jsonl").read_text(encoding="utf-8").splitlines():
        d = json.loads(line)
        pages[d["page_id"]] = Page(d["page_id"], d["url"], d["guide_title"], d["part_title"], d["format"],
                                   d["public_updated_at"], d["updated_at"], d["retrieved_at"], d["body_html"])
    return pages
