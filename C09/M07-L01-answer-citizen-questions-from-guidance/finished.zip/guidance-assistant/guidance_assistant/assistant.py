"""The whole pipeline: search -> context -> model -> parse -> citation check."""

from dataclasses import dataclass, field

from .answer import Answer, AnswerProblem, build_request, parse_answer
from .cite import check_answer
from .context import BUDGET, Context, assemble
from .providers import ProviderError

K = 5


@dataclass
class AskResult:
    question: str
    context: Context
    request: dict
    answer: Answer | None = None
    problem: str = ""
    checks: list = field(default_factory=list)
    completion: object = None


def ask(question: str, retriever, provider, model: str = "chat-small", method: str = "rerank", k: int = K,
        prompt: str = "answer_v1", budget: int = BUDGET) -> AskResult:
    results = retriever.search(question, method=method, k=k)
    context = assemble([r.chunk for r in results], budget)
    request = build_request(question, context, model, prompt)
    out = AskResult(question, context, request)
    try:
        out.completion = provider.complete(request)
        out.answer = parse_answer(out.completion)
    except (ProviderError, AnswerProblem) as e:
        out.problem = str(e)
        return out
    out.checks = check_answer(out.answer, retriever.store, context.ids, question)
    return out
