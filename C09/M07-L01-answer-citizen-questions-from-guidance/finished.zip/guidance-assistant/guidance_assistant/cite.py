"""Check the citations of an answer in code, as in the course's policy assistant.

For every claim:
1. exists:      every cited ID is a chunk in the index (fails: a made-up ID);
2. in_context:  every cited ID was in the passages given to the model;
3. cited:       the claim cites at least one ID;
4. numbers:     every number in the claim (28, 194.32, 6 April 2025) appears in a cited passage
                (with its header) or in the question (fails: "£25,000" cited to a passage about 4 weeks' pay);
5. words:       at least half of the claim's content words appear in the cited passages.
Checks 4 and 5 are clues, not proof: a calculation ("22.4 days") is flagged although it may be
right, and a claim can share every word with a passage and still say the opposite.
"""

import re
from dataclasses import dataclass, field

from .context import format_passage

STOP = set("""a an and are as at be by can cannot do does for from has have if in into is it its may must no not of on
or our that the their them then there these they this to under up was we were what when where which who will with
within without you your""".split())
NUMBER = re.compile(r"\d+(?:[.,]\d+)?")


def numbers(text: str) -> set[str]:
    """'£22,530' -> 22530; '£194.32' -> 194.32; '09' -> 9."""
    text = re.sub(r"(\d),(\d{3})\b", r"\1\2", text)
    found = {n.replace(",", ".") for n in NUMBER.findall(text)}
    return {(n.lstrip("0") or "0") if n.isdigit() else n for n in found}


def content_words(text: str) -> set[str]:
    words = {w for w in re.findall(r"[a-z]+", text.lower()) if w not in STOP and len(w) > 2}
    return {w[:-1] if len(w) > 3 and w.endswith("s") else w for w in words}


@dataclass
class ClaimCheck:
    text: str
    chunk_ids: tuple
    problems: list = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.problems


def check_claim(claim, store, context_ids: list[str], question: str = "") -> ClaimCheck:
    result = ClaimCheck(claim.text, tuple(claim.chunk_ids))
    if not claim.chunk_ids:
        result.problems.append("no_citation")
        return result
    passages = []
    for cid in claim.chunk_ids:
        chunk = store.chunk(cid)
        if chunk is None:
            result.problems.append(f"missing_id:{cid}")
            continue
        if cid not in context_ids:
            result.problems.append(f"not_in_context:{cid}")
        passages.append(chunk)
    if not passages:
        return result
    source = " ".join(format_passage(p) for p in passages)
    missing = sorted(numbers(claim.text) - numbers(source) - numbers(question))
    if missing:
        result.problems.append("number_not_found:" + ",".join(missing))
    words = content_words(claim.text)
    if words:
        share = len(words & content_words(source)) / len(words)
        if share < 0.5:
            result.problems.append(f"unsupported:{share:.2f}")
    return result


def check_answer(answer, store, context_ids: list[str], question: str = "") -> list[ClaimCheck]:
    return [check_claim(c, store, context_ids, question) for c in answer.claims]
