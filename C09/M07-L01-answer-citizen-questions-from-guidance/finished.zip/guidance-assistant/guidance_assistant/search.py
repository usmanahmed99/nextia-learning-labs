"""One entry point for every search method, as in the course's policy assistant.

    bm25    keyword search (lexical.py)
    dense   vector search (dense.py) with the embedding model that built the index
    hybrid  bm25 + dense, combined with reciprocal rank fusion (hybrid.py)
    rerank  hybrid's top CANDIDATES, reread by the cross-encoder (rerank.py)

There are no date or access filters here: every page is public, and the snapshot has one
version of each page. (The course's policy assistant shows both filters.)
"""

from dataclasses import dataclass

from .chunk import Chunk
from .dense import search as dense_search
from .hybrid import rrf
from .lexical import Hit
from .store import IndexMismatch, Store

METHODS = ("bm25", "dense", "hybrid", "rerank")
CANDIDATES = 20


@dataclass(frozen=True)
class Result:
    chunk: Chunk
    score: float
    rank: int


class Retriever:
    def __init__(self, store: Store, embedder=None, reranker=None):
        self.store, self.embedder, self.reranker = store, embedder, reranker
        self._chunks = {c.chunk_id: c for c in store.chunks()}

    def _check_model(self) -> None:
        if self.embedder is None:
            raise ValueError("Dense search needs an embedding model.")
        meta = self.store.meta()
        if (meta.get("embedding_model"), meta.get("embedding_revision")) != (self.embedder.name, self.embedder.revision):
            raise IndexMismatch(f"The index was built with {meta.get('embedding_model') or 'no embedding model'}, "
                                f"and the question would be embedded with {self.embedder.name}. "
                                "Run: python -m guidance_assistant ingest")

    def bm25(self, query: str, k: int) -> list[Hit]:
        return self.store.keywords.search(query, k)

    def dense(self, query: str, k: int) -> list[Hit]:
        self._check_model()
        ids, matrix = self.store.vectors()
        return dense_search(self.embedder.embed_queries([query])[0], matrix, ids, k)

    def hybrid(self, query: str, k: int) -> list[Hit]:
        return rrf([self.bm25(query, CANDIDATES), self.dense(query, CANDIDATES)], k)

    def rerank(self, query: str, k: int) -> list[Hit]:
        if self.reranker is None:
            raise ValueError("Reranking needs a cross-encoder (rerank.Reranker).")
        candidates = [self._chunks[h.id] for h in self.hybrid(query, CANDIDATES)]
        return self.reranker.rerank(query, candidates, k)

    def search(self, query: str, method: str = "rerank", k: int = 5) -> list[Result]:
        if method not in METHODS:
            raise ValueError(f"Unknown method {method!r}: use one of {', '.join(METHODS)}.")
        return [Result(self._chunks[h.id], h.score, h.rank) for h in getattr(self, method)(query, k)]
