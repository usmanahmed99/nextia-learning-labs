"""Show an answer the way a person should see it: every claim numbered, every source with its address
and its dates, and what the assistant is not.

The application writes the sources and the notice, not the model: the model gives only claims and
passage IDs, and this code looks up each ID in the index. So a source line is always a real page,
with the date we fetched it, even when the model is wrong.
"""

from .snapshot import ATTRIBUTION

NOTICE = ("This is what GOV.UK guidance says, not legal advice. This assistant is not a government service. "
          "Pages fetched on {fetched}: check the page for changes.")


def sources_for(answer, store) -> list:
    """The cited chunks, in the order of first citation, without repeats."""
    chunks = [store.chunk(cid) for cid in answer.cited()]
    return [c for c in chunks if c is not None]


def render(answer, checks: list, store) -> str:
    if not answer.answerable:
        lines = [f"Answer: {answer.answer}", "", "The pages in the snapshot do not answer this question.",
                 "Ask the Acas helpline or an adviser."]
        return "\n".join(lines + ["", NOTICE.format(fetched=_fetched(store)), ATTRIBUTION])
    sources = sources_for(answer, store)
    number = {c.chunk_id: i for i, c in enumerate(sources, 1)}
    lines = [f"Answer: {answer.answer}", ""]
    for claim, check in zip(answer.claims, checks):
        refs = "".join(f"[{number[i]}]" for i in claim.chunk_ids if i in number) or "[no source]"
        status = "" if check.ok else "  (check: " + "; ".join(check.problems) + ")"
        lines.append(f"- {claim.text} {refs}{status}")
    lines += ["", "Sources:"]
    for i, c in enumerate(sources, 1):
        section = f', section "{c.section}"' if c.section else ""
        lines.append(f"[{i}] {c.title}{section}")
        lines.append(f"    {c.url}")
        lines.append(f"    fetched {c.retrieved_at}; GOV.UK last updated {c.updated_at}")
    return "\n".join(lines + ["", NOTICE.format(fetched=_fetched(store)), ATTRIBUTION])


def _fetched(store) -> str:
    dates = sorted({c.retrieved_at for c in store.chunks()})
    return dates[-1] if dates else "?"
