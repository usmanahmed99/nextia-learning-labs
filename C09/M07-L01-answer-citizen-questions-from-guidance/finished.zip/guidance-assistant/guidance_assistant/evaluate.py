"""Measure retrieval and answers on the 44 questions (questions/questions.jsonl).

A retrieved chunk is relevant when it comes from a relevant passage of the question: the same
page and the same section. Retrieval measures (the 36 questions that have relevant passages):
- hit@k:       1 if at least one of the top k chunks is relevant;
- recall@k:    the share of the relevant passages that the top k chunks cover;
- precision@k: the share of the top k chunks that are relevant;
- MRR:         1 / the rank of the first relevant chunk in the top k (0 if none).

Answer measures (automatic, a net with holes; read the misses):
- correct:   answerable questions: answered, every key matches, no must_not matches;
             not_covered questions: abstained, and no must_not matches;
- abstained: the answer says the guidance does not answer;
- shown but wrong: answered (not abstained) and not correct. This is the number to keep low:
             an adviser would read it as an answer.
"""

import json
import re
import statistics
from dataclasses import dataclass
from pathlib import Path

PROJECT = Path(__file__).resolve().parent.parent
QUESTIONS = PROJECT / "questions" / "questions.jsonl"
PRICES = {"chat-small": (0.10, 0.50), "chat-strong": (2.00, 10.00)}   # US$ per million tokens in, out


@dataclass(frozen=True)
class Question:
    id: str
    question: str
    kind: str
    abstain: bool
    reference_answer: str
    keys: list
    must_not: list
    relevant: list            # [{"page_id", "section"}]
    relevant_chunks: list
    notes: str


def load_questions(path: Path = QUESTIONS) -> dict[str, Question]:
    qs = [Question(**json.loads(line)) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    return {q.id: q for q in qs}


def covers(chunk, passage: dict) -> bool:
    return chunk.page_id == passage["page_id"] and chunk.section == passage["section"]


def retrieval_scores(q: Question, ranked: list, k: int) -> dict:
    if not q.relevant:
        return {"id": q.id, "kind": q.kind, "scored": False}
    top = ranked[:k]
    rel = [any(covers(c, p) for p in q.relevant) for c in top]
    found = [p for p in q.relevant if any(covers(c, p) for c in top)]
    first = next((i for i, r in enumerate(rel) if r), None)
    return {"id": q.id, "kind": q.kind, "scored": True, "hit": float(any(rel)), "recall": len(found) / len(q.relevant),
            "precision": sum(rel) / k, "rr": 0.0 if first is None else 1.0 / (first + 1)}


def summarise(rows: list[dict]) -> dict:
    scored = [r for r in rows if r["scored"]]
    if not scored:
        return {"questions": 0}
    mean = lambda name: round(statistics.fmean(r[name] for r in scored), 3)  # noqa: E731
    return {"questions": len(scored), "hit": mean("hit"), "recall": mean("recall"),
            "precision": mean("precision"), "mrr": mean("rr")}


ABSTAIN = re.compile(r"(guidance|passages?|pages?|sources?)\s+(do(es)?\s+not|don't|doesn't)\s+(say|answer|cover|"
                     r"mention|state|include|give|specify)|no information", re.I)


def answer_scores(q: Question, answer) -> dict:
    if answer is None:
        return {"id": q.id, "kind": q.kind, "valid": False, "correct": False, "abstained": False, "shown_wrong": False}
    text = answer.text()
    abstained = not answer.answerable
    violated = [m for m in q.must_not if re.search(m, text, re.I)]
    if q.abstain:
        correct = abstained and not violated
    else:
        correct = not abstained and all(re.search(k, text, re.I) for k in q.keys) and not violated
    return {"id": q.id, "kind": q.kind, "valid": True, "correct": correct, "abstained": abstained,
            "shown_wrong": not abstained and not correct, "must_not_hit": violated}


def cost(model: str, tokens_in: int, tokens_out: int) -> float:
    price_in, price_out = PRICES.get(model, (0.0, 0.0))
    return (tokens_in * price_in + tokens_out * price_out) / 1_000_000


def percentile(values: list[float], p: float) -> float:
    values = sorted(values)
    if not values:
        return 0.0
    i = min(len(values) - 1, max(0, round(p / 100 * (len(values) - 1))))
    return values[i]
