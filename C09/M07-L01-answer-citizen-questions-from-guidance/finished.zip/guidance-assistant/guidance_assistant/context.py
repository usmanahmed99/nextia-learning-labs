"""Assemble the context: the passages that go into the prompt, within a token budget.

As in the course's policy assistant: keep the search order, drop near-duplicates from two
different pages (Jaccard similarity of their word sets >= 0.9, title line left out; GOV.UK repeats
some paragraphs, for example the Acas helpline), and stop before the budget is used up (tokens
estimated as characters / 4).

Each passage starts with a header the model can see: its ID, the page, the section, where it
comes from and when we fetched it, and its address. The answer cites the IDs.
"""

import math
import re
from dataclasses import dataclass, field

BUDGET = 1500
SIMILAR = 0.9


def estimate_tokens(text: str) -> int:
    return math.ceil(len(text) / 4)


def word_set(text: str) -> set[str]:
    body = text.split("\n", 1)[1] if "\n" in text else text
    return set(re.findall(r"\w+", body.lower()))


def jaccard(a: str, b: str) -> float:
    wa, wb = word_set(a), word_set(b)
    return len(wa & wb) / len(wa | wb) if wa | wb else 1.0


def format_passage(chunk) -> str:
    return (f"[{chunk.chunk_id}] {chunk.title} | section: {chunk.section or '-'} | "
            f"GOV.UK, fetched {chunk.retrieved_at} | {chunk.url}\n{chunk.text}")


@dataclass
class Context:
    chunks: list = field(default_factory=list)
    dropped: list = field(default_factory=list)     # (chunk_id, reason)
    tokens: int = 0

    @property
    def ids(self) -> list[str]:
        return [c.chunk_id for c in self.chunks]

    def text(self) -> str:
        return "\n\n".join(format_passage(c) for c in self.chunks)


def assemble(chunks: list, budget: int = BUDGET) -> Context:
    ctx = Context()
    for chunk in chunks:
        twin = next((c for c in ctx.chunks if c.page_id != chunk.page_id and jaccard(c.text, chunk.text) >= SIMILAR), None)
        if twin is not None:
            ctx.dropped.append((chunk.chunk_id, f"near-duplicate of {twin.chunk_id}"))
            continue
        cost = estimate_tokens(format_passage(chunk))
        if ctx.tokens + cost > budget:
            ctx.dropped.append((chunk.chunk_id, "over budget"))
            continue
        ctx.chunks.append(chunk)
        ctx.tokens += cost
    return ctx
