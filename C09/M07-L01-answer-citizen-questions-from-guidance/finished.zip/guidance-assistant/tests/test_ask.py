import pytest

from guidance_assistant.assistant import ask
from guidance_assistant.evaluate import load_questions
from guidance_assistant.providers import MockProvider

QS = load_questions()


@pytest.fixture(scope="module")
def retriever(store):
    from guidance_assistant.search import Retriever

    return Retriever(store)


def test_a_recorded_answer_replays_silently(retriever):
    result = ask(QS["Q01"].question, retriever, MockProvider(), "chat-small", "bm25")
    assert result.completion.note == ""
    assert "28" in result.answer.answer
    assert all(c.ok for c in result.checks)


def test_other_passages_replay_with_a_note(retriever):
    result = ask(QS["Q01"].question, retriever, MockProvider(), "chat-small", "bm25", k=3)
    assert result.completion.note.startswith("Recorded with passages")


def test_an_unrecorded_question_says_so(retriever):
    result = ask("Can I bring my dog to work?", retriever, MockProvider(), "chat-small", "bm25")
    assert result.answer is None and result.problem.startswith("No recording for this request")
