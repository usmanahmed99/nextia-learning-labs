import os
import sys
from pathlib import Path

import pytest

PROJECT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT))


@pytest.fixture(autouse=True)
def mock_provider(monkeypatch):
    """Tests never call a real provider and never read a key, whatever .env says."""
    monkeypatch.setenv("ASSISTANT_PROVIDER", "mock")
    monkeypatch.delenv("ASSISTANT_API_KEY", raising=False)


@pytest.fixture(scope="session")
def store(tmp_path_factory):
    """An index of the whole snapshot with BM25 only (no embedding model needed, about 1 second)."""
    pytest.importorskip("guidance_assistant.parse", reason="write guidance_assistant/parse.py first")
    pytest.importorskip("guidance_assistant.chunk", reason="write guidance_assistant/chunk.py first")
    from guidance_assistant.snapshot import load_pages
    from guidance_assistant.store import Store

    s = Store(tmp_path_factory.mktemp("index") / "index.sqlite")
    s.build(load_pages())
    return s
