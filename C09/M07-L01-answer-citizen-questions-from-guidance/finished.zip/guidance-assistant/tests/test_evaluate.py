from dataclasses import dataclass

from guidance_assistant.answer import Answer, Claim
from guidance_assistant.evaluate import Question, answer_scores, retrieval_scores


@dataclass
class C:
    page_id: str
    section: str


Q = Question("Q99", "?", "fact", False, "28 days", [r"\b28\b"], [], [{"page_id": "a", "section": "x"},
                                                                       {"page_id": "b", "section": ""}], [], "")


def test_retrieval_scores_worked_example():
    ranked = [C("c", "x"), C("a", "x"), C("d", ""), C("e", ""), C("f", "")]
    s = retrieval_scores(Q, ranked, 5)
    assert (s["hit"], s["recall"], s["precision"], s["rr"]) == (1.0, 0.5, 0.2, 0.5)


def test_answer_scores():
    right = Answer(True, "At least 28 days.", (Claim("28 days", ("x",)),))
    wrong = Answer(True, "20 days.", ())
    abstained = Answer(False, "The guidance does not say.", ())
    assert answer_scores(Q, right)["correct"]
    assert answer_scores(Q, wrong)["shown_wrong"]
    s = answer_scores(Q, abstained)
    assert s["abstained"] and not s["correct"] and not s["shown_wrong"]
