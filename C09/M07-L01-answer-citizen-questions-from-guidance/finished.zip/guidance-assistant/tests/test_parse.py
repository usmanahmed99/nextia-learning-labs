import pytest

parse = pytest.importorskip("guidance_assistant.parse", reason="write guidance_assistant/parse.py first")

from guidance_assistant.snapshot import load_pages  # noqa: E402

PAGES = load_pages()


def test_the_welsh_line_is_dropped_and_said():
    parsed = parse.parse_page(PAGES["statutory-sick-pay"])
    assert parsed.dropped == ["This guide is also available in Welsh (Cymraeg)."]
    assert not any("Welsh" in b.text for b in parsed.blocks)
    assert parsed.blocks[0].text.startswith("You can get up to £123.25 per week")


def test_a_table_stays_one_block_with_one_line_per_row():
    parsed = parse.parse_page(PAGES["national-minimum-wage-rates"])
    tables = [b for b in parsed.blocks if b.kind == "table"]
    assert len(tables) == 4
    current = tables[0]
    assert current.section == "Current rates" and current.anchor == "current-rates"
    assert current.text.splitlines()[1] == "April 2026 | £12.71 | £10.85 | £8 | £8"


def test_every_block_knows_its_section_and_position():
    parsed = parse.parse_page(PAGES["statutory-sick-pay/eligibility"])
    exceptions = [b for b in parsed.blocks if b.section == "Exceptions"]
    assert exceptions[0].kind == "heading" and exceptions[0].anchor == "exceptions"
    for b in parsed.blocks:
        assert parsed.text[b.start:b.end] == b.text
