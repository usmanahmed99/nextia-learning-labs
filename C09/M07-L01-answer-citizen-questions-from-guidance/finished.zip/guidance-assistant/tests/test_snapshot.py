import shutil

import pytest

from guidance_assistant.snapshot import GUIDANCE, SnapshotChanged, load_pages


def test_the_snapshot_is_the_tested_one():
    pages = load_pages()
    assert len(pages) == 137
    assert all(p.url.startswith("https://www.gov.uk/") for p in pages.values())
    assert {p.retrieved_at[:10] for p in pages.values()} == {"2026-10-09"}
    assert len({p.guide_title for p in pages.values()}) == 38


def test_a_changed_file_stops_the_load(tmp_path):
    copy = tmp_path / "guidance"
    shutil.copytree(GUIDANCE, copy)
    text = (copy / "pages.jsonl").read_text(encoding="utf-8")
    (copy / "pages.jsonl").write_text(text.replace("£123.25", "£132.25", 1), encoding="utf-8")
    with pytest.raises(SnapshotChanged):
        load_pages(copy)
