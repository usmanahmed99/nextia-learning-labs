"""Citation checks. The first four cases are constructed (labelled so); the last is a real recording."""

from guidance_assistant.answer import Claim
from guidance_assistant.cite import check_claim
from guidance_assistant.evaluate import load_questions


def ids(store, page_id, section):
    return next(c.chunk_id for c in store.chunks() if c.page_id == page_id and c.section == section)


def test_constructed_citation_problems(store):
    ssp = ids(store, "statutory-sick-pay/eligibility", "Exceptions")
    context = [ssp]
    assert check_claim(Claim("SSP stops after 28 weeks.", ("000000000000",)), store, context).problems == \
        ["missing_id:000000000000"]                                                  # constructed: made-up ID
    other = ids(store, "rest-breaks-work", "Rest breaks at work")
    assert f"not_in_context:{other}" in check_claim(Claim("A 20 minute break.", (other,)), store, context).problems
    assert check_claim(Claim("You get it for 52 weeks.", (ssp,)), store, context).problems == \
        ["number_not_found:52"]                                                      # constructed: wrong number
    assert check_claim(Claim("It is paid weekly.", ()), store, context).problems == ["no_citation"]


def test_a_correct_calculation_is_flagged_real_recording(store):
    """chat-small, rerank, Q35, recorded 2026-10-09: '22.4' is right (4 x 5.6) but is not on the page."""
    from guidance_assistant.search import Retriever
    from guidance_assistant.assistant import ask
    from guidance_assistant.providers import MockProvider

    q = load_questions()["Q35"]
    result = ask(q.question, Retriever(store), MockProvider(), "chat-small", "bm25")
    problems = [p for c in result.checks for p in c.problems]
    assert "number_not_found:22.4" in problems
