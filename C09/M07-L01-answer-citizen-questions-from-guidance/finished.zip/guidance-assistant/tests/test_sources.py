import pytest

sources = pytest.importorskip("guidance_assistant.sources", reason="write guidance_assistant/sources.py first")

from guidance_assistant.assistant import ask  # noqa: E402
from guidance_assistant.evaluate import load_questions  # noqa: E402
from guidance_assistant.providers import MockProvider  # noqa: E402
from guidance_assistant.search import Retriever  # noqa: E402

QS = load_questions()


def test_every_source_has_its_address_and_dates(store):
    result = ask(QS["Q02"].question, Retriever(store), MockProvider(), "chat-small", "bm25")
    text = sources.render(result.answer, result.checks, store)
    assert "https://www.gov.uk/statutory-sick-pay" in text
    assert "fetched 2026-10-09; GOV.UK last updated 2026-10-05" in text
    assert "not legal advice" in text and "not a government service" in text
    assert "Open Government Licence v3.0" in text


def test_an_abstention_says_where_to_ask(store):
    result = ask(QS["Q42"].question, Retriever(store), MockProvider(), "chat-small", "bm25")
    assert not result.answer.answerable
    text = sources.render(result.answer, result.checks, store)
    assert "do not answer this question" in text and "Acas" in text and "Sources:" not in text
