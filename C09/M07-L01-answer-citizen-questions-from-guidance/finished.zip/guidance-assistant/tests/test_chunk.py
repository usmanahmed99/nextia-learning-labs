import dataclasses

import pytest

chunk = pytest.importorskip("guidance_assistant.chunk", reason="write guidance_assistant/chunk.py first")

from guidance_assistant.parse import parse_page  # noqa: E402
from guidance_assistant.snapshot import load_pages  # noqa: E402

PAGES = load_pages()


def chunks_of(page):
    return chunk.structure(parse_page(page), page)


def test_ids_are_the_same_every_time():
    page = PAGES["redundancy-your-rights/redundancy-pay"]
    assert [c.chunk_id for c in chunks_of(page)] == [c.chunk_id for c in chunks_of(page)]


def test_a_changed_page_gets_new_ids():
    page = PAGES["redundancy-your-rights/redundancy-pay"]
    newer = dataclasses.replace(page, updated_at="2027-04-06T00:00:00+01:00")
    assert not {c.chunk_id for c in chunks_of(page)} & {c.chunk_id for c in chunks_of(newer)}


def test_a_chunk_links_to_its_section_on_gov_uk():
    c = next(c for c in chunks_of(PAGES["statutory-sick-pay/eligibility"]) if c.section == "Exceptions")
    assert c.url == "https://www.gov.uk/statutory-sick-pay/eligibility#exceptions"
    assert c.text.startswith("Statutory Sick Pay (SSP): Eligibility\nExceptions\n")
    assert (c.retrieved_at, c.updated_at) == ("2026-10-09", "2026-10-05")


def test_tables_are_never_split():
    page = PAGES["national-minimum-wage-rates"]
    parsed = parse_page(page)
    chunks = chunk.structure(parsed, page)
    for table in (b for b in parsed.blocks if b.kind == "table"):
        assert any(c.start <= table.start and table.end <= c.end for c in chunks)
    assert len(chunks) == 8
