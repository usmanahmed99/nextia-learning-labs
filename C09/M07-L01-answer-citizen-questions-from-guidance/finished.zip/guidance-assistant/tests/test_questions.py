from collections import Counter

from guidance_assistant.evaluate import load_questions


def test_the_question_set():
    qs = load_questions()
    assert len(qs) == 44
    assert Counter(q.kind for q in qs.values()) == {"fact": 12, "condition": 14, "table": 3, "dated": 5,
                                                     "calculation": 2, "not_covered": 8}
    assert all(q.abstain == (not q.relevant) for q in qs.values())


def test_every_relevant_chunk_is_in_the_index(store):
    ids = {c.chunk_id for c in store.chunks()}
    for q in load_questions().values():
        assert set(q.relevant_chunks) <= ids, q.id
