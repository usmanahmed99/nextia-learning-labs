"""Section versions: what each section said, and from when to when it was in force.

The snapshot has each part as it was on several dates. This file turns those copies into versions:
1. Parse a part (eCFR XML) into sections, and each section into blocks: paragraphs, tables,
   headings inside a section, and the eCFR's notice of a published amendment ("Link to an
   amendment published at 89 FR 84818, Oct. 24, 2024."). The source note (CITA) and the
   approval note (APPRO) are kept out of the text. Each block keeps its top-level paragraph
   label, "(a)", "(b)"..., so that a citation can name it.
2. Walk the dates in order. When a section's text differs from the day before, a new version
   starts on that date, and the previous version ends the day before.
3. The first version starts on the first date of the snapshot (2017-01-01, where the eCFR's history
   starts): it may have been in force earlier, but the snapshot cannot say. The last version has no
   end date: it is still in force on the day the eCFR was up to date to (current_to).

`coverage()` says whether a question's date is inside what the snapshot can answer.
"""

import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from datetime import date, timedelta

TOP_LABEL = re.compile(r"^\(([a-z])\)\s")     # "(a) Subject to ..." starts paragraph (a)
CONTAINERS = {"DIV", "EXTRACT"}                 # wrappers: read what is inside them


def clean(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


@dataclass(frozen=True)
class Block:
    kind: str           # paragraph, table, heading, notice
    text: str
    paragraph: str      # the top-level label, for example "(b)"; "" before the first label


@dataclass(frozen=True)
class SectionText:
    section: str        # 250.5
    heading: str        # § 250.5 Amount of denied boarding compensation for ...
    blocks: tuple
    amended_by: str     # the source note: the Federal Register documents that made this text

    @property
    def text(self) -> str:
        return "\n".join(b.text for b in self.blocks)


@dataclass(frozen=True)
class SectionVersion:
    section: str
    part: str
    heading: str
    effective_from: str     # YYYY-MM-DD
    effective_to: str       # YYYY-MM-DD, or "" when still in force on current_to
    blocks: tuple = field(repr=False)
    amended_by: str = ""
    pending: str = ""       # the eCFR's notice of an amendment published but not yet in force

    @property
    def text(self) -> str:
        return "\n".join(b.text for b in self.blocks)

    def in_force(self, as_of: str) -> bool:
        return self.effective_from <= as_of and (not self.effective_to or as_of <= self.effective_to)

    @property
    def url(self) -> str:
        """The eCFR page of this section as it was on the first day of this version."""
        return f"https://www.ecfr.gov/on/{self.effective_from}/title-14/section-{self.section}"


def _blocks(element, out: list, label: list) -> None:
    for child in element:
        tag = child.tag
        if tag in CONTAINERS:
            _blocks(child, out, label)
        elif tag == "P" or tag.startswith("FP") or tag == "FTNT":     # FP: a flush paragraph; FTNT: a footnote
            text = clean("".join(child.itertext()))
            m = TOP_LABEL.match(text)
            if tag == "P" and m and (not label[0] or ord(m.group(1)) == ord(label[0][1]) + 1 or m.group(1) == "a"):
                label[0] = f"({m.group(1)})"
            if text:
                out.append(Block("paragraph", text, label[0]))
        elif tag == "TABLE":
            rows = [" | ".join(clean("".join(td.itertext())) for td in tr.iter("TD")) for tr in child.iter("TR")]
            out.append(Block("table", "\n".join(r for r in rows if r.strip(" |")), label[0]))
        elif tag in ("HD1", "HD2", "HD3"):
            out.append(Block("heading", clean("".join(child.itertext())), label[0]))
        elif tag == "XREF" and "amendment published" in "".join(child.itertext()):
            out.append(Block("notice", clean("".join(child.itertext())), label[0]))


def parse_part(xml: bytes) -> dict[str, SectionText]:
    """One part on one date: {section number: its heading, blocks and source note}."""
    root = ET.fromstring(xml)
    sections = {}
    for div in root.iter("DIV8"):
        blocks: list = []
        _blocks(div, blocks, [""])
        cita = div.find("CITA")
        sections[div.get("N")] = SectionText(div.get("N"), clean("".join(div.find("HEAD").itertext())),
                                             tuple(blocks), clean("".join(cita.itertext())) if cita is not None else "")
    return sections


def day_before(day: str) -> str:
    return (date.fromisoformat(day) - timedelta(days=1)).isoformat()


def build_versions(snapshot) -> list[SectionVersion]:
    """Every version of every section in the snapshot, in order of section and date."""
    versions = []
    for part in sorted({f.part for f in snapshot.files if f.kind == "part"}):
        current: dict[str, tuple[str, SectionText]] = {}     # section -> (from, text) of the open version
        for day in snapshot.dates(part):
            sections = parse_part(snapshot.xml(part, day))
            for number in list(current):                     # a section that disappears ends the day before
                if number not in sections:
                    start, old = current.pop(number)
                    versions.append(_version(part, old, start, day_before(day)))
            for number, now in sections.items():
                if number in current and (current[number][1].heading, current[number][1].text) == (now.heading, now.text):
                    continue                                 # same text: the same version goes on
                if number in current:
                    start, old = current[number]
                    versions.append(_version(part, old, start, day_before(day)))
                current[number] = (day, now)
        for start, text in current.values():
            versions.append(_version(part, text, start, ""))
    return sorted(versions, key=lambda v: (_order(v.section), v.effective_from))


def _version(part: str, s: SectionText, start: str, end: str) -> SectionVersion:
    pending = next((b.text for b in s.blocks if b.kind == "notice"), "")
    return SectionVersion(s.section, part, s.heading, start, end, s.blocks, s.amended_by, pending)


def _order(section: str) -> list:
    return [int(x) if x.isdigit() else x for x in re.split(r"(\d+)", section)]


def in_force(versions: list[SectionVersion], section: str, as_of: str) -> SectionVersion | None:
    return next((v for v in versions if v.section == section and v.in_force(as_of)), None)


def coverage(as_of: str, snapshot) -> str:
    """'before': the snapshot holds no version on that date; 'after': the date is later than the day
    the eCFR was up to date to, so a newer change may be missing; 'inside' otherwise."""
    if as_of < snapshot.history_start:
        return "before"
    if as_of > snapshot.current_to:
        return "after"
    return "inside"
