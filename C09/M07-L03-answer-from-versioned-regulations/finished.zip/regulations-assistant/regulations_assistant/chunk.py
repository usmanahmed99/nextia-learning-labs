"""Chunks of section versions, with stable IDs and the version's dates, as in the course's policy assistant.

A short section version is one chunk. A long one (250.5 has about 1,000 words) is cut between its
top-level paragraphs, (a), (b), ..., into chunks of at most MAX_WORDS words. A paragraph that is
longer than that is cut between its blocks; a block (one sub-paragraph, or a table) is never cut.
Every chunk starts with the section's heading, so "(b) ... $1,550" still says which section it is.

The chunk ID is the first 12 hexadecimal characters of SHA-256 over
"section|effective_from|start|end": two versions of the same paragraph get two IDs, so a citation
always points to one version. Every chunk carries the version's dates; the date filter and the
citation checks use them.
"""

import hashlib
from dataclasses import asdict, dataclass

from .versions import SectionVersion

MAX_WORDS = 200


def chunk_id(section: str, effective_from: str, start: int, end: int) -> str:
    return hashlib.sha256(f"{section}|{effective_from}|{start}|{end}".encode("utf-8")).hexdigest()[:12]


@dataclass(frozen=True)
class Chunk:
    chunk_id: str
    section: str            # 250.5
    part: str               # 250
    heading: str            # § 250.5 Amount of denied boarding compensation ...
    version: str            # a version is named by its first day (= effective_from)
    effective_from: str
    effective_to: str       # "" = still in force on the day the eCFR was up to date to
    position: int
    start: int              # character positions in the version's text
    end: int
    paragraphs: str         # the top-level paragraphs it holds, for example "(a),(b)"
    text: str               # what is indexed and shown to the model
    url: str                # the eCFR page of the section on the version's first day
    pending: str            # the eCFR's notice of a published amendment not yet in force, or ""

    def to_dict(self) -> dict:
        return asdict(self)

    def in_force(self, as_of: str) -> bool:
        return self.effective_from <= as_of and (not self.effective_to or as_of <= self.effective_to)


def words(spans: list) -> int:
    return sum(len(block.text.split()) for block, _, _ in spans)


def chunks_of(version: SectionVersion, max_words: int = MAX_WORDS) -> list[Chunk]:
    spans, pos = [], 0                   # (block, start, end) in the version's text
    for block in version.blocks:
        spans.append((block, pos, pos + len(block.text)))
        pos += len(block.text) + 1       # the blocks are joined with "\n"
    paragraphs: list[list] = []          # the blocks of each top-level paragraph; a notice joins the next
    for span in spans:
        if paragraphs and (span[0].paragraph == paragraphs[-1][-1][0].paragraph
                           or paragraphs[-1][-1][0].kind == "notice"):
            paragraphs[-1].append(span)
        else:
            paragraphs.append([span])
    parts: list[list] = [[]]
    for paragraph in paragraphs:
        if parts[-1] and words(parts[-1]) + words(paragraph) > max_words:
            parts.append([])             # the paragraph does not fit: start a new chunk
        for span in paragraph:           # a paragraph too long for one chunk is cut between blocks
            if parts[-1] and words(parts[-1]) + words([span]) > max_words:
                parts.append([])
            parts[-1].append(span)
    return [_make(version, part, i) for i, part in enumerate(parts)]


def _make(version: SectionVersion, spans: list, position: int) -> Chunk:
    start, end = (spans[0][1], spans[-1][2]) if spans else (0, 0)   # a reserved section has no text
    labels = list(dict.fromkeys(block.paragraph for block, _, _ in spans if block.paragraph))
    body = "\n".join(block.text for block, _, _ in spans)
    return Chunk(
        chunk_id=chunk_id(version.section, version.effective_from, start, end), section=version.section,
        part=version.part, heading=version.heading, version=version.effective_from,
        effective_from=version.effective_from, effective_to=version.effective_to, position=position,
        start=start, end=end, paragraphs=",".join(labels), text=f"14 CFR {version.heading}\n{body}".strip(),
        url=version.url, pending=version.pending)


def chunk_all(versions: list[SectionVersion]) -> list[Chunk]:
    return [c for v in versions for c in chunks_of(v)]
