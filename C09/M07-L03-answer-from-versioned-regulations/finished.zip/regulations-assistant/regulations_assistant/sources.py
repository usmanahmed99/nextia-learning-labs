"""Show an answer the way a case worker should see it, and check that it cites the right version.

The model gives claims and passage IDs. The application writes everything else from the index:
- every source with its section, the dates of its version, and the eCFR address of that version;
- a line about the question's date when the snapshot cannot be sure (after the day the eCFR was up
  to date to: a newer change would be missing);
- the notice: what this is not, and that the eCFR is not an official legal edition.

`check_versions` is the citation check that this case study adds: every cited passage must come
from a version in force on the question's date. The course's checks (cite.py) would pass a claim
that cites the $775 version for a flight in 2025; this one flags it as wrong_version.
"""

from .snapshot import ATTRIBUTION

NOTICE = ("Question date {as_of}. This is what the regulation's text said, not legal advice. "
          "Check the eCFR page and the Federal Register before you rely on it.")
AFTER = ("Note: {as_of} is after {current_to}, the day the eCFR was up to date to when this snapshot was made. "
         "A change made after {current_to} is not in it.")


def check_versions(answer, store, as_of: str) -> list[str]:
    """The cited IDs whose version was not in force on as_of (in order of first citation)."""
    wrong = []
    for cid in answer.cited():
        chunk = store.chunk(cid)
        if chunk is not None and not chunk.in_force(as_of):
            wrong.append(cid)
    return wrong


def dates(chunk) -> str:
    return f"in force {chunk.effective_from} to {chunk.effective_to or 'today'}"


def render(answer, checks: list, store, as_of: str, snapshot) -> str:
    head = [AFTER.format(as_of=as_of, current_to=snapshot.current_to), ""] if as_of > snapshot.current_to else []
    foot = ["", NOTICE.format(as_of=as_of), ATTRIBUTION]
    if not answer.answerable:
        return "\n".join(head + [f"Answer: {answer.answer}"] + foot)
    sources = [c for c in (store.chunk(i) for i in answer.cited()) if c is not None]
    number = {c.chunk_id: i for i, c in enumerate(sources, 1)}
    wrong = set(check_versions(answer, store, as_of))
    lines = head + [f"Answer: {answer.answer}", ""]
    for claim, check in zip(answer.claims, checks):
        refs = "".join(f"[{number[i]}]" for i in claim.chunk_ids if i in number) or "[no source]"
        problems = list(check.problems) + [f"wrong_version:{i}" for i in claim.chunk_ids if i in wrong]
        lines.append(f"- {claim.text} {refs}" + (f"  (check: {'; '.join(problems)})" if problems else ""))
    lines += ["", f"Sources (question date {as_of}):"]
    for i, c in enumerate(sources, 1):
        flag = "" if c.chunk_id not in wrong else f"  NOT IN FORCE ON {as_of}"
        lines.append(f"[{i}] 14 CFR {c.section} {c.paragraphs}, version {dates(c)}{flag}")
        lines.append(f"    {c.url}")
    return "\n".join(lines + foot)
