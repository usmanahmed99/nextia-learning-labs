# regulations-assistant

A cited question-answering assistant over two US federal regulations **at every date they changed**: 14 CFR Part 250 (oversales and denied boarding compensation) and 14 CFR Part 254 (domestic baggage liability), from the eCFR, fetched once on 2026-10-09. A case worker asks a question with a date, for example the day of a flight; the assistant searches only the versions in force on that date, answers in claims that each cite a passage, checks the citations in code (including the version), and shows every source with its section, its version's dates and its eCFR address. For a date before the snapshot, it says that it cannot answer; for a date after the eCFR's up-to-date date, it warns.

It is the project of the case study *Answer from versioned regulations* in the course *RAG: Building AI That Uses Your Data* (Nextia Learning). It reuses the patterns of the course's `policy-assistant`.

**What it is not.** It is not legal advice, and the eCFR is not an official legal edition of the CFR. An answer describes the text of a version as the eCFR showed it on 2026-10-09. Check the eCFR page and the Federal Register, and ask a person who knows the law, before you rely on an answer.

You need no account and no key. Search runs on your computer (SQLite full-text search, a small open embedding model and a small open reranker). Answers come from recorded model responses (the mock provider) unless you choose a live model.

## The pipeline

```text
regulations/*.xml (a part on each date)  ->  versions (section, text, in force from .. to ..)
    ->  chunks (stable IDs, paragraphs, the version's dates, eCFR address)  ->  index.sqlite (BM25, e5 vectors)
question + date  ->  coverage (before the snapshot? no answer)  ->  date filter (only versions in force)
    ->  BM25 + vectors -> RRF -> rerank -> top 5  ->  context (each passage with its version's dates)
    ->  model (claims + passage IDs)  ->  citation checks + version check  ->  answer card with versions and dates
```

## Files

| Path | What it does |
|---|---|
| `regulations/` | The snapshot: the eCFR's XML of each part on each date, the versions lists, `sources.csv`, `SHA256SUMS` (see `DATASET.md`) |
| `regulations_assistant/snapshot.py` | Loads the snapshot after checking the checksums; its first date and up-to-date date |
| `regulations_assistant/versions.py` | eCFR XML into sections and blocks; section versions with their dates; `coverage()` |
| `regulations_assistant/chunk.py` | Chunks of each version, with stable IDs, paragraphs, dates and the eCFR address |
| `regulations_assistant/store.py` | The index file: chunks, FTS5 keyword index, vectors, how it was built |
| `regulations_assistant/filters.py` | The date filter: only versions in force on the question's date, before the top k |
| `regulations_assistant/lexical.py`, `dense.py`, `hybrid.py`, `rerank.py`, `embed.py`, `search.py` | BM25, vector search, RRF, the cross-encoder, the e5 model, one `Retriever` (from the course) |
| `regulations_assistant/context.py` | The token budget, near-duplicates, the passage header with the version's dates |
| `regulations_assistant/answer.py`, `prompts/` | The answer schema (claims with passage IDs), the request with the question's date, the closed-book baseline |
| `regulations_assistant/cite.py` | The course's citation checks, and their limits |
| `regulations_assistant/sources.py` | The version check, and the answer card: sources with versions, dates and addresses, the notice |
| `regulations_assistant/assistant.py` | `ask()`: coverage, search, context, model, parse, checks |
| `regulations_assistant/evaluate.py` | hit@k, recall@k, precision@k, MRR, chunks out of force; answer checks; citation accuracy; cost |
| `regulations_assistant/providers.py`, `config.py` | The adapter: the mock (recordings) or a live OpenAI-compatible provider |
| `questions/questions.jsonl` | 34 questions, each with a date, a reference answer, keys and relevant passages |
| `recordings/` | The recorded model responses that the mock replays |
| `scripts/` | `check_snapshot.py`; `fetch_snapshot.py` and `build_snapshot.py` (how the snapshot was made) |
| `tests/` | `pytest` tests |

## Set up

You need Python 3.12 or later and about 2 GB of disk space: about 0.9 GB for the Python packages (PyTorch is most of it) and about 1 GB for the two local models, which are downloaded once, on first use, into the Hugging Face cache (`~/.cache/huggingface`). If you did the course, they are already there.

macOS and Linux:

```sh
cd regulations-assistant
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

On Linux, install the CPU-only PyTorch first (`python -m pip install torch==2.14.1 --index-url https://download.pytorch.org/whl/cpu`).

Windows (PowerShell):

```powershell
cd regulations-assistant
py -3.12 -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

## Run

```sh
python -m pytest                                    # the tests (no model download needed)
python scripts/check_snapshot.py                    # the snapshot is the tested one
python -m regulations_assistant snapshot            # the files and their dates
python -m regulations_assistant versions 250.5      # one section over time
python -m regulations_assistant ingest              # index.sqlite: 134 chunks, e5 vectors
python -m regulations_assistant search "What is the baggage liability limit?" --as-of 2023-11-20
python -m regulations_assistant ask Q04             # a recorded answer with its version and dates
python -m regulations_assistant ask Q28             # a date before the snapshot: no answer, no model call
python -m regulations_assistant ask Q03 --no-date-filter     # what goes wrong without the filter
python -m regulations_assistant eval                # retrieval, with the date filter
python -m regulations_assistant eval --no-date-filter
python -m regulations_assistant eval --answers      # and the recorded answers
```

### Recorded answers and live models

The mock replays real answers recorded on Azure, prompt `answer_v1`, top 5: chat-small (gpt-6-luna) for the 34 questions with `--method rerank` (with and without `--no-date-filter`) and with `--method bm25`; chat-strong (gpt-6.1-sol) for the 17 even-numbered questions with `--method rerank`, with and without the filter; and chat-small without passages (`ask --closed-book`). If your passages differ from the recorded ones, the mock still replays the answer of that question, prompt and model, prints `Note: Recorded with passages …; yours: …`, and checks the citations against **your** passages. Any other question needs a live model: copy `.env.example` to `.env` and choose Ollama (free, local) or your own key. Never commit `.env`.

## Licence

Code: MIT (see `LICENSE`). The regulations in `regulations/` and inside `recordings/` (the passages in the recorded requests) are US government works in the public domain; source: eCFR (ecfr.gov), fetched 2026-10-09. The questions and the rest of the recordings: CC0.

## Tested

2026-10-09, Python 3.12.13, macOS (Apple silicon), in a new virtual environment. Windows and Linux are not tested.
