"""Check the snapshot against its checksums and print what it holds.

    python scripts/check_snapshot.py
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from regulations_assistant.snapshot import REGULATIONS, SnapshotChanged, load_snapshot  # noqa: E402

try:
    snapshot = load_snapshot()
except SnapshotChanged as e:
    raise SystemExit(f"Changed: {e}")
lines = (REGULATIONS / "SHA256SUMS").read_text().splitlines()
for line in lines:
    digest, name = line.split()
    print(f"OK  {name:34} SHA-256 {digest[:12]}…")
print(f"{len(lines)} files checked | fetched {snapshot.retrieved} from the eCFR API | "
      f"history from {snapshot.history_start} | up to date to {snapshot.current_to}")
