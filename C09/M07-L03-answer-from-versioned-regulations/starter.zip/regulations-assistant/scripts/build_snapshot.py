"""Turn the raw eCFR responses into the case study's snapshot (author only).

    python -I build_snapshot.py RAW_DIR OUT_DIR

RAW_DIR: the folder written by fetch_snapshot.py (the responses and fetch_log.csv).
OUT_DIR: the project's regulations/ folder. It gets every response file unchanged (each checked
against the SHA-256 in fetch_log.csv), sources.csv (one row per file) and SHA256SUMS.
It also checks two things and stops if they fail:
- every part file is valid XML with the part's sections;
- the part on the up-to-date date is byte for byte the part on its last version date
  (so no change is missing between the last version and the day we fetched).
"""

import csv
import hashlib
import re
import shutil
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

FIELDS = ["file", "kind", "part", "date", "url", "retrieved_at", "sha256"]


def main(raw: Path, out: Path) -> None:
    log = [r for r in csv.DictReader(open(raw / "fetch_log.csv")) if r["status"] == "200"]
    out.mkdir(parents=True, exist_ok=True)
    rows = []
    for r in log:
        data = (raw / r["file"]).read_bytes()
        assert hashlib.sha256(data).hexdigest() == r["sha256"], r["file"]
        m = re.match(r"title-14_part-(\d+)_(\d{4}-\d\d-\d\d)\.xml$", r["file"])
        if m:
            kind, part, date = "part", m.group(1), m.group(2)
            root = ET.fromstring(data)
            assert root.get("N") == part and len(list(root.iter("DIV8"))) > 3, r["file"]
        elif r["file"].startswith("versions_part-"):
            kind, part, date = "versions", r["file"][14:17], ""
        else:
            kind, part, date = "titles", "", ""
        shutil.copyfile(raw / r["file"], out / r["file"])
        rows.append({"file": r["file"], "kind": kind, "part": part, "date": date, "url": r["url"],
                     "retrieved_at": r["retrieved_at"], "sha256": r["sha256"]})
    for part in sorted({r["part"] for r in rows if r["kind"] == "part"}):
        dated = sorted((r["date"], r["sha256"]) for r in rows if r["kind"] == "part" and r["part"] == part)
        assert dated[-1][1] == dated[-2][1], f"part {part}: the up-to-date file differs from the last version"
        print(f"part {part}: {len(dated)} files; {dated[-1][0]} = {dated[-2][0]} (no later change)")
    with open(out / "sources.csv", "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    names = sorted(r["file"] for r in rows) + ["sources.csv"]
    sums = [f"{hashlib.sha256((out / n).read_bytes()).hexdigest()}  {n}" for n in names]
    (out / "SHA256SUMS").write_text("\n".join(sums) + "\n")
    print(f"{len(rows)} files -> {out}")


if __name__ == "__main__":
    main(Path(sys.argv[1]), Path(sys.argv[2]))
