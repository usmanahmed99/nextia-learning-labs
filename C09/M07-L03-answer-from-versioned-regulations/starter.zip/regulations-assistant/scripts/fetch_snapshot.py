"""Fetch two parts of the US Code of Federal Regulations once, at every date they changed, from the eCFR API.

How the case study's snapshot was made (2026-10-09). You do not need to run it: the project includes
the snapshot. If you run it later, a new version may have appeared, so the questions and the recorded
answers may no longer match.

    python fetch_snapshot.py OUT_DIR

The parts: 14 CFR Part 250 (Oversales and denied boarding compensation) and 14 CFR Part 254
(Domestic baggage liability). For each part it asks:
  1. /api/versioner/v1/titles.json                         the date the eCFR is up to date to
  2. /api/versioner/v1/versions/title-14.json?part=N       every section version and its date
  3. /api/versioner/v1/full/DATE/title-14.xml?part=N       the whole part as it was on DATE, for
     every distinct version date (the eCFR's history starts on 2017-01-01, so an earlier date is
     replaced by 2017-01-01), and once more on the up-to-date date, as a check
It writes the exact response bytes, and OUT_DIR/fetch_log.csv with the URL, HTTP status, time (UTC)
and SHA-256 of every response.

Politeness: one request every 1.2 seconds, a User-Agent that names the course, no retries in a
loop. The eCFR asks for compressed responses on /full/ (Accept-Encoding: gzip); the bytes we keep
are the decompressed XML. robots.txt asks crawlers not to index /api/versioner/v1/full/ and /on/:
this is not a crawler, but a single fetch of 16 documents through the documented developer API.

Downloads are untrusted data: OUT_DIR must be a new, empty folder, outside this one.
"""

import argparse
import csv
import gzip
import hashlib
import json
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

API = "https://www.ecfr.gov/api/versioner/v1"
UA = "NextiaLearning-course-snapshot/1.0 (+https://learning.nextia-ai.com)"
PAUSE_S = 1.2
TITLE, PARTS = 14, ("250", "254")
HISTORY_START = "2017-01-01"     # the first date the eCFR's point-in-time API can return


def get(url: str) -> tuple[bytes, int, str]:
    request = urllib.request.Request(url, headers={"User-Agent": UA, "Accept-Encoding": "gzip"})
    retrieved = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    try:
        with urllib.request.urlopen(request, timeout=60) as response:
            body, status = response.read(), response.status
            if response.headers.get("Content-Encoding") == "gzip":
                body = gzip.decompress(body)
    except urllib.error.HTTPError as error:
        body, status = b"", error.code
    time.sleep(PAUSE_S)
    return body, status, retrieved


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("out_dir", type=Path)
    out = parser.parse_args().out_dir
    out.mkdir(parents=True, exist_ok=True)
    rows = []

    def fetch(url: str, name: str) -> bytes:
        body, status, retrieved = get(url)
        if body:
            (out / name).write_bytes(body)
        rows.append({"url": url, "status": status, "retrieved_at": retrieved, "file": name if body else "",
                     "sha256": hashlib.sha256(body).hexdigest() if body else "", "bytes": len(body)})
        print(f"{len(rows)} {status} {url}", file=sys.stderr)
        return body

    titles = json.loads(fetch(f"{API}/titles.json", "titles.json"))
    current = next(t for t in titles["titles"] if t["number"] == TITLE)["up_to_date_as_of"]
    for part in PARTS:
        versions = json.loads(fetch(f"{API}/versions/title-{TITLE}.json?part={part}", f"versions_part-{part}.json"))
        dates = sorted({max(v["date"], HISTORY_START) for v in versions["content_versions"]} | {current})
        for date in dates:
            fetch(f"{API}/full/{date}/title-{TITLE}.xml?part={part}", f"title-{TITLE}_part-{part}_{date}.xml")
    with open(out / "fetch_log.csv", "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


if __name__ == "__main__":
    main()
