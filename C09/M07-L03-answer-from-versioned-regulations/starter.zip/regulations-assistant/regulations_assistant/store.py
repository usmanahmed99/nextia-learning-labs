"""The index: one SQLite file with the chunks, the keyword index (FTS5) and the vectors.

`build()` makes a new index from the snapshot every time: 44 section versions take a few seconds,
so there is no incremental update here (the course's policy assistant shows one). The index
records the chunk count, the snapshot's checksum and the embedding model and revision, so that a
search with another model is refused (IndexMismatch).
"""

import hashlib
import re
import sqlite3
from dataclasses import fields
from pathlib import Path

import numpy as np

from .chunk import Chunk, chunk_all
from .lexical import KeywordIndex
from .snapshot import REGULATIONS
from .versions import build_versions

COLUMNS = [f.name for f in fields(Chunk)]
NUMBERS = {"position", "start", "end"}
SCHEMA = (f"CREATE TABLE IF NOT EXISTS chunks ({', '.join(c + ' TEXT' for c in COLUMNS)}, PRIMARY KEY (chunk_id));"
          "CREATE TABLE IF NOT EXISTS vectors (chunk_id TEXT PRIMARY KEY, vector BLOB);"
          "CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT);")


class IndexMismatch(Exception):
    """The index was built with another embedding model."""


class Store:
    def __init__(self, path: Path | str):
        self.path = Path(path)
        self.conn = sqlite3.connect(str(self.path), check_same_thread=False)
        self.conn.executescript(SCHEMA)
        self.keywords = KeywordIndex(self.conn)
        self._matrix = None
        self._chunks = None

    def meta(self) -> dict:
        return dict(self.conn.execute("SELECT key, value FROM meta"))

    def chunks(self) -> list[Chunk]:
        if self._chunks is None:
            rows = self.conn.execute(f"SELECT {', '.join(COLUMNS)} FROM chunks").fetchall()
            chunks = [Chunk(**{n: int(v) if n in NUMBERS else v for n, v in zip(COLUMNS, r)}) for r in rows]
            order = lambda c: ([int(x) if x.isdigit() else x for x in re.split(r"(\d+)", c.section)],  # noqa: E731
                               c.version, c.position)
            self._chunks = sorted(chunks, key=order)
        return self._chunks

    def chunk(self, chunk_id: str) -> Chunk | None:
        return next((c for c in self.chunks() if c.chunk_id == chunk_id), None)

    def vectors(self) -> tuple[list[str], np.ndarray]:
        if self._matrix is None:
            rows = self.conn.execute("SELECT chunk_id, vector FROM vectors ORDER BY chunk_id").fetchall()
            matrix = np.array([np.frombuffer(r[1], dtype=np.float32) for r in rows]) if rows else np.zeros((0, 0))
            self._matrix = ([r[0] for r in rows], matrix)
        return self._matrix

    def build(self, snapshot, embedder=None) -> tuple[int, int]:
        """Replace everything in the index with the chunks of the snapshot's section versions.
        Returns (section versions, chunks)."""
        versions = build_versions(snapshot)
        chunks = chunk_all(versions)
        with self.conn:
            for table in ("chunks", "vectors", "meta", KeywordIndex.TABLE):
                self.conn.execute(f"DELETE FROM {table}")
            self.conn.executemany(f"INSERT INTO chunks VALUES ({', '.join('?' for _ in COLUMNS)})",
                                  [tuple(getattr(c, n) for n in COLUMNS) for c in chunks])
            self.keywords.add((c.chunk_id, c.text) for c in chunks)
            checksum = hashlib.sha256((REGULATIONS / "SHA256SUMS").read_bytes()).hexdigest()[:12]
            meta = {"chunks": len(chunks), "versions": len(versions), "snapshot": checksum,
                    "history_start": snapshot.history_start, "current_to": snapshot.current_to}
            if embedder is not None:
                vectors = embedder.embed_passages([c.text for c in chunks])
                self.conn.executemany("INSERT INTO vectors VALUES (?, ?)",
                                      [(c.chunk_id, v.astype(np.float32).tobytes()) for c, v in zip(chunks, vectors)])
                meta |= {"embedding_model": embedder.name, "embedding_revision": embedder.revision}
            self.conn.executemany("INSERT INTO meta VALUES (?, ?)", [(k, str(v)) for k, v in meta.items()])
        self._matrix = self._chunks = None
        return len(versions), len(chunks)
