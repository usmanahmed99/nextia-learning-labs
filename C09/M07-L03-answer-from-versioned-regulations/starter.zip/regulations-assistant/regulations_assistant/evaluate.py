"""Measure retrieval and answers on the 34 dated questions (questions/questions.jsonl).

A question has a date (as_of: the day of the flight) and, if the regulation answers it, relevant
passages: a section, the VERSION in force on that date, and a paragraph. A retrieved chunk is
relevant only when it comes from that version: the same paragraph in another version is a wrong
version, not a hit.

Retrieval measures (the questions that have relevant passages):
- hit@k, recall@k, precision@k, MRR as in the course;
- out of force: chunks in the top k whose version was not in force on the question's date
  (0 by construction with the date filter; the measure shows what the filter keeps out).

Answer measures (automatic, a net with holes; read the misses):
- correct:   answerable questions: answered, every key matches, no must_not matches
             (must_not holds the other versions' amounts); abstain questions: abstained, or (for a
             rule that did not exist yet) said so in words that a key matches, and no must_not matches;
- shown but wrong: answered (not abstained) and not correct;
- citation accuracy: the share of cited passages whose version was in force on the question's date.
"""

import json
import re
import statistics
from dataclasses import dataclass
from pathlib import Path

PROJECT = Path(__file__).resolve().parent.parent
QUESTIONS = PROJECT / "questions" / "questions.jsonl"
PRICES = {"chat-small": (0.10, 0.50), "chat-strong": (2.00, 10.00)}   # US$ per million tokens in, out


@dataclass(frozen=True)
class Question:
    id: str
    question: str
    as_of: str
    kind: str
    group: str
    abstain: bool
    reference_answer: str
    keys: list
    must_not: list
    relevant: list            # [{"section", "version", "paragraph"}]
    notes: str


def load_questions(path: Path = QUESTIONS) -> dict[str, Question]:
    qs = [Question(**json.loads(line)) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    return {q.id: q for q in qs}


def covers(chunk, passage: dict, any_version: bool = False) -> bool:
    return (chunk.section == passage["section"] and (any_version or chunk.version == passage["version"])
            and (not passage["paragraph"] or passage["paragraph"] in chunk.paragraphs.split(",")))


def retrieval_scores(q: Question, ranked: list, k: int) -> dict:
    top = ranked[:k]
    out_of_force = sum(1 for c in top if not c.in_force(q.as_of))
    if not q.relevant:
        return {"id": q.id, "kind": q.kind, "scored": False, "out_of_force": out_of_force}
    rel = [any(covers(c, p) for p in q.relevant) for c in top]
    found = [p for p in q.relevant if any(covers(c, p) for c in top)]
    first = next((i for i, r in enumerate(rel) if r), None)
    other = [any(covers(c, p, any_version=True) for p in q.relevant) and not r for c, r in zip(top, rel)]
    return {"id": q.id, "kind": q.kind, "scored": True, "hit": float(any(rel)), "recall": len(found) / len(q.relevant),
            "precision": sum(rel) / k, "rr": 0.0 if first is None else 1.0 / (first + 1),
            "first_rank": None if first is None else first + 1, "other_versions": sum(other),
            "top1_other_version": bool(other and other[0]), "out_of_force": out_of_force}


def summarise(rows: list[dict]) -> dict:
    scored = [r for r in rows if r["scored"]]
    out = {"questions": len(scored), "out_of_force": sum(r["out_of_force"] for r in rows),
           "with_out_of_force": sum(1 for r in rows if r["out_of_force"])}
    if not scored:
        return out
    mean = lambda name: round(statistics.fmean(r[name] for r in scored), 3)  # noqa: E731
    return out | {"hit": mean("hit"), "recall": mean("recall"), "precision": mean("precision"), "mrr": mean("rr"),
                  "top1_other_version": sum(r["top1_other_version"] for r in scored)}


ABSTAIN = re.compile(r"(regulations?|passages?|sections?|snapshot)\s+(in the passages\s+)?(do(es)?\s+not|don't|doesn't)\s+"
                     r"(say|answer|cover|mention|state|include|give|specify|address)|no version|no information", re.I)


def answer_scores(q: Question, answer, store=None) -> dict:
    """store: the index, to check the version of every cited passage (citation accuracy)."""
    if answer is None:
        return {"id": q.id, "kind": q.kind, "valid": False, "correct": False, "abstained": False,
                "shown_wrong": False, "cited": 0, "cited_in_force": 0}
    text = answer.text()
    abstained = not answer.answerable
    violated = [m for m in q.must_not if re.search(m, text, re.I)]
    if q.abstain:     # abstaining is right; so is saying that the version in force has no such rule (the keys)
        correct = (abstained or any(re.search(k, text, re.I) for k in q.keys)) and not violated
    else:
        correct = not abstained and all(re.search(k, text, re.I) for k in q.keys) and not violated
    cited = [store.chunk(i) for i in answer.cited()] if store is not None else []
    cited = [c for c in cited if c is not None]
    return {"id": q.id, "kind": q.kind, "valid": True, "correct": correct, "abstained": abstained,
            "shown_wrong": not abstained and not correct, "must_not_hit": violated,
            "cited": len(cited), "cited_in_force": sum(1 for c in cited if c.in_force(q.as_of))}


def cost(model: str, tokens_in: int, tokens_out: int) -> float:
    price_in, price_out = PRICES.get(model, (0.0, 0.0))
    return (tokens_in * price_in + tokens_out * price_out) / 1_000_000


def percentile(values: list[float], p: float) -> float:
    values = sorted(values)
    if not values:
        return 0.0
    i = min(len(values) - 1, max(0, round(p / 100 * (len(values) - 1))))
    return values[i]
