"""The date filter: which chunks may be retrieved for a question at all, as in the course's policy assistant.

Applied BEFORE the top k is chosen, so a version that was not in force on the question's date
never takes a place in the top 5, never reaches the model and can never be cited.
A chunk passes when effective_from <= as_of, and as_of <= effective_to (the last day is included;
an empty effective_to means the version is still in force).
as_of = None turns the filter off: every version of every section can be found. The case study uses
it to show what goes wrong without the filter.
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class Filters:
    as_of: str | None = None        # YYYY-MM-DD, or None for no date filter

    def allows(self, chunk) -> bool:
        if not self.as_of:
            return True
        if chunk.effective_from > self.as_of:
            return False
        return not chunk.effective_to or self.as_of <= chunk.effective_to
