"""Keyword search with SQLite full-text search (FTS5) and BM25.

FTS5 keeps an inverted index: for every word, the items that contain it. BM25 scores an item higher
when it contains the query's words often (term frequency, with diminishing returns), when those words
are rare in the collection (inverse document frequency), and when the item is short.
SQLite's bm25() returns lower numbers for better matches; `search` turns them round, so that a
higher score is better, as with every other search method in this project.

The tokenizer `unicode61 remove_diacritics 2` lowercases words and removes accents (é -> e), so a
word with an accent matches the same word without it. It splits "250.5" into "250" and
"5": the query is split the same way, so a section number in a question still matches.
"""

import re
import sqlite3
from dataclasses import dataclass
from typing import Callable, Iterable


@dataclass(frozen=True)
class Hit:
    id: str
    score: float
    rank: int  # 1 = best


def words(text: str) -> list[str]:
    """The query's words, lowercased, without duplicates, in order."""
    return list(dict.fromkeys(w.lower() for w in re.findall(r"\w+", text)))


def fts_query(text: str) -> str:
    """'What does 14 CFR 250.5 say?' -> '"what" OR "does" OR "14" OR "cfr" OR "250" OR "5" OR "say"'.

    Every word is quoted, so FTS5 never reads a word as an operator (AND, OR, NOT, NEAR, -).
    OR means that an item needs only some of the words; BM25 ranks the items with more of them,
    and with rarer ones, higher.
    """
    return " OR ".join(f'"{w}"' for w in words(text))


class KeywordIndex:
    """An FTS5 table of (item ID, text) inside a SQLite database."""

    TABLE = "keyword_index"

    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn
        conn.execute(f"CREATE VIRTUAL TABLE IF NOT EXISTS {self.TABLE} USING fts5("
                     "item_id UNINDEXED, text, tokenize = 'unicode61 remove_diacritics 2')")

    def add(self, items: Iterable[tuple[str, str]]) -> None:
        self.conn.executemany(f"INSERT INTO {self.TABLE} (item_id, text) VALUES (?, ?)", list(items))

    def remove(self, ids: Iterable[str]) -> None:
        self.conn.executemany(f"DELETE FROM {self.TABLE} WHERE item_id = ?", [(i,) for i in ids])

    def search(self, query: str, k: int = 5, allowed: Callable[[str], bool] | None = None) -> list[Hit]:
        """The k best items for the query. `allowed(item_id)` removes items before the top k is taken."""
        q = fts_query(query)
        if not q:
            return []
        rows = self.conn.execute(
            f"SELECT item_id, bm25({self.TABLE}) FROM {self.TABLE} WHERE {self.TABLE} MATCH ? "
            f"ORDER BY bm25({self.TABLE}), item_id", (q,)).fetchall()
        hits = [(item_id, -score) for item_id, score in rows if allowed is None or allowed(item_id)]
        return [Hit(item_id, round(score, 4), rank) for rank, (item_id, score) in enumerate(hits[:k], 1)]
