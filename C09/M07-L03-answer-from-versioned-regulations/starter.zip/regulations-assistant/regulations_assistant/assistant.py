"""The whole pipeline: coverage -> search (date filter) -> context -> model -> parse -> checks.

`date_aware=False` turns off the date filter and the coverage check, to show what a naive assistant
does: every version of every section can be found, and a date before the snapshot still gets an answer.
"""

from dataclasses import dataclass, field

from .answer import Answer, AnswerProblem, build_request, parse_answer
from .cite import check_answer
from .context import BUDGET, Context, assemble
from .filters import Filters
from .providers import ProviderError
from .sources import check_versions
from .versions import coverage

K = 5
BEFORE = ("The snapshot holds no version in force on {as_of}: its history starts on {start}. "
          "The rule may have existed then, but this assistant cannot show it.")


@dataclass
class AskResult:
    question: str
    as_of: str
    coverage: str
    context: Context
    request: dict | None
    answer: Answer | None = None
    problem: str = ""
    checks: list = field(default_factory=list)
    wrong_versions: list = field(default_factory=list)
    completion: object = None


def ask(question: str, as_of: str, retriever, provider, snapshot, model: str = "chat-small", method: str = "rerank",
        k: int = K, prompt: str = "answer_v1", date_aware: bool = True, budget: int = BUDGET) -> AskResult:
    where = coverage(as_of, snapshot)
    if date_aware and where == "before":       # no version to show: answer without calling the model
        answer = Answer(False, BEFORE.format(as_of=as_of, start=snapshot.history_start), ())
        return AskResult(question, as_of, where, Context(), None, answer)
    filters = Filters(as_of if date_aware else None)
    results = retriever.search(question, method=method, k=k, filters=filters)
    context = assemble([r.chunk for r in results], budget)
    request = build_request(question, as_of, context, model, prompt)
    out = AskResult(question, as_of, where, context, request)
    try:
        out.completion = provider.complete(request)
        out.answer = parse_answer(out.completion)
    except (ProviderError, AnswerProblem) as e:
        out.problem = str(e)
        return out
    out.checks = check_answer(out.answer, retriever.store, context.ids, f"{as_of} {question}")
    out.wrong_versions = check_versions(out.answer, retriever.store, as_of)
    return out
