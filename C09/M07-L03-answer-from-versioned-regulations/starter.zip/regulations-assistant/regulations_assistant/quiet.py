"""Keep the terminal readable: no download progress bars or token warnings from the model libraries."""


def quiet() -> None:
    try:
        from huggingface_hub.utils import logging as hub_logging
        from transformers.utils import logging as tf_logging

        hub_logging.set_verbosity_error()
        tf_logging.set_verbosity_error()
        tf_logging.disable_progress_bar()
    except ImportError:   # other library versions: the messages are harmless
        pass
