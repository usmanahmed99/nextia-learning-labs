"""Reranking with a cross-encoder: read the question and each candidate chunk together and score the pair.

The model of the course's policy assistant: cross-encoder/mmarco-mMiniLMv2-L12-H384-v1 (Apache-2.0
on its model card, about 470 MB), pinned to the same revision. It rereads only the top candidates
(20) of the hybrid search, because one model run per candidate is slow.
"""

import os

from .quiet import quiet

from .lexical import Hit

RERANK_MODEL = "cross-encoder/mmarco-mMiniLMv2-L12-H384-v1"
RERANK_REVISION = "1427fd652930e4ba29e8149678df786c240d8825"   # Hugging Face commit, 2026-10-09


class Reranker:
    def __init__(self, name: str = RERANK_MODEL, revision: str = RERANK_REVISION):
        self.name, self.revision = name, revision
        self._model = None

    @property
    def model(self):
        if self._model is None:
            from sentence_transformers import CrossEncoder

            quiet()

            threads = os.environ.get("ASSISTANT_TORCH_THREADS")
            if threads:
                import torch
                torch.set_num_threads(int(threads))
            self._model = CrossEncoder(self.name, revision=self.revision, device="cpu")
        return self._model

    def rerank(self, query: str, candidates: list, k: int = 5) -> list[Hit]:
        """candidates: chunks (with .chunk_id and .text). Returns the k best by the cross-encoder's score."""
        if not candidates:
            return []
        scores = self.model.predict([(query, c.text) for c in candidates], batch_size=16)
        order = sorted(range(len(candidates)), key=lambda i: (-float(scores[i]), candidates[i].chunk_id))
        return [Hit(candidates[i].chunk_id, round(float(scores[i]), 4), rank) for rank, i in enumerate(order[:k], 1)]
