"""Assemble the context: the passages that go into the prompt, within a token budget.

As in the course's policy assistant: keep the search order, drop near-duplicates (Jaccard
similarity of their word sets >= 0.9, heading line left out), and stop before the budget is used up
(tokens estimated as characters / 4). Two versions of the same section are NEVER merged as
near-duplicates: they differ in exactly what matters ($775 or $1,075), and the date decides.
The budget is 2,000 tokens, not the course's 1,500: a regulation's paragraphs are long, and five
chunks of up to 200 words need about 1,900.

Each passage starts with a header the model can see: its ID, the section, the version's dates and
paragraphs. The answer cites the IDs, and rule 4 of the prompt asks it to name the version.
"""

import math
import re
from dataclasses import dataclass, field

from .snapshot import HISTORY_START

BUDGET = 2000
SIMILAR = 0.9


def estimate_tokens(text: str) -> int:
    return math.ceil(len(text) / 4)


def word_set(text: str) -> set[str]:
    body = text.split("\n", 1)[1] if "\n" in text else text
    return set(re.findall(r"\w+", body.lower()))


def jaccard(a: str, b: str) -> float:
    wa, wb = word_set(a), word_set(b)
    return len(wa & wb) / len(wa | wb) if wa | wb else 1.0


def version_dates(chunk) -> str:
    start = f"{chunk.effective_from} or earlier" if chunk.effective_from == HISTORY_START else chunk.effective_from
    end = chunk.effective_to or "today (no later version)"
    return f"version in force from {start} to {end}"


def format_passage(chunk) -> str:
    return (f"[{chunk.chunk_id}] 14 CFR {chunk.section} | {version_dates(chunk)} | "
            f"paragraphs: {chunk.paragraphs or '-'}\n{chunk.text}")


@dataclass
class Context:
    chunks: list = field(default_factory=list)
    dropped: list = field(default_factory=list)     # (chunk_id, reason)
    tokens: int = 0

    @property
    def ids(self) -> list[str]:
        return [c.chunk_id for c in self.chunks]

    def text(self) -> str:
        return "\n\n".join(format_passage(c) for c in self.chunks)


def assemble(chunks: list, budget: int = BUDGET) -> Context:
    ctx = Context()
    for chunk in chunks:
        twin = next((c for c in ctx.chunks if c.section != chunk.section and jaccard(c.text, chunk.text) >= SIMILAR), None)
        if twin is not None:
            ctx.dropped.append((chunk.chunk_id, f"near-duplicate of {twin.chunk_id}"))
            continue
        cost = estimate_tokens(format_passage(chunk))
        if ctx.tokens + cost > budget:
            ctx.dropped.append((chunk.chunk_id, "over budget"))
            continue
        ctx.chunks.append(chunk)
        ctx.tokens += cost
    return ctx
