"""The embedding model: turn a text into 384 numbers, so that texts with similar meaning are close.

intfloat/multilingual-e5-small (MIT licence, 118 million parameters, about 470 MB), the model of the
course's policy assistant, pinned to the same revision. It runs on your computer (CPU) and is
downloaded once into the Hugging Face cache (~/.cache/huggingface). e5 models expect "query: "
before a question and "passage: " before a text to search.

An index must be searched with the SAME model and revision that built it: store.py records them.
"""

import os

from .quiet import quiet

import numpy as np

from .dense import normalise

LOCAL_MODEL = "intfloat/multilingual-e5-small"
LOCAL_REVISION = "614241f622f53c4eeff9890bdc4f31cfecc418b3"   # the model's Hugging Face commit, 2026-10-09


class LocalEmbedder:
    def __init__(self, name: str = LOCAL_MODEL, revision: str = LOCAL_REVISION):
        self.name, self.revision = name, revision
        self._model = None

    @property
    def model(self):
        if self._model is None:
            from sentence_transformers import SentenceTransformer  # slow import: only when needed

            quiet()

            threads = os.environ.get("ASSISTANT_TORCH_THREADS")
            if threads:
                import torch
                torch.set_num_threads(int(threads))
            self._model = SentenceTransformer(self.name, revision=self.revision, device="cpu")
        return self._model

    def _encode(self, texts: list[str]) -> np.ndarray:
        return normalise(self.model.encode(list(texts), batch_size=16, normalize_embeddings=True))

    def embed_queries(self, texts: list[str]) -> np.ndarray:
        return self._encode(["query: " + t for t in texts])

    def embed_passages(self, texts: list[str]) -> np.ndarray:
        return self._encode(["passage: " + t for t in texts])
