"""The snapshot: two parts of the US Code of Federal Regulations at every date they changed.

regulations/ holds the eCFR's answers, exactly as they came, fetched once on 2026-10-09:
  title-14_part-250_DATE.xml   14 CFR Part 250 (oversales, denied boarding compensation) on DATE
  title-14_part-254_DATE.xml   14 CFR Part 254 (domestic baggage liability) on DATE
  versions_part-250.json, versions_part-254.json   the eCFR's list of section versions
  titles.json                  the date the eCFR was up to date to when we fetched it
  sources.csv                  one row per file: its URL, date, time of fetching and SHA-256
  SHA256SUMS                   the checksums that `load_snapshot()` checks first

The eCFR's history starts on 2017-01-01: the snapshot cannot show a version before that date.
It is up to date to CURRENT_TO: a change made after that date is not in it.

The CFR is a work of the US government, in the public domain. The eCFR is an editorial compilation,
"not an official legal edition of the CFR" (eCFR). See DATASET.md.
"""

import csv
import hashlib
import json
from dataclasses import dataclass
from pathlib import Path

PROJECT = Path(__file__).resolve().parent.parent
REGULATIONS = PROJECT / "regulations"
TITLE = 14
HISTORY_START = "2017-01-01"    # the first date the eCFR's point-in-time history can show
PARTS = ("250", "254")
PART_NAMES = {"250": "Oversales", "254": "Domestic baggage liability"}
ATTRIBUTION = ("Source: eCFR (ecfr.gov), 14 CFR Parts 250 and 254, fetched 2026-10-09. US government work, "
               "public domain. The eCFR is not an official legal edition of the CFR.")


class SnapshotChanged(Exception):
    """A snapshot file does not match its checksum."""


@dataclass(frozen=True)
class SourceFile:
    file: str
    kind: str           # part, versions or titles
    part: str           # 250, 254, or "" for titles.json
    date: str           # the date the part is shown "on" (part files only)
    url: str
    retrieved_at: str   # when we fetched it (UTC)
    sha256: str


@dataclass(frozen=True)
class Snapshot:
    files: tuple
    history_start: str   # the first date in the snapshot (the eCFR's history starts here)
    current_to: str      # the eCFR was up to date to this date when we fetched it
    retrieved: str       # the day we fetched it

    def dates(self, part: str) -> list[str]:
        return sorted({f.date for f in self.files if f.kind == "part" and f.part == part})

    def xml(self, part: str, date: str) -> bytes:
        return (REGULATIONS / f"title-{TITLE}_part-{part}_{date}.xml").read_bytes()

    def versions_api(self, part: str) -> list[dict]:
        return json.loads((REGULATIONS / f"versions_part-{part}.json").read_text())["content_versions"]


def check_files(folder: Path = REGULATIONS) -> None:
    for line in (folder / "SHA256SUMS").read_text().splitlines():
        expected, name = line.split()
        actual = hashlib.sha256((folder / name).read_bytes()).hexdigest()
        if actual != expected:
            raise SnapshotChanged(f"{name} has SHA-256 {actual[:12]}…, expected {expected[:12]}…. "
                                  "Unzip the project again, or run: python scripts/check_snapshot.py")


def load_snapshot(folder: Path = REGULATIONS, check: bool = True) -> Snapshot:
    if check:
        check_files(folder)
    with open(folder / "sources.csv", encoding="utf-8") as f:
        files = tuple(SourceFile(**row) for row in csv.DictReader(f))
    titles = json.loads((folder / "titles.json").read_text())
    current_to = next(t for t in titles["titles"] if t["number"] == TITLE)["up_to_date_as_of"]
    parts = [f for f in files if f.kind == "part"]
    return Snapshot(files, min(f.date for f in parts), current_to, max(f.retrieved_at for f in files)[:10])
