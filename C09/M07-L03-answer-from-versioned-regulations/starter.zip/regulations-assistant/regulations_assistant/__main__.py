"""The command line of the regulations assistant.

    python -m regulations_assistant snapshot                 the files, their dates and checksums
    python -m regulations_assistant questions [--kind KIND]  the 34 dated questions
    python -m regulations_assistant versions [SECTION]       the versions of the sections and their dates
    python -m regulations_assistant ingest [--embedder none] build index.sqlite (chunks, BM25, e5 vectors)
    python -m regulations_assistant chunks SECTION           the chunks of every version of one section
    python -m regulations_assistant search "QUESTION" [--as-of DATE|none] [--method rerank] [--k 5]
    python -m regulations_assistant ask Q01 | "QUESTION" [--as-of DATE] [--no-date-filter] [--model chat-small]
                                         [--method rerank] [--closed-book]
    python -m regulations_assistant eval [--method rerank] [--no-date-filter] [--answers --model chat-small] [--ids Q01,Q02]

A question ID (Q01) brings its own date. A question in quotes uses --as-of, or the course's today, 2026-10-09.
"""

import argparse
import statistics
from pathlib import Path

from .snapshot import PART_NAMES, PROJECT, REGULATIONS, load_snapshot

INDEX = PROJECT / "index.sqlite"
TODAY = "2026-10-09"


def short(text: str, n: int = 90) -> str:
    text = " ".join(text.split())
    return text if len(text) <= n else text[: n - 1] + "…"


def cmd_snapshot(args) -> None:
    snap = load_snapshot()
    for part, name in PART_NAMES.items():
        print(f"14 CFR Part {part} ({name}): {len(snap.dates(part))} files, on {', '.join(snap.dates(part))}")
    print(f"{len(snap.files)} files | fetched {snap.retrieved} | history from {snap.history_start} | "
          f"eCFR up to date to {snap.current_to} | checksums OK ({REGULATIONS.name}/SHA256SUMS)")


def cmd_questions(args) -> None:
    from .evaluate import load_questions

    qs = [q for q in load_questions().values() if not args.kind or q.kind == args.kind]
    for q in qs:
        print(f"{q.id} {q.as_of} {q.kind:11} {short(q.question, 80)}")
    print(f"{len(qs)} questions")


def cmd_versions(args) -> None:
    from .versions import build_versions

    versions = [v for v in build_versions(load_snapshot()) if not args.section or v.section == args.section]
    if not versions:
        raise SystemExit(f"No section {args.section}. Sections: python -m regulations_assistant versions")
    for v in versions:
        note = "  (amendment published, not yet in force)" if v.pending else ""
        print(f"{v.section:7} {v.effective_from} to {v.effective_to or 'today     '} | {len(v.text.split()):4} words | "
              f"{short(v.heading, 48)}{note}")
    sections = len({v.section for v in versions})
    print(f"{len(versions)} versions of {sections} section{'s' if sections > 1 else ''}")


def open_store(args):
    from .store import Store

    path = Path(args.index)
    if not path.exists():
        raise SystemExit(f"No index at {path}. Run: python -m regulations_assistant ingest")
    return Store(path)


def cmd_ingest(args) -> None:
    import time

    from .store import Store

    path = Path(args.index)
    if path.exists():
        path.unlink()
    embedder = None
    if args.embedder != "none":
        from .embed import LocalEmbedder

        embedder = LocalEmbedder()
    start = time.monotonic()
    n_versions, n_chunks = Store(path).build(load_snapshot(), embedder)
    print(f"index {path.name}: {n_chunks} chunks from {n_versions} section versions | "
          f"embeddings {embedder.name if embedder else 'none'} | {time.monotonic() - start:.1f} s")


def cmd_chunks(args) -> None:
    store = open_store(args)
    chunks = [c for c in store.chunks() if c.section == args.section]
    if not chunks:
        raise SystemExit(f"No chunks for {args.section}. Sections: python -m regulations_assistant versions")
    for c in chunks:
        print(f"{c.chunk_id} {c.effective_from} to {c.effective_to or 'today     '} #{c.position} "
              f"{c.paragraphs or '-':12} {len(c.text.split()):3} words | {short(c.text.split(chr(10), 1)[-1], 44)}")
    print(f"{len(chunks)} chunks")


def make_retriever(args, store):
    from .search import Retriever

    embedder = reranker = None
    if args.method in ("dense", "hybrid", "rerank"):
        from .embed import LocalEmbedder

        embedder = LocalEmbedder()
    if args.method == "rerank":
        from .rerank import Reranker

        reranker = Reranker()
    return Retriever(store, embedder, reranker)


def cmd_search(args) -> None:
    from .filters import Filters

    store = open_store(args)
    as_of = None if args.as_of == "none" else (args.as_of or TODAY)
    for r in make_retriever(args, store).search(args.query, args.method, args.k, Filters(as_of)):
        c = r.chunk
        print(f"{r.rank}. {r.score:>8.4f}  [{c.chunk_id}] 14 CFR {c.section:6} {c.paragraphs or '-':8} "
              f"{c.effective_from} to {c.effective_to or 'today'}")
    print(f"{args.method}, top {args.k}, date filter: {as_of or 'off'}")


def make_provider():
    from .config import Settings, make_provider as make

    return make(Settings.from_env())


def cmd_ask(args) -> None:
    from .assistant import ask
    from .config import Settings
    from .evaluate import load_questions
    from .sources import render

    qs = load_questions()
    if args.question in qs:
        question, as_of = qs[args.question].question, args.as_of or qs[args.question].as_of
    else:
        question, as_of = args.question, args.as_of or TODAY
    model = args.model or Settings.from_env().model
    if args.closed_book:
        from .answer import build_closed_book_request

        c = make_provider().complete(build_closed_book_request(question, as_of, model))
        print(f"Question ({as_of}): {question}\nThe model alone, without the regulations:\n{c.text}")
        print(f"\n{c.model} | {c.input_tokens} tokens in, {c.output_tokens} out | {c.latency_s} s")
        return
    store = open_store(args)
    snapshot = load_snapshot()
    result = ask(question, as_of, make_retriever(args, store), make_provider(), snapshot, model, args.method, args.k,
                 args.prompt, date_aware=not args.no_date_filter)
    print(f"Question ({as_of}): {question}")
    if result.request is None:
        print("No search and no model call: the date is outside the snapshot.\n")
        print(render(result.answer, [], store, as_of, snapshot))
        return
    print(f"Date filter: {'off' if args.no_date_filter else as_of}")
    print(f"Passages: {', '.join(result.context.ids) or 'none'} ({result.context.tokens} tokens, estimated)")
    for cid, reason in result.context.dropped:
        print(f"  dropped {cid}: {reason}")
    if result.completion is not None and result.completion.note:
        print(f"Note: {result.completion.note}")
    if result.problem:
        print(f"No answer: {result.problem}")
        return
    print()
    print(render(result.answer, result.checks, store, as_of, snapshot))
    c = result.completion
    print(f"\n{c.model} | {c.input_tokens} tokens in, {c.output_tokens} out | {c.latency_s} s")


def cmd_eval(args) -> None:
    from .evaluate import answer_scores, cost, load_questions, percentile, retrieval_scores, summarise
    from .filters import Filters

    store = open_store(args)
    retriever = make_retriever(args, store)
    questions = load_questions()
    qs = list(questions.values())
    if args.ids:
        wanted = set(args.ids.split(","))
        qs = [q for q in qs if q.id in wanted]
    mode = "date filter off" if args.no_date_filter else "date filter on"
    if not args.answers:
        rows = []
        for q in qs:
            filters = Filters(None if args.no_date_filter else q.as_of)
            rows.append(retrieval_scores(q, [r.chunk for r in retriever.search(q.question, args.method, args.k, filters)],
                                         args.k))
        s = summarise(rows)
        print(f"{args.method}, top {args.k}, {mode}: hit@{args.k} {s['hit']:.3f} | recall@{args.k} {s['recall']:.3f} | "
              f"precision@{args.k} {s['precision']:.3f} | MRR {s['mrr']:.3f} ({s['questions']} questions with "
              f"relevant passages)")
        print(f"  chunks not in force on the question's date, in the top {args.k}: {s['out_of_force']} "
              f"(in {s['with_out_of_force']} of {len(rows)} questions); first chunk from another version of the "
              f"right paragraph: {s['top1_other_version']}")
        return
    from .assistant import ask

    provider, snapshot = make_provider(), load_snapshot()
    scores, completions, flagged, claims, replayed = [], [], 0, 0, []
    for q in qs:
        res = ask(q.question, q.as_of, retriever, provider, snapshot, args.model, args.method, args.k, args.prompt,
                  date_aware=not args.no_date_filter)
        scores.append(answer_scores(q, res.answer, store))
        if res.completion is not None:
            completions.append(res.completion)
            if res.completion.note:
                replayed.append(q.id)
        claims += len(res.checks)
        flagged += sum(1 for c in res.checks if not c.ok)
    answerable = [s for s in scores if not questions[s["id"]].abstain]
    abstain = [s for s in scores if questions[s["id"]].abstain]
    cited = sum(s["cited"] for s in scores)
    in_force = sum(s["cited_in_force"] for s in scores)
    print(f"{args.model}, {args.method}, top {args.k}, {args.prompt}, {mode}: {len(scores)} questions")
    print(f"  answerable, correct:          {sum(s['correct'] for s in answerable)}/{len(answerable)}")
    print(f"  answerable, abstained:        {sum(s['abstained'] for s in answerable)}/{len(answerable)}")
    print(f"  no answer expected, correct:  {sum(s['correct'] for s in abstain)}/{len(abstain)}")
    print(f"  shown but wrong:              {sum(s['shown_wrong'] for s in scores)}  "
          f"({', '.join(s['id'] for s in scores if s['shown_wrong']) or 'none'})")
    print(f"  citations of the right version: {in_force}/{cited}"
          + (f" ({in_force / cited:.1%})" if cited else ""))
    print(f"  claims flagged by the checks: {flagged} of {claims}")
    if completions:
        tin = [c.input_tokens for c in completions]
        tout = [c.output_tokens for c in completions]
        lat = [c.latency_s for c in completions]
        each = statistics.median(cost(args.model, i, o) for i, o in zip(tin, tout))
        print(f"  model calls:                  {len(completions)} (the other questions were answered without one)")
        print(f"  tokens in / out (median):     {statistics.median(tin):.0f} / {statistics.median(tout):.0f}")
        print(f"  latency median / p95:         {statistics.median(lat):.2f} / {percentile(lat, 95):.2f} s (recorded)")
        print(f"  cost per question (median):   US${each:.5f}")
    if replayed:
        print(f"  replayed with other passages: {', '.join(replayed)} (these answer measures describe the recorded search)")


def main(argv=None) -> None:
    parser = argparse.ArgumentParser(prog="python -m regulations_assistant", description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--index", default=str(INDEX), help="the index file (default: index.sqlite)")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("snapshot").set_defaults(func=cmd_snapshot)
    p = sub.add_parser("questions")
    p.add_argument("--kind")
    p.set_defaults(func=cmd_questions)
    p = sub.add_parser("versions")
    p.add_argument("section", nargs="?")
    p.set_defaults(func=cmd_versions)
    p = sub.add_parser("ingest")
    p.add_argument("--embedder", default="e5", choices=["e5", "none"])
    p.set_defaults(func=cmd_ingest)
    p = sub.add_parser("chunks")
    p.add_argument("section")
    p.set_defaults(func=cmd_chunks)
    for name, func in (("search", cmd_search), ("ask", cmd_ask), ("eval", cmd_eval)):
        p = sub.add_parser(name)
        if name == "search":
            p.add_argument("query")
            p.add_argument("--as-of", help="YYYY-MM-DD, or none for no date filter (default: 2026-10-09)")
        if name == "ask":
            p.add_argument("question", help="a question ID (Q01) or a question in quotes")
            p.add_argument("--as-of", help="the question's date, YYYY-MM-DD (default: the question's own date, "
                                           "or 2026-10-09)")
        p.add_argument("--method", default="rerank", choices=["bm25", "dense", "hybrid", "rerank"])
        p.add_argument("--k", type=int, default=5)
        if name in ("ask", "eval"):
            p.add_argument("--model", default=None if name == "ask" else "chat-small")
            p.add_argument("--prompt", default="answer_v1")
            p.add_argument("--no-date-filter", action="store_true",
                           help="search every version, and skip the coverage check (to see what goes wrong)")
        if name == "ask":
            p.add_argument("--closed-book", action="store_true", help="the model alone, without the regulations")
        if name == "eval":
            p.add_argument("--answers", action="store_true", help="also ask the model (recorded answers by default)")
            p.add_argument("--ids", help="only these question IDs, for example Q01,Q02")
        p.set_defaults(func=func)
    args = parser.parse_args(argv)
    args.func(args)


if __name__ == "__main__":
    main()
