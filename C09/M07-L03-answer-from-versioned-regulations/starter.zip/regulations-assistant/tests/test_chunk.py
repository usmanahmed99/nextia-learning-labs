from .conftest import need


def test_chunks_are_stable_and_one_per_version(snapshot):
    need("versions")
    chunk = need("chunk")
    from regulations_assistant.versions import build_versions

    versions = build_versions(snapshot)
    first, again = chunk.chunk_all(versions), chunk.chunk_all(versions)
    assert [c.chunk_id for c in first] == [c.chunk_id for c in again]
    assert len(first) == 134 and len({c.chunk_id for c in first}) == 134
    assert max(len(c.text.split()) for c in first) <= chunk.MAX_WORDS + 10        # + the heading line
    same = [c for c in first if c.section == "250.5" and c.position == 0]
    assert len(same) == 6 and len({c.chunk_id for c in same}) == 6               # 6 versions, 6 IDs
    reserved = [c for c in first if c.section == "250.7" and c.version == "2017-01-01"]
    assert [c.text for c in reserved] == ["14 CFR § 250.7 [Reserved]"]


def test_every_chunk_carries_its_version(store):
    c = next(c for c in store.chunks() if c.section == "250.5" and c.version == "2021-04-13" and "(b)" in c.paragraphs)
    assert (c.effective_from, c.effective_to) == ("2021-04-13", "2021-08-01")
    assert c.url == "https://www.ecfr.gov/on/2021-04-13/title-14/section-250.5"
    assert c.in_force("2021-06-01") and not c.in_force("2021-08-02")
