import re

from .conftest import need


def test_the_versions_match_the_ecfr_list(snapshot):
    versions = need("versions").build_versions(snapshot)
    assert len(versions) == 44
    for part in ("250", "254"):
        listed = {(v["identifier"], max(v["date"], snapshot.history_start)) for v in snapshot.versions_api(part)}
        assert {(v.section, v.effective_from) for v in versions if v.part == part} == listed


def test_one_section_over_time(snapshot):
    versions = need("versions")
    timeline = [(v.effective_from, v.effective_to, re.findall(r"\$[\d,]+\d", v.text))
                for v in versions.build_versions(snapshot) if v.section == "254.4"]
    assert timeline == [("2017-01-01", "2021-01-12", ["$3,500"]), ("2021-01-13", "2021-04-12", ["$3,500"]),
                        ("2021-04-13", "2024-10-23", ["$3,800"]), ("2024-10-24", "2025-01-21", ["$3,800"]),
                        ("2025-01-22", "", ["$4,700"])]


def test_a_published_amendment_is_not_yet_the_rule(snapshot):
    versions = need("versions")
    v = versions.in_force(versions.build_versions(snapshot), "250.5", "2024-12-20")
    assert v.pending.startswith("Link to an amendment published at 89 FR 84818")
    assert "$775" in v.text and "$1,075" not in v.text


def test_coverage(snapshot):
    coverage = need("versions").coverage
    assert coverage("2016-12-31", snapshot) == "before"
    assert coverage("2017-01-01", snapshot) == "inside"
    assert coverage("2026-10-07", snapshot) == "inside"
    assert coverage("2026-10-09", snapshot) == "after"       # the course's today: two days after the eCFR's date
