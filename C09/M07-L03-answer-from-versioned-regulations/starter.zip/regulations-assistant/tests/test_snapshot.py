import shutil

import pytest

from regulations_assistant.snapshot import REGULATIONS, SnapshotChanged, load_snapshot


def test_the_snapshot_is_the_tested_one(snapshot):
    assert len(snapshot.files) == 16
    assert (snapshot.history_start, snapshot.current_to, snapshot.retrieved) == ("2017-01-01", "2026-10-07", "2026-10-09")
    assert snapshot.dates("254") == ["2017-01-01", "2021-01-13", "2021-04-13", "2024-10-24", "2025-01-22", "2026-10-07"]
    assert all(f.url.startswith("https://www.ecfr.gov/api/versioner/v1/") for f in snapshot.files)


def test_a_changed_file_stops_the_load(tmp_path):
    copy = tmp_path / "regulations"
    shutil.copytree(REGULATIONS, copy)
    path = copy / "title-14_part-254_2025-01-22.xml"
    path.write_text(path.read_text(encoding="utf-8").replace("$4,700", "$7,400", 1), encoding="utf-8")
    with pytest.raises(SnapshotChanged):
        load_snapshot(copy)
