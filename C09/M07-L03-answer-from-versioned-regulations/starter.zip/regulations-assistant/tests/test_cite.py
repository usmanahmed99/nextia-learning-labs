"""Citation checks. The constructed cases are labelled so; the version checks use a real recording."""

from .conftest import need

from regulations_assistant.answer import Answer, Claim
from regulations_assistant.cite import check_claim


def chunk(store, section, version, paragraph="(a)"):
    return next(c.chunk_id for c in store.chunks() if c.section == section and c.version == version
                and (paragraph in c.paragraphs.split(",") or not c.paragraphs))


def test_constructed_citation_problems(store):
    old = chunk(store, "250.5", "2021-08-02")
    context = [old]
    claim = "Compensation shall be at least 200 percent of the fare or ${}, whichever is lower."
    assert check_claim(Claim(claim.format("775"), ("000000000000",)), store, context).problems == \
        ["missing_id:000000000000"]                                                  # constructed: made-up ID
    assert check_claim(Claim(claim.format("1,075"), (old,)), store, context).problems == \
        ["number_not_found:1075"]                                                    # constructed: wrong number
    assert check_claim(Claim(claim.format("775"), ()), store, context).problems == ["no_citation"]


def test_the_course_checks_miss_a_wrong_version_but_check_versions_does_not(store):
    """Constructed: a right number from the 2021 version, cited for a flight in 2025."""
    sources = need("sources")
    old = chunk(store, "250.5", "2021-08-02")
    claim = Claim("Compensation shall be at least 200 percent of the fare or $775, whichever is lower.", (old,))
    answer = Answer(True, "At least 200 percent of the fare or $775, whichever is lower.", (claim,))
    assert check_claim(answer.claims[0], store, [old]).ok                            # every course check passes
    assert sources.check_versions(answer, store, "2025-07-04") == [old]              # the version check does not
    assert sources.check_versions(answer, store, "2022-06-10") == []
