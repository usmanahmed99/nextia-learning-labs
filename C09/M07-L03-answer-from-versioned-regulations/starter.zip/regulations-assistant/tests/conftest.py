import sys
from pathlib import Path

import pytest

PROJECT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT))


@pytest.fixture(autouse=True)
def mock_provider(monkeypatch):
    """Tests never call a real provider and never read a key, whatever .env says."""
    monkeypatch.setenv("ASSISTANT_PROVIDER", "mock")
    monkeypatch.delenv("ASSISTANT_API_KEY", raising=False)


def need(module: str):
    return pytest.importorskip(f"regulations_assistant.{module}",
                               reason=f"write regulations_assistant/{module}.py first")


@pytest.fixture(scope="session")
def snapshot():
    from regulations_assistant.snapshot import load_snapshot

    return load_snapshot()


@pytest.fixture(scope="session")
def store(tmp_path_factory, snapshot):
    """An index of the whole snapshot with BM25 only (no embedding model needed, about 1 second)."""
    need("versions")
    need("chunk")
    from regulations_assistant.store import Store

    s = Store(tmp_path_factory.mktemp("index") / "index.sqlite")
    s.build(snapshot)
    return s
