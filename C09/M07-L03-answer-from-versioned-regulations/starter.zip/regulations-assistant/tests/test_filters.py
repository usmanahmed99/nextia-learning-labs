from dataclasses import dataclass

from regulations_assistant.filters import Filters


@dataclass
class C:
    effective_from: str
    effective_to: str


def test_the_version_in_force_and_its_last_day():
    old, new = C("2021-08-02", "2024-10-23"), C("2025-01-22", "")
    on = lambda day, chunk: Filters(day).allows(chunk)  # noqa: E731
    assert on("2024-10-23", old) and not on("2024-10-24", old)         # the last day is included
    assert not on("2025-01-21", new) and on("2025-01-22", new) and on("2030-01-01", new)   # "" = still in force
    assert not on("2019-01-01", old)
    assert Filters(None).allows(old) and Filters(None).allows(new)     # no date: no filter
