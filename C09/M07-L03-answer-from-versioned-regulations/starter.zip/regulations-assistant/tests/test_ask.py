import pytest

from .conftest import need

from regulations_assistant.evaluate import load_questions
from regulations_assistant.providers import MockProvider

QS = load_questions()


@pytest.fixture(scope="module")
def retriever(store):
    need("sources")
    from regulations_assistant.search import Retriever

    return Retriever(store)


def ask(retriever, snapshot, qid, **kw):
    from regulations_assistant.assistant import ask

    q = QS[qid]
    return ask(q.question, q.as_of, retriever, MockProvider(), snapshot, "chat-small", "bm25", **kw)


def test_a_recorded_answer_replays_silently_with_the_version_in_force(retriever, snapshot):
    result = ask(retriever, snapshot, "Q04")                       # 20 December 2024: published, not in force
    assert result.completion.note == ""
    assert "$775" in result.answer.answer and "1,075" not in result.answer.text()
    assert result.wrong_versions == []


def test_a_date_before_the_snapshot_gets_no_answer_and_no_model_call(retriever, snapshot):
    result = ask(retriever, snapshot, "Q28")
    assert result.request is None and not result.answer.answerable
    assert "history starts on 2017-01-01" in result.answer.answer


def test_the_answer_card_shows_the_version_and_its_dates(retriever, snapshot, store):
    sources = need("sources")
    result = ask(retriever, snapshot, "Q13")
    card = sources.render(result.answer, result.checks, store, "2023-11-20", snapshot)
    assert "version in force 2021-04-13 to 2024-10-23" in card
    assert "https://www.ecfr.gov/on/2021-04-13/title-14/section-254.4" in card
    assert "not legal advice" in card


def test_an_unrecorded_question_says_so(retriever, snapshot):
    from regulations_assistant.assistant import ask as ask_any

    result = ask_any("Can I bring my dog?", "2026-01-01", retriever, MockProvider(), snapshot, "chat-small", "bm25")
    assert result.answer is None and result.problem.startswith("No recording for this request")
