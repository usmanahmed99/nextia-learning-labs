from dataclasses import dataclass

from regulations_assistant.answer import Answer, Claim
from regulations_assistant.evaluate import Question, answer_scores, load_questions, retrieval_scores


@dataclass
class C:
    section: str
    version: str
    paragraphs: str
    effective_from: str
    effective_to: str

    def in_force(self, day):
        return self.effective_from <= day and (not self.effective_to or day <= self.effective_to)


Q = Question("Q99", "?", "2022-06-10", "dated", "g", False, "$775", [r"775"], [r"1,?075"],
             [{"section": "250.5", "version": "2021-08-02", "paragraph": "(a)"}], "")


def test_retrieval_scores_count_only_the_right_version():
    wrong = C("250.5", "2025-01-22", "(a)", "2025-01-22", "")          # the same paragraph, another version
    right = C("250.5", "2021-08-02", "(a)", "2021-08-02", "2024-10-23")
    other = C("250.9", "2021-04-13", "(b)", "2021-04-13", "2024-10-23")
    s = retrieval_scores(Q, [wrong, other, right, other, other], 5)
    assert (s["hit"], s["recall"], s["precision"], s["rr"]) == (1.0, 1.0, 0.2, 1 / 3)
    assert (s["out_of_force"], s["other_versions"], s["top1_other_version"]) == (1, 1, True)


def test_answer_scores():
    right = Answer(True, "$775, in the version in force from 2021-08-02.", (Claim("$775", ("x",)),))
    wrong = Answer(True, "$1,075.", ())
    abstained = Answer(False, "The regulations in the passages do not say.", ())
    assert answer_scores(Q, right)["correct"]
    assert answer_scores(Q, wrong)["shown_wrong"]
    s = answer_scores(Q, abstained)
    assert s["abstained"] and not s["correct"] and not s["shown_wrong"]


def test_the_question_set(store):
    qs = load_questions()
    assert len(qs) == 34 and sum(1 for q in qs.values() if q.relevant) == 26
    for q in qs.values():
        for p in q.relevant:
            found = [c for c in store.chunks() if c.section == p["section"] and c.version == p["version"]]
            assert found and found[0].in_force(q.as_of), (q.id, p)
