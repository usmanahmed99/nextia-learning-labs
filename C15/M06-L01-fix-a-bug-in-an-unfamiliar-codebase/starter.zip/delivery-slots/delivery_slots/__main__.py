import sys

from delivery_slots.cli import main

sys.exit(main())
