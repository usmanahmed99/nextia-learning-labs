"""Postcodes as customers type them, made tidy."""


def normalise(postcode: str) -> str:
    """Capital letters and single spaces, as on an envelope.

    " ls12  2ab " -> "LS12 2AB". A postcode typed without a space keeps no space:
    "ls53qr" -> "LS53QR".
    """
    return " ".join(postcode.upper().split())
