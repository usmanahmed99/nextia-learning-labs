"""The slot plan, and the slots of one zone on one day.

data/slot-plan.csv lists the slots that each zone has in a normal week: the
weekdays, the start and end times, and how many deliveries fit in the slot
(its capacity). Orders for a day close at 20:00 the evening before (the
cut-off), so that the depot can load the vans at night.
"""

import csv
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta
from pathlib import Path

from delivery_slots.bookings import Booking

CUTOFF = time(20, 0)
WEEKDAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]


@dataclass(frozen=True)
class PlanRow:
    zone: str
    weekdays: frozenset[str]
    start: time
    end: time
    capacity: int


@dataclass(frozen=True)
class Slot:
    zone: str
    day: date
    start: time
    end: time
    capacity: int
    booked: int
    closed: bool

    @property
    def places_left(self) -> int:
        return max(self.capacity - self.booked, 0)

    @property
    def bookable(self) -> bool:
        return not self.closed and self.places_left > 0


def load_plan(path: Path) -> list[PlanRow]:
    """Read data/slot-plan.csv."""
    rows = []
    with open(path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            rows.append(
                PlanRow(
                    zone=row["zone"].strip(),
                    weekdays=frozenset(row["weekdays"].split()),
                    start=time.fromisoformat(row["start"]),
                    end=time.fromisoformat(row["end"]),
                    capacity=int(row["capacity"]),
                )
            )
    return rows


def cutoff_for(day: date) -> datetime:
    """The moment when orders for `day` close: 20:00 the evening before."""
    return datetime.combine(day - timedelta(days=1), CUTOFF)


def slots_for(
    zone: str,
    day: date,
    plan: list[PlanRow],
    bookings: list[Booking],
    now: datetime,
) -> list[Slot]:
    """The slots of `zone` on `day`, earliest first, with the places left."""
    weekday = WEEKDAYS[day.weekday()]
    closed = now >= cutoff_for(day)
    slots = []
    for row in plan:
        if row.zone != zone or weekday not in row.weekdays:
            continue
        booked = sum(
            1
            for b in bookings
            if b.zone == zone and b.day == day and b.start == row.start
        )
        slots.append(Slot(zone, day, row.start, row.end, row.capacity, booked, closed))
    return sorted(slots, key=lambda s: s.start)
