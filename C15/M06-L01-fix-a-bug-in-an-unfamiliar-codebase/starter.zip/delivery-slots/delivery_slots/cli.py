"""The command line: list the slots, book a slot, print a driver's list.

    python -m delivery_slots slots "LS6 2AB" --day 2026-10-14
    python -m delivery_slots book L-40001 "LS6 2AB" --day 2026-10-14 --start 08:00
    python -m delivery_slots manifest --day 2026-10-14 --zone north

Exit codes: 0 done, 1 refused (unknown postcode, slot closed or full),
2 wrong arguments.
"""

import argparse
import sys
from dataclasses import dataclass
from datetime import date, datetime, time
from pathlib import Path

from delivery_slots import bookings, checkout, manifest, slots, zones
from delivery_slots.postcodes import normalise


@dataclass
class Data:
    zones: dict[str, str]
    plan: list[slots.PlanRow]
    bookings: list[bookings.Booking]
    bookings_path: Path


def load(folder: Path) -> Data:
    path = folder / "bookings.csv"
    return Data(
        zones=zones.load_zones(folder / "zones.csv"),
        plan=slots.load_plan(folder / "slot-plan.csv"),
        bookings=bookings.load_bookings(path),
        bookings_path=path,
    )


def day_text(day: date) -> str:
    """Tuesday 13 October 2026."""
    return f"{day:%A} {day.day} {day:%B %Y}"


def describe(slot: slots.Slot) -> str:
    if slot.closed:
        return "closed"
    if slot.places_left == 0:
        return "full"
    if slot.places_left == 1:
        return "1 place left"
    return f"{slot.places_left} places left"


def cmd_slots(args: argparse.Namespace, data: Data, now: datetime) -> int:
    zone = zones.zone_for(args.postcode, data.zones)
    found = slots.slots_for(zone, args.day, data.plan, data.bookings, now)
    print(f"{normalise(args.postcode)} is in zone {zone}.")
    if not found:
        print(f"Zone {zone} has no delivery slots on {day_text(args.day)}.")
        return 0
    cutoff = slots.cutoff_for(args.day)
    print(
        f"Slots on {day_text(args.day)} (orders close {cutoff:%A} at {cutoff:%H:%M}):"
    )
    for slot in found:
        print(f"  {slot.start:%H:%M}-{slot.end:%H:%M}  {describe(slot)}")
    return 0


def cmd_book(args: argparse.Namespace, data: Data, now: datetime) -> int:
    booking = checkout.book(
        args.order,
        args.postcode,
        args.day,
        args.start,
        zones=data.zones,
        plan=data.plan,
        bookings=data.bookings,
        now=now,
    )
    bookings.save_booking(data.bookings_path, booking)
    print(
        f"Booked order {booking.order}: {booking.postcode}, zone {booking.zone}, "
        f"{day_text(booking.day)} at {booking.start:%H:%M}."
    )
    return 0


def cmd_manifest(args: argparse.Namespace, data: Data, now: datetime) -> int:
    rows = manifest.for_day(data.bookings, args.day, args.zone)
    print(manifest.format_manifest(rows, args.day, args.zone, day_text))
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="delivery_slots", description="Larkfield's delivery slots."
    )
    parser.add_argument(
        "--data",
        type=Path,
        default=Path("data"),
        help="folder with zones.csv, slot-plan.csv and bookings.csv (default: data)",
    )
    parser.add_argument(
        "--now",
        type=datetime.fromisoformat,
        help="use this time instead of the clock, for example 2026-10-12T10:00",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("slots", help="list the slots for a postcode on a day")
    p.add_argument("postcode")
    p.add_argument("--day", type=date.fromisoformat, required=True)
    p.set_defaults(run=cmd_slots)

    p = sub.add_parser("book", help="book a slot for an order")
    p.add_argument("order")
    p.add_argument("postcode")
    p.add_argument("--day", type=date.fromisoformat, required=True)
    p.add_argument("--start", type=time.fromisoformat, required=True)
    p.set_defaults(run=cmd_book)

    p = sub.add_parser("manifest", help="print a driver's list for a day and a zone")
    p.add_argument("--day", type=date.fromisoformat, required=True)
    p.add_argument("--zone", required=True)
    p.set_defaults(run=cmd_manifest)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    now = args.now or datetime.now()
    data = load(args.data)
    try:
        return args.run(args, data, now)
    except (zones.UnknownPostcode, checkout.BookingError) as error:
        print(f"Error: {error}", file=sys.stderr)
        return 1
