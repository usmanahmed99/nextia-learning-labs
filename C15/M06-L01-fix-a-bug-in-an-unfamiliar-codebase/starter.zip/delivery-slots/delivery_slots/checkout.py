"""Book a slot for an order: what the shop's checkout page calls."""

from datetime import date, datetime, time

from delivery_slots.bookings import Booking
from delivery_slots.postcodes import normalise
from delivery_slots.slots import PlanRow, slots_for
from delivery_slots.zones import zone_for


class BookingError(ValueError):
    """The slot cannot be booked. The message says why, for the customer."""


def book(
    order: str,
    postcode: str,
    day: date,
    start: time,
    *,
    zones: dict[str, str],
    plan: list[PlanRow],
    bookings: list[Booking],
    now: datetime,
) -> Booking:
    """Check that the slot can be booked, and return the new booking.

    The caller saves it. Raises UnknownPostcode or BookingError.
    """
    zone = zone_for(postcode, zones)
    if any(b.order == order for b in bookings):
        raise BookingError(f"Order {order} already has a delivery slot.")
    slot = next(
        (s for s in slots_for(zone, day, plan, bookings, now) if s.start == start),
        None,
    )
    if slot is None:
        raise BookingError(
            f"Zone {zone} has no slot at {start:%H:%M} on {day:%A} {day.day} {day:%B}."
        )
    if slot.closed:
        raise BookingError(
            "Orders for this day are closed (cut-off 20:00 the day before)."
        )
    if slot.places_left == 0:
        raise BookingError("This slot is full. Please choose another one.")
    return Booking(order, normalise(postcode), zone, day, start)
