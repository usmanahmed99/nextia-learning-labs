"""Booked deliveries, kept in data/bookings.csv (one row per order)."""

import csv
from dataclasses import dataclass
from datetime import date, time
from pathlib import Path

FIELDS = ["order", "postcode", "zone", "day", "start"]


@dataclass(frozen=True)
class Booking:
    order: str
    postcode: str
    zone: str
    day: date
    start: time


def load_bookings(path: Path) -> list[Booking]:
    """Read the bookings file. No file yet means no bookings."""
    if not path.exists():
        return []
    with open(path, newline="", encoding="utf-8") as f:
        return [
            Booking(
                order=row["order"],
                postcode=row["postcode"],
                zone=row["zone"],
                day=date.fromisoformat(row["day"]),
                start=time.fromisoformat(row["start"]),
            )
            for row in csv.DictReader(f)
        ]


def save_booking(path: Path, booking: Booking) -> None:
    """Add one booking at the end of the bookings file."""
    new_file = not path.exists()
    with open(path, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS, lineterminator="\n")
        if new_file:
            writer.writeheader()
        writer.writerow(
            {
                "order": booking.order,
                "postcode": booking.postcode,
                "zone": booking.zone,
                "day": booking.day.isoformat(),
                "start": booking.start.strftime("%H:%M"),
            }
        )
