"""The driver's list: the bookings of one zone on one day, in slot order."""

from collections.abc import Callable
from datetime import date

from delivery_slots.bookings import Booking


def for_day(bookings: list[Booking], day: date, zone: str) -> list[Booking]:
    """The bookings of `zone` on `day`, by start time, then by order number."""
    rows = [b for b in bookings if b.day == day and b.zone == zone]
    return sorted(rows, key=lambda b: (b.start, b.order))


def format_manifest(
    rows: list[Booking], day: date, zone: str, day_text: Callable[[date], str]
) -> str:
    count = f"{len(rows)} deliver{'y' if len(rows) == 1 else 'ies'}"
    lines = [f"Zone {zone}, {day_text(day)}: {count}"]
    lines += [f"  {b.start:%H:%M}  {b.order}  {b.postcode}" for b in rows]
    return "\n".join(lines)
