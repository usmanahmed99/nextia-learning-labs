# delivery-slots

Larkfield's delivery time slots, per postcode zone. Larkfield's vans leave the
Leeds depot for three zones: city, north and west. Each zone has its own slots,
and each slot has a capacity: the number of deliveries that fit in it.
The shop's checkout page uses this package to show the slots to a customer and to book one.

Maintainers: Hana (delivery team) and Luis (delivery team).

## Set up

Python 3.12 or newer. The program needs only the standard library; the tests
need pytest.

```sh
python3 -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\Activate.ps1
python -m pip install -r requirements-lock.txt
python -m pytest
```

## Commands

Run every command in the project folder. `--now` replaces the clock, so that
you can see the slots as a customer saw them at a given time.

```sh
python -m delivery_slots --now 2026-10-12T10:00 slots "LS6 2AB" --day 2026-10-14
python -m delivery_slots --now 2026-10-12T10:00 book L-40001 "LS6 2AB" --day 2026-10-14 --start 08:00
python -m delivery_slots manifest --day 2026-10-14 --zone north
```

| Command | What it does |
|---|---|
| `slots POSTCODE --day DAY` | prints the postcode's zone and the zone's slots that day, with the places left |
| `book ORDER POSTCODE --day DAY --start HH:MM` | books the slot for an order and adds it to `data/bookings.csv` |
| `manifest --day DAY --zone ZONE` | prints the driver's list: the zone's bookings that day, in slot order |

Exit codes: 0 done, 1 refused (the message says why), 2 wrong arguments.

## Data

| File | What one row is |
|---|---|
| `data/zones.csv` | a postcode district (the part before the space, such as `LS6`) and its zone |
| `data/slot-plan.csv` | a slot in a normal week: zone, weekdays, start, end, capacity |
| `data/bookings.csv` | a booked delivery: order, postcode, zone, day, start (this week's export from the shop) |

## Rules

- Orders for a day close at 20:00 the evening before (the cut-off), so that the
  depot can load the vans at night.
- A slot with no places left is full.
- Customers may type a postcode with or without the space: `LS5 3QR` or `ls53qr`.
- The west zone has evening slots, 18:00 to 20:00, on Tuesdays and Thursdays.

## Issues

Customer support writes each problem as a file in `issues/`, with a number.

## About this project

Nextia Learning wrote this project for a case study of the course
AI-Assisted Software Development. Larkfield, its people, its customers and the
bookings are invented; the postcode districts are real districts of Leeds.

## Licence

MIT. See `LICENSE`.
