# Issue 12: no evening slots for LS12, although the delivery page promises them

Status: open
Reported by: Grace, customer support

A customer wrote to us on Monday morning. Her email, as she sent it:

> Hello,
>
> Your delivery page says that West Leeds gets evening deliveries on Tuesdays and
> Thursdays, 6 to 8 pm. I live in Armley, LS12 2AB, and I work during the day.
> This morning (Monday, about 10 o'clock) I ordered a garden bench, order L-40213.
> For Tuesday the checkout offered me only 8-10, 10-12 and 12-2. No evening slot
> at all. My sister in Burley, LS4, has an evening delivery booked for tomorrow,
> so the evening slots do exist.
>
> Can you deliver my bench on Tuesday evening, please?
>
> Ruth

What I checked: on the checkout page, `LS12 2AB` and Tuesday 13 October show the
same three daytime slots. Monday 10:00 is long before the 20:00 cut-off. The
order L-40213 is paid, and it has no delivery slot yet. I told Ruth that we will
come back to her today.

Hana and Luis are at the trade fair until Friday. Amira (help-desk tools) said
that she can look at it.
