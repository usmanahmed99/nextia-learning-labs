# Issue 3: "We do not deliver to LS53QR"

Status: closed (fixed in "Accept postcodes typed without a space")
Reported by: Grace, customer support

A customer in Kirkstall typed her postcode without the space, `LS53QR`, and
the checkout said "We do not deliver to LS53QR." With the space, `LS5 3QR`,
it works. Many customers type postcodes without the space, on phones most of all.

To reproduce:

    python -m delivery_slots slots LS53QR --day 2026-09-29

Expected: the west zone's slots. Observed: `Error: We do not deliver to LS53QR.`
