from delivery_slots.postcodes import normalise


def test_capital_letters_and_single_spaces():
    assert normalise(" ls6  2ab ") == "LS6 2AB"


def test_a_tidy_postcode_stays_the_same():
    assert normalise("LS1 4AP") == "LS1 4AP"


def test_a_postcode_without_a_space_keeps_no_space():
    assert normalise("ls53qr") == "LS53QR"
