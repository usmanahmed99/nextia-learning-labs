import shutil
from pathlib import Path

import pytest

DATA = Path(__file__).resolve().parents[1] / "data"


@pytest.fixture
def data_dir(tmp_path):
    """A copy of the zones and the slot plan, with no bookings yet."""
    for name in ("zones.csv", "slot-plan.csv"):
        shutil.copy(DATA / name, tmp_path / name)
    return tmp_path
