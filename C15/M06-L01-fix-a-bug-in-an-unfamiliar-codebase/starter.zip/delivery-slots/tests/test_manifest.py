from datetime import date, time

from delivery_slots.bookings import Booking
from delivery_slots.manifest import for_day, format_manifest

TUESDAY = date(2026, 9, 22)
BOOKINGS = [
    Booking("L-3", "LS5 3QR", "west", TUESDAY, time(8)),
    Booking("L-1", "LS4 2TE", "west", TUESDAY, time(8)),
    Booking("L-2", "LS1 4AP", "city", TUESDAY, time(8)),
    Booking("L-4", "LS13 4EX", "west", date(2026, 9, 24), time(8)),
]


def test_only_the_zone_and_the_day_in_slot_and_order_number_order():
    rows = for_day(BOOKINGS, TUESDAY, "west")
    assert [b.order for b in rows] == ["L-1", "L-3"]


def test_the_driver_sees_one_line_per_delivery():
    rows = for_day(BOOKINGS, TUESDAY, "west")
    text = format_manifest(rows, TUESDAY, "west", lambda d: d.isoformat())
    assert text == (
        "Zone west, 2026-09-22: 2 deliveries\n"
        "  08:00  L-1  LS4 2TE\n"
        "  08:00  L-3  LS5 3QR"
    )


def test_one_delivery_is_not_plural():
    rows = for_day(BOOKINGS, TUESDAY, "city")
    assert format_manifest(rows, TUESDAY, "city", str).startswith(
        "Zone city, 2026-09-22: 1 delivery"
    )
