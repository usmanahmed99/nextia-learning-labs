from datetime import date, datetime, time
from pathlib import Path

import pytest

from delivery_slots.bookings import Booking
from delivery_slots.slots import PlanRow, cutoff_for, load_plan, slots_for

DATA = Path(__file__).resolve().parents[1] / "data"
TUESDAY = date(2026, 9, 22)
MONDAY_MORNING = datetime(2026, 9, 21, 10, 0)
PLAN = [
    PlanRow("west", frozenset({"Tue", "Thu"}), time(8), time(12), 2),
    PlanRow("west", frozenset({"Sat"}), time(12), time(16), 2),
    PlanRow("city", frozenset({"Tue"}), time(8), time(10), 5),
]


def test_the_plan_file_loads():
    plan = load_plan(DATA / "slot-plan.csv")
    assert plan[0] == PlanRow(
        "city",
        frozenset({"Mon", "Tue", "Wed", "Thu", "Fri", "Sat"}),
        time(8),
        time(10),
        10,
    )


def test_only_the_slots_of_the_zone_and_the_weekday():
    slots = slots_for("west", TUESDAY, PLAN, [], MONDAY_MORNING)
    assert [(s.zone, s.start, s.end) for s in slots] == [("west", time(8), time(12))]


def test_places_left_counts_only_the_bookings_of_that_slot():
    bookings = [
        Booking("L-1", "LS5 3QR", "west", TUESDAY, time(8)),
        Booking("L-2", "LS1 4AP", "city", TUESDAY, time(8)),
    ]
    (slot,) = slots_for("west", TUESDAY, PLAN, bookings, MONDAY_MORNING)
    assert (slot.booked, slot.places_left, slot.bookable) == (1, 1, True)


def test_a_full_slot_cannot_be_booked():
    bookings = [Booking(f"L-{n}", "LS5 3QR", "west", TUESDAY, time(8)) for n in (1, 2)]
    (slot,) = slots_for("west", TUESDAY, PLAN, bookings, MONDAY_MORNING)
    assert (slot.places_left, slot.bookable) == (0, False)


def test_the_cutoff_is_20_00_the_day_before():
    assert cutoff_for(TUESDAY) == datetime(2026, 9, 21, 20, 0)


@pytest.mark.parametrize(
    "now, closed",
    [(datetime(2026, 9, 21, 19, 59), False), (datetime(2026, 9, 21, 20, 0), True)],
)
def test_slots_close_at_the_cutoff(now, closed):
    (slot,) = slots_for("west", TUESDAY, PLAN, [], now)
    assert slot.closed is closed
