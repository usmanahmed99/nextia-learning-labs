from datetime import date, datetime, time
from pathlib import Path

import pytest

from delivery_slots.bookings import Booking, load_bookings, save_booking
from delivery_slots.checkout import BookingError, book
from delivery_slots.slots import PlanRow
from delivery_slots.zones import UnknownPostcode

ZONES = {"LS1": "city", "LS5": "west"}
PLAN = [PlanRow("west", frozenset({"Tue"}), time(8), time(12), 2)]
TUESDAY = date(2026, 9, 22)
MONDAY_MORNING = datetime(2026, 9, 21, 10, 0)


def book_west(order="L-9", bookings=(), now=MONDAY_MORNING, start=time(8)):
    return book(
        order,
        "ls5 3qr",
        TUESDAY,
        start,
        zones=ZONES,
        plan=PLAN,
        bookings=list(bookings),
        now=now,
    )


def test_a_free_slot_is_booked_with_the_tidy_postcode_and_the_zone():
    assert book_west() == Booking("L-9", "LS5 3QR", "west", TUESDAY, time(8))


def test_an_order_gets_only_one_slot():
    earlier = Booking("L-9", "LS5 3QR", "west", TUESDAY, time(8))
    with pytest.raises(BookingError, match="already has a delivery slot"):
        book_west(bookings=[earlier])


def test_no_slot_at_that_time():
    with pytest.raises(BookingError, match="Zone west has no slot at 18:00"):
        book_west(start=time(18))


def test_a_closed_day_cannot_be_booked():
    with pytest.raises(BookingError, match="closed"):
        book_west(now=datetime(2026, 9, 21, 20, 0))


def test_a_full_slot_cannot_be_booked():
    full = [Booking(f"L-{n}", "LS5 3QR", "west", TUESDAY, time(8)) for n in (1, 2)]
    with pytest.raises(BookingError, match="full"):
        book_west(bookings=full)


def test_an_unknown_postcode_cannot_book():
    with pytest.raises(UnknownPostcode):
        book(
            "L-9",
            "BD1 1AA",
            TUESDAY,
            time(8),
            zones=ZONES,
            plan=PLAN,
            bookings=[],
            now=MONDAY_MORNING,
        )


def test_saved_bookings_load_again(tmp_path: Path):
    path = tmp_path / "bookings.csv"
    first = Booking("L-1", "LS5 3QR", "west", TUESDAY, time(8))
    second = Booking("L-2", "LS1 4AP", "city", TUESDAY, time(10))
    save_booking(path, first)
    save_booking(path, second)
    assert load_bookings(path) == [first, second]
    assert (
        path.read_text(encoding="utf-8").splitlines()[0]
        == "order,postcode,zone,day,start"
    )
