from pathlib import Path

import pytest

from delivery_slots.zones import UnknownPostcode, load_zones, zone_for

DATA = Path(__file__).resolve().parents[1] / "data"


@pytest.fixture
def zones():
    return load_zones(DATA / "zones.csv")


def test_every_district_has_one_of_the_three_zones(zones):
    assert len(zones) == 15
    assert set(zones.values()) == {"city", "north", "west"}


@pytest.mark.parametrize(
    "postcode, zone",
    [("LS1 4AP", "city"), ("LS6 2AB", "north"), ("LS5 3QR", "west")],
)
def test_zone_of_a_postcode(zones, postcode, zone):
    assert zone_for(postcode, zones) == zone


def test_postcode_as_customers_type_it(zones):
    assert zone_for(" ls6  2ab ", zones) == "north"


def test_postcode_without_a_space(zones):
    """Issue 3: a customer typed "LS53QR" and was told that we do not deliver."""
    assert zone_for("ls53qr", zones) == "west"


def test_unknown_postcode(zones):
    with pytest.raises(UnknownPostcode, match="We do not deliver to BD1 1AA."):
        zone_for("bd1 1aa", zones)
