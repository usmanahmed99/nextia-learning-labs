from delivery_slots.cli import main


def run(data_dir, *args, now="2026-09-21T10:00"):
    return main(["--data", str(data_dir), "--now", now, *args])


def test_slots_prints_the_zone_and_its_slots(data_dir, capsys):
    assert run(data_dir, "slots", "LS1 4AP", "--day", "2026-09-22") == 0
    assert capsys.readouterr().out == (
        "LS1 4AP is in zone city.\n"
        "Slots on Tuesday 22 September 2026 (orders close Monday at 20:00):\n"
        "  08:00-10:00  10 places left\n"
        "  10:00-12:00  10 places left\n"
        "  12:00-14:00  8 places left\n"
    )


def test_a_zone_without_slots_that_day(data_dir, capsys):
    assert run(data_dir, "slots", "LS6 2AB", "--day", "2026-09-22") == 0
    assert capsys.readouterr().out == (
        "LS6 2AB is in zone north.\n"
        "Zone north has no delivery slots on Tuesday 22 September 2026.\n"
    )


def test_after_the_cutoff_every_slot_is_closed(data_dir, capsys):
    run(data_dir, "slots", "LS5 3QR", "--day", "2026-09-22", now="2026-09-21T20:30")
    assert "  08:00-12:00  closed\n" in capsys.readouterr().out


def test_an_unknown_postcode_is_refused(data_dir, capsys):
    assert run(data_dir, "slots", "BD1 1AA", "--day", "2026-09-22") == 1
    assert capsys.readouterr().err == "Error: We do not deliver to BD1 1AA.\n"


def test_book_saves_the_booking(data_dir, capsys):
    code = run(
        data_dir, "book", "L-1", "ls6 2ab", "--day", "2026-09-23", "--start", "08:00"
    )
    assert code == 0
    assert capsys.readouterr().out == (
        "Booked order L-1: LS6 2AB, zone north, Wednesday 23 September 2026 at 08:00.\n"
    )
    assert (data_dir / "bookings.csv").read_text(encoding="utf-8") == (
        "order,postcode,zone,day,start\nL-1,LS6 2AB,north,2026-09-23,08:00\n"
    )


def test_book_refuses_a_full_slot(data_dir, capsys):
    rows = [f"L-{n},LS1 4AP,city,2026-09-22,12:00" for n in range(8)]
    (data_dir / "bookings.csv").write_text(
        "order,postcode,zone,day,start\n" + "\n".join(rows) + "\n", encoding="utf-8"
    )
    code = run(
        data_dir, "book", "L-9", "LS1 4AP", "--day", "2026-09-22", "--start", "12:00"
    )
    assert code == 1
    assert (
        capsys.readouterr().err
        == "Error: This slot is full. Please choose another one.\n"
    )


def test_manifest_lists_the_bookings_of_the_zone(data_dir, capsys):
    run(data_dir, "book", "L-2", "LS5 3QR", "--day", "2026-09-22", "--start", "08:00")
    run(data_dir, "book", "L-1", "LS1 4AP", "--day", "2026-09-22", "--start", "08:00")
    capsys.readouterr()
    assert run(data_dir, "manifest", "--day", "2026-09-22", "--zone", "west") == 0
    assert capsys.readouterr().out == (
        "Zone west, Tuesday 22 September 2026: 1 delivery\n  08:00  L-2  LS5 3QR\n"
    )


def test_west_has_an_evening_slot_on_tuesday(data_dir, capsys):
    assert run(data_dir, "slots", "LS5 3QR", "--day", "2026-10-13") == 0
    assert "  18:00-20:00  6 places left\n" in capsys.readouterr().out
