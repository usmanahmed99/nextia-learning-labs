from pathlib import Path

import pytest

from delivery_slots.zones import UnknownPostcode, load_zones, zone_for

DATA = Path(__file__).resolve().parents[1] / "data"


@pytest.fixture
def zones():
    return load_zones(DATA / "zones.csv")


def test_every_district_has_one_of_the_three_zones(zones):
    assert len(zones) == 15
    assert set(zones.values()) == {"city", "north", "west"}


@pytest.mark.parametrize(
    "postcode, zone",
    [("LS1 4AP", "city"), ("LS6 2AB", "north"), ("LS5 3QR", "west")],
)
def test_zone_of_a_postcode(zones, postcode, zone):
    assert zone_for(postcode, zones) == zone


def test_postcode_as_customers_type_it(zones):
    assert zone_for(" ls6  2ab ", zones) == "north"


def test_postcode_without_a_space(zones):
    """Issue 3: a customer typed "LS53QR" and was told that we do not deliver."""
    assert zone_for("ls53qr", zones) == "west"


def test_unknown_postcode(zones):
    with pytest.raises(UnknownPostcode, match="We do not deliver to BD1 1AA."):
        zone_for("bd1 1aa", zones)


@pytest.mark.parametrize(
    "postcode, zone",
    [
        ("LS12 2AB", "west"),
        ("LS13 4EX", "west"),
        ("LS16 7QR", "north"),
        ("LS17 5DT", "north"),
    ],
)
def test_two_digit_districts(zones, postcode, zone):
    """Issue 12: "LS12 2AB" got the city zone's slots."""
    assert zone_for(postcode, zones) == zone


def test_a_two_digit_district_without_a_space(zones):
    assert zone_for("ls122ab", zones) == "west"


def test_a_district_that_starts_like_a_served_one(zones):
    """LS19 starts with LS1, but Larkfield does not deliver there."""
    with pytest.raises(UnknownPostcode):
        zone_for("LS19 7XB", zones)
