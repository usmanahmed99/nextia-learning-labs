"""Which delivery zone a postcode belongs to.

Larkfield's vans leave the Leeds depot for three zones: city, north and west.
data/zones.csv maps each postcode district (the part before the space, such as
LS6 in "LS6 2AB") to its zone.
"""

import csv
from pathlib import Path

from delivery_slots.postcodes import normalise


class UnknownPostcode(ValueError):
    """Larkfield does not deliver to this postcode."""


def load_zones(path: Path) -> dict[str, str]:
    """Read data/zones.csv: district -> zone, in the order of the file."""
    with open(path, newline="", encoding="utf-8") as f:
        return {
            row["district"].strip().upper(): row["zone"].strip()
            for row in csv.DictReader(f)
        }


def zone_for(postcode: str, zones: dict[str, str]) -> str:
    """The zone of a postcode, for example "west" for "LS5 3QR".

    Customers type postcodes with or without the space ("LS5 3QR", "ls53qr"),
    so remove spaces and the final three characters to get the district.
    """
    code = normalise(postcode).replace(" ", "")
    district = code[:-3]
    if district in zones:
        return zones[district]
    raise UnknownPostcode(f"We do not deliver to {normalise(postcode)}.")
