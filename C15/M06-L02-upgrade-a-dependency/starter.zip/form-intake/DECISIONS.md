# Decisions

The main choices behind `form-intake`. Each one says how it is checked.

## 1. The rules are a marshmallow schema, pinned to one version

`form_intake/schema.py` describes one submission with
[marshmallow](https://pypi.org/project/marshmallow/) (MIT licence). A schema
lists each field with its rules, and gives every problem of a submission at
once, which is what Grace's team needs in `rejected.json`.

The exact version is pinned in `requirements.txt` and `requirements-lock.txt`:
`marshmallow==3.26.2`. A new version is a change to the project, made on a
branch and reviewed like any other change.

- Checked by: `tests/test_schema.py`. The tests call `check_submissions()`,
  not marshmallow itself, so they describe what the form needs, not how the
  library does it.
