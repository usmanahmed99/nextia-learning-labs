from datetime import datetime

from form_intake.schema import Submission, check_submissions

NOW = datetime(2026, 10, 10, 12, 0)
VALID = {
    "ticket_id": "T-4001",
    "email": "ana.lima@example.com",
    "category": "login",
    "priority": 1,
    "subject": "Cannot sign in on the new app",
    "submitted_at": "2026-10-09T08:12:00",
    "page_url": "https://larkfield.example/account",
}


def check(**changes):
    """Check one submission: VALID with some changes. None removes a field."""
    row = {**VALID, **changes}
    row = {key: value for key, value in row.items() if value is not None}
    accepted, rejected = check_submissions([row], now=NOW)
    return accepted, rejected


def problems(**changes) -> dict:
    accepted, rejected = check(**changes)
    assert accepted == [], "expected the submission to be rejected"
    return rejected[0]["problems"]


def test_valid_submission_is_accepted():
    accepted, rejected = check()
    assert rejected == []
    assert accepted == [
        Submission(
            ticket_id="T-4001",
            email="ana.lima@example.com",
            category="login",
            priority=1,
            subject="Cannot sign in on the new app",
            submitted_at=datetime(2026, 10, 9, 8, 12),
            page_url="https://larkfield.example/account",
        )
    ]


def test_missing_category_priority_and_page_get_defaults():
    accepted, _ = check(category=None, priority=None, page_url=None)
    assert accepted[0].category == "other"
    assert accepted[0].priority == 2
    assert accepted[0].page_url is None


def test_fields_that_we_do_not_use_are_ignored():
    accepted, _ = check(browser="Firefox 151")
    assert len(accepted) == 1


def test_missing_required_fields_are_listed():
    accepted, rejected = check_submissions([{"category": "login"}], now=NOW)
    assert accepted == []
    assert sorted(rejected[0]["problems"]) == [
        "email",
        "subject",
        "submitted_at",
        "ticket_id",
    ]


def test_invalid_email_is_rejected():
    assert problems(email="chen.wei.example.com") == {
        "email": ["Not a valid email address."]
    }


def test_blank_subject_is_rejected():
    assert "subject" in problems(subject="   ")


def test_date_without_time_is_rejected():
    assert "submitted_at" in problems(submitted_at="2026-10-09")


def test_time_in_the_future_is_rejected():
    assert problems(submitted_at="2062-10-09T10:15:00") == {
        "submitted_at": ["The time is in the future."]
    }


def test_priority_outside_1_to_3_is_rejected():
    assert "priority" in problems(priority=5)


def test_unknown_category_is_rejected():
    assert "category" in problems(category="refunds")


def test_ticket_id_needs_the_t_prefix():
    assert "ticket_id" in problems(ticket_id="4010")
