import argparse
import json
from dataclasses import asdict
from datetime import datetime
from pathlib import Path

import marshmallow

from form_intake import __version__
from form_intake.schema import check_submissions


def make_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="form_intake",
        description="Check the web form's ticket submissions.",
    )
    parser.add_argument("input", type=Path, help="a JSON file of submissions")
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("out"),
        help="where to save accepted.json and rejected.json (default: out)",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"form_intake {__version__} (marshmallow {marshmallow.__version__})",
    )
    return parser


def save(path: Path, items: list) -> None:
    text = json.dumps(items, indent=2, ensure_ascii=False, default=str)
    path.write_text(text + "\n", encoding="utf-8")


def main(argv: list[str] | None = None) -> int:
    args = make_parser().parse_args(argv)
    rows = json.loads(args.input.read_text(encoding="utf-8"))
    accepted, rejected = check_submissions(rows, now=datetime.now())
    out = args.output_dir
    out.mkdir(parents=True, exist_ok=True)
    save(out / "accepted.json", [asdict(s) for s in accepted])
    save(out / "rejected.json", rejected)
    counts = f"{len(accepted)} accepted, {len(rejected)} rejected"
    print(f"{len(rows)} submissions: {counts}.")
    print(f"Saved: {out / 'accepted.json'}, {out / 'rejected.json'}")
    return 0
