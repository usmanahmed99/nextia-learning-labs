"""The rules for one web-form submission, written as a marshmallow schema."""

from dataclasses import dataclass
from datetime import datetime

from marshmallow import (
    EXCLUDE,
    Schema,
    ValidationError,
    fields,
    post_load,
    validate,
    validates,
)

CATEGORIES = ["account", "billing", "login", "shipping", "other"]


def not_blank(text: str) -> bool:
    """Return False for text that has only spaces."""
    return text.strip() != ""


@dataclass(frozen=True)
class Submission:
    """One accepted submission."""

    ticket_id: str
    email: str
    category: str
    priority: int
    subject: str
    submitted_at: datetime
    page_url: str | None


class SubmissionSchema(Schema):
    """Checks one submission. Pass the time now as context["now"]."""

    class Meta:
        unknown = EXCLUDE  # the form adds fields that we do not use
        ordered = True

    ticket_id = fields.Str(required=True, validate=validate.Regexp(r"^T-\d{4}$"))
    email = fields.Email(required=True)
    category = fields.Str(missing="other", validate=validate.OneOf(CATEGORIES))
    priority = fields.Int(missing=2, validate=validate.Range(min=1, max=3))
    subject = fields.Str(required=True, validate=not_blank)
    submitted_at = fields.DateTime(required=True)
    page_url = fields.Url(missing=None, allow_none=True)

    @validates("submitted_at")
    def not_in_the_future(self, value: datetime) -> None:
        if value > self.context["now"]:
            raise ValidationError("The time is in the future.")

    @post_load
    def make_submission(self, data: dict, **kwargs) -> Submission:
        return Submission(**data)


def check_submissions(rows: list[dict], now: datetime) -> tuple[list, list]:
    """Return the accepted submissions, and the rejected ones with their problems."""
    schema = SubmissionSchema(context={"now": now})
    accepted, rejected = [], []
    for row in rows:
        try:
            accepted.append(schema.load(row))
        except ValidationError as error:
            rejected.append(
                {"ticket_id": row.get("ticket_id"), "problems": error.messages}
            )
    return accepted, rejected
