# form-intake

Checks the ticket submissions of Larkfield's web form before they reach the
help desk. Each submission is accepted, or rejected with every problem that it
has.

Written for the case study *Upgrade a dependency safely* of the Nextia Learning
course *AI-Assisted Software Development*. MIT licence. The submissions in
`data/` are invented.

## Requirements

- Python 3.12 or newer. Check with `python3 --version` (`python --version` on
  Windows).
- No account.

## Set up

Do these steps once, in a terminal in this folder.

1. Make a virtual environment: `python3 -m venv .venv` (on Windows,
   `python -m venv .venv`).
2. Activate it. On macOS and Linux: `source .venv/bin/activate`. On Windows
   (PowerShell): `.venv\Scripts\Activate.ps1`. The prompt now starts with
   `(.venv)`.
3. Install the exact versions of the dependencies:

   ```sh
   python -m pip install -r requirements-lock.txt
   ```

## Run

```sh
python -m form_intake data/submissions.json
```

Expected output:

```text
12 submissions: 3 accepted, 9 rejected.
Saved: out/accepted.json, out/rejected.json
```

`out/rejected.json` lists each rejected submission with its problems.
`python -m form_intake --version` prints the program's version and the
version of marshmallow that it uses.

## The rules

| Field | Rule | If it is missing |
|---|---|---|
| `ticket_id` | `T-` and four digits | rejected |
| `email` | an email address | rejected |
| `category` | `account`, `billing`, `login`, `shipping` or `other` | `other` |
| `priority` | 1, 2 or 3 | 2 |
| `subject` | not only spaces | rejected |
| `submitted_at` | a date **and** a time, not in the future | rejected |
| `page_url` | a web address: the page where the customer pressed Help | none |

Other fields are ignored. Times are Larkfield's local time, without a time
zone, as the form sends them.

## Check

```sh
python -m pytest
ruff check .
ruff format --check .
```

## Layout

```text
form_intake/schema.py    the rules (a marshmallow schema) and check_submissions()
form_intake/cli.py       the command line
tests/                   the rules, as tests
data/submissions.json    12 invented submissions
data/time-formats.json   one submission for each of 10 ways to write a time
data/new-submissions.json  10 more invented submissions
tools/compare.py         which submissions changed their decision between two runs
DECISIONS.md             the main choices, and how each one is checked
```
