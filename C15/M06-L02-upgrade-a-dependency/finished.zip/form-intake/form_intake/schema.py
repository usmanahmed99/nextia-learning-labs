"""The rules for one web-form submission, written as a marshmallow schema."""

import re
from dataclasses import dataclass
from datetime import datetime

from marshmallow import (
    EXCLUDE,
    Schema,
    ValidationError,
    fields,
    post_load,
    validate,
    validates,
)

CATEGORIES = ["account", "billing", "login", "shipping", "other"]


def not_blank(text: str) -> None:
    """Reject text that has only spaces."""
    if not text.strip():
        raise ValidationError("Invalid value.")


# Our rule for submitted_at: a date and a local time, as the form sends them.
# marshmallow 4 reads times with datetime.fromisoformat, which also accepts a
# date alone and other ISO 8601 forms (changelog, 4.0.0). So the rule is ours.
LOCAL_TIME = re.compile(r"\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}(:\d{2}(\.\d{1,6})?)?")


class SubmissionDateTime(fields.DateTime):
    """A date and a local time: YYYY-MM-DD, T or a space, HH:MM, seconds if any."""

    def _deserialize(self, value, attr, data, **kwargs):
        if not isinstance(value, str) or not LOCAL_TIME.fullmatch(value):
            raise self.make_error("invalid", input=value, obj_type=self.OBJ_TYPE)
        return super()._deserialize(value, attr, data, **kwargs)


@dataclass(frozen=True)
class Submission:
    """One accepted submission."""

    ticket_id: str
    email: str
    category: str
    priority: int
    subject: str
    submitted_at: datetime
    page_url: str | None


class SubmissionSchema(Schema):
    """Checks one submission against the supplied current time."""

    def __init__(self, *, now: datetime, **kwargs):
        super().__init__(**kwargs)
        self.now = now

    class Meta:
        unknown = EXCLUDE  # the form adds fields that we do not use

    ticket_id = fields.Str(required=True, validate=validate.Regexp(r"^T-\d{4}$"))
    email = fields.Email(required=True)
    category = fields.Str(load_default="other", validate=validate.OneOf(CATEGORIES))
    priority = fields.Int(load_default=2, validate=validate.Range(min=1, max=3))
    subject = fields.Str(required=True, validate=not_blank)
    submitted_at = SubmissionDateTime(required=True)
    page_url = fields.Url(load_default=None, allow_none=True)

    @validates("submitted_at")
    def not_in_the_future(self, value: datetime, **kwargs) -> None:
        if value > self.now:
            raise ValidationError("The time is in the future.")

    @post_load
    def make_submission(self, data: dict, **kwargs) -> Submission:
        return Submission(**data)


def check_submissions(rows: list[dict], now: datetime) -> tuple[list, list]:
    """Return the accepted submissions, and the rejected ones with their problems."""
    schema = SubmissionSchema(now=now)
    accepted, rejected = [], []
    for row in rows:
        try:
            accepted.append(schema.load(row))
        except ValidationError as error:
            rejected.append(
                {"ticket_id": row.get("ticket_id"), "problems": error.messages}
            )
    return accepted, rejected
