"""Check the web form's ticket submissions before they reach the help desk."""

__version__ = "1.0.0"
