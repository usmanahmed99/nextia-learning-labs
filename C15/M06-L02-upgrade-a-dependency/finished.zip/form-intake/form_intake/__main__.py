from form_intake.cli import main

raise SystemExit(main())
