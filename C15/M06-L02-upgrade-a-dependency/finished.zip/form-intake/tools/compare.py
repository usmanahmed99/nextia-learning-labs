"""Compare two runs of form_intake: which submissions changed their decision.

python tools/compare.py out/before/time-formats out/after/time-formats
"""

import json
import sys
from pathlib import Path


def accepted_ids(folder: Path) -> set[str]:
    rows = json.loads((folder / "accepted.json").read_text(encoding="utf-8"))
    return {row["ticket_id"] for row in rows}


def rejected_ids(folder: Path) -> set[str]:
    rows = json.loads((folder / "rejected.json").read_text(encoding="utf-8"))
    return {row["ticket_id"] for row in rows}


def main() -> int:
    before, after = Path(sys.argv[1]), Path(sys.argv[2])
    now_rejected = sorted(accepted_ids(before) & rejected_ids(after))
    now_accepted = sorted(rejected_ids(before) & accepted_ids(after))
    same = len(accepted_ids(before) & accepted_ids(after))
    same += len(rejected_ids(before) & rejected_ids(after))
    print(f"Same decision: {same}")
    print(f"Accepted before, rejected now: {', '.join(now_rejected) or 'none'}")
    print(f"Rejected before, accepted now: {', '.join(now_accepted) or 'none'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
