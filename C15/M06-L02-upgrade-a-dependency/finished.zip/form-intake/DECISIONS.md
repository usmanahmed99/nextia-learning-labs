# Decisions

The main choices behind `form-intake`. Each one says how it is checked.

## 1. The rules are a marshmallow schema, pinned to one version

`form_intake/schema.py` describes one submission with
[marshmallow](https://pypi.org/project/marshmallow/) (MIT licence). A schema
lists each field with its rules, and gives every problem of a submission at
once, which is what Grace's team needs in `rejected.json`.

The exact version is pinned in `requirements.txt` and `requirements-lock.txt`:
`marshmallow==4.3.1` since decision 2. A new version is a change to the project, made on a
branch and reviewed like any other change.

- Checked by: `tests/test_schema.py`. The tests call `check_submissions()`,
  not marshmallow itself, so they describe what the form needs, not how the
  library does it.

## 2. Upgrade marshmallow from 3.26.2 to 4.3.1

**Why.** Grace's team saw two real submissions rejected with "Not a valid
URL.": `https://larkfield.example#help` and
`https://café.larkfield.example/help`. Both are fixed in marshmallow 4
(changelog: 4.2.4, "`URL` and `Email` accept Internationalized Domain Names";
4.3.1, "`URL` accepts a fragment that follows an empty path"). The 3.x line
has had no release since 3.26.2.

**What changed in our code**, each for one entry of the 4.0.0 changelog:

| Our code | marshmallow 4.0.0 changelog entry |
|---|---|
| `missing=` → `load_default=` (three fields) | "`default` and `missing` parameters ... removed" |
| `not_blank()` raises `ValidationError` | "Custom validators must raise a `ValidationError` ... Returning `False` is no longer supported" |
| `@validates` method takes `**kwargs` | "Decorated methods now receive `data_key` as a keyword argument" |
| `now` is passed to `SubmissionSchema(now=...)` | "Remove `Schema`'s `context` attribute" |
| `ordered = True` removed from `Meta` | "The `ordered` class Meta option is removed" |
| `importlib.metadata.version("marshmallow")` in `--version` | "Remove `__version__` ... attributes" |
| `SubmissionDateTime` with our own time rule | "Use `datetime.datetime.fromisoformat` ... YYYY-MM-DD is now accepted as a datetime" |

**How it was checked.**

- `python -m pytest`: 24 passed, also with `-W error` (no warnings left).
- Before the upgrade, `data/time-formats.json` was run with 3.26.2 and saved.
  After it, one decision differs, on purpose: `2026-1-9T8:05` (one-digit
  parts) is now rejected, because our rule asks for two digits.
- `data/submissions.json`: 5 accepted, 7 rejected. Only Grace's two
  submissions changed, from rejected to accepted.

**Suggestions that we changed or did not take.**

- A recorded assistant session wrote the first version of this migration.
  Its date check rejected a date alone but accepted five other forms that
  3.26.2 rejected (for example `2026-10-09T08` and `2026-W41-5T08:12`). All
  its tests passed. We replaced the check with the explicit rule above and
  tests for each form.
- The changelog suggests `contextvars` or the *experimental* `Context` class
  instead of `context`. We pass `now` to the schema's constructor: it is
  simpler, and it does not depend on an experimental API.

**Found, not changed by this upgrade:** with 3.26.2, a time with a zone
(`2026-10-09T08:12:00+02:00`) crashed the program (`TypeError: can't compare
offset-naive and offset-aware datetimes`). The new rule rejects it, as the
README always said. A test pins it.
