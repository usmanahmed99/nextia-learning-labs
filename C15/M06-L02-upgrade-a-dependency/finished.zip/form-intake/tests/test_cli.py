import json
from importlib.metadata import version

import pytest

from form_intake.cli import main


def test_cli_writes_accepted_and_rejected(tmp_path, capsys):
    exit_code = main(["data/submissions.json", "--output-dir", str(tmp_path)])

    assert exit_code == 0
    assert capsys.readouterr().out.startswith("12 submissions: 5 accepted, 7 rejected.")
    accepted = json.loads((tmp_path / "accepted.json").read_text(encoding="utf-8"))
    rejected = json.loads((tmp_path / "rejected.json").read_text(encoding="utf-8"))
    assert [s["ticket_id"] for s in accepted] == [
        "T-4001",
        "T-4002",
        "T-4007",
        "T-4011",
        "T-4012",
    ]
    assert len(rejected) == 7


def test_version_names_the_marshmallow_version(capsys):
    with pytest.raises(SystemExit):
        main(["--version"])

    out = capsys.readouterr().out
    assert out == f"form_intake 1.0.0 (marshmallow {version('marshmallow')})\n"
