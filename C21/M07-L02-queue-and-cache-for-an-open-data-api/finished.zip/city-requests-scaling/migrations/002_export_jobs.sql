-- Export jobs: a queue in PostgreSQL. The API saves a job and answers 202 at once;
-- a worker process takes queued jobs with SELECT ... FOR UPDATE SKIP LOCKED, writes
-- the CSV file, and marks the job finished.

CREATE TABLE export_jobs (
    export_id       bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    -- Who asked (the X-Client-ID header). The worker trusts this row only.
    actor           text NOT NULL,
    -- The caller's Idempotency-Key: the same key again means the same request.
    idempotency_key text,
    request_sha256  text NOT NULL,
    filters         jsonb NOT NULL,
    state           text NOT NULL DEFAULT 'queued',
    attempts        integer NOT NULL DEFAULT 0,
    max_attempts    integer NOT NULL DEFAULT 3,
    run_after       timestamptz NOT NULL DEFAULT now(),
    locked_by       text,
    locked_until    timestamptz,
    last_error      text,
    data_version    integer,     -- the data version that the file was made from
    row_count       integer,
    file_bytes      bigint,
    created_at      timestamptz NOT NULL DEFAULT now(),
    started_at      timestamptz,
    finished_at     timestamptz,
    updated_at      timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT export_state_known CHECK (state IN
        ('queued', 'running', 'succeeded', 'failed', 'cancelled', 'dead_letter')),
    CONSTRAINT export_attempts_in_range CHECK (attempts >= 0 AND attempts <= max_attempts),
    CONSTRAINT export_finished_has_time
        CHECK ((state IN ('succeeded', 'failed', 'cancelled', 'dead_letter')) = (finished_at IS NOT NULL))
);
-- One job per caller and idempotency key.
CREATE UNIQUE INDEX export_idempotency_key ON export_jobs (actor, idempotency_key)
    WHERE idempotency_key IS NOT NULL;
-- What the workers look for: queued jobs that may run now, and running jobs whose lease ended.
CREATE INDEX export_queued_idx ON export_jobs (run_after, export_id) WHERE state = 'queued';
CREATE INDEX export_running_idx ON export_jobs (locked_until) WHERE state = 'running';
CREATE INDEX export_finished_idx ON export_jobs (finished_at) WHERE finished_at IS NOT NULL;
