"""Send many export requests at the same moment, and count the answers.

    python -m scripts.send_exports --count 30

Each request asks for the whole city (about 110,000 rows), from its own caller
(X-Client-ID: burst-1, burst-2, ...), so the rate limit per caller does not stop them:
only the queue's bound does. It prints the status codes, the Retry-After values of
the refusals, and the queue right after. Run it only against your own API.
"""

import argparse
import json
import os
import sys
import urllib.error
import urllib.request
from collections import Counter
from concurrent.futures import ThreadPoolExecutor


def post(host: str, number: int, headers: dict) -> tuple[int, str | None]:
    request = urllib.request.Request(
        f"{host}/v1/exports",
        data=b"{}",
        method="POST",
        headers={**headers, "Content-Type": "application/json", "X-Client-ID": f"burst-{number}"},
    )
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            return response.status, None
    except urllib.error.HTTPError as error:
        return error.code, error.headers.get("Retry-After")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--count", type=int, default=30)
    parser.add_argument("--host", default="http://127.0.0.1:8000")
    args = parser.parse_args(argv)
    headers = {"X-API-Key": os.environ["API_KEY"]} if os.environ.get("API_KEY") else {}
    with ThreadPoolExecutor(args.count) as pool:
        answers = list(pool.map(lambda n: post(args.host, n, headers), range(1, args.count + 1)))
    statuses = Counter(status for status, _ in answers)
    print(f"{args.count} export requests at once: status codes {dict(sorted(statuses.items()))}")
    waits = sorted({int(r) for _, r in answers if r is not None})
    if waits:
        print(f"Retry-After of the refused ones: {', '.join(str(w) for w in waits)} s")
    request = urllib.request.Request(f"{args.host}/v1/export-queue", headers=headers)
    with urllib.request.urlopen(request, timeout=10) as response:
        print(f"Queue now: {json.load(response)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
