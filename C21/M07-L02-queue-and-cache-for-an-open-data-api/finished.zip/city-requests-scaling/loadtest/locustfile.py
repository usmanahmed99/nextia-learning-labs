"""The Monday-morning workload of the city requests API (Locust, https://locust.io, MIT).

Run it only against your own API on your computer:

    locust -f loadtest/locustfile.py --host http://127.0.0.1:8000 --headless -u 34 -r 34 -t 60s

Two kinds of users (docs/workload.md explains the numbers). -u must be VIEWERS + ANALYSTS:

- DashboardViewer (VIEWERS, 30): opens a dashboard every PACE_SECONDS (10 s): the
  complaint types, two daily-number charts, a page of requests, the next page, and
  one request's details: 6 requests per visit. PACE_SECONDS=0: no pause at all.
- Analyst (ANALYSTS, 4): asks for a CSV export every EXPORT_PACE_SECONDS (15 s):
  it calls POST /v1/exports, asks for the state every second, and downloads the file
  when it is ready. (The starter's version called GET /v1/exports.csv and waited.)

Each user starts at a random moment of its first pace, so the clicks are spread out.
Every user picks its filters with a fixed seed, from a list where some views are much
more popular than others, as on a real dashboard. The client gives up after
TIMEOUT_SECONDS (30 s), as a proxy in front of an API often does.

Set SAMPLES_CSV=<file> to write one line per request (start, name, status, ms). The
line "export: click to file" is the time an analyst waits for the file.
"""

import os
import random
import time
import uuid

from locust import constant_pacing, events, task
from locust.contrib.fasthttp import FastHttpUser

HEADERS = {"X-API-Key": os.environ["API_KEY"]} if os.environ.get("API_KEY") else {}
TIMEOUT = float(os.environ.get("TIMEOUT_SECONDS", "30"))

# The views of the dashboards, most popular first, with their weights.
RANGES = [  # (from, to): "today" is early June 2025, before June's data is loaded
    (("2025-05-01", "2025-06-01"), 30),  # the last month
    (("2025-03-01", "2025-06-01"), 25),  # the last three months
    (("2025-04-01", "2025-05-01"), 12),
    (("2025-01-01", "2025-04-01"), 10),
    (("2025-03-01", "2025-04-01"), 8),
    (("2025-02-01", "2025-03-01"), 6),
    (("2025-01-01", "2025-02-01"), 5),
    (("2025-02-01", "2025-05-01"), 4),
]
BOROUGHS = [
    (None, 40),
    ("brooklyn", 18),
    ("queens", 17),
    ("manhattan", 12),
    ("bronx", 8),
    ("staten_island", 5),
]
TYPES = [
    (None, 40),
    ("Street Condition", 25),
    ("Traffic Signal Condition", 15),
    ("Street Light Condition", 12),
    ("Sidewalk Condition", 8),
]
EXPORT_SIZES = [  # (filters, weight): most analysts export one borough, three months
    (
        {
            "borough": "brooklyn",
            "created_from": "2025-03-01T00:00:00",
            "created_to": "2025-06-01T00:00:00",
        },
        30,
    ),
    (
        {
            "borough": "queens",
            "created_from": "2025-03-01T00:00:00",
            "created_to": "2025-06-01T00:00:00",
        },
        25,
    ),
    ({"complaint_type": "Street Condition"}, 25),
    ({}, 20),  # everything that is loaded: about 90,000 rows, 15 MB
]


def pick(rng: random.Random, choices):
    values, weights = zip(*choices, strict=True)
    return rng.choices(values, weights)[0]


_rng = random.Random(21)
_samples = None


@events.test_start.add_listener
def open_samples(environment, **kwargs):
    global _samples
    path = os.environ.get("SAMPLES_CSV")
    if path:
        _samples = open(path, "w", encoding="utf-8", newline="")
        _samples.write("start,name,status,ms\n")


@events.request.add_listener
def record(request_type, name, response_time, response, exception, start_time=None, **kwargs):
    if _samples is not None:
        status = getattr(response, "status_code", 0) or 0
        if exception is not None and status in (200, 202):
            status = 0
        _samples.write(f"{start_time or time.time():.3f},{name},{status},{response_time:.1f}\n")


@events.test_stop.add_listener
def close_samples(environment, **kwargs):
    if _samples is not None:
        _samples.flush()


def clean(params: dict) -> dict:
    return {k: v for k, v in params.items() if v is not None}


class DashboardViewer(FastHttpUser):
    """Opens a dashboard: six requests, then waits for the next visit."""

    fixed_count = int(os.environ.get("VIEWERS", "30"))
    pace = float(os.environ.get("PACE_SECONDS", "10"))
    wait_time = constant_pacing(pace)
    network_timeout = TIMEOUT
    connection_timeout = TIMEOUT

    def on_start(self):
        # Start at a random moment of the first pace, so that the viewers do not all
        # click in the same second again and again.
        time.sleep(_rng.uniform(0, self.pace))

    def get(self, path: str, name: str, params: dict | None = None):
        with self.client.get(
            path, params=params, headers=HEADERS, name=name, catch_response=True
        ) as r:
            if r.status_code == 200:
                r.success()
            else:
                r.failure(f"{r.status_code}")
            return r

    @task
    def visit(self):
        (start, end), borough = pick(_rng, RANGES), pick(_rng, BOROUGHS)
        kind = pick(_rng, TYPES)
        self.get("/v1/complaint-types", "GET /v1/complaint-types")
        dates = {"created_from": start, "created_to": end}
        self.get("/v1/stats/daily", "GET /v1/stats/daily", clean({**dates, "borough": borough}))
        self.get("/v1/stats/daily", "GET /v1/stats/daily", clean({**dates, "complaint_type": kind}))
        filters = clean({**dates, "borough": borough, "complaint_type": kind, "limit": 50})
        page = self.get("/v1/service-requests", "GET /v1/service-requests", filters)
        if page.status_code != 200:
            return
        body = page.json()
        if body["next_cursor"]:
            self.get(
                "/v1/service-requests",
                "GET /v1/service-requests",
                {**filters, "cursor": body["next_cursor"]},
            )
        if body["items"]:
            item = _rng.choice(body["items"])
            self.get(f"/v1/service-requests/{item['id']}", "GET /v1/service-requests/{id}")


class Analyst(FastHttpUser):
    """Asks for a CSV export, waits for the file, and asks again later."""

    fixed_count = int(os.environ.get("ANALYSTS", "4"))
    pace = float(os.environ.get("EXPORT_PACE_SECONDS", "15"))
    wait_time = constant_pacing(pace)
    network_timeout = TIMEOUT
    connection_timeout = TIMEOUT

    def on_start(self):
        time.sleep(_rng.uniform(0, self.pace))

    def done(self, started: float, status: int) -> None:
        """One line for the whole wait: from the click to the file (or the failure)."""
        events.request.fire(
            request_type="EXPORT",
            name="export: click to file",
            response_time=(time.time() - started) * 1000,
            response_length=0,
            response=type("R", (), {"status_code": status})(),
            exception=None if status == 200 else Exception(str(status)),
            start_time=started,
        )

    @task
    def export(self):
        filters = pick(_rng, EXPORT_SIZES)
        started = time.time()
        headers = {
            **HEADERS,
            "Idempotency-Key": uuid.uuid4().hex,
            "X-Client-ID": f"analyst-{id(self) % 1000}",
        }
        with self.client.post(
            "/v1/exports",
            json=filters,
            headers=headers,
            name="POST /v1/exports",
            catch_response=True,
        ) as r:
            if r.status_code != 202:
                # 429 or 503: nothing was saved. The analyst tries again at its next turn.
                r.failure(f"{r.status_code}")
                self.done(started, r.status_code)
                return
            r.success()
            location = r.headers["Location"]
        while time.time() - started < 120:
            time.sleep(1)
            with self.client.get(
                location, headers=HEADERS, name="GET /v1/exports/{id}", catch_response=True
            ) as r:
                if r.status_code != 200:
                    r.failure(f"{r.status_code}")
                    continue
                r.success()
                state = r.json()["state"]
            if state == "succeeded":
                with self.client.get(
                    f"{location}/file",
                    headers=HEADERS,
                    name="GET /v1/exports/{id}/file",
                    catch_response=True,
                ) as f:
                    f.success() if f.status_code == 200 else f.failure(f"{f.status_code}")
                self.done(started, f.status_code)
                return
            if state in ("dead_letter", "failed", "cancelled"):
                self.done(started, 500)
                return
        self.done(started, 504)
