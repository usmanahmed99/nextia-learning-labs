import os
from dataclasses import dataclass, field
from pathlib import Path


@dataclass(frozen=True)
class Settings:
    api_key: str | None = field(repr=False)
    allowed_origins: list[str]
    database_url: str = field(repr=False)
    db_pool_max: int
    db_pool_timeout: float
    log_level: str
    show_docs: bool
    # The cache (Valkey). Empty: no cache.
    cache_url: str | None = field(repr=False)
    cache_timeout: float
    cache_ttl_seconds: int
    cache_lock_seconds: float
    # The export queue.
    export_dir: Path
    export_queue_max: int
    export_rate_per_minute: int
    export_max_attempts: int
    export_lease_seconds: float
    worker_poll_seconds: float


def _int(name: str, default: int) -> int:
    return int(os.environ.get(name, default))


def _float(name: str, default: float) -> float:
    return float(os.environ.get(name, default))


def load_settings() -> Settings:
    """Read the settings from environment variables, with safe defaults."""
    origins = os.environ.get("ALLOWED_ORIGINS", "")
    return Settings(
        api_key=os.environ.get("API_KEY") or None,
        allowed_origins=[o.strip() for o in origins.split(",") if o.strip()],
        database_url=os.environ.get(
            "DATABASE_URL", "postgresql://city:city-local-only@127.0.0.1:5432/city"
        ),
        db_pool_max=_int("DB_POOL_MAX", 10),
        db_pool_timeout=_float("DB_POOL_TIMEOUT", 5.0),
        log_level=os.environ.get("LOG_LEVEL", "INFO").upper(),
        show_docs=os.environ.get("SHOW_DOCS", "true").lower() == "true",
        cache_url=os.environ.get("CACHE_URL", "redis://127.0.0.1:6379/0") or None,
        cache_timeout=_float("CACHE_TIMEOUT", 0.05),
        cache_ttl_seconds=_int("CACHE_TTL_SECONDS", 3600),
        cache_lock_seconds=_float("CACHE_LOCK_SECONDS", 10.0),
        export_dir=Path(os.environ.get("EXPORT_DIR", "exports")),
        export_queue_max=_int("EXPORT_QUEUE_MAX", 20),
        export_rate_per_minute=_int("EXPORT_RATE_PER_MINUTE", 10),
        export_max_attempts=_int("EXPORT_MAX_ATTEMPTS", 3),
        export_lease_seconds=_float("EXPORT_LEASE_SECONDS", 60.0),
        worker_poll_seconds=_float("WORKER_POLL_SECONDS", 0.5),
    )
