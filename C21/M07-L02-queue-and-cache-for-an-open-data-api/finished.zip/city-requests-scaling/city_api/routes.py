from datetime import datetime
from typing import Annotated

from fastapi import APIRouter, Depends, Path, Query, Request, Response

from city_api import queries
from city_api.cache import answer_key
from city_api.errors import ApiError
from city_api.models import (
    ComplaintTypeList,
    DailyStats,
    DatasetInfo,
    ErrorResponse,
    ListQuery,
    ServiceRequest,
    ServiceRequestPage,
    StatsQuery,
)
from city_api.pagination import decode_cursor, encode_cursor
from city_api.security import require_api_key

MAX_STATS_DAYS = 92

ERRORS = {
    401: {"model": ErrorResponse, "description": "The API key is missing or wrong."},
    422: {"model": ErrorResponse, "description": "A parameter is not valid."},
    503: {"model": ErrorResponse, "description": "The data is not available now."},
}
CACHE_HEADER = {
    "X-Cache": {
        "description": "hit: from the cache; miss: computed and stored; wait: another "
        "request computed it; off: the cache is not available.",
        "schema": {"type": "string"},
    }
}

router = APIRouter(prefix="/v1", dependencies=[Depends(require_api_key)], responses=ERRORS)


def iso(moment: datetime | None) -> str | None:
    return moment.isoformat() if moment else None


def check_range(start, end) -> None:
    if start is not None and end is not None and start >= end:
        raise ApiError(
            422,
            "invalid_range",
            "created_from must be before created_to.",
            ["created_from", "created_to"],
        )


def cached(request: Request, response: Response, name: str, params: dict, compute):
    """Answer from the cache when it has this answer for the current data version.

    The data version is read from PostgreSQL first (a quick query), and the connection
    goes back to the pool before the cache is asked: a request that waits for another
    one's result does not keep a connection."""
    app = request.app
    cache, settings = app.state.cache, app.state.settings
    if cache is None:
        with app.state.db.connection() as conn:
            return compute(conn)
    with app.state.db.connection() as conn:
        version = queries.data_version(conn)
    key = answer_key(name, version, params)

    def compute_with_a_connection():
        with app.state.db.connection() as conn:
            return compute(conn)

    value, how = cache.get_or_compute(
        key, compute_with_a_connection, settings.cache_ttl_seconds, settings.cache_lock_seconds
    )
    response.headers["X-Cache"] = how
    response.headers["X-Data-Version"] = str(version)
    return value


@router.get(
    "/service-requests",
    tags=["service requests"],
    summary="List service requests, one page at a time",
    description=(
        "Requests that match every filter, oldest first (by created_at, then id). "
        "Each page has at most `limit` requests. If `next_cursor` is not null, send it "
        "as `cursor`, with the same filters, to get the next page."
    ),
)
def list_service_requests(
    request: Request, query: Annotated[ListQuery, Query()]
) -> ServiceRequestPage:
    check_range(query.created_from, query.created_to)
    filters = {
        "borough": query.borough,
        "complaint_type": query.complaint_type,
        "status": query.status,
        "created_from": iso(query.created_from),
        "created_to": iso(query.created_to),
    }
    after = None
    if query.cursor:
        created_at, request_id = decode_cursor(query.cursor, filters)
        after = (datetime.fromisoformat(created_at), request_id)
    with request.app.state.db.connection() as conn:
        rows = queries.list_requests(conn, filters, after, query.limit)
    page = rows[: query.limit]
    next_cursor = None
    if len(rows) > query.limit:
        last = page[-1]
        next_cursor = encode_cursor(last["created_at"], last["id"], filters)
    return ServiceRequestPage(items=page, next_cursor=next_cursor)


@router.get(
    "/service-requests/{request_id}",
    tags=["service requests"],
    summary="Get one service request",
    responses={404: {"model": ErrorResponse, "description": "No request has this ID."}},
)
def get_service_request(
    request: Request,
    request_id: Annotated[int, Path(ge=1, description="The request's id.")],
) -> ServiceRequest:
    with request.app.state.db.connection() as conn:
        row = queries.get_request(conn, request_id)
    if row is None:
        raise ApiError(404, "not_found", f"No service request has the ID {request_id}.")
    return ServiceRequest(**row)


@router.get(
    "/complaint-types",
    tags=["service requests"],
    summary="List the complaint types, with the number of requests",
    responses={200: {"headers": CACHE_HEADER}},
)
def list_complaint_types(request: Request, response: Response) -> ComplaintTypeList:
    items = cached(request, response, "complaint-types", {}, queries.complaint_types)
    return ComplaintTypeList(items=items)


@router.get(
    "/stats/daily",
    tags=["statistics"],
    summary="Count the requests opened and closed for each day",
    description=(
        "For each day from `created_from` to the day before `created_to`: the requests "
        "opened, how many of them were closed within 14 days, and the median days to "
        f"close. The range is at most {MAX_STATS_DAYS} days. Days without requests are "
        "included, with `opened` 0."
    ),
    responses={200: {"headers": CACHE_HEADER}},
)
def daily_stats(
    request: Request, response: Response, query: Annotated[StatsQuery, Query()]
) -> DailyStats:
    check_range(query.created_from, query.created_to)
    if (query.created_to - query.created_from).days > MAX_STATS_DAYS:
        raise ApiError(
            422,
            "range_too_large",
            f"The range is longer than {MAX_STATS_DAYS} days. Ask for a shorter one.",
            ["created_from", "created_to"],
        )
    filters = {"borough": query.borough, "complaint_type": query.complaint_type}
    # Everything that changes the answer: the filters and both dates. They are the
    # validated values, so the order of the query parameters does not change the key.
    params = {**filters, "created_from": query.created_from, "created_to": query.created_to}
    items = cached(
        request,
        response,
        "stats-daily",
        params,
        lambda conn: queries.daily_stats(conn, filters, query.created_from, query.created_to),
    )
    return DailyStats(items=items)


@router.get(
    "/dataset",
    tags=["statistics"],
    summary="Where the data comes from, its snapshot date and its version",
)
def dataset(request: Request) -> DatasetInfo:
    with request.app.state.db.connection() as conn:
        return DatasetInfo(**queries.dataset_info(conn))
