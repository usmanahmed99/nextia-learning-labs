"""The export worker: takes queued exports from PostgreSQL and writes their CSV files.

    python -m city_api.worker            # runs until Ctrl+C (or SIGTERM)
    python -m city_api.worker --once     # does the jobs that wait now, then stops

One worker makes one file at a time. For more at once, start more workers (each in its
own terminal): the queue gives each job to exactly one of them (FOR UPDATE SKIP LOCKED).
On Ctrl+C or SIGTERM the worker finishes the file it is writing, then stops.
"""

import argparse
import logging
import os
import signal
import socket
import time

from city_api import exports, queries
from city_api.config import Settings, load_settings
from city_api.db import Database

logger = logging.getLogger("city_api.worker")


class Worker:
    def __init__(self, settings: Settings, database: Database, name: str | None = None):
        self.settings, self.db = settings, database
        self.name = name or f"{socket.gethostname()}-{os.getpid()}"
        self.stopping = False
        settings.export_dir.mkdir(parents=True, exist_ok=True)

    def run_one(self) -> dict | None:
        """Take one job and do it. Returns the job (None: nothing to do)."""
        with self.db.connection() as conn:
            exports.expired_without_attempts(conn)
            job = exports.claim(conn, self.name, self.settings.export_lease_seconds)
        if job is None:
            return None
        started = time.perf_counter()
        path = exports.file_path(self.settings.export_dir, job["export_id"])
        try:
            with self.db.connection() as conn:
                # One snapshot for the version and the rows: a load that commits while
                # the file is written does not mix two versions in one file.
                conn.execute("SET TRANSACTION ISOLATION LEVEL REPEATABLE READ")
                version = queries.data_version(conn)
                rows = exports.write_csv(conn, job["filters"], path)
            with self.db.connection() as conn:
                done = exports.succeed(
                    conn, job["export_id"], self.name, version, rows, path.stat().st_size
                )
            logger.info(
                "export %s: %s rows in %.2f s%s",
                job["export_id"],
                rows,
                time.perf_counter() - started,
                "" if done else " (another worker took it over)",
            )
        except Exception as error:  # noqa: BLE001 - any error: retry later, then dead letter
            delay = exports.backoff_seconds(job["attempts"])
            with self.db.connection() as conn:
                state = exports.fail(
                    conn, job, self.name, f"{type(error).__name__}: {error}", delay
                )
            logger.warning("export %s failed (%s): %s", job["export_id"], state, error)
        return job

    def run(self, once: bool = False) -> int:
        done = 0
        while not self.stopping:
            if self.run_one() is not None:
                done += 1
                continue
            if once:
                break
            time.sleep(self.settings.worker_poll_seconds)
        return done


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--once", action="store_true", help="stop when the queue is empty")
    args = parser.parse_args()
    settings = load_settings()
    logging.basicConfig(level=settings.log_level, format="%(levelname)s %(name)s: %(message)s")
    database = Database(settings.database_url, max_size=2, timeout=settings.db_pool_timeout)
    database.open()
    worker = Worker(settings, database)

    def stop(signum, frame):
        logger.info("stopping after the current export")
        worker.stopping = True

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    logger.info("worker %s: waiting for exports", worker.name)
    try:
        done = worker.run(once=args.once)
    finally:
        database.close()
    logger.info("worker %s stopped after %s exports", worker.name, done)


if __name__ == "__main__":
    main()
