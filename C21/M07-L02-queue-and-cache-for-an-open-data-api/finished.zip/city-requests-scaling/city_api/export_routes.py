"""Exports: a CSV file of a filtered query, made by a worker in the background.

POST /v1/exports saves a job and answers 202 at once, with Location: /v1/exports/{id}.
The client asks GET /v1/exports/{id} until the state is succeeded, then downloads
GET /v1/exports/{id}/file. Three protections keep the queue bounded:

- Idempotency-Key: a client that sends the same request again (after a timeout, say)
  gets the same job back (Idempotent-Replayed: true), not a second export.
- A rate limit per caller: more than EXPORT_RATE_PER_MINUTE exports in one minute
  -> 429 rate_limited, with Retry-After.
- A bound on the queue: EXPORT_QUEUE_MAX exports waiting -> 503 queue_full, with
  Retry-After from the queue's pace. Nothing is saved.
"""

import hashlib
import json
import re
import time
from typing import Annotated

from fastapi import APIRouter, Depends, Header, Path, Request, Response
from fastapi.responses import FileResponse

from city_api import exports
from city_api.cache import PREFIX
from city_api.errors import ApiError
from city_api.models import ErrorResponse, ExportJob, ExportQueue, ExportRequest
from city_api.security import require_api_key

CLIENT_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,39}$")

router = APIRouter(
    prefix="/v1",
    tags=["exports"],
    dependencies=[Depends(require_api_key)],
    responses={
        401: {"model": ErrorResponse, "description": "The API key is missing or wrong."},
        422: {"model": ErrorResponse, "description": "A parameter is not valid."},
    },
)


def actor_of(client_id: str | None) -> str:
    """Who asks. The header stands for a real sign-in, which an authentication layer adds."""
    if client_id is None:
        return "client:anonymous"
    if not CLIENT_ID.match(client_id):
        raise ApiError(
            422, "invalid_request", "X-Client-ID: 1 to 40 of a-z, 0-9 and -.", ["X-Client-ID"]
        )
    return f"client:{client_id}"


def check_rate(request: Request, actor: str) -> None:
    """A fixed window per caller and minute, counted in the shared cache. Without a
    cache there is no limit (fail open): the queue's bound still protects the service."""
    cache, limit = request.app.state.cache, request.app.state.settings.export_rate_per_minute
    if cache is None or limit <= 0:
        return
    now = time.time()
    count = cache.count(f"{PREFIX}:rate:exports:{actor}:{int(now // 60)}", 60)
    if count is not None and count > limit:
        retry = max(1, 60 - int(now % 60))
        raise ApiError(
            429,
            "rate_limited",
            f"More than {limit} exports in one minute. Try again in {retry} seconds.",
            headers={"Retry-After": str(retry)},
        )


def as_api(job: dict, ahead: int | None = None, wait: int | None = None) -> ExportJob:
    done = job["state"] == "succeeded"
    return ExportJob(
        export_id=job["export_id"],
        state=job["state"],
        filters=job["filters"],
        attempts=job["attempts"],
        created_at=job["created_at"].isoformat(timespec="seconds"),
        started_at=job["started_at"] and job["started_at"].isoformat(timespec="seconds"),
        finished_at=job["finished_at"] and job["finished_at"].isoformat(timespec="seconds"),
        queued_ahead=ahead,
        estimated_wait_seconds=wait,
        data_version=job["data_version"],
        row_count=job["row_count"],
        file_bytes=job["file_bytes"],
        download_url=f"/v1/exports/{job['export_id']}/file" if done else None,
        error=job["last_error"] if job["state"] != "succeeded" else None,
    )


@router.post(
    "/exports",
    status_code=202,
    summary="Ask for a CSV file of the requests that match the filters",
    responses={
        429: {"model": ErrorResponse, "description": "Too many exports from this caller."},
        503: {"model": ErrorResponse, "description": "The queue is full. See Retry-After."},
    },
)
def create_export(
    request: Request,
    response: Response,
    body: ExportRequest,
    idempotency_key: Annotated[str | None, Header(max_length=100)] = None,
    x_client_id: Annotated[str | None, Header()] = None,
) -> ExportJob:
    if body.created_from and body.created_to and body.created_from >= body.created_to:
        raise ApiError(
            422,
            "invalid_range",
            "created_from must be before created_to.",
            ["created_from", "created_to"],
        )
    actor = actor_of(x_client_id)
    filters = {
        "borough": body.borough,
        "complaint_type": body.complaint_type,
        "status": body.status,
        "created_from": body.created_from and body.created_from.isoformat(),
        "created_to": body.created_to and body.created_to.isoformat(),
    }
    sha = hashlib.sha256(json.dumps(filters, sort_keys=True).encode()).hexdigest()
    settings = request.app.state.settings
    check_rate(request, actor)
    try:
        with request.app.state.db.connection() as conn:
            job, replayed = exports.submit(
                conn,
                actor,
                filters,
                sha,
                idempotency_key=idempotency_key,
                queue_max=settings.export_queue_max,
                max_attempts=settings.export_max_attempts,
            )
            ahead = exports.queued_ahead(conn, job) if job["state"] == "queued" else None
            wait = exports.estimated_wait(conn, ahead) if ahead is not None else None
    except exports.IdempotencyConflict:
        raise ApiError(
            422,
            "idempotency_key_reused",
            "This Idempotency-Key was used for another request. Use a new key.",
            ["Idempotency-Key"],
        ) from None
    except exports.QueueFull as full:
        raise ApiError(
            503,
            "queue_full",
            f"{full.queued} exports are waiting. Try again in {full.retry_after} seconds.",
            headers={"Retry-After": str(full.retry_after)},
        ) from None
    response.headers["Location"] = f"/v1/exports/{job['export_id']}"
    if replayed:
        response.headers["Idempotent-Replayed"] = "true"
    return as_api(job, ahead, wait)


@router.get("/export-queue", summary="How many exports wait, and how old the oldest is")
def export_queue(request: Request) -> ExportQueue:
    with request.app.state.db.connection() as conn:
        return ExportQueue(**exports.stats(conn))


def find(request: Request, export_id: int) -> tuple[dict, int | None, int | None]:
    with request.app.state.db.connection() as conn:
        job = exports.get(conn, export_id)
        if job is None:
            raise ApiError(404, "not_found", f"No export has the ID {export_id}.")
        ahead = exports.queued_ahead(conn, job) if job["state"] == "queued" else None
        wait = exports.estimated_wait(conn, ahead) if ahead is not None else None
    return job, ahead, wait


@router.get(
    "/exports/{export_id}",
    summary="Get the state of an export",
    responses={404: {"model": ErrorResponse, "description": "No export has this ID."}},
)
def get_export(request: Request, export_id: Annotated[int, Path(ge=1)]) -> ExportJob:
    job, ahead, wait = find(request, export_id)
    return as_api(job, ahead, wait)


@router.get(
    "/exports/{export_id}/file",
    summary="Download the CSV file of a finished export",
    response_class=FileResponse,
    responses={
        200: {"content": {"text/csv": {}}, "description": "The CSV file."},
        404: {"model": ErrorResponse, "description": "No such export."},
        409: {"model": ErrorResponse, "description": "The export has not succeeded (yet)."},
    },
)
def download_export(request: Request, export_id: Annotated[int, Path(ge=1)]):
    job, _, _ = find(request, export_id)
    if job["state"] != "succeeded":
        raise ApiError(409, "not_ready", f"The export is {job['state']}, not succeeded.")
    path = exports.file_path(request.app.state.settings.export_dir, export_id)
    if not path.is_file():
        raise ApiError(404, "not_found", "The file of this export is no longer kept.")
    return FileResponse(
        path, media_type="text/csv", filename=f"service-requests-export-{export_id}.csv"
    )
