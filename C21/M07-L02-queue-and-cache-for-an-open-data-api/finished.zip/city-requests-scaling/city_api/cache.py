"""A shared cache in Valkey for the expensive answers (the aggregates).

Valkey (BSD licence) is an open-source fork of Redis and speaks the same protocol, so the
client is the `redis` package. Every API process uses the same cache.

The key holds everything that changes the answer:

    city:v1:stats-daily:data=7:scope=public:3f9c...
         |  |           |      |            the request's values, normalised and hashed
         |  |           |      who may see it: the data is open, so everyone ("public")
         |  |           the data version: a new load of requests makes a new key
         |  which answer
         the format of the stored value

So new data needs no search for old keys: the next key is a new one, and old keys are
never read again; their TTL removes them.

The routes are normal functions, which FastAPI runs in a thread pool, so the client is
the normal (blocking) one. In an async endpoint, use redis.asyncio instead.

When the cache does not answer (it is down, or slower than CACHE_TIMEOUT), the API works
without it: the answer is computed, X-Cache says "off", and the cache is not tried again
for a few seconds (fail open).
"""

import hashlib
import json
import logging
import threading
import time
import uuid
from collections.abc import Callable

import redis

logger = logging.getLogger("city_api")

PREFIX = "city"


def answer_key(name: str, data_version: int, params: dict, scope: str = "public") -> str:
    """The key of a cached answer. The same parameters in another order give the same key."""
    text = json.dumps(params, sort_keys=True, default=str, separators=(",", ":"))
    digest = hashlib.sha256(text.encode()).hexdigest()[:32]
    return f"{PREFIX}:v1:{name}:data={data_version}:scope={scope}:{digest}"


class Cache:
    def __init__(self, url: str, timeout: float = 0.05, retry_after_failure: float = 5.0):
        self.client = redis.Redis.from_url(
            url, socket_timeout=timeout, socket_connect_timeout=timeout, decode_responses=True
        )
        self.retry_after_failure = retry_after_failure
        self.down_until = 0.0
        self._lock = threading.Lock()
        self.hits = self.misses = self.waits = self.off = 0

    # ----- the cache may fail: then we work without it for a few seconds -----

    def available(self) -> bool:
        return time.monotonic() >= self.down_until

    def _failed(self, error: Exception) -> None:
        with self._lock:
            if self.available():
                logger.warning("cache not available (%s): working without it", error)
            self.down_until = time.monotonic() + self.retry_after_failure

    def get(self, key: str):
        """(found, value). A failure counts as not found."""
        if not self.available():
            return False, None
        try:
            raw = self.client.get(key)
        except redis.RedisError as error:
            self._failed(error)
            return False, None
        return (False, None) if raw is None else (True, json.loads(raw))

    def set(self, key: str, value, ttl: int) -> None:
        if not self.available():
            return
        try:
            self.client.set(key, json.dumps(value, default=str), ex=ttl)
        except redis.RedisError as error:
            self._failed(error)

    # ----- one computation at a time per key (the stampede guard) -----

    def lock(self, key: str, seconds: float) -> str | None:
        """A token if this caller may compute the value of `key`; None if another one does."""
        if not self.available():
            return None
        token = uuid.uuid4().hex
        try:
            if self.client.set(f"{key}:lock", token, nx=True, px=int(seconds * 1000)):
                return token
        except redis.RedisError as error:
            self._failed(error)
        return None

    def unlock(self, key: str, token: str) -> None:
        # Delete the lock only if it is still ours (it may have expired and been taken).
        script = (
            "if redis.call('get', KEYS[1]) == ARGV[1] then "
            "return redis.call('del', KEYS[1]) else return 0 end"
        )
        try:
            self.client.eval(script, 1, f"{key}:lock", token)
        except redis.RedisError as error:
            self._failed(error)

    def count(self, key: str, window_seconds: int) -> int | None:
        """Add 1 to a counter that lives for one window. Its new value (None: no cache)."""
        if not self.available():
            return None
        try:
            with self.client.pipeline(transaction=True) as pipe:
                pipe.incr(key)
                pipe.expire(key, window_seconds + 1, nx=True)
                value, _ = pipe.execute()
            return int(value)
        except redis.RedisError as error:
            self._failed(error)
            return None

    def ping(self) -> bool:
        try:
            return bool(self.client.ping())
        except redis.RedisError:
            return False

    def close(self) -> None:
        self.client.close()

    # ----- the whole path: hit, or one request computes while the others wait -----

    def get_or_compute(self, key: str, compute: Callable, ttl: int, lock_seconds: float):
        """(value, how): how is "hit", "miss" (we computed it), "wait" (another request
        computed it while we waited) or "off" (no cache: computed without it)."""
        found, value = self.get(key)
        if found:
            self.hits += 1
            return value, "hit"
        if not self.available():
            self.off += 1
            return compute(), "off"
        token = self.lock(key, lock_seconds)
        if token is None and self.available():
            # Another request computes this answer now: wait for it, up to the lock's time.
            deadline = time.monotonic() + lock_seconds
            while time.monotonic() < deadline and self.available():
                time.sleep(0.02)
                found, value = self.get(key)
                if found:
                    self.waits += 1
                    return value, "wait"
        if not self.available():
            self.off += 1
            return compute(), "off"
        try:
            value = compute()
            self.set(key, value, ttl)
        finally:
            if token is not None:
                self.unlock(key, token)
        self.misses += 1
        return value, "miss"


def make_cache(url: str | None, timeout: float) -> Cache | None:
    return Cache(url, timeout=timeout) if url else None
