"""The export queue in PostgreSQL: every SQL statement of the export jobs, in one place.

A job's life:

    submit -> queued -> running -> succeeded
                 ^         |-----> dead_letter  (still failing after max_attempts: a person looks)
                 |---------|       (an error: queued again, later, with backoff and jitter)

A worker takes a job with a lease (locked_until). If the worker stops without finishing,
the lease ends and another worker takes the job again: the job is DELIVERED TWICE. The
work is idempotent: the file is written under a temporary name and renamed at the end,
so a second delivery writes the same file again, never a second or a half file.
"""

import csv
import json
import math
import os
import random
from pathlib import Path

import psycopg

from city_api.queries import COLUMNS, as_api, where

FINISHED = ("succeeded", "failed", "cancelled", "dead_letter")
JOB_COLUMNS = (
    "export_id, actor, filters, state, attempts, max_attempts, run_after, locked_by,"
    " locked_until, last_error, data_version, row_count, file_bytes, created_at,"
    " started_at, finished_at"
)
# Any number: the key of the lock that makes "count, then insert" one step.
SUBMIT_LOCK = 211


class IdempotencyConflict(Exception):
    """The same Idempotency-Key came with a different request."""


class QueueFull(Exception):
    def __init__(self, queued: int, retry_after: int):
        super().__init__(f"{queued} exports are waiting")
        self.queued, self.retry_after = queued, retry_after


def submit(
    conn: psycopg.Connection,
    actor: str,
    filters: dict,
    request_sha256: str,
    *,
    idempotency_key: str | None,
    queue_max: int,
    max_attempts: int,
) -> tuple[dict, bool]:
    """Save a new queued job, or find the one that this key already made.
    Returns (job, replayed). Raises IdempotencyConflict or QueueFull."""
    # One submit at a time: without it, two requests could both count 19 and both insert,
    # and a queue bounded at 20 would hold 21.
    conn.execute("SELECT pg_advisory_xact_lock(%s)", (SUBMIT_LOCK,))
    if idempotency_key is not None:
        old = conn.execute(
            f"SELECT {JOB_COLUMNS}, request_sha256 FROM export_jobs"
            " WHERE actor = %s AND idempotency_key = %s",
            (actor, idempotency_key),
        ).fetchone()
        if old is not None:
            if old.pop("request_sha256") != request_sha256:
                raise IdempotencyConflict(idempotency_key)
            return old, True
    queued = queued_count(conn)
    if queued >= queue_max:
        raise QueueFull(queued, retry_after_seconds(conn, queued))
    job = conn.execute(
        "INSERT INTO export_jobs (actor, idempotency_key, request_sha256, filters, max_attempts)"
        f" VALUES (%s, %s, %s, %s, %s) RETURNING {JOB_COLUMNS}",
        (actor, idempotency_key, request_sha256, json.dumps(filters), max_attempts),
    ).fetchone()
    return job, False


def get(conn: psycopg.Connection, export_id: int) -> dict | None:
    return conn.execute(
        f"SELECT {JOB_COLUMNS} FROM export_jobs WHERE export_id = %s", (export_id,)
    ).fetchone()


def claim(conn: psycopg.Connection, worker: str, lease_seconds: float) -> dict | None:
    """Take one job: a queued job that may run now, or a running job whose lease has ended
    (its worker stopped). SKIP LOCKED: a row that another worker is taking is skipped."""
    return conn.execute(
        "UPDATE export_jobs SET state = 'running', attempts = attempts + 1,"
        " locked_by = %(worker)s, locked_until = now() + make_interval(secs => %(lease)s),"
        " started_at = coalesce(started_at, now()), updated_at = now()"
        " WHERE export_id = ("
        "   SELECT export_id FROM export_jobs"
        "   WHERE ((state = 'queued' AND run_after <= now())"
        "      OR (state = 'running' AND locked_until < now()))"
        "     AND attempts < max_attempts"
        "   ORDER BY run_after, export_id LIMIT 1 FOR UPDATE SKIP LOCKED)"
        f" RETURNING {JOB_COLUMNS}",
        {"worker": worker, "lease": lease_seconds},
    ).fetchone()


def expired_without_attempts(conn: psycopg.Connection) -> int:
    """Running jobs whose lease ended and that have no attempt left: dead letters."""
    return conn.execute(
        "UPDATE export_jobs SET state = 'dead_letter', finished_at = now(), updated_at = now(),"
        " last_error = coalesce(last_error, 'the worker stopped during the last attempt'),"
        " locked_by = NULL, locked_until = NULL"
        " WHERE state = 'running' AND locked_until < now() AND attempts >= max_attempts"
    ).rowcount


def succeed(
    conn: psycopg.Connection, export_id: int, worker: str, data_version: int, rows: int, size: int
) -> bool:
    """Mark the job done, only if this worker still holds it."""
    return (
        conn.execute(
            "UPDATE export_jobs SET state = 'succeeded', data_version = %s, row_count = %s,"
            " file_bytes = %s, last_error = NULL, finished_at = now(), updated_at = now(),"
            " locked_by = NULL, locked_until = NULL"
            " WHERE export_id = %s AND locked_by = %s AND state = 'running'",
            (data_version, rows, size, export_id, worker),
        ).rowcount
        == 1
    )


def fail(conn: psycopg.Connection, job: dict, worker: str, error: str, delay: float) -> str:
    """After an error: queued again after `delay`, or a dead letter if no attempt is left."""
    last = job["attempts"] >= job["max_attempts"]
    conn.execute(
        "UPDATE export_jobs SET state = %s, last_error = %s,"
        " run_after = now() + make_interval(secs => %s),"
        " finished_at = CASE WHEN %s THEN now() END,"
        " locked_by = NULL, locked_until = NULL, updated_at = now()"
        " WHERE export_id = %s AND locked_by = %s AND state = 'running'",
        ("dead_letter" if last else "queued", error[:500], delay, last, job["export_id"], worker),
    )
    return "dead_letter" if last else "queued"


def release(conn: psycopg.Connection, export_id: int, worker: str) -> bool:
    """Give a job back without counting the attempt: the worker is stopping."""
    return (
        conn.execute(
            "UPDATE export_jobs SET state = 'queued', attempts = attempts - 1,"
            " locked_by = NULL, locked_until = NULL, updated_at = now()"
            " WHERE export_id = %s AND locked_by = %s AND state = 'running'",
            (export_id, worker),
        ).rowcount
        == 1
    )


def queued_count(conn: psycopg.Connection) -> int:
    return conn.execute("SELECT count(*) AS n FROM export_jobs WHERE state = 'queued'").fetchone()[
        "n"
    ]


def queued_ahead(conn: psycopg.Connection, job: dict) -> int:
    return conn.execute(
        "SELECT count(*) AS n FROM export_jobs"
        " WHERE state = 'queued' AND (run_after, export_id) < (%s, %s)",
        (job["run_after"], job["export_id"]),
    ).fetchone()["n"]


def pace_per_second(conn: psycopg.Connection) -> float:
    """Exports finished in the last minute, per second: how fast the queue moves now."""
    n = conn.execute(
        "SELECT count(*) AS n FROM export_jobs"
        " WHERE state = 'succeeded' AND finished_at > now() - interval '1 minute'"
    ).fetchone()["n"]
    return n / 60


def retry_after_seconds(conn: psycopg.Connection, queued: int) -> int:
    """When to try again: the time the queue needs to move by its length (1 to 300 s).
    With no export finished in the last minute, we cannot know: 60 s."""
    pace = pace_per_second(conn)
    if pace == 0:
        return 60
    return max(1, min(300, math.ceil(queued / pace)))


def estimated_wait(conn: psycopg.Connection, ahead: int) -> int | None:
    pace = pace_per_second(conn)
    return math.ceil((ahead + 1) / pace) if pace else None


def stats(conn: psycopg.Connection) -> dict:
    """The numbers to watch: how many wait, how old the oldest is, how many finished."""
    row = conn.execute(
        "SELECT"
        " count(*) FILTER (WHERE state = 'queued') AS queued,"
        " count(*) FILTER (WHERE state = 'running') AS running,"
        " count(*) FILTER (WHERE state = 'dead_letter') AS dead_letter,"
        " count(*) FILTER (WHERE state = 'succeeded'"
        "   AND finished_at > now() - interval '1 minute') AS succeeded_last_minute,"
        " coalesce(extract(epoch FROM now() - min(created_at)"
        "   FILTER (WHERE state = 'queued')), 0) AS oldest_queued_seconds"
        " FROM export_jobs"
    ).fetchone()
    return {
        k: (round(float(v), 1) if k == "oldest_queued_seconds" else int(v)) for k, v in row.items()
    }


def backoff_seconds(attempt: int, base: float = 2.0, cap: float = 60.0, rng=random) -> float:
    """Exponential backoff with full jitter: a random wait from 0 to base * 2^(attempt-1)."""
    return rng.uniform(0, min(cap, base * 2 ** (attempt - 1)))


# ----- the work itself: one CSV file -----

HEADER = [c.strip() for c in COLUMNS.split(",")]


def file_path(export_dir: Path, export_id: int) -> Path:
    return export_dir / f"export-{export_id}.csv"


def write_csv(conn: psycopg.Connection, filters: dict, path: Path) -> int:
    """Write every request that matches the filters, oldest first, into `path`.
    The file appears only when it is complete: it is written as path.tmp, then renamed.
    Returns the number of rows."""
    condition, params = where(filters)
    tmp = path.with_suffix(".csv.tmp")
    rows = 0
    with tmp.open("w", encoding="utf-8", newline="") as out:
        writer = csv.writer(out)
        writer.writerow(HEADER)
        # A server-side cursor: PostgreSQL sends the rows in batches of 2,000, so a
        # large export does not hold every row in memory at once.
        with conn.cursor(name="export") as cur:
            cur.itersize = 2000
            cur.execute(
                f"SELECT {COLUMNS} FROM service_requests WHERE {condition} ORDER BY created_at, id",
                params,
            )
            for row in cur:
                item = as_api(row)
                writer.writerow(["" if item[c] is None else item[c] for c in HEADER])
                rows += 1
    os.replace(tmp, path)
    return rows
