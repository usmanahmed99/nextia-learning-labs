# city-requests-scaling

A read-only web API over New York City's 311 street-repair requests from January to June 2025 (109,915 requests), made ready for a busy Monday morning:

- The daily numbers and the complaint types come from a **cache** (Valkey) while the data does not change. The key holds the data version, so a load of new requests makes every old answer unused at once.
- A **CSV export** is a background job: `POST /v1/exports` answers `202` at once, a worker writes the file, and the client downloads it. The queue is bounded (`503 queue_full` with `Retry-After`), each caller has a rate limit (`429 rate_limited`), and an `Idempotency-Key` makes a repeated request return the same job.

It starts from the API of the API course's case study *Build a data API for city service requests*, moved to PostgreSQL. `docs/workload.md` states the workload, and `docs/results.md` the measured results.

## Requirements

- Python 3.12 or newer, and Docker (PostgreSQL 18 and Valkey 9 run in containers).

## Set up

```sh
python3 -m venv .venv
source .venv/bin/activate                # Windows: .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
docker compose up -d                     # PostgreSQL on 5432, Valkey on 6379
python scripts/get_db.py                 # downloads and checks the data (8 MB)
python -m scripts.load                   # January to May: data version 1
python -m scripts.load --month 2025-06   # June, as new data: data version 2
python -m pytest
```

## Run

Three terminals, each with the virtual environment active:

```sh
fastapi dev                  # the API, http://127.0.0.1:8000
python -m city_api.worker    # an export worker (start two for two exports at once)
curl -i "http://127.0.0.1:8000/v1/stats/daily?created_from=2025-06-01&created_to=2025-07-01"
```

Settings are environment variables; `.env.example` lists them, with their defaults. Without Valkey the API still works, without a cache (`X-Cache: off`).

| Endpoint | Meaning |
|---|---|
| `GET /v1/service-requests` | Requests, oldest first, filtered; follow `next_cursor` |
| `GET /v1/service-requests/{id}` | One request |
| `GET /v1/complaint-types` | The complaint types, with counts (cached, `X-Cache`) |
| `GET /v1/stats/daily` | Daily numbers, at most 92 days (cached, `X-Cache`) |
| `GET /v1/dataset` | The source, the rules and the data version |
| `POST /v1/exports` | Ask for a CSV file of a filter: `202` and `Location` |
| `GET /v1/exports/{id}`, `GET /v1/exports/{id}/file` | The state of an export, and its file |
| `GET /v1/export-queue` | How many exports wait, and how old the oldest is |
| `GET /health`, `GET /ready` | Liveness, and readiness (the database answers) |

## Measure

Only against your own API on your own computer. Start the API without a log line per request, and two workers:

```sh
LOG_LEVEL=WARNING fastapi run
python -m scripts.bench --label finished                                  # Monday morning
python -m scripts.bench --label finished-burst --analysts 16 --export-pace 0
python -m scripts.bench --label finished-capacity --viewers 32 --pace 0 --analysts 0 --seconds 40
python -m scripts.send_exports --count 30                                 # the queue's bound
```

## Check

```sh
python -m pytest     # needs docker compose up -d
ruff check .
```

When the contract test fails, read the difference. If the change is intended, run `python -m city_api.export_contract` and review `contract/openapi.json`.

## Data and licence

The code is under the MIT licence (`LICENSE`). The data is from NYC Open Data, 311 Service Requests (erm2-nwe9), agency DOT, snapshot of 2026-10-07, cleaned as `DATASET.md` describes. NYC Open Data has no restrictions on use.
