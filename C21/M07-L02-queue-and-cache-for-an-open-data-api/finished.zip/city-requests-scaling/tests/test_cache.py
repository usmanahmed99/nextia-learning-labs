"""The cache: hits, keys that hold everything that changes the answer, new data, failure."""

from concurrent.futures import ThreadPoolExecutor

import psycopg
import pytest

from city_api import queries
from city_api.cache import answer_key

STATS = {"created_from": "2025-03-01", "created_to": "2025-03-06"}


def test_second_request_is_a_hit_with_the_same_answer(client):
    first = client.get("/v1/stats/daily", params=STATS)
    second = client.get("/v1/stats/daily", params=STATS)
    assert first.headers["X-Cache"] == "miss"
    assert second.headers["X-Cache"] == "hit"
    assert first.json() == second.json()
    assert second.headers["X-Data-Version"] == "1"


def test_the_order_of_parameters_does_not_change_the_key(client):
    client.get("/v1/stats/daily?created_from=2025-03-01&created_to=2025-03-06&borough=bronx")
    again = client.get(
        "/v1/stats/daily?borough=bronx&created_to=2025-03-06&created_from=2025-03-01"
    )
    assert again.headers["X-Cache"] == "hit"


@pytest.mark.parametrize(
    "other",
    [
        {**STATS, "borough": "queens"},
        {**STATS, "complaint_type": "Street Condition"},
        {"created_from": "2025-03-01", "created_to": "2025-03-07"},
    ],
)
def test_other_parameters_are_another_key(client, other):
    client.get("/v1/stats/daily", params=STATS)
    response = client.get("/v1/stats/daily", params=other)
    assert response.headers["X-Cache"] == "miss"


def test_the_key_holds_the_version_and_the_scope():
    key = answer_key("stats-daily", 7, {"borough": None, "created_from": "2025-03-01"})
    assert key.startswith("city:v1:stats-daily:data=7:scope=public:")
    assert key != answer_key("stats-daily", 8, {"borough": None, "created_from": "2025-03-01"})


def test_an_error_is_not_cached(client):
    bad = {"created_from": "2025-03-06", "created_to": "2025-03-01"}
    assert client.get("/v1/stats/daily", params=bad).status_code == 422
    assert "X-Cache" not in client.get("/v1/stats/daily", params=bad).headers


@pytest.fixture
def new_data(database_url):
    """Add one request on 2025-03-05 as a new load (data version 2); remove it afterwards."""

    def load():
        with psycopg.connect(database_url) as conn:
            conn.execute(
                "INSERT INTO service_requests (id, created_at, closed_at, status, complaint_type,"
                " borough, days_to_close) VALUES (99000001, '2025-03-05T09:00:00',"
                " '2025-03-06T09:00:00', 'closed', 'Street Condition', 'bronx', 1.0)"
            )
            conn.execute(
                "INSERT INTO data_loads (created_from, created_to, rows_added)"
                " VALUES ('2025-03-05', '2025-03-06', 1)"
            )

    yield load
    with psycopg.connect(database_url) as conn:
        conn.execute("DELETE FROM service_requests WHERE id = 99000001")
        conn.execute("DELETE FROM data_loads WHERE version > 1")


def test_new_data_makes_a_new_key(client, new_data):
    before = client.get("/v1/stats/daily", params=STATS)
    assert client.get("/v1/stats/daily", params=STATS).headers["X-Cache"] == "hit"
    new_data()
    after = client.get("/v1/stats/daily", params=STATS)
    assert after.headers["X-Cache"] == "miss"
    assert after.headers["X-Data-Version"] == "2"
    assert before.json()["items"][4]["opened"] == 6
    assert after.json()["items"][4]["opened"] == 7  # the new request is counted at once
    types = {
        t["complaint_type"]: t["count"] for t in client.get("/v1/complaint-types").json()["items"]
    }
    assert types["Street Condition"] == 13


def test_cache_down_still_answers(make_client):
    client = make_client(cache_url="redis://127.0.0.1:1/0")  # nothing listens on port 1
    response = client.get("/v1/stats/daily", params=STATS)
    assert response.status_code == 200
    assert response.headers["X-Cache"] == "off"
    assert len(response.json()["items"]) == 5


def test_without_a_cache_url_there_is_no_cache_header(make_client):
    response = make_client(cache_url=None).get("/v1/complaint-types")
    assert response.status_code == 200
    assert "X-Cache" not in response.headers


def test_one_computation_for_many_requests_at_once(client, monkeypatch):
    """The stampede guard: 8 requests for a new key at the same time compute it once."""
    calls = []
    original = queries.complaint_types

    def slow(conn):
        calls.append(1)
        conn.execute("SELECT pg_sleep(0.3)")
        return original(conn)

    monkeypatch.setattr(queries, "complaint_types", slow)
    with ThreadPoolExecutor(8) as pool:
        results = list(pool.map(lambda _: client.get("/v1/complaint-types"), range(8)))
    hows = sorted(r.headers["X-Cache"] for r in results)
    assert all(r.status_code == 200 for r in results)
    assert hows.count("miss") == 1 and hows.count("wait") == 7
    assert len(calls) == 1
