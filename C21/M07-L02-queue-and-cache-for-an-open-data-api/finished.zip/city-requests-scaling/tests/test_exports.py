"""Exports through the queue: 202, the worker, idempotency, backpressure, a second delivery."""

import csv
import io

import psycopg
import pytest

from city_api import exports
from city_api.db import Database
from city_api.worker import Worker

BROOKLYN = {"borough": "brooklyn"}


@pytest.fixture(autouse=True)
def empty_queue(database_url):
    with psycopg.connect(database_url) as conn:
        conn.execute("TRUNCATE export_jobs RESTART IDENTITY")


@pytest.fixture
def worker(client):
    app = client.app
    database = Database(app.state.settings.database_url, max_size=2)
    database.open()
    yield Worker(app.state.settings, database, name="test-worker")
    database.close()


def submit(client, body, key=None, client_id="dash-ops"):
    headers = {"X-Client-ID": client_id}
    if key:
        headers["Idempotency-Key"] = key
    return client.post("/v1/exports", json=body, headers=headers)


def test_export_answers_202_at_once_and_the_worker_makes_the_file(client, worker):
    response = submit(client, BROOKLYN)
    assert response.status_code == 202
    job = response.json()
    assert job["state"] == "queued" and job["queued_ahead"] == 0
    assert response.headers["Location"] == f"/v1/exports/{job['export_id']}"
    assert client.get(response.headers["Location"] + "/file").status_code == 409

    assert worker.run(once=True) == 1
    done = client.get(response.headers["Location"]).json()
    assert done["state"] == "succeeded" and done["data_version"] == 1
    assert done["download_url"] == f"/v1/exports/{job['export_id']}/file"

    file = client.get(done["download_url"])
    assert file.status_code == 200 and file.headers["content-type"].startswith("text/csv")
    rows = list(csv.DictReader(io.StringIO(file.text)))
    listed = client.get("/v1/service-requests", params={"limit": 200, **BROOKLYN}).json()
    assert [int(r["id"]) for r in rows] == [item["id"] for item in listed["items"]]
    assert done["row_count"] == len(rows) == 7


def test_the_csv_has_the_api_values(client, worker):
    location = submit(
        client, {"created_from": "2025-03-03T17:55:20", "created_to": "2025-03-03T17:55:21"}
    ).headers["Location"]
    worker.run(once=True)
    row = next(csv.DictReader(io.StringIO(client.get(location + "/file").text)))
    assert row["id"] == "64246800" and row["created_at"] == "2025-03-03T17:55:20"
    assert row["borough"] == "manhattan" and row["days_to_close"] == "0.97"


def test_same_idempotency_key_gives_the_same_job(client):
    first = submit(client, BROOKLYN, key="k-1")
    again = submit(client, BROOKLYN, key="k-1")
    assert again.status_code == 202
    assert again.json()["export_id"] == first.json()["export_id"]
    assert again.headers["Idempotent-Replayed"] == "true"
    assert client.get("/v1/export-queue").json()["queued"] == 1


def test_same_key_from_another_caller_is_another_job(client):
    first = submit(client, BROOKLYN, key="k-1", client_id="dash-ops")
    other = submit(client, BROOKLYN, key="k-1", client_id="dash-roads")
    assert other.json()["export_id"] != first.json()["export_id"]


def test_same_key_with_another_body_is_refused(client):
    submit(client, BROOKLYN, key="k-1")
    response = submit(client, {"borough": "queens"}, key="k-1")
    assert response.status_code == 422
    assert response.json()["error"]["code"] == "idempotency_key_reused"


def test_full_queue_gives_503_with_retry_after_and_saves_nothing(make_client):
    client = make_client(export_queue_max=2)
    assert submit(client, BROOKLYN).status_code == 202
    assert submit(client, BROOKLYN).status_code == 202
    response = submit(client, BROOKLYN)
    assert response.status_code == 503
    assert response.json()["error"]["code"] == "queue_full"
    assert 1 <= int(response.headers["Retry-After"]) <= 300
    assert client.get("/v1/export-queue").json()["queued"] == 2


def test_rate_limit_per_caller_gives_429(make_client):
    client = make_client(export_rate_per_minute=2)
    assert submit(client, BROOKLYN, client_id="a").status_code == 202
    assert submit(client, BROOKLYN, client_id="a").status_code == 202
    response = submit(client, BROOKLYN, client_id="a")
    assert response.status_code == 429
    assert response.json()["error"]["code"] == "rate_limited"
    assert 1 <= int(response.headers["Retry-After"]) <= 60
    assert submit(client, BROOKLYN, client_id="b").status_code == 202  # another caller


@pytest.mark.parametrize(
    ("body", "field"),
    [({"borough": "Brooklyn"}, "borough"), ({"limit": 5}, "limit"), ({"status": "done"}, "status")],
)
def test_invalid_export_requests(client, body, field):
    response = submit(client, body)
    assert response.status_code == 422
    assert response.json()["error"]["fields"] == [field]


def test_invalid_client_id(client):
    response = submit(client, BROOKLYN, client_id="Not Valid!")
    assert response.status_code == 422
    assert response.json()["error"]["fields"] == ["X-Client-ID"]


def test_unknown_export_gives_404(client):
    assert client.get("/v1/exports/999").status_code == 404


def test_second_delivery_writes_the_same_single_file(client, worker, database_url):
    """A worker took the job and stopped (its lease ended). Another worker takes it again."""
    export_id = submit(client, BROOKLYN).json()["export_id"]
    with psycopg.connect(database_url) as conn:  # worker 1 takes it, then "crashes"
        conn.execute(
            "UPDATE export_jobs SET state = 'running', attempts = 1, locked_by = 'gone',"
            " locked_until = now() - interval '1 second', started_at = now() WHERE export_id = %s",
            (export_id,),
        )
    path = exports.file_path(worker.settings.export_dir, export_id)
    path.with_suffix(".csv.tmp").write_text("half a fi")  # what the crash left behind
    assert worker.run(once=True) == 1
    job = client.get(f"/v1/exports/{export_id}").json()
    assert job["state"] == "succeeded" and job["attempts"] == 2
    assert sorted(p.name for p in path.parent.iterdir()) == [path.name]  # one complete file
    assert len(path.read_text().splitlines()) == 8  # the header and 7 rows


def test_errors_are_retried_then_dead_letter(client, worker, monkeypatch):
    def broken(conn, filters, path):
        raise OSError("disk full")

    monkeypatch.setattr(exports, "write_csv", broken)
    monkeypatch.setattr(exports, "backoff_seconds", lambda attempt: 0)
    export_id = submit(client, BROOKLYN).json()["export_id"]
    worker.run(once=True)  # 3 attempts, then no attempt is left
    job = client.get(f"/v1/exports/{export_id}").json()
    assert job["state"] == "dead_letter" and job["attempts"] == 3
    assert "disk full" in job["error"]
