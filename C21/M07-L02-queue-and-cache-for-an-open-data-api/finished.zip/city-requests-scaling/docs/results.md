# Results

The author's measurements of the three versions of this project, under the workload of
`docs/workload.md`. Replace them with your own: your computer, your three runs.

## Machine

Apple M4, 10 cores, 16 GB memory, Darwin 25.6.0 (arm64); Docker Engine 29.6.1, 10 CPUs, 7.8 GB;
PostgreSQL 18.6 and Valkey 9.1.2 in Docker; Python 3.12.13. The API ran as one process
(`LOG_LEVEL=WARNING fastapi run`); the finished version had two workers. Locust ran on the same
computer. The computer was shared with other work: the 1-minute load average before the
passes was between 3.3 and 12.1.

## How

`python -m scripts.bench` with the three workloads (`--label …`; the burst adds `--analysts 16
--export-pace 0`; the capacity run `--viewers 32 --pace 0 --analysts 0 --seconds 40`). Each
run is 3 passes of 60 seconds (40 for capacity), without the first 10 seconds of each pass.
Every number below is the **median of the 3 passes**; the ranges are in `results/*.json`.

## Results

| Workload | Measure | Starter | Cache | Cache and queue |
|---|---|---|---|---|
| Monday morning | dashboard p50 / p95 / p99 (ms) | 29 / 175 / 289 | 23 / 118 / 182 | 23 / 48 / 56 |
| Monday morning | dashboard errors | 0 | 0 | 0 |
| Monday morning | export, click to file, p50 / p95 (ms) | 302 / 1,035 | 306 / 1,237 | 1,057 / 2,139 |
| Monday morning | files per second | 0.4 | 0.4 | 0.4 |
| Monday morning | exports refused (429), per pass | 0 | 0 | 0 |
| Monday morning | API CPU mean / API memory max | 7% / 284 MB | 7% / 284 MB | 3% / 94 MB |
| Monday morning | database CPU mean | 9% | 4% | 3% |
| Month-end burst | dashboard p50 / p95 / p99 (ms) | 1,340 / 1,970 / 2,244 | 1,340 / 2,213 / 2,875 | 30 / 53 / 68 |
| Month-end burst | dashboard errors | 0 | 0 | 0 |
| Month-end burst | export, click to file, p50 / p95 (ms) | 2,262 / 5,499 | 2,350 / 5,129 | 2,024 / 2,256 |
| Month-end burst | files per second | 5.7 | 5.6 | 3.6 |
| Month-end burst | exports refused (429), per pass | 0 | 0 | 75,327 |
| Month-end burst | API CPU mean / API memory max | 104% / 974 MB | 104% / 604 MB | 70% / 99 MB |
| Month-end burst | database CPU mean | 20% | 16% | 15% |
| Capacity | dashboard requests per second | 881 | 1,348 | 1,409 |
| Capacity | dashboard p95 (ms) | 50 | 37 | 32 |
| Capacity | API CPU mean / database CPU mean | 123% / 315% | 127% / 33% | 142% / 33% |

## What changed

- The cache raised the dashboards-only capacity by about half and cut the database's CPU from
  about three cores to a third of one. It did not help the month-end burst: the exports' CPU
  work was in the API process.
- The export queue brought the burst's dashboard p95 under the 300 ms target and the API's
  memory from about 1 GB to about 100 MB. A small export waits longer from click to file,
  because the client asks for the state once a second.
- The 429 refusals come from the load test's analysts: they ask back to back and do not wait
  for `Retry-After`. Each analyst may start 10 exports a minute (`EXPORT_RATE_PER_MINUTE`).
- No export timed out in any version at this data size (90,329 rows).

## The next bottleneck

With the cache, the dashboards-only run is limited by the one API process (its CPU is the
highest; the database is at about a third of one core). The next step is more API processes,
measured in the same way. Do not extrapolate these numbers to another computer, another data
size or a network.
