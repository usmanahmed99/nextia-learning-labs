"""Test fixtures: a small PostgreSQL database with 30 real rows.

The tests need the database of compose.yaml (docker compose up -d). They use their own
database (TEST_DATABASE_URL), which this file makes if it does not exist.
"""

import csv
import os
from dataclasses import replace
from pathlib import Path

import psycopg
import pytest
from fastapi.testclient import TestClient
from psycopg import sql

from city_api.config import load_settings
from city_api.main import create_app
from city_api.migrate import migrate

HERE = Path(__file__).parent
TEST_DATABASE_URL = os.environ.get(
    "TEST_DATABASE_URL", "postgresql://city:city-local-only@127.0.0.1:5432/city_test"
)
COLUMNS = (
    "id, created_at, closed_at, status, complaint_type, descriptor, location_type, "
    "borough, community_board, council_district, incident_zip, channel, "
    "latitude, longitude, days_to_close"
)


def create_database_if_missing(url: str) -> None:
    info = psycopg.conninfo.conninfo_to_dict(url)
    name = info["dbname"]
    try:
        psycopg.connect(url, connect_timeout=3).close()
        return
    except psycopg.OperationalError as error:
        if "does not exist" not in str(error):
            raise
    admin = psycopg.conninfo.make_conninfo(url, dbname="postgres")
    with psycopg.connect(admin, autocommit=True) as conn:
        conn.execute(sql.SQL("CREATE DATABASE {}").format(sql.Identifier(name)))


def build_fixture_db(url: str) -> None:
    """The real schema, with the 30 rows of fixture_rows.csv: data version 1."""
    create_database_if_missing(url)
    with psycopg.connect(url, autocommit=True) as conn:
        conn.execute("DROP SCHEMA public CASCADE")
        conn.execute("CREATE SCHEMA public")
    migrate(url, quiet=True)
    with (HERE / "fixture_rows.csv").open(newline="", encoding="utf-8") as file:
        rows = [[value or None for value in row.values()] for row in csv.DictReader(file)]
    with psycopg.connect(url) as conn:
        with conn.cursor().copy(f"COPY service_requests ({COLUMNS}) FROM STDIN") as copy:
            for row in rows:
                copy.write_row(row)
        for name, value in [
            ("source", "Test rows from NYC 311 Service Requests"),
            ("pulled_on", "2026-10-07"),
            ("rules", "The rules of DATASET.md."),
        ]:
            conn.execute("INSERT INTO meta VALUES (%s, %s)", (name, value))
        conn.execute(
            "INSERT INTO data_loads (created_from, created_to, rows_added)"
            " VALUES ('2025-03-01', '2025-03-13', %s)",
            (len(rows),),
        )


@pytest.fixture(scope="session")
def database_url() -> str:
    build_fixture_db(TEST_DATABASE_URL)
    return TEST_DATABASE_URL


@pytest.fixture
def make_client(database_url):
    """Return a function that makes a test client with changed settings."""
    settings = replace(
        load_settings(),
        api_key=None,
        allowed_origins=[],
        database_url=database_url,
        log_level="WARNING",
        show_docs=True,
    )
    clients = []

    def make(**changes) -> TestClient:
        client = TestClient(create_app(replace(settings, **changes)))
        client.__enter__()  # runs the start-up: the pool opens
        clients.append(client)
        return client

    yield make
    for client in clients:
        client.__exit__(None, None, None)


@pytest.fixture
def client(make_client) -> TestClient:
    return make_client()
