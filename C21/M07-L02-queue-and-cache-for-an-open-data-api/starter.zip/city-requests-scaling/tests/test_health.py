def test_health(client):
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}
    assert len(response.headers["X-Request-ID"]) == 12


def test_unknown_path_gives_404_in_the_standard_shape(client):
    response = client.get("/v1/nothing-here")
    assert response.status_code == 404
    assert response.json()["error"]["code"] == "not_found"


def test_ready_with_the_database(client):
    response = client.get("/ready")
    assert response.status_code == 200
    assert response.json() == {"status": "ready"}


def test_not_ready_without_the_database(make_client):
    # Port 1: nothing listens there. A short pool timeout keeps the test quick.
    client = make_client(database_url="postgresql://city:x@127.0.0.1:1/city", db_pool_timeout=0.5)
    assert client.get("/health").status_code == 200
    response = client.get("/ready")
    assert response.status_code == 503
    assert response.json()["error"]["code"] in ("database_unavailable", "database_busy")
    assert "127.0.0.1" not in response.text  # no internal addresses for the client
    assert client.get("/v1/service-requests").status_code == 503
