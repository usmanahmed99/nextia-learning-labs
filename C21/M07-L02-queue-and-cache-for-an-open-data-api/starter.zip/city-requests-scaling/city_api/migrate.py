"""Apply the SQL files of migrations/ that the database does not have yet, in order.

    python -m city_api.migrate

Each file runs in its own transaction, and its name is saved in schema_migrations,
so running the command again changes nothing.
"""

import sys
from pathlib import Path

import psycopg

from city_api.config import load_settings

MIGRATIONS = Path(__file__).resolve().parent.parent / "migrations"


def migrate(url: str, quiet: bool = False) -> list[str]:
    applied = []
    with psycopg.connect(url, autocommit=True) as conn:
        conn.execute(
            "CREATE TABLE IF NOT EXISTS schema_migrations"
            " (name text PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now())"
        )
        done = {row[0] for row in conn.execute("SELECT name FROM schema_migrations")}
        for path in sorted(MIGRATIONS.glob("*.sql")):
            if path.name in done:
                continue
            with conn.transaction():
                conn.execute(path.read_text(encoding="utf-8"))
                conn.execute("INSERT INTO schema_migrations (name) VALUES (%s)", (path.name,))
            applied.append(path.name)
            if not quiet:
                print(f"Applied {path.name}")
    if not quiet and not applied:
        print("The database is up to date.")
    return applied


if __name__ == "__main__":
    migrate(load_settings().database_url)
    sys.exit(0)
