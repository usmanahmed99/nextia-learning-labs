import logging
import time
import uuid
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware

from city_api import csv_export
from city_api.config import Settings, load_settings
from city_api.db import Database
from city_api.errors import add_error_handlers, error_response
from city_api.models import ErrorResponse, Health, Readiness
from city_api.routes import router

MAX_BODY_BYTES = 16_384

logger = logging.getLogger("city_api")

DESCRIPTION = """
Read-only access to New York City's 311 street-repair requests (DOT),
January to June 2025, cleaned and without addresses.

Lists are paged: follow `next_cursor` until it is null. Times are New York
local time. Every error has the same shape:
`{"error": {"code": ..., "message": ..., "request_id": ..., "fields": [...]}}`.

Data: NYC Open Data, 311 Service Requests (erm2-nwe9), snapshot of 2026-10-07.
"""


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or load_settings()
    logging.basicConfig(level=settings.log_level, format="%(levelname)s %(name)s: %(message)s")

    database = Database(
        settings.database_url, max_size=settings.db_pool_max, timeout=settings.db_pool_timeout
    )

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        database.open()
        yield
        database.close()

    app = FastAPI(
        title="City Service Requests API",
        version="1.1.0",
        lifespan=lifespan,
        description=DESCRIPTION,
        openapi_tags=[
            {"name": "service requests", "description": "Find and read requests."},
            {"name": "statistics", "description": "Daily numbers and data facts."},
            {"name": "exports", "description": "CSV files of a filtered query."},
            {"name": "health", "description": "Check that the service runs."},
        ],
        docs_url="/docs" if settings.show_docs else None,
        redoc_url="/redoc" if settings.show_docs else None,
        openapi_url="/openapi.json" if settings.show_docs else None,
    )
    app.state.settings = settings
    app.state.db = database
    if settings.api_key is None:
        logger.warning("API_KEY is not set: /v1 accepts requests without a key")

    @app.middleware("http")
    async def request_id_and_limits(request: Request, call_next):
        request.state.request_id = uuid.uuid4().hex[:12]
        started = time.perf_counter()
        length = request.headers.get("content-length")
        if length and int(length) > MAX_BODY_BYTES:
            response = error_response(
                request,
                413,
                "body_too_large",
                f"The body is larger than {MAX_BODY_BYTES} bytes.",
            )
        else:
            response = await call_next(request)
        response.headers["X-Request-ID"] = request.state.request_id
        logger.info(
            "%s %s %d %.0fms id=%s",
            request.method,
            request.url.path,
            response.status_code,
            (time.perf_counter() - started) * 1000,
            request.state.request_id,
        )
        return response

    if settings.allowed_origins:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=settings.allowed_origins,
            allow_methods=["GET"],
            allow_headers=["X-API-Key"],
        )

    add_error_handlers(app)
    app.include_router(router)
    app.include_router(csv_export.router)

    @app.get("/health", tags=["health"], summary="Check that the service runs")
    def health() -> Health:
        return Health(status="ok")

    @app.get(
        "/ready",
        tags=["health"],
        summary="Check that the service can read the data",
        responses={503: {"model": ErrorResponse, "description": "Not ready."}},
    )
    def ready() -> Readiness:
        # The cache is not checked: without it the API still works (more slowly).
        with database.connection() as conn:
            conn.execute("SELECT id FROM service_requests LIMIT 1").fetchone()
        return Readiness(status="ready")

    return app


app = create_app()
