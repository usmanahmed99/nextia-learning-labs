from datetime import date
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, NaiveDatetime

Borough = Literal["bronx", "brooklyn", "manhattan", "queens", "staten_island"]
Status = Literal["open", "assigned", "in_progress", "pending", "closed"]

EXAMPLE_REQUEST = {
    "id": 64246800,
    "created_at": "2025-03-03T17:55:20",
    "closed_at": "2025-03-04T17:14:24",
    "status": "closed",
    "complaint_type": "Street Sign - Missing",
    "descriptor": "Speed Limit",
    "location_type": "Street",
    "borough": "manhattan",
    "community_board": "01 MANHATTAN",
    "council_district": 1,
    "incident_zip": "10013",
    "channel": "phone",
    "latitude": 40.721709619645075,
    "longitude": -74.01136041681767,
    "days_to_close": 0.97,
}


class RequestFilters(BaseModel):
    """The filters that the list and the statistics share."""

    model_config = ConfigDict(extra="forbid")

    borough: Borough | None = Field(default=None, description="Only requests in this borough.")
    complaint_type: str | None = Field(
        default=None,
        min_length=1,
        max_length=60,
        description="Only this complaint type, exactly as in /v1/complaint-types.",
    )


class ListQuery(RequestFilters):
    status: Status | None = Field(default=None, description="Only this status.")
    created_from: NaiveDatetime | None = Field(
        default=None,
        description="Created at or after this time (New York local time, no time zone). "
        "A date such as 2025-03-01 means its first second.",
    )
    created_to: NaiveDatetime | None = Field(
        default=None,
        description="Created before this time (not included).",
    )
    limit: int = Field(default=50, ge=1, le=200, description="Requests per page.")
    cursor: str | None = Field(
        default=None,
        max_length=200,
        description="next_cursor from the previous page. Use it with the same filters.",
    )


class StatsQuery(RequestFilters):
    created_from: date = Field(description="The first day, for example 2025-03-01.")
    created_to: date = Field(
        description="The day after the last day (not included). At most 92 days after created_from."
    )


class ServiceRequest(BaseModel):
    """One request to the city about a street, a sign, a light or a sidewalk."""

    model_config = ConfigDict(json_schema_extra={"examples": [EXAMPLE_REQUEST]})

    id: int = Field(description="The city's ID of the request (unique_key).")
    created_at: str = Field(description="When it was made, New York local time.")
    closed_at: str | None = Field(description="When it was closed, as published.")
    status: Status | None = Field(
        description="Status on the snapshot date. To find closed requests, use closed_at."
    )
    complaint_type: str
    descriptor: str | None = Field(description="Detail of the complaint, such as Pothole.")
    location_type: str | None
    borough: Borough | None = Field(description="null: the city did not record it.")
    community_board: str | None
    council_district: int | None
    incident_zip: str | None
    channel: Literal["online", "phone", "mobile", "other"] | None = Field(
        description="How the request was made. null: unknown."
    )
    latitude: float | None
    longitude: float | None
    days_to_close: float | None = Field(
        description="Days from created_at to closed_at, when closed_at is set."
    )


class ServiceRequestPage(BaseModel):
    """One page of requests, oldest first."""

    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "items": [EXAMPLE_REQUEST],
                    "next_cursor": (
                        "eyJjIjoiMjAyNS0wMy0wM1QxNzo1NToyMCIsImkiOjY0MjQ2ODAwLCJmIjoiZDVmMjc4NTIifQ"
                    ),
                }
            ]
        }
    )

    items: list[ServiceRequest]
    next_cursor: str | None = Field(
        description="Send it as cursor to get the next page. null: this is the last page."
    )


class ComplaintTypeCount(BaseModel):
    complaint_type: str
    count: int = Field(description="Requests of this type in the whole database.")


class ComplaintTypeList(BaseModel):
    items: list[ComplaintTypeCount] = Field(description="The most common type first.")


class DailyStat(BaseModel):
    date: date
    opened: int = Field(description="Requests created on this day.")
    closed_within_14_days: int = Field(
        description="Of those, the ones with a closed_at at most 14 days after created_at."
    )
    share_closed_within_14_days: float | None = Field(
        description="closed_within_14_days / opened, from 0 to 1. null when opened is 0."
    )
    median_days_to_close: float | None = Field(
        description=(
            "The middle value of days_to_close of the requests with a closed_at. null when none."
        )
    )


class DailyStats(BaseModel):
    """One row for every day of the range, also days without requests."""

    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "items": [
                        {
                            "date": "2025-03-03",
                            "opened": 752,
                            "closed_within_14_days": 680,
                            "share_closed_within_14_days": 0.904,
                            "median_days_to_close": 1.52,
                        }
                    ]
                }
            ]
        }
    )

    items: list[DailyStat]


class DatasetInfo(BaseModel):
    """Where the data comes from, how it was changed, and what has been loaded."""

    source: str
    pulled_on: str = Field(description="The snapshot date: statuses are as of this day.")
    rules: str
    rows: int = Field(description="Requests in the database now.")
    data_version: int = Field(
        description="Grows by 1 each time new requests are loaded. Cached answers of an "
        "older version are not used."
    )
    loaded_at: str | None = Field(description="When the newest data was loaded.")
    created_from: str | None = Field(description="The first day of the loaded requests.")
    created_to: str | None = Field(description="The day after the last loaded day.")


class Health(BaseModel):
    status: Literal["ok"]


class Readiness(BaseModel):
    status: Literal["ready"]


class ErrorDetail(BaseModel):
    code: str = Field(description="A stable code that a program can check.")
    message: str = Field(description="A short explanation for a person.")
    request_id: str | None = Field(
        default=None, description="Give this ID when you report a problem."
    )
    fields: list[str] = Field(
        default=[], description="The request fields that are not valid, if any."
    )


class ErrorResponse(BaseModel):
    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "error": {
                        "code": "invalid_request",
                        "message": "The request is not valid.",
                        "fields": ["borough"],
                    }
                }
            ]
        }
    )

    error: ErrorDetail
