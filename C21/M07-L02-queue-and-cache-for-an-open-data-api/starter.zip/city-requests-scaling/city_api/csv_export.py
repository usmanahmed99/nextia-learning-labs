"""A CSV export of a filtered query, made while the client waits.

GET /v1/exports.csv takes the filters of the list (without paging) and answers with the
whole file. Simple, and fine for a few hundred rows. For all six months it reads about
110,000 rows, builds an 18 MB text in memory, and keeps a thread, a database connection
and the CPU of the API busy for as long as that takes.
"""

import csv
import io
from typing import Annotated

from fastapi import APIRouter, Depends, Query, Request, Response
from pydantic import NaiveDatetime

from city_api.errors import ApiError
from city_api.models import ErrorResponse, RequestFilters, Status
from city_api.queries import COLUMNS, as_api, where
from city_api.security import require_api_key

HEADER = [c.strip() for c in COLUMNS.split(",")]

router = APIRouter(
    prefix="/v1",
    tags=["exports"],
    dependencies=[Depends(require_api_key)],
    responses={
        401: {"model": ErrorResponse, "description": "The API key is missing or wrong."},
        422: {"model": ErrorResponse, "description": "A parameter is not valid."},
    },
)


class ExportQuery(RequestFilters):
    status: Status | None = None
    created_from: NaiveDatetime | None = None
    created_to: NaiveDatetime | None = None


@router.get(
    "/exports.csv",
    summary="Download a CSV file of the requests that match the filters",
    response_class=Response,
    responses={200: {"content": {"text/csv": {}}, "description": "The CSV file."}},
)
def export_csv(request: Request, query: Annotated[ExportQuery, Query()]) -> Response:
    if query.created_from and query.created_to and query.created_from >= query.created_to:
        raise ApiError(
            422,
            "invalid_range",
            "created_from must be before created_to.",
            ["created_from", "created_to"],
        )
    filters = {
        "borough": query.borough,
        "complaint_type": query.complaint_type,
        "status": query.status,
        "created_from": query.created_from and query.created_from.isoformat(),
        "created_to": query.created_to and query.created_to.isoformat(),
    }
    condition, params = where(filters)
    with request.app.state.db.connection() as conn:
        rows = conn.execute(
            f"SELECT {COLUMNS} FROM service_requests WHERE {condition}"
            " ORDER BY created_at, id",
            params,
        ).fetchall()
    out = io.StringIO()
    writer = csv.writer(out)
    writer.writerow(HEADER)
    for row in rows:
        item = as_api(row)
        writer.writerow(["" if item[c] is None else item[c] for c in HEADER])
    return Response(
        out.getvalue(),
        media_type="text/csv",
        headers={"Content-Disposition": 'attachment; filename="service-requests.csv"'},
    )


