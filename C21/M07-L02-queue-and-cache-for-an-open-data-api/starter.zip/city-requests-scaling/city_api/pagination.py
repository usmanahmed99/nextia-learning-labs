import base64
import binascii
import hashlib
import json
from datetime import datetime

from city_api.errors import ApiError


def fingerprint(filters: dict) -> str:
    """A short code for a set of filters, so that a cursor works only with them."""
    text = json.dumps(filters, sort_keys=True, default=str)
    return hashlib.sha256(text.encode()).hexdigest()[:8]


def encode_cursor(created_at: str, request_id: int, filters: dict) -> str:
    """The position after the last request of a page, as an opaque text."""
    data = {"c": created_at, "i": request_id, "f": fingerprint(filters)}
    raw = json.dumps(data, separators=(",", ":")).encode()
    return base64.urlsafe_b64encode(raw).decode().rstrip("=")


def decode_cursor(cursor: str, filters: dict) -> tuple[str, int]:
    """Return (created_at, id) from a cursor, or raise ApiError invalid_cursor."""
    try:
        raw = base64.urlsafe_b64decode(cursor + "=" * (-len(cursor) % 4))
        data = json.loads(raw)
        created_at, request_id = data["c"], data["i"]
        datetime.fromisoformat(created_at)
        if type(request_id) is not int:
            raise ValueError("id is not an integer")
    except (binascii.Error, UnicodeDecodeError, ValueError, KeyError, TypeError):
        raise ApiError(422, "invalid_cursor", "The cursor is not valid.", ["cursor"]) from None
    if data.get("f") != fingerprint(filters):
        raise ApiError(
            422,
            "invalid_cursor",
            "The cursor belongs to other filters. Start again without a cursor.",
            ["cursor"],
        )
    return created_at, request_id
