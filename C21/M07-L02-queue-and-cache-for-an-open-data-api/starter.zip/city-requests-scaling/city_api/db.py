"""Connections to PostgreSQL: a pool that the app opens at start-up and closes at shutdown.

    with database.connection() as conn:   # borrow a connection; it goes back at the end
        conn.execute(...)

At the end of the block the transaction is committed (or rolled back after an error),
and the connection goes back to the pool: a failed request never keeps one.
"""

import logging
from collections.abc import Iterator
from contextlib import contextmanager

import psycopg
from psycopg.rows import dict_row
from psycopg_pool import ConnectionPool, PoolTimeout

logger = logging.getLogger("city_api")


class DatabaseUnavailable(Exception):
    """The database does not answer. The request may work later."""


class DatabaseBusy(Exception):
    """Every connection of the pool is in use, and none came back in time."""


class Database:
    def __init__(self, url: str, max_size: int = 10, timeout: float = 5.0):
        self.timeout = timeout
        self.pool = ConnectionPool(
            url,
            min_size=2,
            max_size=max_size,
            timeout=timeout,
            kwargs={"row_factory": dict_row, "connect_timeout": 3},
            open=False,
            name="city-api",
        )

    def open(self) -> None:
        self.pool.open(wait=False)

    def close(self) -> None:
        self.pool.close()

    @contextmanager
    def connection(self) -> Iterator[psycopg.Connection]:
        try:
            with self.pool.connection() as conn:
                yield conn
        except PoolTimeout as error:
            raise DatabaseBusy(f"no connection within {self.timeout} seconds") from error
        except psycopg.OperationalError as error:
            raise DatabaseUnavailable("the database does not answer") from error

    def stats(self) -> dict:
        s = self.pool.get_stats()
        return {
            "size": s.get("pool_size", 0),
            "available": s.get("pool_available", 0),
            "waiting": s.get("requests_waiting", 0),
            "max_size": self.pool.max_size,
        }
