"""Every SQL statement of the API's reads.

Values from the request reach PostgreSQL only as parameters (the %s marks), never
as part of the SQL text. Column names and SQL words come only from this file.
"""

from datetime import date, datetime, timedelta

import psycopg

COLUMNS = (
    "id, created_at, closed_at, status, complaint_type, descriptor, location_type, "
    "borough, community_board, council_district, incident_zip, channel, "
    "latitude, longitude, days_to_close"
)

# The filters that a request may use, and the condition each one adds.
# A filter that is not in this table cannot reach the SQL.
CONDITIONS = {
    "borough": "borough = %s",
    "complaint_type": "complaint_type = %s",
    "status": "status = %s",
    "created_from": "created_at >= %s",
    "created_to": "created_at < %s",
}


def where(filters: dict) -> tuple[str, list]:
    """Build the WHERE clause and its parameters from the filters that are set."""
    parts, params = [], []
    for name, value in filters.items():
        if value is not None:
            parts.append(CONDITIONS[name])
            params.append(value)
    return (" AND ".join(parts) or "true"), params


def as_api(row: dict) -> dict:
    """Times as the API writes them: 2025-03-01T07:00:00 (New York local time)."""
    out = dict(row)
    for name in ("created_at", "closed_at"):
        if isinstance(out.get(name), datetime):
            out[name] = out[name].isoformat()
    return out


def get_request(conn: psycopg.Connection, request_id: int) -> dict | None:
    row = conn.execute(
        f"SELECT {COLUMNS} FROM service_requests WHERE id = %s", (request_id,)
    ).fetchone()
    return as_api(row) if row else None


def list_requests(
    conn: psycopg.Connection, filters: dict, after: tuple[datetime, int] | None, limit: int
) -> list[dict]:
    """One page, oldest first. Asks for limit + 1 rows to know if more exist."""
    condition, params = where(filters)
    if after is not None:
        condition += " AND (created_at, id) > (%s, %s)"
        params += list(after)
    sql = (
        f"SELECT {COLUMNS} FROM service_requests WHERE {condition} ORDER BY created_at, id LIMIT %s"
    )
    return [as_api(r) for r in conn.execute(sql, [*params, limit + 1]).fetchall()]


def complaint_types(conn: psycopg.Connection) -> list[dict]:
    return conn.execute(
        "SELECT complaint_type, count(*) AS count FROM service_requests "
        "GROUP BY complaint_type ORDER BY count DESC, complaint_type"
    ).fetchall()


def daily_stats(conn: psycopg.Connection, filters: dict, start: date, end: date) -> list[dict]:
    """Opened, closed within 14 days and the median days to close, for each day."""
    condition, params = where({**filters, "created_from": start, "created_to": end})
    rows = conn.execute(
        "SELECT created_at::date AS day, count(*) AS opened,"
        " count(*) FILTER (WHERE closed_at IS NOT NULL AND days_to_close <= 14) AS within_14,"
        " percentile_cont(0.5) WITHIN GROUP (ORDER BY days_to_close) AS median"
        f" FROM service_requests WHERE {condition} GROUP BY day",
        params,
    ).fetchall()
    by_day = {row["day"]: row for row in rows}
    result = []
    for offset in range((end - start).days):
        day = start + timedelta(days=offset)
        row = by_day.get(day)
        opened = row["opened"] if row else 0
        within = row["within_14"] if row else 0
        median = row["median"] if row else None
        result.append(
            {
                "date": day.isoformat(),
                "opened": opened,
                "closed_within_14_days": within,
                "share_closed_within_14_days": round(within / opened, 3) if opened else None,
                "median_days_to_close": round(median, 2) if median is not None else None,
            }
        )
    return result


def data_version(conn: psycopg.Connection) -> int:
    """The newest load of data. It changes each time new requests arrive."""
    row = conn.execute("SELECT max(version) AS v FROM data_loads").fetchone()
    return row["v"] or 0


def dataset_info(conn: psycopg.Connection) -> dict:
    """The source and rules (table meta), and what the loads added (table data_loads)."""
    info = {r["name"]: r["value"] for r in conn.execute("SELECT name, value FROM meta")}
    loads = conn.execute(
        "SELECT max(version) AS data_version, max(loaded_at) AS loaded_at,"
        " min(created_from) AS created_from, max(created_to) AS created_to,"
        " (SELECT count(*) FROM service_requests) AS rows FROM data_loads"
    ).fetchone()
    return {
        "source": info.get("source", ""),
        "pulled_on": info.get("pulled_on", ""),
        "rules": info.get("rules", ""),
        "rows": loads["rows"],
        "data_version": loads["data_version"] or 0,
        "loaded_at": loads["loaded_at"].isoformat(timespec="seconds")
        if loads["loaded_at"]
        else None,
        "created_from": loads["created_from"].date().isoformat() if loads["created_from"] else None,
        "created_to": loads["created_to"].date().isoformat() if loads["created_to"] else None,
    }
