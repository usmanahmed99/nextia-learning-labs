import os
from dataclasses import dataclass, field


@dataclass(frozen=True)
class Settings:
    api_key: str | None = field(repr=False)
    allowed_origins: list[str]
    database_url: str = field(repr=False)
    db_pool_max: int
    db_pool_timeout: float
    log_level: str
    show_docs: bool


def _int(name: str, default: int) -> int:
    return int(os.environ.get(name, default))


def _float(name: str, default: float) -> float:
    return float(os.environ.get(name, default))


def load_settings() -> Settings:
    """Read the settings from environment variables, with safe defaults."""
    origins = os.environ.get("ALLOWED_ORIGINS", "")
    return Settings(
        api_key=os.environ.get("API_KEY") or None,
        allowed_origins=[o.strip() for o in origins.split(",") if o.strip()],
        database_url=os.environ.get(
            "DATABASE_URL", "postgresql://city:city-local-only@127.0.0.1:5432/city"
        ),
        db_pool_max=_int("DB_POOL_MAX", 10),
        db_pool_timeout=_float("DB_POOL_TIMEOUT", 5.0),
        log_level=os.environ.get("LOG_LEVEL", "INFO").upper(),
        show_docs=os.environ.get("SHOW_DOCS", "true").lower() == "true",
    )
