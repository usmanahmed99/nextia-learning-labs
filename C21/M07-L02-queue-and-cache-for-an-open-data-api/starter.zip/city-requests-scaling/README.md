# city-requests-scaling (starter)

A read-only web API over New York City's 311 street-repair requests from January to June 2025 (109,915 requests). It is the API of the API course's case study *Build a data API for city service requests*, with two changes:

- The data is in **PostgreSQL** instead of a SQLite file, with a connection pool, as in the databases course. `scripts/load.py` loads it, and every load gets a **data version**.
- It has the CSV export that the analysts asked for: `GET /v1/exports.csv` builds the file while the client waits.

In the case study *Queue and cache for an open-data API*, you measure it under a stated workload (`docs/workload.md`), then add a cache and an export queue, and measure again.

## Requirements

- Python 3.12 or newer, and Docker (PostgreSQL 18 runs in a container).

## Set up

```sh
python3 -m venv .venv
source .venv/bin/activate                # Windows: .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
docker compose up -d                     # PostgreSQL on 127.0.0.1:5432
python scripts/get_db.py                 # downloads and checks the data (8 MB)
python -m scripts.load                   # January to May: data version 1
python -m scripts.load --month 2025-06   # June, as new data: data version 2
python -m pytest
```

## Run

```sh
fastapi dev                              # http://127.0.0.1:8000, documentation at /docs
curl -i "http://127.0.0.1:8000/v1/stats/daily?created_from=2025-06-01&created_to=2025-07-01"
```

Settings are environment variables; `.env.example` lists them, with their defaults.

| Endpoint | Meaning |
|---|---|
| `GET /v1/service-requests` | Requests, oldest first, filtered; follow `next_cursor` |
| `GET /v1/service-requests/{id}` | One request |
| `GET /v1/complaint-types` | The complaint types, with counts |
| `GET /v1/stats/daily` | Daily numbers, at most 92 days |
| `GET /v1/dataset` | The source, the rules and the data version |
| `GET /v1/exports.csv` | A CSV file of the requests that match the filters |
| `GET /health`, `GET /ready` | Liveness, and readiness (the database answers) |

## Measure

Only against your own API on your own computer:

```sh
LOG_LEVEL=WARNING fastapi run
python -m scripts.machine
python -m scripts.bench --label baseline
```

## Data and licence

The code is under the MIT licence (`LICENSE`). The data is from NYC Open Data, 311 Service Requests (erm2-nwe9), agency DOT, snapshot of 2026-10-07, cleaned as `DATASET.md` describes. NYC Open Data has no restrictions on use.
