-- The service requests, as in the API course's case study, now in PostgreSQL.
-- scripts/load.py fills them from the SQLite file of that case study.

CREATE TABLE service_requests (
    id               bigint PRIMARY KEY,          -- the city's unique_key
    created_at       timestamp NOT NULL,          -- New York local time, no time zone
    closed_at        timestamp,                   -- as published; NULL while not closed
    status           text CHECK (status IN ('open', 'assigned', 'in_progress', 'pending', 'closed')),
    complaint_type   text NOT NULL,               -- for example 'Street Condition'
    descriptor       text,                        -- for example 'Pothole'
    location_type    text,
    borough          text CHECK (borough IN ('bronx', 'brooklyn', 'manhattan', 'queens', 'staten_island')),
    community_board  text,
    council_district integer,
    incident_zip     text,
    channel          text CHECK (channel IN ('online', 'phone', 'mobile', 'other')),
    latitude         double precision,
    longitude        double precision,
    days_to_close    double precision,            -- closed_at - created_at in days
    CHECK (closed_at IS NULL OR closed_at >= created_at),
    CHECK ((closed_at IS NULL) = (days_to_close IS NULL))
);

-- One index for each way the API reads the table. Each one ends with
-- (created_at, id), the order of the pages.
CREATE INDEX ix_created ON service_requests (created_at, id);
CREATE INDEX ix_borough_created ON service_requests (borough, created_at, id);
CREATE INDEX ix_type_created ON service_requests (complaint_type, created_at, id);
CREATE INDEX ix_status_created ON service_requests (status, created_at, id);

-- Facts about the data: its source, its snapshot date and the cleaning rules.
CREATE TABLE meta (
    name  text PRIMARY KEY,
    value text NOT NULL
);

-- Every load of new requests is one row. The newest version is the data
-- version: it changes each time new data arrives.
CREATE TABLE data_loads (
    version      integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    loaded_at    timestamptz NOT NULL DEFAULT now(),
    created_from timestamp NOT NULL,
    created_to   timestamp NOT NULL,
    rows_added   integer NOT NULL
);
