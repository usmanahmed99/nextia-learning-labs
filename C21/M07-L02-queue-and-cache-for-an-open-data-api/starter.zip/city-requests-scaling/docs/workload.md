# The workload of the city requests API

A load test is only as good as the workload behind it. This file says what we assume, so
that every number in `docs/results.md` can be read against it, and changed when the
assumptions change. The API has no traffic log yet: these are **assumptions from the team**,
not measured traffic. Measure the real traffic as soon as the API is live, and update this file.

## Who uses the API

| Who | How many at the busiest time | What they do | Rate |
|---|---|---|---|
| Dashboard viewers | 30, on Monday from 9:00 | open a view: the complaint types, two charts of daily numbers, a page of requests, the next page, one request's details (6 requests) | one view every 10 s each: 3 views/s, about 18 requests/s |
| Analysts | 4 on a normal morning | ask for a CSV file of a filter | one export every 15 s each: 16 per minute |
| Analysts at month end | 16 | ask for CSV files for the monthly report, one after the other | back to back: 16 exports in flight |

## What they ask for

"Today" is early June 2025: the data holds January to May (90,329 requests, data version 1),
and June arrives later as new data.

- **Views** (from the dashboards' menus): the last month, May (30 %), the last three months
  (25 %), and older months; all boroughs (40 %) or one; all complaint types (40 %) or one of the
  four most common. A few views are much more popular than the rest: that makes a cache useful.
- **Exports**: one borough for three months (about 17,000 rows, 55 %), one complaint type for
  five months (32,202 rows, 25 %), or everything (90,329 rows, 20 %).

## What "good" means

- A dashboard view feels instant: **p95 of the dashboard requests under 300 ms**, p99 under 500 ms.
- An analyst gets the file. The wait may be longer than for a view, but the export must not slow
  the dashboards, and the API must not fail because of it.
- New data shows at once: after a load, no answer of the old data is served.
- The client (or a proxy in front of the API) gives up after **30 seconds**.

## The three runs

| Run | Command | Question |
|---|---|---|
| Monday morning | `python -m scripts.bench --label <name>` | Is the normal busy hour good? |
| Month-end burst | `python -m scripts.bench --label <name> --analysts 16 --export-pace 0` | What do many exports do to everyone else? |
| Capacity (dashboards only) | `python -m scripts.bench --label <name> --viewers 32 --pace 0 --analysts 0 --seconds 40` | How many dashboard requests per second fit, and what runs out first? |

Each run: 3 passes, 60 s each (40 s for capacity), the first 10 s left out. Write the machine
(`python -m scripts.machine`) next to the results. Run load tests only against your own API on
your own computer.
