# Results: <the change you measured>

Fill this in for every comparison. A number without its machine and its workload means little.

## Machine and conditions

- Computer (`python -m scripts.machine`):
- Docker (CPUs, memory):
- Load average before each pass:
- Anything else running:

## Workload

`docs/workload.md`, with these settings (`scripts.bench` options):

| Run | Viewers | Pace (s) | Analysts | Export pace (s) | Seconds per pass | Passes |
|---|---|---|---|---|---|---|
| Monday morning | 30 | 10 | 4 | 15 | 60 | 3 |
| Month-end burst | 30 | 10 | 16 | 0 | 60 | 3 |
| Capacity | 32 | 0 | 0 | - | 40 | 3 |

## Results (median of the passes, lowest-highest)

| Run | Version | Dashboard p50 / p95 / p99 (ms) | Errors | Export: click to file p50 / p95 (ms) | API memory max (MB) |
|---|---|---|---|---|---|
| Monday morning | starter | | | | |
| Month-end burst | starter | | | | |

| Capacity run | Version | Dashboard requests/s | p95 (ms) | API CPU (mean, % of one core) | Database CPU (mean) |
|---|---|---|---|---|---|
| | starter | | | | |

## What changed, and why

## The next bottleneck

## What we did not measure
