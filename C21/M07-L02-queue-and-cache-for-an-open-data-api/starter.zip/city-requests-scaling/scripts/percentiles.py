"""Exact latency percentiles from a load test's samples (one line per request).

    SAMPLES_CSV=run.csv locust -f loadtest/locustfile.py ... --headless
    python -m scripts.percentiles run.csv [--skip 10]

It prints one line per kind of request, and one line for all the dashboard requests
together. --skip leaves out the first seconds (the warm-up). Only successful answers
(2xx) count in the times; the other answers are counted as errors. A percentile here is
the nearest rank: p95 is the time that 95 of 100 requests did not exceed.
"""

import argparse
import csv
import math
import sys

DASHBOARD = "dashboard (all GET requests of a visit)"
DASHBOARD_NAMES = {
    "GET /v1/complaint-types",
    "GET /v1/stats/daily",
    "GET /v1/service-requests",
    "GET /v1/service-requests/{id}",
}


def nearest_rank(sorted_values: list[float], p: float) -> float | None:
    if not sorted_values:
        return None
    k = max(1, math.ceil(p / 100 * len(sorted_values)))
    return sorted_values[k - 1]


def read(path: str, skip: float = 0.0) -> list[dict]:
    with open(path, encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    if not rows:
        return []
    t0 = min(float(r["start"]) for r in rows)
    return [r for r in rows if float(r["start"]) - t0 >= skip]


def summarize(rows: list[dict]) -> dict:
    """Count, errors, throughput and percentiles of these requests."""
    if not rows:
        return {"requests": 0}
    starts = [float(r["start"]) for r in rows]
    ends = [float(r["start"]) + float(r["ms"]) / 1000 for r in rows]
    seconds = max(ends) - min(starts)
    ok = sorted(float(r["ms"]) for r in rows if 200 <= int(r["status"]) < 300)
    errors: dict[str, int] = {}
    for r in rows:
        if not 200 <= int(r["status"]) < 300:
            errors[r["status"]] = errors.get(r["status"], 0) + 1
    return {
        "requests": len(rows),
        "ok": len(ok),
        "errors": dict(sorted(errors.items())),
        "ok_per_s": round(len(ok) / seconds, 2) if seconds else 0.0,
        "p50_ms": nearest_rank(ok, 50),
        "p95_ms": nearest_rank(ok, 95),
        "p99_ms": nearest_rank(ok, 99),
        "max_ms": ok[-1] if ok else None,
    }


def by_name(rows: list[dict]) -> dict[str, dict]:
    names = sorted({r["name"] for r in rows})
    result = {name: summarize([r for r in rows if r["name"] == name]) for name in names}
    dashboard = [r for r in rows if r["name"] in DASHBOARD_NAMES]
    if dashboard:
        result[DASHBOARD] = summarize(dashboard)
    return result


def fmt(value) -> str:
    return "-" if value is None else f"{value:,.0f}"


def print_table(result: dict[str, dict]) -> None:
    print(
        f"{'request':42} {'count':>6} {'errors':>12} {'ok/s':>7} {'p50':>7} {'p95':>7} {'p99':>7}"
    )
    for name, s in result.items():
        if not s.get("requests"):
            continue
        errors = ",".join(f"{k}:{v}" for k, v in s["errors"].items()) or "0"
        print(
            f"{name:42} {s['requests']:>6} {errors:>12} {s['ok_per_s']:>7} "
            f"{fmt(s['p50_ms']):>7} {fmt(s['p95_ms']):>7} {fmt(s['p99_ms']):>7}"
        )
    print("Times in ms, of the successful answers. errors: status code:count (0 = no answer).")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("samples")
    parser.add_argument("--skip", type=float, default=0.0, help="seconds of warm-up to leave out")
    args = parser.parse_args(argv)
    rows = read(args.samples, args.skip)
    if not rows:
        sys.exit("No samples.")
    print_table(by_name(rows))
    return 0


if __name__ == "__main__":
    sys.exit(main())
