"""Load the service requests from the SQLite file into PostgreSQL.

    python -m scripts.load                  # empty the tables, load January to May 2025
    python -m scripts.load --month 2025-06  # add the requests of June 2025: new data

The first command applies the migrations, empties the tables and loads the requests
created before 2025-06-01: on a new database, the data version is 1. The second adds
one month, as the city publishes new requests, and makes the data version one higher.
The rows and the new version are saved in ONE transaction: a reader sees both or neither.

Run python scripts/get_db.py first: it downloads data/service_requests_2025h1.db.
"""

import argparse
import sqlite3
import sys
import time
from datetime import date
from pathlib import Path

import psycopg

from city_api.config import load_settings
from city_api.migrate import migrate

ROOT = Path(__file__).resolve().parent.parent
SQLITE = ROOT / "data" / "service_requests_2025h1.db"
COLUMNS = (
    "id, created_at, closed_at, status, complaint_type, descriptor, location_type, "
    "borough, community_board, council_district, incident_zip, channel, "
    "latitude, longitude, days_to_close"
)
FIRST_DAY, FIRST_NEW_MONTH = date(2025, 1, 1), date(2025, 6, 1)


def month_range(text: str) -> tuple[date, date]:
    year, month = (int(part) for part in text.split("-"))
    start = date(year, month, 1)
    end = date(year + month // 12, month % 12 + 1, 1)
    return start, end


def read_rows(source: Path, start: date, end: date) -> list[tuple]:
    con = sqlite3.connect(f"{source.resolve().as_uri()}?mode=ro", uri=True)
    try:
        return con.execute(
            f"SELECT {COLUMNS} FROM service_requests"
            " WHERE created_at >= ? AND created_at < ? ORDER BY created_at, id",
            (start.isoformat(), end.isoformat()),
        ).fetchall()
    finally:
        con.close()


def read_meta(source: Path) -> dict[str, str]:
    con = sqlite3.connect(f"{source.resolve().as_uri()}?mode=ro", uri=True)
    try:
        return dict(con.execute("SELECT name, value FROM meta").fetchall())
    finally:
        con.close()


def load(url: str, source: Path, start: date, end: date, reset: bool) -> tuple[int, int]:
    """Add the requests created from start to end (not included). (rows added, version)"""
    rows = read_rows(source, start, end)
    with psycopg.connect(url) as conn:  # one transaction, committed at the end
        if reset:
            # The versions keep counting after a reset: a version number always means
            # the same data, so a cached answer of an old version is never read again.
            conn.execute("TRUNCATE service_requests, meta, data_loads")
            meta = read_meta(source)
            for name in ("source", "pulled_on", "rules"):
                conn.execute("INSERT INTO meta VALUES (%s, %s)", (name, meta[name]))
        # The new rows go to a temporary table first; then only the ones that are not
        # in the table yet are added. So loading the same month twice adds nothing.
        conn.execute(
            "CREATE TEMP TABLE incoming (LIKE service_requests INCLUDING DEFAULTS) ON COMMIT DROP"
        )
        with conn.cursor().copy(f"COPY incoming ({COLUMNS}) FROM STDIN") as copy:
            for row in rows:
                copy.write_row(row)
        added = conn.execute(
            f"INSERT INTO service_requests ({COLUMNS}) SELECT {COLUMNS} FROM incoming"
            " ON CONFLICT (id) DO NOTHING"
        ).rowcount
        if added == 0:
            version = conn.execute("SELECT max(version) FROM data_loads").fetchone()[0] or 0
            return 0, version
        version = conn.execute(
            "INSERT INTO data_loads (created_from, created_to, rows_added)"
            " VALUES (%s, %s, %s) RETURNING version",
            (start, end, added),
        ).fetchone()[0]
        conn.execute("ANALYZE service_requests")
    return added, version


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--month", help="add the requests of one month, for example 2025-06")
    parser.add_argument("--source", default=str(SQLITE), help="the SQLite file")
    args = parser.parse_args(argv)
    source = Path(args.source)
    if not source.is_file():
        sys.exit(f"No file {source}. Run: python scripts/get_db.py")
    url = load_settings().database_url
    started = time.perf_counter()
    if args.month:
        start, end = month_range(args.month)
        added, version = load(url, source, start, end, reset=False)
        if added == 0:
            print(f"No new requests for {args.month}: the data version stays {version}.")
            return 0
        print(f"Added {added:,} requests created in {args.month}.")
    else:
        migrate(url, quiet=True)
        added, version = load(url, source, FIRST_DAY, FIRST_NEW_MONTH, reset=True)
        print(
            f"Loaded {added:,} requests created from {FIRST_DAY}"
            f" to {FIRST_NEW_MONTH} (not included)."
        )
    print(f"Data version: {version} ({time.perf_counter() - started:.1f} s)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
