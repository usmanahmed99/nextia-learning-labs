"""Run the workload several times against your running API, and report the median pass.

    python -m scripts.bench --label baseline
    python -m scripts.bench --label finished --passes 3 --seconds 60
    python -m scripts.bench --label burst --analysts 16 --export-pace 0

--viewers, --pace, --analysts and --export-pace set the workload of
loadtest/locustfile.py (VIEWERS, PACE_SECONDS, ANALYSTS, EXPORT_PACE_SECONDS).

Before each pass it deletes the cache's keys of this project (city:*), so every pass
starts cold, waits until the export queue is empty, and deletes old export files. Then
it runs Locust (loadtest/locustfile.py, headless) for --seconds and reads its samples.
During the pass it measures the CPU use of the API process and of the PostgreSQL
container. It prints each pass, then the median of the passes with the range
(lowest-highest), and saves everything in results/<label>.json.

Run it only on your own computer, against your own API, with nothing else heavy
running (python -m scripts.machine prints the load).
"""

import argparse
import json
import os
import statistics
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path

import psutil

from scripts import machine, percentiles

ROOT = Path(__file__).resolve().parent.parent


def api_process(port: int) -> psutil.Process | None:
    """The process that listens on the API's port (lsof, on macOS and Linux)."""
    out = subprocess.run(
        ["lsof", "-ti", f"tcp:{port}", "-sTCP:LISTEN"], capture_output=True, text=True
    ).stdout.split()
    return psutil.Process(int(out[0])) if out else None


def db_container() -> str | None:
    """The PostgreSQL container of this project (or DB_CONTAINER, if you set it)."""
    if os.environ.get("DB_CONTAINER"):
        return os.environ["DB_CONTAINER"]
    out = subprocess.run(
        ["docker", "compose", "ps", "-q", "db"], capture_output=True, text=True, cwd=ROOT
    ).stdout.strip()
    return out or None


class CpuWatch(threading.Thread):
    """Samples the CPU use (100 = one full core) of the API process (and its children)
    and of the database container every 2 seconds, and the API's memory."""

    def __init__(self, api: psutil.Process | None, container: str | None):
        super().__init__(daemon=True)
        self.api, self.container = api, container
        self.api_samples: list[float] = []
        self.db_samples: list[float] = []
        self.rss_mb: list[float] = []
        self.stop = threading.Event()

    def run(self) -> None:
        procs = []
        if self.api is not None:
            procs = [self.api, *self.api.children(recursive=True)]
            for p in procs:
                p.cpu_percent(None)
        while not self.stop.wait(2):
            if procs:
                total, rss = 0.0, 0
                for p in procs:
                    try:
                        total += p.cpu_percent(None)
                        rss += p.memory_info().rss
                    except psutil.Error:
                        pass
                self.api_samples.append(total)
                self.rss_mb.append(rss / 2**20)
            if self.container:
                out = (
                    subprocess.run(
                        [
                            "docker",
                            "stats",
                            "--no-stream",
                            "--format",
                            "{{.CPUPerc}}",
                            self.container,
                        ],
                        capture_output=True,
                        text=True,
                    )
                    .stdout.strip()
                    .rstrip("%")
                )
                if out:
                    self.db_samples.append(float(out))

    def result(self) -> dict:
        def med(values):
            return round(statistics.median(values)) if values else None

        def mean(values):
            return round(statistics.fmean(values)) if values else None

        return {
            "api_cpu_median": med(self.api_samples),
            "api_cpu_mean": mean(self.api_samples),
            "api_cpu_max": max(self.api_samples, default=None),
            "db_cpu_median": med(self.db_samples),
            "db_cpu_mean": mean(self.db_samples),
            "db_cpu_max": max(self.db_samples, default=None),
            "api_memory_mb_max": round(max(self.rss_mb)) if self.rss_mb else None,
            "samples": {
                "api_cpu": self.api_samples,
                "db_cpu": self.db_samples,
                "api_memory_mb": [round(m) for m in self.rss_mb],
            },
        }


def get_json(url: str, headers: dict) -> dict:
    request = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(request, timeout=10) as response:
        return json.load(response)


def prepare(host: str, headers: dict) -> None:
    try:
        import redis  # the starter has no cache, and no redis package
    except ImportError:
        redis = None
    cache_url = os.environ.get("CACHE_URL", "redis://127.0.0.1:6379/0")
    if redis is not None and cache_url:
        client = redis.Redis.from_url(cache_url, socket_connect_timeout=1)
        try:
            keys = list(client.scan_iter("city:*", count=1000))
            if keys:
                client.delete(*keys)
        except redis.RedisError:
            pass  # no cache running: nothing to empty
        client.close()
    deadline = time.monotonic() + 180
    while time.monotonic() < deadline:  # wait for the jobs of the last pass to finish
        try:
            q = get_json(f"{host}/v1/export-queue", headers)
        except urllib.error.HTTPError:
            break  # no export queue (the starter)
        if q["queued"] == 0 and q["running"] == 0:
            break
        time.sleep(2)
    for path in (ROOT / "exports").glob("export-*.csv"):
        path.unlink()


def run_pass(args, label: str, number: int, headers: dict) -> dict:
    prepare(args.host, headers)
    samples = ROOT / "results" / f"{label}-pass{number}.csv"
    samples.parent.mkdir(exist_ok=True)
    env = {
        **os.environ,
        "SAMPLES_CSV": str(samples),
        "VIEWERS": str(args.viewers),
        "PACE_SECONDS": str(args.pace),
        "ANALYSTS": str(args.analysts),
        "EXPORT_PACE_SECONDS": str(args.export_pace),
    }
    users = args.viewers + args.analysts
    watch = CpuWatch(api_process(int(args.host.rsplit(":", 1)[1])), db_container())
    load_before = os.getloadavg()[0]
    watch.start()
    subprocess.run(
        [
            sys.executable,
            "-m",
            "locust",
            "-f",
            str(ROOT / "loadtest" / "locustfile.py"),
            "--host",
            args.host,
            "--headless",
            "-u",
            str(users),
            "-r",
            str(users),
            "-t",
            f"{args.seconds}s",
            "--only-summary",
            "--stop-timeout",
            "30",
            "--loglevel",
            "ERROR",
        ],
        env=env,
        check=False,
        stdout=subprocess.DEVNULL,
    )
    watch.stop.set()
    watch.join()
    result = percentiles.by_name(percentiles.read(str(samples), args.skip))
    return {
        "pass": number,
        "load_1min_before": round(load_before, 2),
        **watch.result(),
        "requests": result,
    }


def median_of(passes: list[dict], name: str, field: str):
    values = [p["requests"].get(name, {}).get(field) for p in passes]
    values = [v for v in values if v is not None]
    if not values:
        return None
    return statistics.median(values), min(values), max(values)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--label", required=True, help="a name for this configuration")
    parser.add_argument("--host", default="http://127.0.0.1:8000")
    parser.add_argument("--viewers", type=int, default=30, help="dashboard viewers")
    parser.add_argument("--pace", type=float, default=10, help="seconds between visits")
    parser.add_argument("--analysts", type=int, default=4, help="analysts who export")
    parser.add_argument("--export-pace", type=float, default=15, help="seconds between exports")
    parser.add_argument("--seconds", type=int, default=60)
    parser.add_argument("--skip", type=float, default=10, help="warm-up seconds to leave out")
    parser.add_argument("--passes", type=int, default=3)
    args = parser.parse_args(argv)
    headers = {"X-API-Key": os.environ["API_KEY"]} if os.environ.get("API_KEY") else {}

    computer = machine.describe()
    print(
        f"Computer: {computer['cpu']}, {computer['cores']} cores, {computer['memory_gb']} GB; "
        f"{computer['os']}; load {computer['load_1min']}"
    )
    print(
        f"Workload: loadtest/locustfile.py, {args.viewers} viewers (a visit every "
        f"{args.pace:g} s), {args.analysts} analysts (an export every {args.export_pace:g} s), "
        f"{args.seconds} s per pass "
        f"(first {args.skip:.0f} s left out), {args.passes} passes"
    )
    passes = []
    for number in range(1, args.passes + 1):
        p = run_pass(args, args.label, number, headers)
        passes.append(p)
        print(
            f"\nPass {number} (load before {p['load_1min_before']}; CPU median: API "
            f"{p['api_cpu_median']}%, database {p['db_cpu_median']}%; API memory up to "
            f"{p['api_memory_mb_max']} MB)"
        )
        percentiles.print_table(p["requests"])

    print(f"\nMedian of {len(passes)} passes (lowest-highest):")
    names = sorted({n for p in passes for n in p["requests"]})
    for name in names:
        line = [f"{name:42}"]
        for field in ("ok_per_s", "p50_ms", "p95_ms", "p99_ms"):
            m = median_of(passes, name, field)
            line.append(
                f"{field} "
                + (
                    "-"
                    if m is None
                    else f"{m[0]:,.0f} ({m[1]:,.0f}-{m[2]:,.0f})"
                    if field != "ok_per_s"
                    else f"{m[0]} ({m[1]}-{m[2]})"
                )
            )
        errors = [sum(p["requests"].get(name, {}).get("errors", {}).values()) for p in passes]
        line.append(f"errors {statistics.median(errors):.0f} ({min(errors)}-{max(errors)})")
        print(" | ".join(line))
    out = ROOT / "results" / f"{args.label}.json"
    out.write_text(
        json.dumps(
            {"label": args.label, "machine": computer, "args": vars(args), "passes": passes},
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    print(f"\nSaved {out.relative_to(ROOT)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
