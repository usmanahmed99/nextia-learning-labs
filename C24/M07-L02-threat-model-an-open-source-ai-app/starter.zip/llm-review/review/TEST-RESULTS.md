# Test results

Paste the summary line of each run (Parts 3 to 7), and write one sentence on each attack that
reached its goal.

| Design | Model | Attack goal reached /10 | Unsafe side effect | Tasks right /4 |
|---|---|---|---|---|
| | | | | |
