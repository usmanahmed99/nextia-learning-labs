# Threat model of llm at Wren & Oak's buying team

Write each threat as a path: actor -> where their text enters -> the tool that acts -> the asset
-> the harm. Score likelihood and impact from 1 to 3 before any test; priority = likelihood x impact.

| # | Threat (a plausible path) | Asset | Likelihood | Impact | Priority | Existing control | Tested by |
|---|---|---|---|---|---|---|---|
| T1 | | | | | | | |

## The order of the work

(which threats first, and why)
