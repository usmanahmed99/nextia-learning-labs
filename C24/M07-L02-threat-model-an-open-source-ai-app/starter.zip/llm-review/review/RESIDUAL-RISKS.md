# Residual-risk register

A residual risk is a risk that is still there after the controls.

| ID | Risk | Evidence | What limits it now | Owner | Decision | Review |
|---|---|---|---|---|---|---|
| R1 | | | | | | |
