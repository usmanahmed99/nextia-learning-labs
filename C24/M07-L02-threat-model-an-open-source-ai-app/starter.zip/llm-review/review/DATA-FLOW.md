# Data flow of llm at Wren & Oak's buying team

The system under review: llm 0.36 (commit 764dc386c58b625f3ad9d203e699715ad208455f), the team's
toolbox (tools/start_tools.py) and a model behind an OpenAI-compatible API.

Draw the map (Part 2 of the case study): the buyer, the trust boundary, llm, the model provider,
each tool and what it can reach, and what is stored after every run.

```
(your map)
```

## Assets

| Asset | Where it lives | Who must never get it |
|---|---|---|
| | | |

## Actors

| Actor | What they can do | Trusted? |
|---|---|---|
| | | |
