# llm-review: a security review of an open-source AI assistant

A threat model and harmless local tests of [llm](https://github.com/simonw/llm), Simon Willison's
command-line assistant (Apache-2.0), as a small team would use it: summarise supplier documents and
pages, with two tools of its own. The case study of the course
[AI Security, Privacy and Responsible Design](https://learning.nextia-ai.com/courses/ai-security/)
on Nextia Learning.

Everything runs on your computer. The model is a **replay server** with recorded answers (no
account, no key); the web is a **practice network** that plays every host; every secret is a
made-up canary that opens nothing. Nothing here targets the llm project or any real service.

## What is reviewed

- **llm 0.36**: PyPI release, the GitHub tag `0.36`, commit `764dc386c58b625f3ad9d203e699715ad208455f`.
  `requirements.txt` pins it, pytest and their dependencies (36 packages, a few only for Windows)
  with SHA-256 hashes.
- **The team's toolbox**: `tools/start_tools.py` (as proposed: no checks) and
  `tools/controls_tools.py` (with controls in code).
- **The settings**: llm's own folder in `.llm-home/` (`setup_home.py`), so your own llm settings
  are never touched.

## The files

The **starter** has everything except `tools/controls_tools.py`, `tests/test_controls.py` and the
content of the four `review/` documents: you write those in the case study. The **finished**
project has them all.

```text
review/DATA-FLOW.md        the data-flow map, trust boundary, assets and actors
review/THREAT-MODEL.md     seven threats, scored likelihood x impact, with the tests for each
review/TEST-RESULTS.md     what happened, per design and model
review/RESIDUAL-RISKS.md   what is left, with owners and decisions
tools/start_tools.py       the toolbox as proposed
tools/controls_tools.py    the toolbox with a file sandbox, a fetch allow-list, masking and an audit log
prompts/system-strong.md   the strong system prompt (the prompt and secure designs)
cases.json                 4 normal tasks, 10 harmless attacks, 1 sealed new case, 2 checks of llm itself
run_cases.py               runs each case as a real llm command and scores it from llm's log
inspect_logs.py            what llm's log database keeps
replay_server.py           the replay model (and the obedient stand-in) and the practice network
obedient.py                a constructed worst case: a "model" that always obeys injected text
recordings/                372 recorded chat-small answers (Azure, 2026-10-10, three repeats)
practice/, site/           the made-up documents, config file and web pages
tests/                     21 tests: the controls, and the practice set-up
```

## Run it

Python 3.12 or newer. In the project folder:

```sh
python -m venv .venv
source .venv/bin/activate              # Windows: .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m pytest
python setup_home.py
export LLM_USER_PATH="$PWD/.llm-home"  # Windows: $env:LLM_USER_PATH = "$PWD\.llm-home"
```

In a second terminal (same folder, venv active): `python replay_server.py`. Then:

```sh
python run_cases.py --design start
python run_cases.py --design start --model obedient
python run_cases.py --design secure
python run_cases.py --app
python inspect_logs.py
```

`python replay_server.py --repeat 2` (or 3) replays the other recorded repeats.

## A live model (optional)

The recordings answer only the exact commands of the case study. To try your own prompts, point
the `chat-small` entry in `.llm-home/extra-openai-models.yaml` at your provider's
OpenAI-compatible URL and key, and set a spending limit with your provider first. Or record new
answers through the server: `python replay_server.py --record --upstream URL` with the key in
`UPSTREAM_API_KEY`. Your numbers will differ: models change fast; the method lasts.

## Licence

The files of this folder: MIT (`LICENSE`). llm is Apache-2.0 and is installed from PyPI, not copied
here. The documents, pages, companies and keys are made up for this case study.
