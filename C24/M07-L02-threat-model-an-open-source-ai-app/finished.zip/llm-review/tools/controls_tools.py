"""Wren & Oak's toolbox for llm, with controls in code.

    llm --functions tools/controls_tools.py "..."

The same two tools as tools/start_tools.py, with the smallest reach that the normal tasks need:

- read_doc reads one Markdown file from practice/inbox, by its plain name: no folders, no "..".
- fetch_page fetches only HTTPS pages of the allowed supplier host, with no query string,
  follows no redirect and never fetches a private or internal address.
- Every call writes one audit event to work/tool-audit.jsonl: the tool, the decision (allowed or
  refused), the reason code, and the file name or the host and path. Never a query, a page or the
  text of a file, so the audit log can stay on when llm's own log is off.
- A refusal raises an error: llm sends its message to the model and stores it in its log.
- Key-shaped secrets are masked in everything a tool returns.

llm turns every public function of this file into a tool, so helpers start with "_".
Practice only: pages come from the practice network on your computer (replay_server.py).
"""

import http.client
import ipaddress
import json
import pathlib
import re
import time
import urllib.parse

INBOX = pathlib.Path("practice/inbox")
ALLOWED_HOSTS = {"alderridge.example"}
MAX_CHARS = 20_000
_SECRET = re.compile(r"\b[a-z]{2,8}_(?:live|cloud|backup|test)_[A-Za-z0-9]{12,}\b")


def read_doc(name: str) -> str:
    """Read one document from the buying team's inbox by its file name, for example price-list-oct.md."""
    if "/" in name or "\\" in name or ".." in name or not name.endswith(".md"):
        _refuse("read_doc", "not_a_plain_name", detail=name)
    path = (INBOX / name).resolve()
    if path.parent != INBOX.resolve() or path.is_symlink() or not path.is_file():
        _refuse("read_doc", "not_in_inbox", detail=name)
    _audit("read_doc", "allowed", "ok", detail=name)
    return _mask(path.read_text(encoding="utf-8")[:MAX_CHARS])


def fetch_page(url: str) -> str:
    """Fetch one page of the supplier's website (https://alderridge.example/...) and return its text."""
    parts = urllib.parse.urlsplit(url)
    host = (parts.hostname or "").lower()
    if parts.scheme != "https":
        _refuse("fetch_page", "not_https", host=host, path=parts.path)
    if _is_private(host):
        _refuse("fetch_page", "private_address", host=host, path=parts.path)
    if host not in ALLOWED_HOSTS:
        _refuse("fetch_page", "host_not_allowed", host=host, path=parts.path)
    if parts.query or parts.fragment or parts.username or parts.port:
        _refuse("fetch_page", "extra_url_parts", host=host, path=parts.path)
    status, location, text = _practice_get(host, parts.path or "/")
    if 300 <= status < 400:
        target = urllib.parse.urlsplit(urllib.parse.urljoin(url, location))
        _refuse("fetch_page", "redirect_not_followed", host=host, path=parts.path,
                detail=f"to {target.hostname}")
    if status != 200:
        _refuse("fetch_page", f"status_{status}", host=host, path=parts.path)
    _audit("fetch_page", "allowed", "ok", host=host, path=parts.path)
    return _mask(text[:MAX_CHARS])


def _is_private(host: str) -> bool:
    try:
        address = ipaddress.ip_address(host)
    except ValueError:
        return host in {"localhost"} or host.endswith((".internal", ".local", ".localhost"))
    return address.is_private or address.is_loopback or address.is_link_local or address.is_reserved


def _mask(text: str) -> str:
    return _SECRET.sub("[secret removed]", text)


def _audit(tool: str, decision: str, code: str, **where: str) -> None:
    event = {"time": time.strftime("%Y-%m-%dT%H:%M:%S"), "tool": tool, "decision": decision, "code": code}
    if "detail" in where:  # a file name or a redirect host: never a query or a page
        where["detail"] = _mask(where["detail"])[:80]
    event.update(where)
    pathlib.Path("work").mkdir(exist_ok=True)
    with open("work/tool-audit.jsonl", "a", encoding="utf-8") as f:
        f.write(json.dumps(event) + "\n")


def _refuse(tool: str, code: str, **where: str) -> None:
    _audit(tool, "refused", code, **where)
    raise ValueError(f"refused ({code}): {tool} may not do this. Tell the team member; do not try another way.")


def _practice_get(host: str, path: str) -> tuple[int, str, str]:
    """GET a page from the practice network (127.0.0.1:8766), which plays every host."""
    conn = http.client.HTTPConnection("127.0.0.1", 8766, timeout=10)
    conn.request("GET", path, headers={"X-Practice-Host": host})
    resp = conn.getresponse()
    text = resp.read().decode("utf-8", "replace")
    conn.close()
    return resp.status, resp.getheader("Location") or "", text
