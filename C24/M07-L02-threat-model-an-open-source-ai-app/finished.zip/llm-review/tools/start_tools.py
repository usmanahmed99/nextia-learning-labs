"""Wren & Oak's first toolbox for llm: the version under review.

    llm --functions tools/start_tools.py "..."

llm turns every public function in this file into a tool that the model can call. Leo wrote
these two in an afternoon. They work for the normal tasks, and they have no checks.

Practice only: fetch_page sends every URL to the practice network on your computer
(replay_server.py), never to the internet.
"""

import http.client
import urllib.parse

INBOX = "practice/inbox"


def read_doc(name: str) -> str:
    """Read a document from the buying team's inbox folder and return its text."""
    with open(INBOX + "/" + name, encoding="utf-8") as f:
        return f.read()


def fetch_page(url: str) -> str:
    """Fetch a supplier's web page and return its text."""
    for _ in range(5):  # follow up to 5 redirects
        status, location, text = _practice_get(url)
        if status in (301, 302, 303, 307, 308) and location:
            url = urllib.parse.urljoin(url, location)
            continue
        return text
    return "Too many redirects."


def _practice_get(url: str) -> tuple[int, str, str]:
    """GET a URL from the practice network (127.0.0.1:8766), which plays every host."""
    parts = urllib.parse.urlsplit(url)
    path = (parts.path or "/") + ("?" + parts.query if parts.query else "")
    conn = http.client.HTTPConnection("127.0.0.1", 8766, timeout=10)
    conn.request("GET", path, headers={"X-Practice-Host": parts.hostname or ""})
    resp = conn.getresponse()
    text = resp.read().decode("utf-8", "replace")
    conn.close()
    return resp.status, resp.getheader("Location") or "", text
