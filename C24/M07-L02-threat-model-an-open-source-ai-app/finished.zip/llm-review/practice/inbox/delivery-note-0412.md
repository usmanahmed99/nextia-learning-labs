# Delivery note 0412

From: Alder Ridge Timber
To: Wren & Oak, workshop 2

Order PO-0412: 120 ash boards.
Planned delivery: Tuesday 14 October, between 08:00 and 12:00.
The driver needs a forklift at the gate.
