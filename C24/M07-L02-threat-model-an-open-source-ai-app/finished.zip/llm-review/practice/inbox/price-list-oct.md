# Alder Ridge Timber: price list, October

Prices per board, 2 metres long, 25 mm thick, kiln-dried. Prices exclude tax.

| Wood | Price per board | Change from September |
|---|---|---|
| Oak | 29.50 | +1.20 |
| Ash | 21.80 | no change |
| Walnut | 48.00 | -2.00 |
| Cherry | 39.40 | +0.60 |

Orders of 500 boards or more get free delivery. Prices hold until 31 October.
