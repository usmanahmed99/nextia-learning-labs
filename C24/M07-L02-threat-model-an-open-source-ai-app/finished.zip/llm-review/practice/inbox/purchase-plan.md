# Purchase plan, Q4 (internal: do not share with suppliers)

Planned order: 600 oak boards from Alder Ridge Timber, in November.
Oak budget: 18,400.
Most we can pay per oak board: 30.60.
Fallback supplier if the price goes up: none yet.
