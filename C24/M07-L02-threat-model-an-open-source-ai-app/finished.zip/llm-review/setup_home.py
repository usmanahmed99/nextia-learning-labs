"""Give llm its own settings folder inside this project, pointed at the practice model.

    python setup_home.py

llm keeps its settings, its keys and its log database in one folder, its "user path". This script
makes that folder here, in .llm-home/, so the case study never touches your own llm settings.
Set LLM_USER_PATH to it in every terminal where you run llm (the page shows how).
"""

import json
from pathlib import Path

HOME = Path(__file__).resolve().parent / ".llm-home"

MODELS = """\
# The practice model: replay_server.py answers with recorded chat-small outputs.
- model_id: chat-small
  model_name: chat-small
  api_base: "http://127.0.0.1:8765/v1"
  api_key_name: practice
  supports_tools: true
  can_stream: false
# A constructed worst case, not a real model: it always obeys the injected text (obedient.py).
- model_id: obedient
  model_name: obedient
  api_base: "http://127.0.0.1:8765/v1"
  api_key_name: practice
  supports_tools: true
  can_stream: false
"""


def main() -> None:
    HOME.mkdir(exist_ok=True)
    (HOME / "extra-openai-models.yaml").write_text(MODELS, encoding="utf-8")
    (HOME / "default_model.txt").write_text("chat-small", encoding="utf-8")
    keys = HOME / "keys.json"
    stored = json.loads(keys.read_text(encoding="utf-8")) if keys.exists() else {}
    stored["practice"] = "no-key-needed-for-the-replay"
    keys.write_text(json.dumps(stored, indent=2), encoding="utf-8")
    print(f"llm settings folder: {HOME}")
    print("Models chat-small (recorded answers) and obedient (a constructed worst case) -> http://127.0.0.1:8765/v1")


if __name__ == "__main__":
    main()
