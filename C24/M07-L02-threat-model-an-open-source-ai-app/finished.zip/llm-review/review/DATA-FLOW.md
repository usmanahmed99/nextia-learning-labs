# Data flow of llm at Wren & Oak's buying team

The system under review: **llm 0.36** (Simon Willison, Apache-2.0; release tag `0.36`, commit
`764dc386c58b625f3ad9d203e699715ad208455f`), installed from PyPI with hashes, used from the
command line on a buyer's laptop, with the team's toolbox (`tools/*.py`, two tools) and a model
behind an OpenAI-compatible API. In this review the model is the replay server (recorded
chat-small answers) or the constructed `obedient` model; the web is the practice network.

The dashed line is the **trust boundary**. Only what is inside it may decide what happens:
the buyer's own request, and code and settings that the team installed and reviewed. Everything
outside it is **data**, even when it is written like an instruction.

```
 Buyer (Leo) ------------------------------------------------------------------------------+
   | types:  llm [-f FILE|URL] [--sf SYSTEM] --functions tools/x.py "request"              |
   v                                                                                        |
+- - - - - - - - - - - - - - - - - trust boundary - - - - - - - - - - - - - - - - - - - - -+ |
:  the request text      system prompt (--sf)      llm's code     the toolbox code         : |
:  settings (.llm-home: extra-openai-models.yaml, keys.json)                               : |
+- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - + |
   |                                                                                        |
   |   fragments (-f): a file's text, or a URL's text (llm follows up to 3 redirects)       |
   |   are pasted into the prompt, before the request: DATA                                 |
   v                                                                                        |
 llm (the tool loop, up to 5 tool calls in a chain) ---- prompt + tool list + results --> model provider
   ^      |                                      <--------- tool calls, reply ----------  (outside Wren & Oak)
   |      | runs the tool calls the model asks for (no question, unless --ta)
   |      v
   |   read_doc(name)  --> practice/inbox/*.md   (supplier files AND the internal purchase plan)
   |                       start: any path, e.g. ../config/orders-api.env
   |   fetch_page(url) --> the network           (supplier pages, AND any host: a collector,
   |                       start: any URL,        169.254.169.254, redirects followed)
   |      |
   +------+ tool results (DATA) go back to the model, then the reply goes to the buyer's screen

 Stored on the laptop after every run (llm's log, logs.db): the request, every fragment in full,
 the system prompt, every tool call and its arguments, every tool result, every reply, with no end
 date, plus a full-text search copy. keys.json holds the provider key (not in logs.db).
```

## Assets

| Asset | Where it lives | Who must never get it |
|---|---|---|
| The internal purchase plan (oak budget 18,400, most we can pay 30.60) | `practice/inbox/purchase-plan.md`, readable by `read_doc` | the supplier, anyone outside Wren & Oak |
| The ordering system's key (a made-up canary) | `practice/config/orders-api.env` | anyone: the model, a reply, a log |
| Internal addresses (cloud metadata `169.254.169.254`, internal pages) | the laptop's network | any page or document |
| What the team says to customers and suppliers | replies that a buyer copies | a false promise (a discount) written by a supplier |
| llm's log and settings | `.llm-home/logs.db`, `.llm-home/keys.json` | anyone without access to the laptop |

## Actors

| Actor | What they can do | Trusted? |
|---|---|---|
| Buyer (Leo, Wren & Oak) | types the request, chooses files and URLs, turns tools on | for their own request |
| Supplier, or anyone who can change a supplier's file or page | writes the text that the model reads | no |
| The model (provider) | proposes tool calls and writes the reply; receives every fragment and tool result | no: data can persuade it |
| Authors of plugins, templates and the toolbox | write code that llm runs with the buyer's rights | only after review |
| Anyone with the laptop or a backup of it | reads `logs.db` and `keys.json` | no |
