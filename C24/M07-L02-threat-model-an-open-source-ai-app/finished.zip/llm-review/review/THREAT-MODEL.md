# Threat model of llm at Wren & Oak's buying team

Written before any test, from `DATA-FLOW.md`. A **threat** is a plausible path from an actor to an
asset or an action that they should not reach. Likelihood and impact are 1 (low) to 3 (high);
priority = likelihood x impact. "Existing control" is what stops the path in the set-up as Leo
proposed it: llm 0.36 with `tools/start_tools.py`, no system prompt, logging on.

| # | Threat (a plausible path) | Asset | Likelihood | Impact | Priority | Existing control | Tested by |
|---|---|---|---|---|---|---|---|
| T1 | A supplier page tells the model to read the purchase plan and put the budget in a URL; `fetch_page` sends it (exfiltration) | purchase plan | 3 | 3 | 9 | none | ATK-3, 4, 8, 9 |
| T2 | A page sends `fetch_page` to an internal address, directly or by a redirect (SSRF) | internal addresses, cloud credentials | 2 | 3 | 6 | none | ATK-5, 10 |
| T3 | A document tells the model to open a file outside the inbox with `read_doc` | the ordering system's key | 2 | 3 | 6 | none | ATK-2, 7 |
| T4 | The log keeps every document, tool result and reply on the laptop, with no end date | purchase plan, keys, supplier data | 3 | 2 | 6 | none (llm 0.36 has `logs off`, no delete) | inspect_logs.py |
| T5 | Text in a document puts a false promise into a reply that a buyer copies | what the team says | 2 | 2 | 4 | none | ATK-1, 6 |
| T6 | A template or plugin from outside runs code with the buyer's rights | the laptop, everything on it | 1 | 3 | 3 | llm ignores `functions:` in a template loaded from a URL | APP-1 |
| T7 | A URL that the buyer types redirects to an internal page; its text enters the prompt and the log | internal pages | 1 | 2 | 2 | none (the buyer chooses the URL) | APP-2 |

Every document and tool result also goes to the model provider. That is not a threat path but a
data flow by design: it belongs in the data inventory and the provider contract (R5).

## The order of the work

T1 first: it combines the three parts of the "lethal trifecta" that llm's own documentation warns
about: private data (the plan), untrusted instructions (a page) and a way out (a fetch). Then T2
and T3, which are limits on what a tool can reach. T4 is about what is kept. T5 has no code control
that we can add to llm's reply: a person reads every reply before it leaves Wren & Oak.
