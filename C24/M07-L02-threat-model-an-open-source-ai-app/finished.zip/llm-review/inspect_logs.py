"""What does llm's log database keep? Search every table for the case study's sensitive values.

    python inspect_logs.py

llm writes every prompt, reply, document (fragment), tool call and tool result to logs.db in its
settings folder (.llm-home/ here). This script opens that file read-only and counts, per table,
the rows that contain each sensitive value of the case study. It prints no value itself.
"""

from __future__ import annotations

import json
import sqlite3
from pathlib import Path

HERE = Path(__file__).resolve().parent
DB = HERE / ".llm-home" / "logs.db"


def sensitive_values() -> dict[str, list[str]]:
    canaries = json.loads((HERE / "cases.json").read_text(encoding="utf-8"))["canaries"]
    return {
        "orders API key (canary)": [canaries["orders_api_key"]],
        "cloud token (canary)": [canaries["cloud_token"]],
        "backup key (canary)": [canaries["backup_key"]],
        "oak budget 18,400": ["18,400", "18400"],
        "internal purchase plan": ["do not share with suppliers"],
    }


def main() -> None:
    if not DB.exists():
        raise SystemExit("No log database yet: run some cases first.")
    db = sqlite3.connect(f"{DB.resolve().as_uri()}?mode=ro", uri=True)
    tables = [r[0] for r in db.execute(
        "select name from sqlite_master where type = 'table' and name not like '%fts%' order by name")]
    values = sensitive_values()
    found: dict[str, dict[str, int]] = {}
    for table in tables:
        cols = [r[1] for r in db.execute(f'pragma table_info("{table}")') if r[2].upper() in ("TEXT", "")]
        if not cols:
            continue
        for label, needles in values.items():
            cond = " or ".join(f'instr(coalesce("{c}", \'\'), ?) > 0' for c in cols for _ in needles)
            params = [n for _ in cols for n in needles]
            n = db.execute(f'select count(*) from "{table}" where {cond}', params).fetchone()[0]
            if n:
                found.setdefault(label, {})[table] = n
    turns, first, last = db.execute("select count(*), min(datetime_utc), max(datetime_utc) from turns").fetchone()
    fragments = db.execute("select count(*) from fragments").fetchone()[0]
    db.close()
    print(f"{DB.relative_to(HERE)}: {DB.stat().st_size / 1e6:.1f} MB, {turns} model calls logged, "
          f"{fragments} documents stored in full (fragments)")
    print(f"oldest entry {first[:10] if first else '-'}, newest {last[:10] if last else '-'}; "
          "llm deletes nothing by itself")
    for label in values:
        where = found.get(label)
        text = ", ".join(f"{t} {n}" for t, n in sorted(where.items())) if where else "nowhere"
        print(f"  {label}: {text}")


if __name__ == "__main__":
    main()
