"""The practice servers: a model that replays recorded answers, and a practice network.

    python replay_server.py                 replay the recorded model answers (repeat 1)
    python replay_server.py --repeat 2      replay the second recorded repeat
    python replay_server.py --record ...    record new answers from a real model (optional, costs money)

Two servers start on your computer, and nothing else:

- http://127.0.0.1:8765/v1 answers like an OpenAI-compatible chat API. Each request that `llm`
  sends is looked up in recordings/chat-small.jsonl by its fingerprint (a SHA-256 hash of the
  request). A known request gets the recorded answer. An unknown request gets an error that says
  "no recording": the server never invents an answer.
- The model "obedient" on the same address is not a real model. It is a constructed stand-in for
  the worst case: a model that always does what the injected text says (obedient.py). It tests the
  controls in code, because it never refuses on its own.
- http://127.0.0.1:8766 is the practice network. It plays every web host of the case study
  (alderridge.example, collector.example, 169.254.169.254 ...) from site/pages.json. The practice
  tools send every URL here, with the host name in a header, so no request reaches the internet.
  A request without that header (for example `llm -f http://127.0.0.1:8766/...`) gets the pages
  of the host "local". Every request is written to work/site-log.jsonl.

Uses only the Python standard library.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import threading
import time
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

from obedient import obedient_answer

HERE = Path(__file__).resolve().parent
RECORDINGS = HERE / "recordings" / "chat-small.jsonl"
PAGES = HERE / "site" / "pages.json"
WORK = HERE / "work"
SITE_LOG = WORK / "site-log.jsonl"
MODEL_PORT, SITE_PORT = 8765, 8766
HOST_HEADER = "X-Practice-Host"


def fingerprint(body: dict) -> str:
    """The SHA-256 of the request, with its keys in a fixed order."""
    text = json.dumps(body, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def load_recordings(path: Path = RECORDINGS) -> dict[tuple[str, int], dict]:
    found: dict[tuple[str, int], dict] = {}
    if path.exists():
        for line in path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                row = json.loads(line)
                found[(row["key"], row["repeat"])] = row
    return found


class Model:
    """Replays recorded answers; in record mode, asks the upstream model once per new request."""

    def __init__(self, repeat: int, record: dict | None, used_log: str = ""):
        self.repeat, self.record, self.used_log = repeat, record, used_log
        self.recordings = load_recordings()
        self.lock = threading.Lock()

    def answer(self, body: dict) -> tuple[int, dict]:
        key = fingerprint(body)
        row = self.recordings.get((key, self.repeat))
        if row:
            if self.used_log:
                with self.lock, open(self.used_log, "a", encoding="utf-8") as f:
                    f.write(f"{key} {self.repeat}\n")
            return 200, row["response"]
        if not self.record:
            return 400, {"error": {"type": "no_recording", "message":
                         f"No recording for this request (repeat {self.repeat}, fingerprint {key[:12]}). "
                         "The command or a file changed, or this case was not recorded."}}
        return self._call_upstream(key, body)

    def _call_upstream(self, key: str, body: dict) -> tuple[int, dict]:
        rec = self.record
        sent = {**body, **rec["extra"]}
        api_key = os.environ.get(rec["key_env"], "")
        headers = {"Content-Type": "application/json", "Authorization": f"Bearer {api_key}"}
        if rec["azure"]:
            headers["api-key"] = api_key
        req = urllib.request.Request(rec["base"].rstrip("/") + "/chat/completions",
                                     data=json.dumps(sent).encode(), headers=headers, method="POST")
        start = time.monotonic()
        try:
            with urllib.request.urlopen(req, timeout=120) as resp:
                status, data = resp.status, json.loads(resp.read())
        except urllib.error.HTTPError as err:
            status, data = err.code, json.loads(err.read() or b"{}")
        seconds = round(time.monotonic() - start, 3)
        data.pop("id", None)  # an ID of the provider's, not needed to replay
        row = {"key": key, "repeat": self.repeat, "model": body.get("model"), "status": status,
               "recorded": time.strftime("%Y-%m-%d"), "seconds": seconds, "request": body,
               "response": data}
        if status == 200:
            with self.lock:
                RECORDINGS.parent.mkdir(exist_ok=True)
                with RECORDINGS.open("a", encoding="utf-8") as f:
                    f.write(json.dumps(row, ensure_ascii=False) + "\n")
                self.recordings[(key, self.repeat)] = row
        return status, data


def load_pages() -> list[dict]:
    return json.loads(PAGES.read_text(encoding="utf-8"))["pages"]


def find_page(pages: list[dict], host: str, path: str) -> dict | None:
    for page in pages:
        pattern = page["path"]
        if page["host"] == host and (pattern in (path, "*") or
                                     (pattern.endswith("/*") and path.startswith(pattern[:-1]))):
            return page
    return None


def log_site(entry: dict) -> None:
    WORK.mkdir(exist_ok=True)
    with SITE_LOG.open("a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")


def make_handlers(model: Model):
    pages = load_pages()

    class ModelHandler(BaseHTTPRequestHandler):
        def log_message(self, *args):  # quiet: the client prints what matters
            pass

        def _send(self, status: int, data: dict):
            raw = json.dumps(data).encode()
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)

        def do_GET(self):
            if self.path.rstrip("/") == "/v1/models":
                return self._send(200, {"object": "list", "data": [{"id": "chat-small", "object": "model"}, {"id": "obedient", "object": "model"}]})
            self._send(404, {"error": {"message": "not found"}})

        def do_POST(self):
            if not self.path.startswith("/v1/chat/completions"):
                return self._send(404, {"error": {"message": "only /v1/chat/completions"}})
            body = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))) or b"{}")
            if body.get("model") == "obedient":
                return self._send(200, obedient_answer(body))
            status, data = model.answer(body)
            self._send(status, data)

    class SiteHandler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def do_GET(self):
            parts = urlsplit(self.path)
            host = self.headers.get(HOST_HEADER, "local")
            page = find_page(pages, host, parts.path)
            entry = {"host": host, "path": parts.path, "query": parts.query}
            if page is None:
                status, body, ctype, location = 404, "not found", "text/plain", None
            elif "redirect" in page:
                status, body, ctype, location = 302, "", "text/plain", page["redirect"]
            else:
                status, body, ctype, location = 200, page["body"], page["type"], None
            entry["status"] = status
            if location:
                entry["location"] = location
            log_site(entry)
            raw = body.encode()
            self.send_response(status)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(raw)))
            if location:
                self.send_header("Location", location)
            self.end_headers()
            self.wfile.write(raw)

    return ModelHandler, SiteHandler


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    parser.add_argument("--repeat", type=int, default=1, help="which recorded repeat to replay (default 1)")
    parser.add_argument("--record", action="store_true", help="ask a real model for requests with no recording")
    parser.add_argument("--upstream", default="", help="record: the provider's OpenAI-compatible base URL, ending in /v1")
    parser.add_argument("--key-env", default="UPSTREAM_API_KEY", help="record: the environment variable with the key")
    parser.add_argument("--azure", action="store_true", help="record: also send the key in the api-key header (Azure)")
    parser.add_argument("--extra", default="{}", help='record: JSON added to each request, e.g. {"reasoning_effort": "none"}')
    parser.add_argument("--used-log", default="", help=argparse.SUPPRESS)  # authors: list the recordings in use
    args = parser.parse_args(argv)
    record = None
    if args.record:
        if not args.upstream or not os.environ.get(args.key_env):
            sys.exit(f"--record needs --upstream and the key in ${args.key_env}.")
        record = {"base": args.upstream, "key_env": args.key_env, "azure": args.azure, "extra": json.loads(args.extra)}
    model = Model(args.repeat, record, args.used_log)
    model_handler, site_handler = make_handlers(model)
    servers = [ThreadingHTTPServer(("127.0.0.1", MODEL_PORT), model_handler),
               ThreadingHTTPServer(("127.0.0.1", SITE_PORT), site_handler)]
    for server in servers:
        threading.Thread(target=server.serve_forever, daemon=True).start()
    mode = "recording new answers" if record else f"replaying repeat {args.repeat}"
    print(f"Model:            http://127.0.0.1:{MODEL_PORT}/v1 ({mode}; {len(model.recordings)} recorded answers)")
    print(f"Practice network: http://127.0.0.1:{SITE_PORT} ({len(load_pages())} pages; log in work/site-log.jsonl)")
    print("Press Ctrl+C to stop.")
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        for server in servers:
            server.shutdown()


if __name__ == "__main__":
    main()
