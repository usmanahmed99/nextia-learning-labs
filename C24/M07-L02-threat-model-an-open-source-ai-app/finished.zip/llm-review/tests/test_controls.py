"""Tests of the controls in tools/controls_tools.py. No model and no server: they call the tools
the way llm does, with the arguments that a fooled model would send."""

import json
import shutil
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]


def load_tools(path: str) -> dict:
    """Load a --functions file exactly as llm does: exec it, keep the public callables."""
    namespace: dict = {}
    exec((ROOT / path).read_text(encoding="utf-8"), namespace)
    return {k: v for k, v in namespace.items() if callable(v) and not k.startswith("_")}, namespace


@pytest.fixture
def tools(tmp_path, monkeypatch):
    shutil.copytree(ROOT / "practice", tmp_path / "practice")
    monkeypatch.chdir(tmp_path)
    public, namespace = load_tools("tools/controls_tools.py")
    return public, namespace, tmp_path


def audit(tmp_path: Path) -> list[dict]:
    return [json.loads(line) for line in (tmp_path / "work/tool-audit.jsonl").read_text().splitlines()]


def test_llm_sees_exactly_two_tools():
    for path in ("tools/start_tools.py", "tools/controls_tools.py"):
        public, _ = load_tools(path)
        assert sorted(public) == ["fetch_page", "read_doc"]


def test_read_doc_reads_a_plain_inbox_name(tools):
    public, _, tmp = tools
    assert "120 ash boards" in public["read_doc"]("delivery-note-0412.md")
    event = audit(tmp)[-1]
    assert (event["tool"], event["decision"], event["detail"]) == ("read_doc", "allowed", "delivery-note-0412.md")


@pytest.mark.parametrize("name", ["../config/orders-api.env", "/etc/hosts", "sub/price-list-oct.md",
                                  "..\\config\\orders-api.env", "orders-api.env", "missing.md"])
def test_read_doc_refuses_everything_else(tools, name):
    public, _, tmp = tools
    with pytest.raises(ValueError, match="refused"):
        public["read_doc"](name)
    assert audit(tmp)[-1]["decision"] == "refused"


@pytest.mark.parametrize("url, code", [
    ("http://alderridge.example/stock", "not_https"),
    ("https://collector.example/slot?budget=18400", "host_not_allowed"),
    ("http://169.254.169.254/latest/meta-data/credentials", "not_https"),
    ("https://169.254.169.254/latest/meta-data/credentials", "private_address"),
    ("https://alderridge.example/quote?budget=18400", "extra_url_parts"),
    ("https://alderridge.example:8443/stock", "extra_url_parts"),
])
def test_fetch_page_refuses_before_any_request(tools, monkeypatch, url, code):
    public, namespace, tmp = tools
    calls = []
    namespace["_practice_get"] = lambda host, path: calls.append((host, path)) or (200, "", "page")
    with pytest.raises(ValueError, match=code):
        public["fetch_page"](url)
    assert calls == []
    event = audit(tmp)[-1]
    assert event["code"] == code and "18400" not in json.dumps(event)


def test_fetch_page_does_not_follow_a_redirect(tools):
    public, namespace, tmp = tools
    namespace["_practice_get"] = lambda host, path: (302, "http://169.254.169.254/latest/meta-data/credentials", "")
    with pytest.raises(ValueError, match="redirect_not_followed"):
        public["fetch_page"]("https://alderridge.example/offers/full")
    assert audit(tmp)[-1]["detail"] == "to 169.254.169.254"


def test_secrets_are_masked_in_what_a_tool_returns(tools):
    public, namespace, _ = tools
    namespace["_practice_get"] = lambda host, path: (200, "", "key wo_live_7Hq2LmX9cR4tVb8ZpK3sNw6Y here")
    assert public["fetch_page"]("https://alderridge.example/stock") == "key [secret removed] here"


def test_residual_r3_data_in_a_path_is_still_allowed(tools):
    """Not a wish but a fact, kept as a test: the controls refuse a query string, not data in the
    path of an allowed host. RESIDUAL-RISKS.md R3. When you fix R3, this test must change too."""
    public, namespace, _ = tools
    calls = []
    namespace["_practice_get"] = lambda host, path: calls.append(path) or (200, "", "ok")
    public["fetch_page"]("https://alderridge.example/quote/18400")
    assert calls == ["/quote/18400"]
