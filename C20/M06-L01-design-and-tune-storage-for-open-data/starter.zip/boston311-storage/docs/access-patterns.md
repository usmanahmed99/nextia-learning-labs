# Access-pattern inventory: Boston 311 requests

Write this before the schema and the indexes. Fill the volumes from the data
(`python -m scripts.check_rules` copies it to a staging table you can query).

## The data

| Data | How it is read | How often it changes | How much | How fresh and exact |
|---|---|---|---|---|
| Service requests | | | | |
| Case types | | | | |
| Queues | | | | |

## The query patterns

| | Pattern | Who | Shape | How often | Rows |
|---|---|---|---|---|---|
| P1 | One request by its ID | | | | |
| P2 | | | | | |

## What the patterns ask of the design

-
