# boston311-storage (starter)

The starter of the case study *Design and tune storage for an open public dataset*
(Nextia Learning, Databases and Storage for AI Applications). Follow the steps on the page.

It has the tools: the settings, the migration runner, a connection pool, the download (with
SHA-256), the staging copy, the rules report, the fixed workload, `bench`, `explain`,
`candidates`, `backup` and `restore_drill`, the test database fixture and two small samples of
the real data. You write the inventory (`docs/access-patterns.md`), the migrations
(`migrations/`), the load (`scripts/load.py`), the queries (`boston311/queries.py`), the
new-system load (`scripts/load_new.py`) and the tests.

```sh
python3 -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
cp .env.example .env                                    # then change the password in both places
docker compose up -d db                                 # PostgreSQL on 127.0.0.1:5433
python -m scripts.download                              # 341 MB, checked with SHA-256
python -m scripts.check_rules                           # the first command of the page
```

The data is the City of Boston's, under the PDDL (`DATASET.md`). The code is MIT (`LICENSE`).
