# boston311-storage

Boston's 311 service requests of 2024 and 2025 (582,849 real requests) in PostgreSQL, designed
from an access-pattern inventory: a schema with the rules the data really satisfies, a tested
load, parameterized queries with keyset pages, three measured indexes, a schema change for the
city's new 311 system, and a backup that is proven by a restore drill.

The data is the City of Boston's, under the Open Data Commons Public Domain Dedication and
License (PDDL). See `DATASET.md`. The code is under the MIT licence (`LICENSE`).

## Run it

Needs Python 3.12+, Docker (or PostgreSQL 18 of your own), and about 1 GB of free disk space.

```sh
python3 -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
cp .env.example .env                                    # then change the password in both places
docker compose up -d db                                 # PostgreSQL on 127.0.0.1:5433
python -m scripts.download                              # 341 MB, checked with SHA-256
python -m scripts.load                                  # migrations, then 582,849 requests
python -m pytest                                        # 24 tests on a small sample
```

| Command | What it does |
|---|---|
| `python -m scripts.check_rules` | counts the raw rows that break each candidate rule |
| `python -m scripts.load [--reset] [--to 001]` | migrations, staging, cleaning, the tables |
| `python -m scripts.bench` | the fixed workload: median and p95 per access pattern |
| `python -m scripts.explain queue` | `EXPLAIN (ANALYZE, BUFFERS)` of one pattern (`all` for every one) |
| `python -m scripts.candidates` | index candidates one at a time: size, time, write cost (needs a table with its key only) |
| `python -m scripts.load_new data/boston_311_new_system_2026-10-01_07.csv` | one week from the new 311 system (needs migration 003) |
| `python -m scripts.backup` then `python -m scripts.restore_drill backups/<file>.dump` | a backup and the 7-check restore drill |

To measure from the start, with no indexes: `docker compose down --volumes`,
`docker compose up -d db`, then `python -m scripts.load --to 001`.

## Design

- **Inventory first:** `docs/access-patterns.md` (P1–P6, volumes, freshness).
- **Rules the data satisfies:** `migrations/001_service_requests.sql`. Every rule was counted on the
  raw files first (`scripts.check_rules`). "Closed ⇔ has a closure reason" is not a rule: 464 real
  requests break it (reopened requests, and a bulk closing). Ward 0 and council district 0 are
  stored as NULL.
- **One query file:** `boston311/queries.py`, parameters only, keyset pages.
- **Measured indexes:** `migrations/002_workload_indexes.sql`: a partial index for the open work
  queue, a composite index for the area feed, a partial index for the duplicate check. P5 and P6
  have no index on purpose.
- **A safe schema change:** `migrations/003_new_case_system.sql` (a default without a rewrite, a
  `NOT VALID` rule, then `VALIDATE`).
- **Recovery:** `scripts/backup.py` (one snapshot for the dump and the manifest),
  `scripts/restore_drill.py` (7 checks, including the plan and the answers of the workload).

## Limits

Statuses are as the city published them (the files of 18 September 2026 and one week of the new
system). A request is not a problem: several people report the same pothole. The new system uses
other neighborhood names and categories, so 2024–2025 and 2026 are not like for like. See
`DATASET.md`.
