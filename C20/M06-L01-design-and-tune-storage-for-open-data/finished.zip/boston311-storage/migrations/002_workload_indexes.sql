-- migrate: no-transaction
-- One index per measured access pattern (docs/access-patterns.md, scripts.candidates).
-- P2, the work queue: only open requests, so the index stays small (partial index).
-- P3, the area feed: equal neighborhood, then the order of the feed, newest first.
-- P4, the duplicate check: equal address and type, open requests only.
-- P5 and P6 read most of the table: no index helps them (measured).
CREATE INDEX CONCURRENTLY IF NOT EXISTS requests_open_queue_idx
    ON service_requests (queue_id, opened_at, case_id) WHERE status = 'open';
CREATE INDEX CONCURRENTLY IF NOT EXISTS requests_area_idx
    ON service_requests (neighborhood, opened_at DESC, case_id DESC);
CREATE INDEX CONCURRENTLY IF NOT EXISTS requests_open_address_idx
    ON service_requests (address, type_id) WHERE status = 'open';
