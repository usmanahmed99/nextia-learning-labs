-- migrate: no-transaction
-- The city's new 311 system (from August 2025) numbers its cases BCS-00253943, not
-- 101005236041. Each request records the system it came from, and its ID format must
-- fit that system. Three steps, each in its own transaction:
-- 1. A new column with a constant default: PostgreSQL stores the default once, it does
--    not rewrite the 582,849 rows.
-- 2. The new rule, NOT VALID: checked for new rows only, so the table is locked for a
--    moment, not for a scan.
-- 3. VALIDATE: checks the old rows, with a lock that lets reads and writes go on.
ALTER TABLE service_requests ADD COLUMN source_system text NOT NULL DEFAULT 'legacy';
ALTER TABLE service_requests
    DROP CONSTRAINT requests_case_id_format,
    ADD CONSTRAINT requests_case_id_format CHECK (
        (source_system = 'legacy' AND case_id ~ '^[0-9]{12}$')
        OR (source_system = 'bcs' AND case_id ~ '^BCS-[0-9]{8}$')
    ) NOT VALID;
ALTER TABLE service_requests VALIDATE CONSTRAINT requests_case_id_format;
