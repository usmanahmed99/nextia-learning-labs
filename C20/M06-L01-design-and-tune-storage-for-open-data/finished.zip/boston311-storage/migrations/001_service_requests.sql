-- The service requests of Boston's 311 system (2024 and 2025), with the rules that the
-- data really satisfies. Each rule was checked on the raw files first (scripts.check_rules).

-- What a request is about. In the raw files, each type always has the same reason and
-- subject, so they are stored once here, not on 582,849 rows.
CREATE TABLE case_types (
    type_id  smallint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name     text NOT NULL,
    reason   text NOT NULL,
    subject  text NOT NULL,
    CONSTRAINT case_types_name_unique UNIQUE (name)
);

-- Who works on it. Each queue always belongs to one department.
CREATE TABLE queues (
    queue_id   smallint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name       text NOT NULL,
    department text NOT NULL,
    CONSTRAINT queues_name_unique UNIQUE (name)
);

CREATE TABLE service_requests (
    case_id        text PRIMARY KEY,
    opened_at      timestamptz NOT NULL,
    sla_target_at  timestamptz,
    closed_at      timestamptz,
    status         text NOT NULL,
    on_time        text NOT NULL,
    closure_reason text,
    title          text,
    type_id        smallint NOT NULL REFERENCES case_types,
    queue_id       smallint NOT NULL REFERENCES queues,
    source         text NOT NULL,
    neighborhood   text,
    ward           smallint,
    council_district smallint,
    pwd_district   text,
    zipcode        text,
    address        text,   -- a street address or an intersection, without the city
    latitude       double precision,
    longitude      double precision,

    CONSTRAINT requests_case_id_format CHECK (case_id ~ '^[0-9]{12}$'),
    CONSTRAINT requests_status_known CHECK (status IN ('open', 'closed')),
    -- A closed request has a closing time; an open one has none.
    CONSTRAINT requests_closed_at_matches_status
        CHECK ((status = 'closed') = (closed_at IS NOT NULL)),
    CONSTRAINT requests_closed_after_opened CHECK (closed_at >= opened_at),
    CONSTRAINT requests_target_after_opened CHECK (sla_target_at >= opened_at),
    CONSTRAINT requests_on_time_known CHECK (on_time IN ('ontime', 'overdue')),
    CONSTRAINT requests_ward_range CHECK (ward BETWEEN 1 AND 22),
    CONSTRAINT requests_council_district_range CHECK (council_district BETWEEN 1 AND 9),
    CONSTRAINT requests_zipcode_format CHECK (zipcode ~ '^[0-9]{5}$'),
    -- A point is either complete and in or near Boston, or missing.
    CONSTRAINT requests_point_complete CHECK ((latitude IS NULL) = (longitude IS NULL)),
    CONSTRAINT requests_point_in_boston
        CHECK (latitude BETWEEN 42.2 AND 42.45 AND longitude BETWEEN -71.2 AND -70.95)
);
