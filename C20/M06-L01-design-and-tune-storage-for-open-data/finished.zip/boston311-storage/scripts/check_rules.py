"""Check candidate rules on the raw files before they become constraints.

    python -m scripts.check_rules           count the raw rows that break each rule
    python -m scripts.check_rules --json    the same, as JSON

A rule belongs in the schema only if the data satisfies it, or a cleaning rule can
make the data satisfy it without inventing facts. This script counts, for each
candidate rule, the raw rows that break it. Nothing is changed in the tables.
"""

import argparse
import json
import sys

import psycopg

from boston311.config import database_url
from boston311.staging import FILES, stage

# (rule, SQL that counts the raw rows breaking it). The SQL reads staging_requests.
RULES = [
    ("each case ID appears once",
     "SELECT count(*) - count(DISTINCT case_enquiry_id) FROM staging_requests"),
    ("case ID is 12 digits",
     "SELECT count(*) FROM staging_requests WHERE case_enquiry_id !~ '^[0-9]{12}$'"),
    ("status is Open or Closed",
     "SELECT count(*) FROM staging_requests WHERE case_status NOT IN ('Open', 'Closed')"),
    ("closed <=> has a closing time",
     "SELECT count(*) FROM staging_requests"
     " WHERE (case_status = 'Closed') <> (closed_dt IS NOT NULL)"),
    ("closed <=> has a closure reason",
     "SELECT count(*) FROM staging_requests"
     " WHERE (case_status = 'Closed') <> (closure_reason IS NOT NULL)"),
    ("closed after opened",
     "SELECT count(*) FROM staging_requests"
     " WHERE closed_dt::timestamp < open_dt::timestamp"),
    ("target time after opened",
     "SELECT count(*) FROM staging_requests"
     " WHERE sla_target_dt::timestamp < open_dt::timestamp"),
    ("ward written as a plain number",
     "SELECT count(*) FROM staging_requests WHERE ward !~ '^[1-9][0-9]?$'"),
    ("ward between 1 and 22 (after removing 'Ward ' and zeros)",
     "SELECT count(*) FROM staging_requests"
     " WHERE regexp_replace(ward, '^Ward ', '')::int NOT BETWEEN 1 AND 22"),
    ("council district between 1 and 9",
     "SELECT count(*) FROM staging_requests"
     " WHERE city_council_district::int NOT BETWEEN 1 AND 9"),
    ("ZIP code is 5 digits",
     "SELECT count(*) FROM staging_requests WHERE location_zipcode !~ '^[0-9]{5}$'"),
    ("point in or near Boston",
     "SELECT count(*) FROM staging_requests WHERE NOT (latitude::float8 BETWEEN 42.2 AND 42.45"
     " AND longitude::float8 BETWEEN -71.2 AND -70.95)"),
    ("each type has one reason and subject",
     "SELECT count(*) FROM (SELECT type FROM staging_requests GROUP BY type"
     " HAVING count(DISTINCT (reason, subject)) > 1) t"),
    ("each queue has one department",
     "SELECT count(*) FROM (SELECT queue FROM staging_requests GROUP BY queue"
     " HAVING count(DISTINCT department) > 1) q"),
    ("each type has one department",
     "SELECT count(*) FROM (SELECT type FROM staging_requests GROUP BY type"
     " HAVING count(DISTINCT department) > 1) t"),
]  # fmt: skip


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)
    with psycopg.connect(database_url()) as conn:
        total = stage(conn, FILES, quiet=args.json)
        result = {name: conn.execute(sql).fetchone()[0] for name, sql in RULES}
        conn.execute("DROP TABLE staging_requests")
    if args.json:
        print(json.dumps({"rows": total, "broken": result}, indent=2))
        return 0
    print(f"{total:,} raw rows. Rows (or groups) that break each candidate rule:")
    width = max(len(n) for n in result)
    for name, broken in result.items():
        print(f"  {name:<{width}}  {broken:>7,}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
