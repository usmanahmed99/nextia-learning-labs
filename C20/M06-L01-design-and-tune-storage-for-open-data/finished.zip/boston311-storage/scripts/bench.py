"""Run the fixed workload and print the median time of each access pattern.

    python -m scripts.bench                      5 passes, 4 connections at a time
    python -m scripts.bench --passes 3
    python -m scripts.bench --json results/no-indexes.json --label "no indexes"

Each pass runs every call of every pattern (boston311.workload), 4 at a time through a
connection pool, and times each call from the program's side. The median of a pattern is
the median over its calls; the result is the median of the passes' medians, and p95 is
over all the calls of all passes. A warm-up pass runs first and is not counted. Run it
with nothing else busy on the computer, and compare runs on the same data only.
"""

import argparse
import json
import platform
import statistics
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import UTC, datetime
from pathlib import Path

from boston311 import workload
from boston311.config import database_url
from boston311.db import make_pool


def percentile(values: list[float], p: float) -> float:
    values = sorted(values)
    return values[max(0, round(p * len(values)) - 1)]


def timed(pool, fn, kwargs) -> float:
    with pool.connection() as conn:
        started = time.perf_counter()
        fn(conn, **kwargs)
        return (time.perf_counter() - started) * 1000


def run(passes: int = 5, concurrency: int = 4) -> dict:
    pool = make_pool(database_url(), size=concurrency)
    try:
        with pool.connection() as conn:
            calls = workload.build(conn)
            indexes = [
                r["indexname"]
                for r in conn.execute(
                    "SELECT indexname FROM pg_indexes WHERE tablename = 'service_requests'"
                    " ORDER BY 1"
                )
            ]
        out = {}
        with ThreadPoolExecutor(concurrency) as ex:
            for name, items in calls.items():
                list(ex.map(lambda c: timed(pool, *c), items))  # warm-up
                medians, every = [], []
                for _ in range(passes):
                    times = list(ex.map(lambda c: timed(pool, *c), items))
                    medians.append(statistics.median(times))
                    every += times
                out[name] = {
                    "calls": len(items),
                    "median_ms": round(statistics.median(medians), 3),
                    "p95_ms": round(percentile(every, 0.95), 3),
                    "pass_medians_ms": [round(m, 3) for m in medians],
                }
    finally:
        pool.close()
    return {
        "patterns": out,
        "indexes": indexes,
        "passes": passes,
        "concurrency": concurrency,
        "machine": f"{platform.system()} {platform.machine()}, Python {platform.python_version()}",
        "ran_at": datetime.now(UTC).isoformat(timespec="seconds"),
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--passes", type=int, default=5)
    parser.add_argument("--concurrency", type=int, default=4)
    parser.add_argument("--label", default="")
    parser.add_argument("--json", type=Path, help="also save every number to this file")
    args = parser.parse_args(argv)
    result = run(args.passes, args.concurrency)
    result["label"] = args.label
    print(f"Indexes on service_requests: {', '.join(result['indexes'])}")
    print(f"{args.passes} passes, {args.concurrency} at a time. Median and p95 per call:")
    width = max(len(n) for n in result["patterns"])
    for name, r in result["patterns"].items():
        print(
            f"  {name:<{width}}  {r['calls']:>3} calls  median {r['median_ms']:>9.3f} ms"
            f"  p95 {r['p95_ms']:>9.3f} ms"
        )
    if args.json:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(json.dumps(result, indent=2, default=str) + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
