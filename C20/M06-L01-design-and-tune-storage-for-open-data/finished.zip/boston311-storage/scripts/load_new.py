"""Load (or refresh) requests from the city's new 311 system, from a CSV file.

    python -m scripts.load_new data/boston_311_new_system_2026-10-01_07.csv

The new system has other column names, its own ID format (BCS-00253943), times with a
zone (UTC), and six statuses. This script maps them to the schema in one transaction:

  - status: "Closed" -> closed; "In progress", "Needs Reallocation", "Submit", "Apply"
    and "Create" -> open (the request is not finished)
  - type: service_name (reason: case_topic; subject: the department)
  - queue: assigned_team; an empty team -> "Not assigned", department -> "Not recorded"
  - address: street number and street name, as the old system wrote them
  - ward 0 and council district 0 -> NULL, as in scripts.load

A request that is already in the table is updated (its status may have changed): run the
same file again, or a newer one, and nothing is counted twice.
"""

import argparse
import sys
import time
from pathlib import Path

import psycopg
from psycopg.rows import tuple_row

from boston311.config import database_url

NEW_COLUMNS = [
    "case_id", "open_date", "case_topic", "service_name", "assigned_department",
    "assigned_team", "case_status", "closure_reason", "closure_comments", "close_date",
    "target_close_date", "on_time", "report_source", "full_address", "street_number",
    "street_name", "zip_code", "neighborhood", "public_works_district",
    "city_council_district", "fire_district", "police_district", "ward", "precinct",
    "submitted_photo", "closed_photo", "longitude", "latitude",
]  # fmt: skip

DEPARTMENT = "coalesce(nullif(assigned_department, ''), 'Not recorded')"

UPSERT = f"""
INSERT INTO case_types (name, reason, subject)
SELECT DISTINCT ON (service_name) service_name, case_topic, {DEPARTMENT}
FROM staging_new ORDER BY service_name
ON CONFLICT (name) DO NOTHING;

INSERT INTO queues (name, department)
SELECT DISTINCT ON (team) team, {DEPARTMENT}
FROM (SELECT *, coalesce(nullif(assigned_team, ''), 'Not assigned') AS team FROM staging_new) s
ORDER BY team
ON CONFLICT (name) DO NOTHING;

INSERT INTO service_requests (
    case_id, source_system, opened_at, sla_target_at, closed_at, status, on_time,
    closure_reason, title, type_id, queue_id, source, neighborhood, ward, council_district,
    pwd_district, zipcode, address, latitude, longitude)
SELECT
    s.case_id, 'bcs', s.open_date::timestamptz, nullif(s.target_close_date, '')::timestamptz,
    nullif(s.close_date, '')::timestamptz,
    CASE WHEN s.case_status = 'Closed' THEN 'closed' ELSE 'open' END,
    lower(s.on_time), nullif(s.closure_reason, ''), s.service_name, t.type_id, q.queue_id,
    s.report_source, nullif(s.neighborhood, ''),
    nullif(nullif(s.ward, '')::smallint, 0),
    nullif(nullif(s.city_council_district, '')::smallint, 0),
    nullif(s.public_works_district, ''), nullif(s.zip_code, ''),
    nullif(trim(concat_ws(' ', nullif(s.street_number, ''), nullif(s.street_name, ''))), ''),
    nullif(s.latitude, '')::double precision, nullif(s.longitude, '')::double precision
FROM staging_new s
JOIN case_types t ON t.name = s.service_name
JOIN queues q ON q.name = coalesce(nullif(s.assigned_team, ''), 'Not assigned')
ON CONFLICT (case_id) DO UPDATE SET
    status = excluded.status, closed_at = excluded.closed_at, on_time = excluded.on_time,
    closure_reason = excluded.closure_reason, sla_target_at = excluded.sla_target_at,
    queue_id = excluded.queue_id
"""


def load_new_file(conn: psycopg.Connection, path: Path) -> tuple[int, int]:
    """Upsert the file's requests in one transaction. Returns (rows in the file, new rows)."""
    cur = conn.cursor(row_factory=tuple_row)
    count = "SELECT count(*) FROM service_requests"
    with conn.transaction():
        before = cur.execute(count).fetchone()[0]
        columns = ", ".join(f"{c} text" for c in NEW_COLUMNS)
        conn.execute("DROP TABLE IF EXISTS staging_new")
        conn.execute(f"CREATE TEMP TABLE staging_new ({columns}) ON COMMIT DROP")
        with conn.cursor().copy("COPY staging_new FROM STDIN WITH (FORMAT csv, HEADER true)") as cp:
            cp.write(path.read_bytes())
        staged = cur.execute("SELECT count(*) FROM staging_new").fetchone()[0]
        cur.execute(UPSERT)
        after = cur.execute(count).fetchone()[0]
    return staged, after - before


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("file", type=Path)
    args = parser.parse_args(argv)
    header = args.file.open(encoding="utf-8").readline().strip().split(",")
    if header != NEW_COLUMNS:
        print(f"{args.file.name}: these are not the new system's columns.")
        return 1
    started = time.perf_counter()
    with psycopg.connect(database_url()) as conn:
        has_system = conn.execute(
            "SELECT EXISTS (SELECT 1 FROM information_schema.columns"
            " WHERE table_name = 'service_requests' AND column_name = 'source_system')"
        ).fetchone()[0]
        if not has_system:
            print("The table has no source_system column yet: run python -m boston311.migrate.")
            return 1
        staged, new = load_new_file(conn, args.file)
    print(
        f"{args.file.name}: {staged:,} rows; {new:,} new requests,"
        f" {staged - new:,} updated, in {time.perf_counter() - started:.1f} s."
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
