"""Download Boston's 311 service requests of 2024 and 2025, and check each file's SHA-256.

    python -m scripts.download                    both years (341 MB), into data/raw/
    python -m scripts.download --accept-changed   keep a file whose checksum is different

The files come from the City of Boston's open data portal (Analyze Boston), under the
Open Data Commons Public Domain Dedication and License (PDDL). The checksums are those of
the files that the case study used. The city sometimes publishes a revised file under the
same address: then the checksum is different, and the script stops. With
--accept-changed it keeps the new file, and your counts will differ from the page.
"""

import argparse
import hashlib
import sys
import time
import urllib.request
from pathlib import Path

from boston311.config import ROOT

RAW = ROOT / "data" / "raw"
BASE = "https://data.boston.gov/dataset/8048697b-ad64-4bfc-b090-ee00169f2323/resource"
FILES = {
    "boston_311_2024.csv": (
        f"{BASE}/dff4d804-5031-443a-8409-8344efd0e5c8/download/lagan_311_open_data_2024_rvsd3.csv",
        "a3f80f43cc03e00a87fcb26bf2c66bc9ed63dc7ee349b8d3aa803ebac288502d",
        182_147_317,
    ),
    "boston_311_2025.csv": (
        f"{BASE}/9d7c2214-4709-478a-a2e8-fb2020a5bb94/download/lagan_311_open_data_2025_rvsd3.csv",
        "9924067503d044b376001f3fa3ddfc8d378f321e5da8c761d47e8a863a957a56",
        159_465_243,
    ),
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


class Redirect(urllib.request.HTTPRedirectHandler):
    """The portal redirects to a signed storage address written with ":443". urllib would send
    that port in the Host header, which breaks the signature (403), so it is removed."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return super().redirect_request(req, fp, code, msg, headers,
                                         newurl.replace(":443/", "/", 1))  # fmt: skip


def fetch(url: str, path: Path) -> None:
    part = path.with_suffix(".part")
    request = urllib.request.Request(url, headers={"User-Agent": "boston311-storage/1.0"})
    opener = urllib.request.build_opener(Redirect)
    with opener.open(request, timeout=120) as response, open(part, "wb") as f:
        while block := response.read(1 << 20):
            f.write(block)
    part.replace(path)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--accept-changed", action="store_true")
    args = parser.parse_args(argv)
    RAW.mkdir(parents=True, exist_ok=True)
    for name, (url, expected, size) in FILES.items():
        path = RAW / name
        if path.exists() and sha256(path) == expected:
            print(f"{name}: already here, checksum OK")
            continue
        print(f"{name}: downloading {size / 1e6:.0f} MB ...", flush=True)
        started = time.perf_counter()
        fetch(url, path)
        got = sha256(path)
        seconds = time.perf_counter() - started
        if got != expected:
            if args.accept_changed:
                print(f"{name}: the city changed the file (SHA-256 {got[:12]}...). Kept it.")
                continue
            print(
                f"{name}: the SHA-256 is {got[:12]}..., not {expected[:12]}... The city has"
                " published a revised file. Run again with --accept-changed to use it (your"
                " counts will differ from the page).",
                file=sys.stderr,
            )
            return 1
        print(f"{name}: {path.stat().st_size / 1e6:.0f} MB in {seconds:.0f} s, checksum OK")
    return 0


if __name__ == "__main__":
    sys.exit(main())
