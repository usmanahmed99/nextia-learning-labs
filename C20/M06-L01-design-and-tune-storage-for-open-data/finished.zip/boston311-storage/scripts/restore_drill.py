"""A restore drill: restore a backup into a new, empty database and check that it is complete.

    python -m scripts.restore_drill backups/boston311-20261010-120000.dump
    python -m scripts.restore_drill backups/....dump --keep      keep the restored database

The drill restores the dump into <your database>_restore_drill (your own database does
not change), then checks:

  1. the dump file is the one the manifest describes (SHA-256)
  2. pg_restore finished with no error
  3. the same migrations are applied
  4. every table has the same number of rows, with the same contents (checksums)
  5. every constraint and every index is valid
  6. the work queue still uses its index (the plan, not only the rows)
  7. three workload queries give the same answers as before the backup

and prints PASS or FAIL for each, and the time the restore took.
"""

import argparse
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

import psycopg

from boston311 import queries
from boston311.config import database_url
from scripts.backup import dbname, manifest, tool


def check(results: list, name: str, ok: bool, detail: str = "") -> None:
    results.append({"check": name, "ok": ok, "detail": detail})
    print(f"{'PASS' if ok else 'FAIL'}  {name}" + (f": {detail}" if detail else ""))


def restore(url: str, dump: Path, keep: bool = False) -> list[dict]:
    info = json.loads(dump.with_suffix(".json").read_text())
    results = []
    same_file = hashlib.sha256(dump.read_bytes()).hexdigest() == info["sha256"]
    check(results, "dump matches its manifest", same_file)
    base = url.rsplit("/", 1)[0]
    target = f"{dbname(url)}_restore_drill"
    with psycopg.connect(f"{base}/postgres", autocommit=True) as conn:
        conn.execute(f"DROP DATABASE IF EXISTS {target} WITH (FORCE)")
        conn.execute(f"CREATE DATABASE {target}")
    target_url = f"{base}/{target}"
    command = tool("pg_restore", url)
    where = target_url if len(command) == 1 else target
    started = time.perf_counter()
    with open(dump, "rb") as f:
        done = subprocess.run(command + ["--no-owner", "-d", where], stdin=f,
                              capture_output=True, text=True)  # fmt: skip
    seconds = time.perf_counter() - started
    errors = [ln for ln in done.stderr.splitlines() if ln.strip()]
    check(results, "pg_restore finished", done.returncode == 0,
          f"{seconds:.1f} s" if done.returncode == 0 else "; ".join(errors[:3]))  # fmt: skip
    with psycopg.connect(target_url) as conn:
        now = manifest(conn)
        conn.rollback()
        check(results, "same migrations", now["migrations"] == info["migrations"],
              f"{len(now['migrations'])} of {len(info['migrations'])}")  # fmt: skip
        wrong = [t for t, v in info["tables"].items() if now["tables"].get(t) != v]
        check(
            results,
            "same rows and contents in every table",
            not wrong,
            ", ".join(f"{t} {v['rows']:,}" for t, v in now["tables"].items())
            if not wrong
            else "different: " + ", ".join(wrong),
        )
        bad = conn.execute(
            "SELECT conname FROM pg_constraint WHERE NOT convalidated"
            " UNION ALL SELECT indexrelid::regclass::text FROM pg_index WHERE NOT indisvalid"
        ).fetchall()
        check(results, "every constraint and index is valid", not bad,
              ", ".join(r[0] for r in bad))  # fmt: skip
        conn.execute("ANALYZE")  # pg_restore does not restore the statistics
        sql, params = queries.open_queue_sql("PWDx_Sidewalk Repair")
        plan = "\n".join(r[0] for r in conn.execute(f"EXPLAIN {sql}", params))
        check(results, "the work queue uses its index", "requests_open_queue_idx" in plan)
        same = now["answers"] == info["answers"]
        check(results, "workload answers are the same", same,
              "P2, P3 and P5" if same else "different")  # fmt: skip
    if not keep:
        with psycopg.connect(f"{base}/postgres", autocommit=True) as conn:
            conn.execute(f"DROP DATABASE IF EXISTS {target} WITH (FORCE)")
    return results


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("dump", type=Path)
    parser.add_argument("--keep", action="store_true", help="keep the restored database")
    args = parser.parse_args(argv)
    results = restore(database_url(), args.dump, args.keep)
    failed = [r for r in results if not r["ok"]]
    print(f"Restore drill: {len(results) - len(failed)} of {len(results)} checks passed.")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
