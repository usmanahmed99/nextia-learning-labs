"""Show the query plan of each access pattern: EXPLAIN (ANALYZE, BUFFERS).

    python -m scripts.explain queue                  the plan of one query, with its real times
    python -m scripts.explain area --runs 5          the median execution time of 5 runs
    python -m scripts.explain all --runs 5 --json results/plans.json
    python -m scripts.explain queue --no-analyze     the plan only: the query does not run

The queries are the ones of boston311.queries, with fixed values:

    request     P1  case 101005236041
    queue       P2  open requests of BTDT_Parking Enforcement (61,333 open), first page
    queue-small P2  open requests of PWDx_Highway Construction (2,376 open), first page
    area        P3  Dorchester (77,047 requests), first page
    area-rare   P3  Chestnut Hill (27 requests, the last in 2025), first page
    deep-offset P3  Dorchester, the page after 5,000 rows, with OFFSET
    deep-keyset P3  the same page, with the keyset cursor
    duplicates  P4  open "Request for Pothole Repair" at 100A Southampton St, 30 days
    overdue     P5  open requests past their target, per department
    report      P6  2025, per department and month
"""

import argparse
import json
import statistics
import sys
from datetime import datetime, timedelta
from pathlib import Path

import psycopg
from psycopg.rows import tuple_row

from boston311 import queries
from boston311.config import database_url
from boston311.workload import NOW


def dorchester_cursor(conn) -> str:
    at, case_id = conn.execute(
        "SELECT opened_at, case_id FROM service_requests WHERE neighborhood = 'Dorchester'"
        " ORDER BY opened_at DESC, case_id DESC OFFSET 4999 LIMIT 1"
    ).fetchone()
    return queries.encode_cursor(at, case_id)


def plans(conn) -> dict:
    return {
        "request": lambda: queries.get_request_sql("101005236041"),
        "queue": lambda: queries.open_queue_sql("BTDT_Parking Enforcement"),
        "queue-small": lambda: queries.open_queue_sql("PWDx_Highway Construction"),
        "area": lambda: queries.area_feed_sql("Dorchester"),
        "area-rare": lambda: queries.area_feed_sql("Chestnut Hill"),
        "deep-offset": lambda: queries.area_feed_offset_sql("Dorchester", offset=5000),
        "deep-keyset": lambda: queries.area_feed_sql("Dorchester", after=dorchester_cursor(conn)),
        "duplicates": lambda: queries.possible_duplicates_sql(
            "100A Southampton St", "Request for Pothole Repair",
            datetime.fromisoformat("2025-12-31T12:00:00-05:00") - timedelta(days=30)),
        "overdue": lambda: queries.overdue_by_department_sql(NOW),
        "report": lambda: queries.on_time_by_month_sql(2025),
    }  # fmt: skip


def explain(conn, sql: str, params: dict, analyze: bool = True) -> tuple[list[str], float | None]:
    options = "ANALYZE, BUFFERS" if analyze else "COSTS"
    lines = [r[0] for r in conn.execute(f"EXPLAIN ({options}) {sql}", params)]
    ms = None
    for line in lines:
        if line.startswith("Execution Time:"):
            ms = float(line.split()[2])
    return lines, ms


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("query", help="a name from the list above, or all")
    parser.add_argument("--runs", type=int, default=1, help="run it N times; print the median")
    parser.add_argument("--no-analyze", action="store_true")
    parser.add_argument("--json", type=Path)
    args = parser.parse_args(argv)
    out = {}
    with psycopg.connect(database_url(), row_factory=tuple_row, autocommit=True) as conn:
        builders = plans(conn)
        names = list(builders) if args.query == "all" else [args.query]
        for name in names:
            if name not in builders:
                print(f"Unknown query {name!r}. Choose one of: {', '.join(builders)}, all.")
                return 1
            sql, params = builders[name]()
            times, lines = [], []
            for _ in range(max(1, args.runs)):
                lines, ms = explain(conn, sql, params, not args.no_analyze)
                times.append(ms)
            median = statistics.median(times) if not args.no_analyze else None
            out[name] = {"plan": lines, "runs_ms": times, "median_ms": median}
            if args.query != "all" or not args.json:
                print(f"-- {name}")
                print("\n".join(lines))
            if median is not None and args.runs > 1:
                print(f"{name}: median execution time of {args.runs} runs: {median:.3f} ms")
    if args.json:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(json.dumps(out, indent=2) + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
