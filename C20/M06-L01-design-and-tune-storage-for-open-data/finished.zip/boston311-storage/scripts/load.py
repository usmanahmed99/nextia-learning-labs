"""Load the 311 requests of 2024 and 2025 into the tables, with the cleaning rules.

    python -m scripts.load            migrations, then COPY to staging, then the tables
    python -m scripts.load --reset    delete the requests first, and load again
    python -m scripts.load --to 001   apply the migrations up to 001 only (no indexes yet)

Steps: apply the migrations; copy both CSV files into staging_requests (text only);
insert the case types and queues; insert the requests with the cleaning rules below,
in one transaction; drop the staging table; ANALYZE; print the counts.

Cleaning rules (each one was found by scripts.check_rules on the raw files):
  - times: the city writes Boston local time with no zone: read as America/New_York
  - status and on_time: lower case ("Closed" -> "closed", "ONTIME" -> "ontime")
  - ward: written "Ward 5", "05" or "5": stored as the number 5
  - ward 0 and council district 0 (there are none): stored as NULL ("not known")
  - "&amp;" in addresses and titles (an HTML escape): stored as "&"
  - empty text: stored as NULL
"""

import argparse
import sys
import time

import psycopg

from boston311 import migrate
from boston311.config import database_url
from boston311.staging import FILES, stage

INSERT_TYPES = """
INSERT INTO case_types (name, reason, subject)
SELECT DISTINCT type, reason, subject FROM staging_requests ORDER BY type
ON CONFLICT (name) DO NOTHING
"""

INSERT_QUEUES = """
INSERT INTO queues (name, department)
SELECT DISTINCT queue, department FROM staging_requests ORDER BY queue
ON CONFLICT (name) DO NOTHING
"""

INSERT_REQUESTS = """
INSERT INTO service_requests (
    case_id, opened_at, sla_target_at, closed_at, status, on_time, closure_reason, title,
    type_id, queue_id, source, neighborhood, ward, council_district, pwd_district, zipcode,
    address, latitude, longitude)
SELECT
    s.case_enquiry_id,
    s.open_dt::timestamp AT TIME ZONE 'America/New_York',
    nullif(s.sla_target_dt, '')::timestamp AT TIME ZONE 'America/New_York',
    nullif(s.closed_dt, '')::timestamp AT TIME ZONE 'America/New_York',
    lower(s.case_status),
    lower(s.on_time),
    nullif(s.closure_reason, ''),
    replace(nullif(s.case_title, ''), '&amp;', '&'),
    t.type_id,
    q.queue_id,
    s.source,
    nullif(s.neighborhood, ''),
    nullif(nullif(regexp_replace(s.ward, '^Ward ', ''), '')::smallint, 0),
    nullif(nullif(s.city_council_district, ''), '0')::smallint,
    nullif(s.pwd_district, ''),
    nullif(s.location_zipcode, ''),
    replace(nullif(s.location_street_name, ''), '&amp;', '&'),
    nullif(s.latitude, '')::double precision,
    nullif(s.longitude, '')::double precision
FROM staging_requests s
JOIN case_types t ON t.name = s.type
JOIN queues q ON q.name = s.queue
"""

CLEANED = """
SELECT
    count(*) FILTER (WHERE ward LIKE 'Ward %') AS ward_prefixed,
    count(*) FILTER (WHERE ward ~ '^0[0-9]$') AS ward_leading_zero,
    count(*) FILTER (WHERE regexp_replace(ward, '^Ward ', '')::int = 0) AS ward_zero,
    count(*) FILTER (WHERE city_council_district = '0') AS council_district_zero,
    count(*) FILTER (WHERE location LIKE '%&amp;%' OR case_title LIKE '%&amp;%') AS html_escape
FROM staging_requests
"""


def load_files(conn: psycopg.Connection, files: list, quiet: bool = False) -> dict:
    """Stage the files and insert the cleaned requests (one transaction). Returns the counts."""
    staged = stage(conn, files, quiet=quiet)
    fixed = conn.execute(CLEANED).fetchone()
    with conn.transaction():
        conn.execute(INSERT_TYPES)
        conn.execute(INSERT_QUEUES)
        loaded = conn.execute(INSERT_REQUESTS).rowcount
    conn.execute("DROP TABLE staging_requests")
    conn.commit()
    return {"staged": staged, "loaded": loaded, "cleaned": fixed}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--reset", action="store_true", help="delete the requests and load again")
    parser.add_argument("--to", help="apply the migrations up to this number only")
    args = parser.parse_args(argv)
    url = database_url()
    missing = [f.name for f in FILES if not f.exists()]
    if missing:
        print(f"Missing {', '.join(missing)}. Run python -m scripts.download first.")
        return 1
    with psycopg.connect(url) as conn:
        table = conn.execute("SELECT to_regclass('service_requests')").fetchone()[0]
        loaded = table and conn.execute("SELECT EXISTS (SELECT 1 FROM service_requests)")
        if loaded and loaded.fetchone()[0] and not args.reset:
            print("The tables already have requests. Run again with --reset to load again.")
            return 1
    if migrate.main(["--to", args.to] if args.to else [], url=url) != 0:
        return 1
    started = time.perf_counter()
    with psycopg.connect(url) as conn:
        if args.reset:
            conn.execute("TRUNCATE service_requests, case_types, queues RESTART IDENTITY")
        result = load_files(conn, FILES)
        conn.autocommit = True
        conn.execute("ANALYZE case_types, queues, service_requests")
        counts = {
            t: conn.execute(f"SELECT count(*) FROM {t}").fetchone()[0]
            for t in ("case_types", "queues", "service_requests")
        }
        size = conn.execute("SELECT pg_size_pretty(pg_database_size(current_database()))")
        size = size.fetchone()[0]
    fixed = result["cleaned"]
    print(
        f"Staged {result['staged']:,} rows; loaded {result['loaded']:,} requests in"
        f" {time.perf_counter() - started:.1f} s."
    )
    print(
        f"Cleaned: ward written 'Ward N' {fixed[0]:,}, ward with a leading zero {fixed[1]:,},"
        f" ward 0 -> NULL {fixed[2]:,}, council district 0 -> NULL {fixed[3]:,},"
        f" '&amp;' -> '&' {fixed[4]:,}."
    )
    print(", ".join(f"{t} {n:,}" for t, n in counts.items()) + f". Database: {size}.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
