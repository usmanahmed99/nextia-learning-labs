"""Back up the database with pg_dump, and write a manifest that a restore drill can check.

    python -m scripts.backup        writes backups/<database>-<time>.dump and .json

The dump is PostgreSQL's custom format (pg_dump -Fc): compressed, and pg_restore can
restore all of it or a part. The manifest has what a restore must give back: the
migrations, the rows and a checksum of each table, and the answers of three workload
queries. The dump and the manifest are read from one snapshot, so they agree even if
requests are written while the backup runs.

It uses pg_dump on your computer if it has the server's major version (18); else it
runs pg_dump inside the Docker container (docker compose exec db). PG_TOOLS=docker
forces the container.
"""

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
from datetime import UTC, datetime
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

from boston311 import queries
from boston311.config import ROOT, database_url
from boston311.workload import NOW

BACKUPS = ROOT / "backups"
TABLES = {"case_types": "type_id", "queues": "queue_id", "service_requests": "case_id"}


def server_major(url: str) -> int:
    with psycopg.connect(url) as conn:
        return int(conn.execute("SHOW server_version_num").fetchone()[0]) // 10000


def user(url: str) -> str:
    return psycopg.conninfo.conninfo_to_dict(url).get("user", "postgres")


def dbname(url: str) -> str:
    return psycopg.conninfo.conninfo_to_dict(url)["dbname"]


def tool(name: str, url: str) -> list[str]:
    """The command for pg_dump or pg_restore: local if it fits the server, else in Docker."""
    local = shutil.which(name)
    if local and os.environ.get("PG_TOOLS") != "docker":
        out = subprocess.run([local, "--version"], capture_output=True, text=True).stdout
        if out.split()[-1].split(".")[0] == str(server_major(url)):
            return [local]
    if shutil.which("docker"):
        return ["docker", "compose", "exec", "-T", "db", name, "-U", user(url)]
    raise SystemExit(f"{name} {server_major(url)} was not found, and Docker is not available.")


def answers(conn: psycopg.Connection) -> dict:
    """The answers of three workload queries: a restored database must give the same."""
    old, conn.row_factory = conn.row_factory, dict_row
    try:
        queue = queries.open_queue(conn, "PWDx_Sidewalk Repair", limit=5)
        area = queries.area_feed(conn, "Charlestown", limit=5)
        overdue = queries.overdue_by_department(conn, NOW)
    finally:
        conn.row_factory = old
    return {
        "P2 first ids": [r["case_id"] for r in queue["rows"]],
        "P3 first ids": [r["case_id"] for r in area["rows"]],
        "P5 overdue": {r["department"]: r["overdue"] for r in overdue},
    }


def manifest(conn: psycopg.Connection) -> dict:
    """Migrations, rows and a checksum of each table, and the workload answers."""
    out = {
        "migrations": [
            r[0] for r in conn.execute("SELECT version FROM schema_migrations ORDER BY 1")
        ],
        "tables": {},
    }
    for table, order in TABLES.items():
        n, digest = conn.execute(
            f"SELECT count(*), md5(coalesce(string_agg(t::text, E'\\n' ORDER BY {order}), ''))"
            f" FROM {table} t"
        ).fetchone()
        out["tables"][table] = {"rows": n, "md5": digest}
    out["answers"] = answers(conn)
    return out


def backup(url: str) -> Path:
    BACKUPS.mkdir(exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%d-%H%M%S")
    path = BACKUPS / f"{dbname(url)}-{stamp}.dump"
    command = tool("pg_dump", url)
    with psycopg.connect(url) as conn:
        # One snapshot for the dump and the manifest.
        conn.isolation_level = psycopg.IsolationLevel.REPEATABLE_READ
        snapshot = conn.execute("SELECT pg_export_snapshot()").fetchone()[0]
        target = url if len(command) == 1 else dbname(url)
        started = time.perf_counter()
        with open(path, "wb") as f:
            subprocess.run(command + ["-Fc", f"--snapshot={snapshot}", "-d", target], stdout=f,
                           check=True)  # fmt: skip
        seconds = time.perf_counter() - started
        contents = manifest(conn)
    info = {
        "database": dbname(url),
        "made_at": stamp,
        "dump": path.name,
        "bytes": path.stat().st_size,
        "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "seconds": round(seconds, 2),
        "pg_dump": subprocess.run(
            command + ["--version"], capture_output=True, text=True
        ).stdout.strip(),
        **contents,
    }
    path.with_suffix(".json").write_text(json.dumps(info, indent=2) + "\n")
    return path


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.parse_args(argv)
    path = backup(database_url())
    info = json.loads(path.with_suffix(".json").read_text())
    print(f"Backup: {path.relative_to(ROOT)} ({info['bytes'] / 1e6:.1f} MB, {info['seconds']} s)")
    print(
        f"Manifest: {path.with_suffix('.json').relative_to(ROOT)}: {len(info['migrations'])}"
        " migrations, " + ", ".join(f"{t} {v['rows']:,}" for t, v in info["tables"].items())
    )
    print(f"A backup is not proven until a restore works: python -m scripts.restore_drill"
          f" {path.relative_to(ROOT)}")  # fmt: skip
    return 0


if __name__ == "__main__":
    sys.exit(main())
