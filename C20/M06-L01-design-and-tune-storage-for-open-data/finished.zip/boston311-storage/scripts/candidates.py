"""Measure index candidates one at a time: size, build time, and the plans they change.

    python -m scripts.candidates --json results/candidates.json
    python -m scripts.candidates --only queue_partial area_composite

For each candidate: CREATE INDEX, ANALYZE, then each query it is meant for, 5 times
(EXPLAIN ANALYZE, median of the execution times), then DROP INDEX. Then the write
cost: the nightly refresh (10,000 requests closed and 10,000 new ones) with the keys
only, with the chosen indexes, and with every candidate, in transactions that are
rolled back. Your tables are the same afterwards. It takes a few minutes.
"""

import argparse
import json
import statistics
import sys
import time
from pathlib import Path

import psycopg
from psycopg.rows import tuple_row

from boston311.config import database_url
from scripts.explain import explain, plans

T = "service_requests"
CANDIDATES = {  # name: (index definition, the queries it is for)
    "none": (None, ["queue", "queue-small", "area", "area-rare", "deep-offset", "deep-keyset",
                    "duplicates", "overdue"]),
    "queue": ("(queue_id)", ["queue", "queue-small"]),
    "status_queue": ("(status, queue_id)", ["queue", "queue-small"]),
    "queue_opened": ("(queue_id, opened_at, case_id)", ["queue", "queue-small"]),
    "queue_partial": ("(queue_id, opened_at, case_id) WHERE status = 'open'",
                      ["queue", "queue-small", "overdue"]),
    "neighborhood": ("(neighborhood)", ["area", "area-rare", "deep-offset", "deep-keyset"]),
    "opened": ("(opened_at)", ["area", "area-rare", "deep-offset", "deep-keyset"]),
    "area_composite": ("(neighborhood, opened_at DESC, case_id DESC)",
                       ["area", "area-rare", "deep-offset", "deep-keyset"]),
    "address": ("(address)", ["duplicates"]),
    "address_partial": ("(address, type_id) WHERE status = 'open'", ["duplicates"]),
    "overdue_partial": ("(sla_target_at) WHERE status = 'open'", ["overdue"]),
}  # fmt: skip
CHOSEN = ["queue_partial", "area_composite", "address_partial"]

REFRESH = """
WITH closing AS (
    SELECT case_id FROM service_requests WHERE status = 'open' ORDER BY md5(case_id) LIMIT 10000
)
UPDATE service_requests r
SET status = 'closed', closed_at = r.opened_at + interval '2 days', closure_reason = 'Resolved'
FROM closing c WHERE r.case_id = c.case_id;
INSERT INTO service_requests (case_id, opened_at, sla_target_at, closed_at, status, on_time,
    closure_reason, title, type_id, queue_id, source, neighborhood, ward, council_district,
    pwd_district, zipcode, address, latitude, longitude)
SELECT lpad((900000000000 + row_number() OVER (ORDER BY case_id))::text, 12, '0'),
    opened_at + interval '730 days', sla_target_at + interval '730 days', NULL, 'open', on_time,
    NULL, title, type_id, queue_id, source, neighborhood, ward, council_district,
    pwd_district, zipcode, address, latitude, longitude
FROM (SELECT * FROM service_requests ORDER BY md5(case_id) LIMIT 10000) s;
"""


def create(conn, name: str) -> tuple[str, float]:
    index = f"cand_{name}"
    started = time.perf_counter()
    conn.execute(f"CREATE INDEX {index} ON {T} {CANDIDATES[name][0]}")
    seconds = time.perf_counter() - started
    conn.execute(f"ANALYZE {T}")
    return index, seconds


def size_mb(conn, index: str) -> float:
    n = conn.execute("SELECT pg_relation_size(%s::regclass)", (index,)).fetchone()[0]
    return round(n / 1e6, 2)


def measure(conn, builders, names: list[str], runs: int) -> dict:
    out = {}
    for q in names:
        sql, params = builders[q]()
        explain(conn, sql, params)  # warm the cache
        times, lines = [], []
        for _ in range(runs):
            lines, ms = explain(conn, sql, params)
            times.append(ms)
        out[q] = {
            "median_ms": round(statistics.median(times), 3),
            "first_lines": [ln for ln in lines if "Scan" in ln or "Sort" in ln][:4],
            "buffers": next((ln.strip() for ln in lines if "Buffers" in ln), ""),
        }
    return out


def refresh_seconds(conn, runs: int = 3) -> float:
    times = []
    for _ in range(runs):
        with conn.transaction(force_rollback=True):
            started = time.perf_counter()
            conn.execute(REFRESH)
            times.append(time.perf_counter() - started)
    return round(statistics.median(times), 3)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--only", nargs="*", help="candidate names (default: all)")
    parser.add_argument("--runs", type=int, default=5)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args(argv)
    result = {"candidates": {}, "write_cost": {}}
    with psycopg.connect(database_url(), row_factory=tuple_row, autocommit=True) as conn:
        extra = conn.execute(
            "SELECT indexname FROM pg_indexes WHERE tablename = %s AND indexname <> %s",
            (T, f"{T}_pkey"),
        ).fetchall()
        if extra:
            print(f"Drop these indexes first (the table must have only its key): {extra}")
            return 1
        conn.execute(f"VACUUM ANALYZE {T}")
        builders = plans(conn)
        for name in args.only or list(CANDIDATES):
            definition, queries = CANDIDATES[name]
            index, build_s, mb = None, 0.0, 0.0
            if definition:
                index, build_s = create(conn, name)
                mb = size_mb(conn, index)
            r = {"definition": definition, "size_mb": mb, "build_s": round(build_s, 2),
                 "queries": measure(conn, builders, queries, args.runs)}  # fmt: skip
            if index:
                conn.execute(f"DROP INDEX {index}")
            result["candidates"][name] = r
            times = ", ".join(f"{q} {v['median_ms']} ms" for q, v in r["queries"].items())
            print(f"{name:<16} {mb:>6} MB  {times}")
        # The write cost of the nightly refresh, with three sets of indexes.
        sets = {"keys only": [], "chosen (3)": CHOSEN,
                "every candidate (10)": [n for n in CANDIDATES if n != "none"]}  # fmt: skip
        for label, names in sets.items():
            made = [create(conn, n)[0] for n in names]
            total = sum(size_mb(conn, i) for i in made)
            seconds = refresh_seconds(conn)
            for i in made:
                conn.execute(f"DROP INDEX {i}")
            result["write_cost"][label] = {"refresh_s": seconds, "indexes_mb": round(total, 1)}
            print(f"refresh with {label}: {seconds} s ({total:.1f} MB of extra indexes)")
        result["table_mb"] = round(
            conn.execute("SELECT pg_relation_size(%s)", (T,)).fetchone()[0] / 1e6, 1
        )
    if args.json:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(json.dumps(result, indent=2) + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
