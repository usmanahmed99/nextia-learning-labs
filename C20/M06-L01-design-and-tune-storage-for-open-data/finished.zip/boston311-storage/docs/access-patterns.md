# Access-pattern inventory: Boston 311 requests

Written before the schema and the indexes, and checked against the data. Volumes are from the
loaded 2024–2025 files (582,849 requests). The people are invented; the patterns are the usual
uses of a city's 311 data.

## The data

| Data | How it is read | How often it changes | How much | How fresh and exact |
|---|---|---|---|---|
| Service requests | by case ID; open ones per queue, oldest first; per neighborhood, newest first; open ones at one address and type; counts per department and month | about 800 new a day; a request changes when it is closed or reopened | 582,849 rows, about 190 MB; 120,140 open | the queue and the duplicate check at once; reports can be a day old |
| Case types (type, reason, subject) | joined to requests by ID; listed in menus | a few new ones a year | 175 types | exact: a type always has one reason and one subject (checked) |
| Queues (queue, department) | joined to requests; the department for reports | a few changes a year | 172 queues | exact: a queue always has one department (checked) |

## The query patterns

| | Pattern | Who | Shape | How often | Rows |
|---|---|---|---|---|---|
| P1 | One request by its ID | a resident on the phone, a clerk | `case_id = ?` | all day | 1 |
| P2 | Work queue: open requests of one queue, oldest first, pages of 50 | crews and supervisors | `status = 'open' AND queue_id = ? ORDER BY opened_at, case_id` | all day, many times | 50 of up to 61,333 |
| P3 | Area feed: requests of one neighborhood, newest first, pages of 50 | the public map, analysts | `neighborhood = ? ORDER BY opened_at DESC, case_id DESC` | often; analysts page deep | 50 of up to 77,047 |
| P4 | Duplicate check: open requests of the same type at the same address in the last 30 days | the system, before a new request is saved | `address = ? AND type_id = ? AND status = 'open' AND opened_at >= ?` | about 800 times a day, one per new request | 0 to a few |
| P5 | Overdue dashboard: open requests past their target, per department | managers | aggregate over open requests | every few minutes | 11 |
| P6 | Monthly report: requests and on-time share per department and month | managers, the public | aggregate over a year | once a month | about 150 |

Writes: about 800 new requests a day, and the nightly refresh from the city's file (closings,
reopenings, new requests). Correctness rules: a closed request has a closing time; IDs are unique
and in the format of their system; times are stored with a time zone.

## What the patterns ask of the design

- P1: the primary key. Nothing else.
- P2, P3, P4: an index each, fitted to the equal columns and then the order (measured in
  `scripts.candidates`); keyset pages for P2 and P3 (`boston311.queries`).
- P5, P6: read most of the table; no index helps much (measured). Run them on a schedule, or on a
  replica, if they become slow.
