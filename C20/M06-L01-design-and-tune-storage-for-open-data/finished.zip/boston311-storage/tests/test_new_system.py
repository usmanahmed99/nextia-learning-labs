"""Requests from the new 311 system: mapped, and loaded twice without being counted twice."""

from pathlib import Path

from scripts.load_new import load_new_file

FILE = Path(__file__).parent / "fixtures" / "new_system_sample.csv"


def test_new_system_rows_load_once(conn):
    staged, new = load_new_file(conn, FILE)
    assert staged == new == 22
    staged, new = load_new_file(conn, FILE)
    assert (staged, new) == (22, 0)


def test_statuses_are_mapped(conn):
    load_new_file(conn, FILE)
    rows = conn.execute(
        "SELECT status, count(*) AS n, bool_and(closed_at IS NOT NULL) AS closed_at"
        " FROM service_requests WHERE source_system = 'bcs' GROUP BY 1 ORDER BY 1"
    ).fetchall()
    by = {r["status"]: r for r in rows}
    assert set(by) == {"closed", "open"}
    assert by["closed"]["closed_at"] is True
