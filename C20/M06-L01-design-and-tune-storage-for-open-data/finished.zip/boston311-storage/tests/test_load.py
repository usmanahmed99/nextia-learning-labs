"""The load keeps every row and applies the cleaning rules."""


def test_every_row_is_loaded(conn):
    n = conn.execute("SELECT count(*) AS n FROM service_requests").fetchone()["n"]
    assert n == 304


def test_ward_and_district_zero_become_null(conn):
    row = conn.execute(
        "SELECT count(*) FILTER (WHERE ward = 0) AS ward0,"
        " count(*) FILTER (WHERE council_district = 0) AS cd0,"
        " count(*) FILTER (WHERE ward BETWEEN 1 AND 22) AS wards"
        " FROM service_requests"
    ).fetchone()
    assert row["ward0"] == 0 and row["cd0"] == 0 and row["wards"] > 250


def test_html_escape_is_fixed(conn):
    n = conn.execute(
        "SELECT count(*) AS n FROM service_requests WHERE address LIKE '%&amp;%'"
    ).fetchone()["n"]
    assert n == 0


def test_times_are_boston_local_time(conn):
    # 101005236041 opened at 10:43:17.097 in Boston (EST, UTC-5) on 4 January 2024.
    row = conn.execute(
        "SELECT opened_at AT TIME ZONE 'UTC' AS utc FROM service_requests"
        " WHERE case_id = '101005236041'"
    ).fetchone()
    if row:  # the sample has it only if the fixture picked it
        assert str(row["utc"]) == "2024-01-04 15:43:17.097000"


def test_requests_that_break_the_dropped_rule_are_kept(conn):
    # Open requests with a closure reason (reopened), and closed ones without a reason.
    row = conn.execute(
        "SELECT count(*) FILTER (WHERE status = 'open' AND closure_reason IS NOT NULL) AS a,"
        " count(*) FILTER (WHERE status = 'closed' AND closure_reason IS NULL) AS b"
        " FROM service_requests"
    ).fetchone()
    assert row["a"] >= 2 and row["b"] >= 2
