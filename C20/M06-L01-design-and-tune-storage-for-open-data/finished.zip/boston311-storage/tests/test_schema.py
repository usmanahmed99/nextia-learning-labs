"""The database rejects rows that break the rules (each test is rolled back)."""

import psycopg
import pytest

GOOD = {
    "case_id": "101099999999",
    "opened_at": "2025-06-01 09:00:00-04",
    "status": "open",
    "closed_at": None,
    "on_time": "ontime",
    "ward": 5,
}


def insert(conn, **changes):
    row = {**GOOD, **changes}
    conn.execute(
        "INSERT INTO service_requests (case_id, opened_at, status, closed_at, on_time, ward,"
        " type_id, queue_id, source)"
        " VALUES (%(case_id)s, %(opened_at)s, %(status)s, %(closed_at)s, %(on_time)s,"
        " %(ward)s, (SELECT min(type_id) FROM case_types), (SELECT min(queue_id) FROM queues),"
        " 'Constituent Call')",
        row,
    )


def rejected(conn, error, **changes):
    with pytest.raises(error):
        with conn.transaction():
            insert(conn, **changes)


def test_a_good_row_is_accepted(conn):
    insert(conn)


def test_duplicate_case_id(conn):
    insert(conn)
    rejected(conn, psycopg.errors.UniqueViolation)


@pytest.mark.parametrize(
    "changes, constraint",
    [
        ({"status": "closed"}, "requests_closed_at_matches_status"),
        ({"closed_at": "2025-06-02 09:00:00-04"}, "requests_closed_at_matches_status"),
        ({"status": "closed", "closed_at": "2025-05-01 09:00:00-04"},
         "requests_closed_after_opened"),
        ({"status": "In progress"}, "requests_status_known"),
        ({"ward": 0}, "requests_ward_range"),
        ({"case_id": "BCS-00253943"}, "requests_case_id_format"),
    ],
)  # fmt: skip
def test_check_constraints(conn, changes, constraint):
    with pytest.raises(psycopg.errors.CheckViolation) as error:
        with conn.transaction():
            insert(conn, **changes)
    assert error.value.diag.constraint_name == constraint


def test_unknown_type_is_rejected(conn):
    with pytest.raises(psycopg.errors.ForeignKeyViolation):
        conn.execute(
            "INSERT INTO service_requests (case_id, opened_at, status, on_time, type_id,"
            " queue_id, source) VALUES ('101099999998', now(), 'open', 'ontime', 9999,"
            " (SELECT min(queue_id) FROM queues), 'x')"
        )


def test_the_workload_indexes_exist_and_are_valid(conn):
    rows = conn.execute(
        "SELECT c.relname, i.indisvalid FROM pg_index i JOIN pg_class c ON c.oid = i.indexrelid"
        " WHERE i.indrelid = 'service_requests'::regclass ORDER BY 1"
    ).fetchall()
    names = {r["relname"]: r["indisvalid"] for r in rows}
    for name in ("requests_open_queue_idx", "requests_area_idx", "requests_open_address_idx"):
        assert names.get(name) is True
