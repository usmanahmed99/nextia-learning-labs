"""The queries: parameters only, and keyset pages that never skip or repeat a row."""

from datetime import datetime

import pytest

from boston311 import queries


def walk(fetch, **kwargs) -> list[str]:
    ids, after = [], None
    while True:
        page = fetch(after=after, **kwargs)
        ids += [r["case_id"] for r in page["rows"]]
        after = page["next"]
        if after is None:
            return ids


def test_area_feed_pages_cover_every_request_once(conn):
    expected = [
        r["case_id"]
        for r in conn.execute(
            "SELECT case_id FROM service_requests WHERE neighborhood = 'Chestnut Hill'"
            " ORDER BY opened_at DESC, case_id DESC"
        )
    ]
    assert len(expected) >= 20
    got = walk(lambda **k: queries.area_feed(conn, "Chestnut Hill", limit=7, **k))
    assert got == expected


def test_open_queue_pages_cover_every_open_request_once(conn):
    queue = conn.execute(
        "SELECT q.name FROM service_requests r JOIN queues q USING (queue_id)"
        " WHERE r.status = 'open' GROUP BY 1 ORDER BY count(*) DESC LIMIT 1"
    ).fetchone()["name"]
    got = walk(lambda **k: queries.open_queue(conn, queue, limit=5, **k))
    assert len(got) == len(set(got)) > 5


def test_a_new_request_while_paging_does_not_shift_the_pages(conn):
    first = queries.area_feed(conn, "Chestnut Hill", limit=5)
    conn.execute(
        "INSERT INTO service_requests (case_id, opened_at, status, on_time, type_id, queue_id,"
        " source, neighborhood) SELECT '101099999999', now(), 'open', 'ontime', type_id,"
        " queue_id, source, neighborhood FROM service_requests"
        " WHERE neighborhood = 'Chestnut Hill' LIMIT 1"
    )
    second = queries.area_feed(conn, "Chestnut Hill", limit=5, after=first["next"])
    seen = {r["case_id"] for r in first["rows"]}
    assert not seen & {r["case_id"] for r in second["rows"]}


def test_a_value_never_becomes_sql(conn):
    page = queries.area_feed(conn, "x' OR '1'='1")
    assert page["rows"] == []


def test_an_invalid_cursor_is_refused(conn):
    with pytest.raises(queries.InvalidCursor):
        queries.area_feed(conn, "Chestnut Hill", after="not-a-cursor")


def test_get_request_and_duplicates(conn):
    row = conn.execute(
        "SELECT r.case_id, r.address, t.name, r.opened_at FROM service_requests r"
        " JOIN case_types t USING (type_id) WHERE r.status = 'open' AND r.address IS NOT NULL"
        " ORDER BY r.case_id LIMIT 1"
    ).fetchone()
    assert queries.get_request(conn, row["case_id"])["case_id"] == row["case_id"]
    found = queries.possible_duplicates(conn, row["address"], row["name"], row["opened_at"])
    assert row["case_id"] in [r["case_id"] for r in found]
    assert queries.get_request(conn, "000000000000") is None


def test_reports_run(conn):
    assert queries.overdue_by_department(conn, datetime.fromisoformat("2026-01-01T00:00:00+00:00"))
    assert queries.on_time_by_month(conn, 2025)
