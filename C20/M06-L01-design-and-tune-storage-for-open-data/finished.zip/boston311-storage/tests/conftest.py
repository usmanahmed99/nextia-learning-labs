"""A test database with the migrations and a small sample of the real data.

TEST_DATABASE_URL (in .env) must end in _test: the tests drop and make it again.
Without a database server, the tests are skipped.
"""

import os
from pathlib import Path

import psycopg
import pytest
from psycopg.rows import dict_row

from boston311 import migrate
from boston311.config import load_env
from scripts.load import load_files

FIXTURES = Path(__file__).parent / "fixtures"


@pytest.fixture(scope="session")
def db_url():
    load_env()
    url = os.environ.get("TEST_DATABASE_URL")
    if not url:
        pytest.skip("TEST_DATABASE_URL is not set")
    name = url.rsplit("/", 1)[1]
    if not name.endswith("_test"):
        pytest.exit("TEST_DATABASE_URL must end in _test: the tests drop that database.")
    admin = url.rsplit("/", 1)[0] + "/postgres"
    try:
        with psycopg.connect(admin, autocommit=True, connect_timeout=3) as conn:
            conn.execute(f"DROP DATABASE IF EXISTS {name} WITH (FORCE)")
            conn.execute(f"CREATE DATABASE {name}")
    except psycopg.OperationalError:
        pytest.skip("no database server")
    assert migrate.main([], url=url, quiet=True) == 0
    with psycopg.connect(url) as conn:
        load_files(conn, [FIXTURES / "requests_sample.csv"], quiet=True)
    return url


@pytest.fixture
def conn(db_url):
    """A connection whose changes are rolled back at the end of the test."""
    with psycopg.connect(db_url, row_factory=dict_row) as conn:
        with conn.transaction(force_rollback=True):
            yield conn
