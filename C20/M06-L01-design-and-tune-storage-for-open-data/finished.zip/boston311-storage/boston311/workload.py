"""The fixed workload: the same queries with the same values, in the same order, every time.

The values come from the data itself, chosen by fixed rules (no random numbers), so
anyone with the same files gets the same workload. One call is (query function, values).
"""

from datetime import UTC, datetime, timedelta

import psycopg
from psycopg.rows import tuple_row

from boston311 import queries

# The data ends on 31 December 2025; the dashboard runs "on" 1 January 2026.
NOW = datetime(2026, 1, 1, 5, 0, tzinfo=UTC)
DEEP = 5_000  # rows before the deep page of P3


def build(conn: psycopg.Connection) -> dict[str, list[tuple]]:
    """The calls of each access pattern. md5(case_id) gives a fixed, well-mixed order."""
    conn = conn.cursor(row_factory=tuple_row)  # rows as tuples here
    cases = [
        r[0]
        for r in conn.execute("SELECT case_id FROM service_requests ORDER BY md5(case_id) LIMIT 50")
    ]
    busy_queues = [
        r[0]
        for r in conn.execute(
            "SELECT q.name FROM service_requests r JOIN queues q USING (queue_id)"
            " WHERE r.status = 'open' GROUP BY q.name ORDER BY count(*) DESC, q.name LIMIT 20"
        )
    ]
    areas = [
        r[0]
        for r in conn.execute(
            "SELECT neighborhood FROM service_requests WHERE neighborhood IS NOT NULL"
            " GROUP BY 1 HAVING count(*) > %s ORDER BY count(*) DESC",
            (DEEP + 50,),
        )
    ]
    dupes = conn.execute(
        "SELECT r.address, t.name, r.opened_at FROM service_requests r"
        " JOIN case_types t USING (type_id)"
        " WHERE r.status = 'open' AND r.address IS NOT NULL ORDER BY md5(r.case_id) LIMIT 50"
    ).fetchall()
    deep_cursors = []
    for area in areas[:5]:
        row = conn.execute(
            "SELECT opened_at, case_id FROM service_requests WHERE neighborhood = %s"
            " ORDER BY opened_at DESC, case_id DESC OFFSET %s LIMIT 1",
            (area, DEEP - 1),
        ).fetchone()
        deep_cursors.append((area, queries.encode_cursor(row[0], row[1])))
    return {
        "P1 one request": [(queries.get_request, {"case_id": c}) for c in cases],
        "P2 work queue": [(queries.open_queue, {"queue": q}) for q in busy_queues],
        "P3 area feed": [(queries.area_feed, {"neighborhood": a}) for a in areas],
        "P3 deep page, OFFSET": [
            (queries.area_feed_offset, {"neighborhood": a, "offset": DEEP}) for a in areas[:5]
        ],
        "P3 deep page, keyset": [
            (queries.area_feed, {"neighborhood": a, "after": c}) for a, c in deep_cursors
        ],
        "P4 duplicates": [
            (
                queries.possible_duplicates,
                {"address": a, "type_name": t, "since": o + timedelta(days=1) - timedelta(days=30)},
            )
            for a, t, o in dupes
        ],
        "P5 overdue": [(queries.overdue_by_department, {"now": NOW})],
        "P6 monthly report": [(queries.on_time_by_month, {"year": 2025})],
    }
