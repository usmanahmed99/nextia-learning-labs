"""Copy the city's CSV files, as they are, into a staging table of text columns.

Every column is text, so COPY never fails on a value: the rules are checked
afterwards, in SQL, where each broken rule can be counted and shown. The table is
UNLOGGED (faster to fill; PostgreSQL empties it after a crash, which is fine for a copy
that can be made again from the files).
"""

import time
from pathlib import Path

import psycopg

from boston311.config import ROOT

RAW = ROOT / "data" / "raw"
FILES = [RAW / "boston_311_2024.csv", RAW / "boston_311_2025.csv"]

RAW_COLUMNS = [
    "case_enquiry_id", "open_dt", "sla_target_dt", "closed_dt", "on_time", "case_status",
    "closure_reason", "case_title", "subject", "reason", "type", "queue", "department",
    "submitted_photo", "closed_photo", "location", "fire_district", "pwd_district",
    "city_council_district", "police_district", "neighborhood", "neighborhood_services_district",
    "ward", "precinct", "location_street_name", "location_zipcode", "latitude", "longitude",
    "geom_4326", "source",
]  # fmt: skip


def stage(conn: psycopg.Connection, files: list[Path], quiet: bool = False) -> int:
    """Fill staging_requests from the files (it is emptied first). Returns the row count."""
    columns = ", ".join(f"{c} text" for c in RAW_COLUMNS)
    conn.execute(f"CREATE UNLOGGED TABLE IF NOT EXISTS staging_requests ({columns})")
    conn.execute("TRUNCATE staging_requests")
    for path in files:
        header = path.open(encoding="utf-8").readline().strip().split(",")
        if header != RAW_COLUMNS:
            raise SystemExit(f"{path.name}: the columns are not the ones this project expects.")
        started = time.perf_counter()
        with conn.cursor() as cur:
            with cur.copy(
                "COPY staging_requests FROM STDIN WITH (FORMAT csv, HEADER true)"
            ) as copy:
                with open(path, "rb") as f:
                    while block := f.read(1 << 20):
                        copy.write(block)
            if not quiet:
                print(
                    f"Copied {path.name}: {cur.rowcount:,} rows in"
                    f" {time.perf_counter() - started:.1f} s"
                )
    conn.execute("ANALYZE staging_requests")
    return conn.execute("SELECT count(*) FROM staging_requests").fetchone()[0]
