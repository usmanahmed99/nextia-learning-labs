"""Every query of the access-pattern inventory (docs/access-patterns.md), in one place.

The rules of the databases course:
- Values go to the database as parameters (%(name)s), never inside the SQL text.
- Lists come in pages: keyset pagination with a cursor, never OFFSET (area_feed_offset
  is kept only to measure the difference).
- Each query names its columns.
- A function gets a connection; the caller decides the transaction. Each *_sql function
  returns the SQL text and its parameters, so scripts.explain can show the same query.
"""

import base64
from datetime import datetime

import psycopg

LIST_COLUMNS = "r.case_id, r.opened_at, r.status, r.title, r.neighborhood, r.address"


class InvalidCursor(ValueError):
    """The `after` value is not one that this module made."""


def encode_cursor(opened_at: datetime, case_id: str) -> str:
    raw = f"{opened_at.isoformat()}|{case_id}".encode()
    return base64.urlsafe_b64encode(raw).decode().rstrip("=")


def decode_cursor(cursor: str) -> tuple[datetime, str]:
    try:
        raw = base64.urlsafe_b64decode(cursor + "=" * (-len(cursor) % 4)).decode()
        opened, case_id = raw.split("|")
        return datetime.fromisoformat(opened), case_id
    except ValueError as error:  # also binascii.Error and UnicodeDecodeError
        raise InvalidCursor(cursor) from error


def page(rows: list[dict], limit: int) -> dict:
    """A page and the cursor of the next one. One extra row tells whether there is more."""
    more = len(rows) > limit
    rows = rows[:limit]
    last = rows[-1] if rows else None
    return {
        "rows": rows,
        "next": encode_cursor(last["opened_at"], last["case_id"]) if more else None,
    }


# P1. One request by its ID: a resident asks "what happened to my request?"
def get_request(conn: psycopg.Connection, case_id: str) -> dict | None:
    return conn.execute(*get_request_sql(case_id)).fetchone()


def get_request_sql(case_id: str) -> tuple[str, dict]:
    return (
        """
        SELECT r.case_id, r.opened_at, r.sla_target_at, r.closed_at, r.status, r.on_time,
               r.closure_reason, r.title, t.name AS type, q.name AS queue, q.department,
               r.neighborhood, r.address
        FROM service_requests r
        JOIN case_types t USING (type_id)
        JOIN queues q USING (queue_id)
        WHERE r.case_id = %(case_id)s
        """,
        {"case_id": case_id},
    )


# P2. A crew's work queue: the open requests of one queue, oldest first.
def open_queue(
    conn: psycopg.Connection, queue: str, *, limit: int = 50, after: str | None = None
) -> dict:
    return page(conn.execute(*open_queue_sql(queue, limit=limit, after=after)).fetchall(), limit)


def open_queue_sql(queue: str, *, limit: int = 50, after: str | None = None) -> tuple[str, dict]:
    params = {"queue": queue, "limit": limit + 1}
    keyset = ""
    if after:
        params["after_at"], params["after_id"] = decode_cursor(after)
        keyset = "AND (r.opened_at, r.case_id) > (%(after_at)s, %(after_id)s)"
    return (
        f"""
        SELECT {LIST_COLUMNS}
        FROM service_requests r
        WHERE r.status = 'open'
          AND r.queue_id = (SELECT queue_id FROM queues WHERE name = %(queue)s)
          {keyset}
        ORDER BY r.opened_at, r.case_id
        LIMIT %(limit)s
        """,
        params,
    )


# P3. The requests of one neighborhood, newest first (a public map, an analyst's list).
def area_feed(
    conn: psycopg.Connection, neighborhood: str, *, limit: int = 50, after: str | None = None
) -> dict:
    sql, params = area_feed_sql(neighborhood, limit=limit, after=after)
    return page(conn.execute(sql, params).fetchall(), limit)


def area_feed_sql(
    neighborhood: str, *, limit: int = 50, after: str | None = None
) -> tuple[str, dict]:
    params = {"neighborhood": neighborhood, "limit": limit + 1}
    keyset = ""
    if after:
        params["after_at"], params["after_id"] = decode_cursor(after)
        keyset = "AND (r.opened_at, r.case_id) < (%(after_at)s, %(after_id)s)"
    return (
        f"""
        SELECT {LIST_COLUMNS}
        FROM service_requests r
        WHERE r.neighborhood = %(neighborhood)s
          {keyset}
        ORDER BY r.opened_at DESC, r.case_id DESC
        LIMIT %(limit)s
        """,
        params,
    )


def area_feed_offset(
    conn: psycopg.Connection, neighborhood: str, *, limit: int = 50, offset: int = 0
) -> list[dict]:
    """P3 with OFFSET: kept only to measure it against the keyset."""
    return conn.execute(*area_feed_offset_sql(neighborhood, limit=limit, offset=offset)).fetchall()


def area_feed_offset_sql(
    neighborhood: str, *, limit: int = 50, offset: int = 0
) -> tuple[str, dict]:
    return (
        f"""
        SELECT {LIST_COLUMNS}
        FROM service_requests r
        WHERE r.neighborhood = %(neighborhood)s
        ORDER BY r.opened_at DESC, r.case_id DESC
        LIMIT %(limit)s OFFSET %(offset)s
        """,
        {"neighborhood": neighborhood, "limit": limit, "offset": offset},
    )


# P4. Before a new request is saved: is the same problem already open at that address?
def possible_duplicates(
    conn: psycopg.Connection, address: str, type_name: str, since: datetime
) -> list[dict]:
    return conn.execute(*possible_duplicates_sql(address, type_name, since)).fetchall()


def possible_duplicates_sql(address: str, type_name: str, since: datetime) -> tuple[str, dict]:
    return (
        f"""
        SELECT {LIST_COLUMNS}
        FROM service_requests r
        WHERE r.address = %(address)s
          AND r.type_id = (SELECT type_id FROM case_types WHERE name = %(type)s)
          AND r.status = 'open'
          AND r.opened_at >= %(since)s
        ORDER BY r.opened_at DESC
        LIMIT 10
        """,
        {"address": address, "type": type_name, "since": since},
    )


# P5. The dashboard: open requests past their target time, per department.
def overdue_by_department(conn: psycopg.Connection, now: datetime) -> list[dict]:
    return conn.execute(*overdue_by_department_sql(now)).fetchall()


def overdue_by_department_sql(now: datetime) -> tuple[str, dict]:
    return (
        """
        SELECT q.department, count(*) AS overdue
        FROM service_requests r
        JOIN queues q USING (queue_id)
        WHERE r.status = 'open' AND r.sla_target_at < %(now)s
        GROUP BY q.department
        ORDER BY overdue DESC
        """,
        {"now": now},
    )


# P6. The monthly report: requests closed on time, per department and month.
def on_time_by_month(conn: psycopg.Connection, year: int) -> list[dict]:
    return conn.execute(*on_time_by_month_sql(year)).fetchall()


def on_time_by_month_sql(year: int) -> tuple[str, dict]:
    return (
        """
        SELECT q.department,
               date_trunc('month', r.opened_at AT TIME ZONE 'America/New_York')::date AS month,
               count(*) AS opened,
               round(avg((r.on_time = 'ontime')::int) * 100, 1) AS on_time_pct
        FROM service_requests r
        JOIN queues q USING (queue_id)
        WHERE r.opened_at >= make_timestamptz(%(year)s, 1, 1, 0, 0, 0, 'America/New_York')
          AND r.opened_at < make_timestamptz(%(year)s + 1, 1, 1, 0, 0, 0, 'America/New_York')
        GROUP BY 1, 2
        ORDER BY 1, 2
        """,
        {"year": year},
    )
