"""A connection pool: open connections once, borrow one per unit of work.

    pool = make_pool(url, size=4)
    with pool.connection() as conn:     # borrowed; it goes back at the end
        rows = queries.open_queue(conn, "PWDx_Sidewalk Repair")

A block that ends with an error rolls back, and the connection still goes back.
"""

from psycopg.rows import dict_row
from psycopg_pool import ConnectionPool


def make_pool(url: str, size: int = 4, timeout: float = 10.0) -> ConnectionPool:
    pool = ConnectionPool(
        url,
        min_size=size,
        max_size=size,
        timeout=timeout,
        kwargs={"row_factory": dict_row, "connect_timeout": 3},
        open=False,
        name="boston311",
    )
    pool.open(wait=True)
    return pool
