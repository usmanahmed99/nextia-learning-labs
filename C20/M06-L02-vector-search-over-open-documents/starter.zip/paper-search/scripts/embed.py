"""Make the vectors of one embedding version, on the CPU, in batches that can be resumed.

    python -m scripts.embed                         the current version
    python -m scripts.embed --version bge-small-v1  another version (it need not be current)
    python -m scripts.embed --limit 2000            only the first 2,000 papers that need a vector

A paper needs a vector when it has none of this version, or when its abstract changed since the
vector was made (the stored source_sha256 differs: a stale vector). Each batch is committed on its
own, so an interrupted run loses at most one batch, and the next run continues where it stopped.
"""

import argparse
import sys
import time

from paper_search import versions
from paper_search.db import connect
from paper_search.embedding import encode, load_model, sha256, to_sql

TODO = """
SELECT p.arxiv_id, p.abstract
FROM papers p
LEFT JOIN paper_embeddings e ON e.arxiv_id = p.arxiv_id AND e.embedding_version = %(v)s
WHERE e.arxiv_id IS NULL OR e.source_sha256 <> encode(sha256(convert_to(p.abstract, 'UTF8')), 'hex')
ORDER BY p.arxiv_id
"""
UPSERT = """
INSERT INTO paper_embeddings (arxiv_id, embedding_version, source_sha256, embedding)
VALUES (%s, %s, %s, %s::vector)
ON CONFLICT (arxiv_id, embedding_version)
DO UPDATE SET source_sha256 = EXCLUDED.source_sha256, embedding = EXCLUDED.embedding
"""


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--version", help="default: the current version")
    parser.add_argument("--batch", type=int, default=500, help="papers per committed batch")
    parser.add_argument("--limit", type=int)
    args = parser.parse_args()
    with connect() as conn:
        v = versions.get(conn, args.version)
        todo = conn.execute(TODO, {"v": v.version}).fetchall()
        if args.limit:
            todo = todo[: args.limit]
        if not todo:
            print(f"Every paper has an up-to-date vector of {v.version}.")
            return 0
        print(f"{len(todo):,} papers need a vector of {v.version} ({v.model}).")
        start = time.perf_counter()
        model = load_model(v)
        loaded = time.perf_counter()
        for i in range(0, len(todo), args.batch):
            batch = todo[i : i + args.batch]
            vectors = encode(model, [abstract for _, abstract in batch], v.document_prefix)
            with conn.cursor() as cur:
                cur.executemany(UPSERT, [(pid, v.version, sha256(abstract), to_sql(vec))
                                         for (pid, abstract), vec in zip(batch, vectors)])
            conn.commit()
            done = i + len(batch)
            print(f"  {done:>6,} of {len(todo):,}  ({time.perf_counter() - loaded:.0f} s)", flush=True)
        took = time.perf_counter() - loaded
        print(f"Embedded {len(todo):,} papers with {v.model} in {took:.0f} s "
              f"({len(todo) / took:.0f} per second; loading the model took {loaded - start:.1f} s).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
