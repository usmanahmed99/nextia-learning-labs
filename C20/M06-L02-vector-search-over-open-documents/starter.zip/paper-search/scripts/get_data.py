"""Download the fixed sample of arXiv records and check its SHA-256.

    python -m scripts.get_data              the papers and the April papers, from the course's labs repository
    python -m scripts.get_data --from DIR   copy them from a folder instead (offline)

The records are arXiv's metadata, under CC0 1.0 (see DATASET.md). The files are kept in data/.
"""

import argparse
import hashlib
import shutil
import sys
import urllib.request
from pathlib import Path

BASE = ("https://github.com/usmanahmed99/nextia-learning-labs/raw/main/"
        "C20/M06-L02-vector-search-over-open-documents/data/")
FILES = {
    "arxiv-cs-2024-papers.jsonl.gz": "fb138597e9beaf56d6a2176652f6e6303d9c5b8169409e07a236bef607c06006",
    "arxiv-cs-2024-04-new.jsonl.gz": "1b924ae04f2754a4863445e341a56c8068b413d47df9b4dac002ed4108fbd47f",
}
DATA = Path(__file__).resolve().parent.parent / "data"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--from", dest="source", help="a folder that has the two files")
    args = parser.parse_args()
    DATA.mkdir(exist_ok=True)
    for name, expected in FILES.items():
        target = DATA / name
        if not (target.exists() and sha256(target) == expected):
            if args.source:
                print(f"Copying {name} from {args.source}")
                shutil.copyfile(Path(args.source) / name, target)
            else:
                print(f"Downloading {BASE}{name}")
                with urllib.request.urlopen(BASE + name, timeout=120) as resp, open(target, "wb") as out:
                    shutil.copyfileobj(resp, out)
        actual = sha256(target)
        if actual != expected:
            target.unlink()
            print(f"{name}: the SHA-256 is {actual[:12]}..., expected {expected[:12]}.... "
                  "The file was deleted. Download it again.", file=sys.stderr)
            return 1
        print(f"Checked {name}: SHA-256 {actual[:12]}... is correct ({target.stat().st_size / 1e6:.1f} MB)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
