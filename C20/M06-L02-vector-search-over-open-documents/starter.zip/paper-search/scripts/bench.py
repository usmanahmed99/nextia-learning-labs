"""Exact search against the HNSW index: recall@10 and time, on the same queries.

    python -m scripts.bench                         the current version, no filter, an ef_search sweep
    python -m scripts.bench --category cs.DB        with a metadata filter: the iterative scan off and on
    python -m scripts.bench --json FILE             also write the results

The queries are "papers like this one": 200 papers chosen with a fixed seed, each searched with its
own stored vector. The paper itself is left out of its results. The exact search (no index) gives
the true ten nearest; recall@10 is the share of them that the index search returned. Times are the
median over all searches of 5 passes, after one pass to warm up. Your times will differ.
"""

import argparse
import json
import random
import statistics
import sys
import time

from paper_search import versions
from paper_search.db import connect
from paper_search.search import search

K = 10


def run(conn, queries, version, passes, **opts):
    """Results of the first pass, and the median time per search over all passes."""
    times, results = [], None
    for p in range(passes + 1):
        found = []
        for pid, vec in queries:
            t = time.perf_counter()
            hits = search(conn, vec, version, k=K, exclude=pid, **opts)
            if p > 0:
                times.append((time.perf_counter() - t) * 1000)
            found.append([h.arxiv_id for h in hits])
        results = results or found
    return results, round(statistics.median(times), 3)


def compare(truth, found):
    recall = statistics.mean(len(set(t) & set(f)) / len(t) for t, f in zip(truth, found) if t)
    short = sum(1 for f in found if len(f) < K)
    return round(recall, 3), short


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--version", help="default: the current version")
    parser.add_argument("--category", help="a primary category to filter on, for example cs.DB")
    parser.add_argument("--queries", type=int, default=200)
    parser.add_argument("--passes", type=int, default=5)
    parser.add_argument("--seed", type=int, default=11)
    parser.add_argument("--json")
    args = parser.parse_args()
    with connect() as conn:
        v = versions.get(conn, args.version)
        ids = [r[0] for r in conn.execute(
            "SELECT arxiv_id FROM paper_embeddings WHERE embedding_version = %s ORDER BY arxiv_id", (v.version,))]
        chosen = sorted(random.Random(args.seed).sample(ids, args.queries))
        queries = conn.execute(
            "SELECT arxiv_id, embedding::text FROM paper_embeddings WHERE embedding_version = %s "
            "AND arxiv_id = ANY(%s) ORDER BY arxiv_id", (v.version, chosen)).fetchall()
        stats = conn.execute(
            "SELECT count(*), (SELECT count(*) FROM papers WHERE primary_category = %s) FROM paper_embeddings "
            "WHERE embedding_version = %s", (args.category, v.version)).fetchone()
        opts = {"category": args.category}
        truth, exact_ms = run(conn, queries, v.version, args.passes, exact=True, **opts)
        rows = [{"search": "exact (no index)", "recall_at_10": 1.0, "short": compare(truth, truth)[1], "ms": exact_ms}]
        if args.category:
            settings = [("index, iterative scan off", 40, "off"), ("index, strict_order", 40, "strict_order"),
                        ("index, relaxed_order", 40, "relaxed_order")]
        else:
            settings = [(f"index, ef_search {ef}", ef, "off") for ef in (20, 40, 80, 160, 320)]
        for name, ef, iterative in settings:
            found, ms = run(conn, queries, v.version, args.passes, ef_search=ef, iterative=iterative, **opts)
            recall, short = compare(truth, found)
            rows.append({"search": name, "ef_search": ef, "iterative_scan": iterative,
                         "recall_at_10": recall, "short": short, "ms": ms})
    where = f", filter primary_category = '{args.category}' ({stats[1]:,} papers)" if args.category else ""
    print(f"{v.version}: {stats[0]:,} vectors, {len(queries)} queries, k = {K}{where}")
    print(f"{'search':<28} recall@10  short  ms/search")
    for r in rows:
        print(f"{r['search']:<28} {r['recall_at_10']:>9.3f}  {r['short']:>5}  {r['ms']:>9.3f}")
    if args.json:
        with open(args.json, "w", encoding="utf-8") as f:
            json.dump({"version": v.version, "vectors": stats[0], "queries": len(queries),
                       "category": args.category, "category_papers": stats[1] if args.category else None,
                       "rows": rows}, f, indent=1)
    return 0


if __name__ == "__main__":
    sys.exit(main())
