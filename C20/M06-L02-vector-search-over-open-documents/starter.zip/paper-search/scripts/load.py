"""Load the arXiv records into the papers table.

    python -m scripts.load                      apply the migrations, then load the sample (once)
    python -m scripts.load --updates FILE       apply newer records: changed abstracts, new papers

The loader never loads a paper that is in the removals table (once migration 006 exists).
"""

import argparse
import gzip
import json
import sys
import time
from pathlib import Path

from paper_search import migrate
from paper_search.db import connect

DATA = Path(__file__).resolve().parent.parent / "data"
PAPERS = DATA / "arxiv-cs-2024-papers.jsonl.gz"
COLUMNS = ("arxiv_id", "title", "abstract", "primary_category", "categories", "authors",
           "created", "updated", "doi", "journal_ref", "comments", "paper_licence")


def read(path: Path) -> list[dict]:
    with gzip.open(path, "rt", encoding="utf-8") as f:
        return [json.loads(line) for line in f]


def row(r: dict) -> tuple:
    return (r["arxiv_id"], r["title"], r["abstract"], r["categories"][0], r["categories"], r["authors"],
            r["created"], r["updated"], r["doi"], r["journal_ref"], r["comments"], r["paper_licence"])


def removed_ids(conn) -> set[str]:
    if conn.execute("SELECT to_regclass('removals')").fetchone()[0] is None:
        return set()
    return {r[0] for r in conn.execute("SELECT arxiv_id FROM removals")}


def load_sample(conn) -> int:
    if conn.execute("SELECT EXISTS (SELECT FROM papers)").fetchone()[0]:
        print("The papers table already has data. Nothing was loaded.")
        return 0
    start = time.perf_counter()
    removed = removed_ids(conn)
    records = [r for r in read(PAPERS) if r["arxiv_id"] not in removed]
    with conn.cursor().copy(f"COPY papers ({', '.join(COLUMNS)}) FROM STDIN") as copy:
        for r in records:
            copy.write_row(row(r))
    conn.execute("ANALYZE papers")
    conn.commit()
    print(f"Loaded {len(records):,} papers in {time.perf_counter() - start:.1f} s.")
    if removed:
        print(f"Skipped {len(removed)} removed paper(s).")
    return 0


def load_updates(conn, path: Path) -> int:
    removed = removed_ids(conn)
    new = changed = same = skipped = 0
    for r in read(path):
        if r["arxiv_id"] in removed:
            skipped += 1
            continue
        old = conn.execute("SELECT abstract FROM papers WHERE arxiv_id = %s", (r["arxiv_id"],)).fetchone()
        conn.execute(
            f"INSERT INTO papers ({', '.join(COLUMNS)}) VALUES ({', '.join(['%s'] * len(COLUMNS))}) "
            "ON CONFLICT (arxiv_id) DO UPDATE SET "
            + ", ".join(f"{c} = EXCLUDED.{c}" for c in COLUMNS[1:]),
            row(r),
        )
        if old is None:
            new += 1
        elif old[0] != r["abstract"]:
            changed += 1
        else:
            same += 1
    conn.commit()
    print(f"Updates from {path.name}: {new} new papers, {changed} changed abstracts, "
          f"{same} other changes, {skipped} removed (skipped).")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--updates", type=Path, help="a file of newer records")
    args = parser.parse_args()
    if migrate.main([], quiet=False) != 0:
        return 1
    with connect() as conn:
        if args.updates:
            return load_updates(conn, args.updates)
        if not PAPERS.exists():
            print(f"{PAPERS.name} is missing. Run: python -m scripts.get_data", file=sys.stderr)
            return 1
        return load_sample(conn)


if __name__ == "__main__":
    sys.exit(main())
