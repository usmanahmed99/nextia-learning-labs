"""Compare search methods on one fixed task: find a paper from its title.

    python -m scripts.evaluate                       keyword search and every version that has vectors
    python -m scripts.evaluate --mix bge-small-v1:minilm-v1   (the mistake) bge query vectors against MiniLM vectors

The task: for 500 papers, chosen with a fixed seed, the title is the query and the paper's own
abstract is the one right answer. Vectors are made from the abstract only, so the title is never
part of the text that is searched. Every method answers the same 500 queries with the same metric:
hit@10 (the share of queries whose paper is in the first ten results) and MRR@10 (the mean of
1 / rank, 0 when the paper is not in the first ten). Vector methods use the exact search here, so
the comparison is about the model, not about the index.
"""

import argparse
import json
import random
import statistics
import sys
import time

from paper_search import versions
from paper_search.db import connect
from paper_search.embedding import encode, load_model, to_sql
from paper_search.search import search

KEYWORD = """
SELECT arxiv_id
FROM papers, to_tsquery('simple', replace(plainto_tsquery('english', %(title)s)::text, ' & ', ' | ')) AS q
WHERE abstract_tsv @@ q
ORDER BY ts_rank_cd(abstract_tsv, q) DESC, arxiv_id
LIMIT 10
"""


def score(ranked: list[list[str]], targets: list[str]) -> dict:
    ranks = [r.index(t) + 1 if t in r else None for r, t in zip(ranked, targets)]
    return {
        "queries": len(targets),
        "hit_at_1": round(sum(1 for x in ranks if x == 1) / len(targets), 3),
        "hit_at_10": round(sum(1 for x in ranks if x) / len(targets), 3),
        "mrr_at_10": round(sum(1 / x for x in ranks if x) / len(targets), 3),
    }


def conn_titles(missed):
    with connect() as conn:
        return conn.execute("SELECT arxiv_id, title FROM papers WHERE arxiv_id = ANY(%s)",
                            ([m[2] for m in missed],)).fetchall()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--queries", type=int, default=500)
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--mix", help="QUERY_VERSION:STORED_VERSION, to show what mixing does")
    parser.add_argument("--only", help="evaluate only this version (no keyword search)")
    parser.add_argument("--misses", type=int, default=0, help="show this many titles that the last method missed")
    parser.add_argument("--json", help="also write the results to this file")
    args = parser.parse_args()
    results = {}
    with connect() as conn:
        ids = [r[0] for r in conn.execute("SELECT arxiv_id FROM papers ORDER BY arxiv_id")]
        chosen = sorted(random.Random(args.seed).sample(ids, args.queries))
        titles = dict(conn.execute("SELECT arxiv_id, title FROM papers WHERE arxiv_id = ANY(%s)", (chosen,)).fetchall())
        queries = [titles[i] for i in chosen]
        if args.mix:
            pairs = [tuple(args.mix.split(":"))]
        elif args.only:
            pairs = [(args.only, args.only)]
        else:
            times, ranked = [], []
            for q in queries:
                t = time.perf_counter()
                ranked.append([r[0] for r in conn.execute(KEYWORD, {"title": q})])
                times.append((time.perf_counter() - t) * 1000)
            results["keyword (full-text search)"] = score(ranked, chosen) | {
                "ms_per_query": round(statistics.median(times), 2)}
            have = [r[0] for r in conn.execute(
                "SELECT version FROM embedding_versions v WHERE EXISTS "
                "(SELECT FROM paper_embeddings e WHERE e.embedding_version = v.version) ORDER BY version DESC")]
            pairs = [(v, v) for v in have]
        for query_version, stored_version in pairs:
            qv = versions.get(conn, query_version)
            model = load_model(qv)
            vectors = encode(model, queries, qv.query_prefix)
            times, ranked = [], []
            for vec in vectors:
                t = time.perf_counter()
                ranked.append([h.arxiv_id for h in search(conn, to_sql(vec), stored_version, k=10, exact=True)])
                times.append((time.perf_counter() - t) * 1000)
            name = qv.version if query_version == stored_version else f"{query_version} queries against {stored_version} vectors"
            results[name] = score(ranked, chosen) | {"ms_per_query": round(statistics.median(times), 2)}
            missed = [(q, t, r[0]) for q, t, r in zip(queries, chosen, ranked) if t not in r]
    width = max(len(k) for k in results)
    print(f"{'method':<{width}}  hit@1  hit@10  MRR@10  ms/query   ({args.queries} titles, seed {args.seed})")
    for name, r in results.items():
        print(f"{name:<{width}}  {r['hit_at_1']:.3f}  {r['hit_at_10']:.3f}   {r['mrr_at_10']:.3f}  {r['ms_per_query']:>8}")
    if args.misses:
        top = dict(conn_titles(missed[: args.misses]))
        for q, t, first in missed[: args.misses]:
            print(f"missed {t}: {q[:70]!r}\n    first result {first}: {top[first][:70]!r}")
    if args.json:
        with open(args.json, "w", encoding="utf-8") as f:
            json.dump(results, f, indent=1)
    return 0


if __name__ == "__main__":
    sys.exit(main())
