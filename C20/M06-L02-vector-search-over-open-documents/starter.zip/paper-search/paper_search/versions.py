"""Embedding versions: read the recipe from the database, never from the request."""

from dataclasses import dataclass

import psycopg


@dataclass(frozen=True)
class Version:
    version: str
    model: str
    revision: str
    query_prefix: str
    document_prefix: str
    is_current: bool


COLUMNS = "version, model, revision, query_prefix, document_prefix, is_current"


def get(conn: psycopg.Connection, version: str | None = None) -> Version:
    """The named version, or the current one."""
    if version is None:
        row = conn.execute(f"SELECT {COLUMNS} FROM embedding_versions WHERE is_current").fetchone()
        if row is None:
            raise LookupError("No embedding version is current.")
    else:
        row = conn.execute(f"SELECT {COLUMNS} FROM embedding_versions WHERE version = %s", (version,)).fetchone()
        if row is None:
            raise LookupError(f"Unknown embedding version: {version}")
    return Version(*row)
