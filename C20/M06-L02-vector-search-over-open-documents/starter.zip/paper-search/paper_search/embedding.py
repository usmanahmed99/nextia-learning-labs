"""Turn text into vectors on the CPU with sentence-transformers. Only the scripts need it."""

import hashlib
import os

from paper_search.versions import Version


def sha256(text: str) -> str:
    """The checksum of the exact text that a vector is made from."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def load_model(v: Version):
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
    import torch
    import transformers
    from sentence_transformers import SentenceTransformer

    from huggingface_hub.utils import logging as hub_logging

    hub_logging.set_verbosity_error()  # no token is needed: the models are public
    transformers.logging.set_verbosity_error()
    transformers.logging.disable_progress_bar()

    torch.set_num_threads(int(os.environ.get("EMBED_THREADS", "4")))
    return SentenceTransformer(v.model, revision=v.revision, device="cpu")


def encode(model, texts: list[str], prefix: str = "", batch_size: int = 32):
    """Normalized vectors (length 1), so cosine distance and dot product agree."""
    return model.encode([prefix + t for t in texts], batch_size=batch_size,
                        normalize_embeddings=True, convert_to_numpy=True, show_progress_bar=False)


def to_sql(vector) -> str:
    """The text form that pgvector reads: '[0.1,-0.2,...]'."""
    return "[" + ",".join(f"{float(x):.8g}" for x in vector) + "]"
