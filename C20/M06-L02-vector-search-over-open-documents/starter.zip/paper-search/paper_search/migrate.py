"""Apply the SQL files in migrations/, in order, once each.

    python -m paper_search.migrate            apply what is not applied yet
    python -m paper_search.migrate --status   list the migrations

The same rules as the ticket API of the databases course: each file runs in one
transaction and is recorded with its SHA-256; an applied file must never change;
a file whose first line is "-- migrate: no-transaction" runs one statement at a
time outside a transaction (CREATE INDEX CONCURRENTLY needs it), and an index
left INVALID stops the run.
"""

import argparse
import hashlib
import sys
from pathlib import Path

import psycopg

from paper_search.config import database_url

MIGRATIONS = Path(__file__).resolve().parent.parent / "migrations"
NO_TRANSACTION = "-- migrate: no-transaction"
CREATE_LOG = """
CREATE TABLE IF NOT EXISTS schema_migrations (
    version    text        PRIMARY KEY,
    checksum   text        NOT NULL,
    applied_at timestamptz NOT NULL DEFAULT now()
)
"""


class MigrationError(Exception):
    pass


def checksum(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def statements(sql: str) -> list[str]:
    lines = [ln for ln in sql.splitlines() if not ln.strip().startswith("--")]
    return [s.strip() for s in "\n".join(lines).split(";") if s.strip()]


def apply(url: str, path: Path) -> None:
    sql = path.read_text(encoding="utf-8")
    record = "INSERT INTO schema_migrations (version, checksum) VALUES (%s, %s)"
    if sql.startswith(NO_TRANSACTION):
        with psycopg.connect(url, autocommit=True) as conn:
            conn.execute("SET lock_timeout = '5s'")
            for statement in statements(sql):
                conn.execute(statement)
            invalid = conn.execute("SELECT indexrelid::regclass::text FROM pg_index WHERE NOT indisvalid").fetchall()
            if invalid:
                raise MigrationError(f"{path.name} left an invalid index: {', '.join(r[0] for r in invalid)}. "
                                     "Drop it (DROP INDEX CONCURRENTLY name) and run the migrations again.")
            conn.execute(record, (path.stem, checksum(path)))
        return
    with psycopg.connect(url) as conn, conn.transaction():
        conn.execute("SET LOCAL lock_timeout = '5s'")
        conn.execute(sql)
        conn.execute(record, (path.stem, checksum(path)))


def main(argv: list[str] | None = None, url: str | None = None, quiet: bool = False) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--status", action="store_true")
    args = parser.parse_args(argv)
    url = url or database_url()
    current = None
    try:
        with psycopg.connect(url, connect_timeout=5) as conn:
            conn.execute("SET client_min_messages = warning")
            conn.execute(CREATE_LOG)
            applied = dict(conn.execute("SELECT version, checksum FROM schema_migrations").fetchall())
        files = sorted(MIGRATIONS.glob("*.sql"))
        for f in files:
            if f.stem in applied and applied[f.stem] != checksum(f):
                raise MigrationError(f"{f.name} was changed after it was applied. "
                                     "Put it back as it was, and write the change as a new migration.")
        if args.status:
            for f in files:
                print(f"{'applied' if f.stem in applied else 'pending'}  {f.stem}")
            return 0
        todo = [f for f in files if f.stem not in applied]
        for current in todo:
            apply(url, current)
            if not quiet:
                print(f"applied  {current.stem}")
    except MigrationError as error:
        print(f"Migration stopped: {error}", file=sys.stderr)
        return 1
    except psycopg.Error as error:
        name = current.name if current else "the database"
        print(f"Migration stopped: {name} failed: {str(error).strip().splitlines()[0]}", file=sys.stderr)
        return 1
    if not quiet:
        print(f"Database is up to date ({len(applied) + len(todo)} migrations).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
