"""One place that opens database connections."""

import psycopg

from paper_search.config import database_url


def connect(url: str | None = None, **kwargs) -> psycopg.Connection:
    return psycopg.connect(url or database_url(), connect_timeout=5, **kwargs)
