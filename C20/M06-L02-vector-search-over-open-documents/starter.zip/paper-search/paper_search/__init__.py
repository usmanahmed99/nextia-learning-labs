"""Find related papers in an open collection of arXiv records, with PostgreSQL and pgvector."""
