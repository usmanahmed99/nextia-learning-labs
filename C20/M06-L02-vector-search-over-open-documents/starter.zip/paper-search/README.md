# paper-search (starter)

The starting point of the case study [Vector search over an open document collection](https://learning.nextia-ai.com/courses/databases/m06/vector-search-over-open-documents/) of Nextia Learning.

It has the database in Docker, the papers table (migration 001), the loader, and the scripts that
make vectors, evaluate and measure. You add the vector table with versions, the search, the HNSW
indexes, the version switch, removal and the scan, as the page shows. `finished.zip` is the result.

```sh
python3 -m venv .venv
source .venv/bin/activate                  # Windows: .venv\Scripts\Activate.ps1
python -m pip install -r requirements-lock.txt
cp .env.example .env                       # Windows: Copy-Item .env.example .env
docker compose up -d
python -m scripts.get_data
python -m scripts.load
python -m pytest
```

The records are arXiv's metadata, under CC0 1.0: see `DATASET.md`. Metadata from arXiv.org. Thank
you to arXiv for use of its open access interoperability. The code is under the MIT licence.
