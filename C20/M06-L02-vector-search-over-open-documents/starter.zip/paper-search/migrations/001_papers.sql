-- The papers: one row per arXiv record. This table is the original (the source of truth).
-- Every vector is a copy made from a row here, so it can always be made again.
CREATE EXTENSION IF NOT EXISTS vector;

CREATE TABLE papers (
    arxiv_id         text PRIMARY KEY,
    title            text NOT NULL,
    abstract         text NOT NULL,
    primary_category text NOT NULL,
    categories       text[] NOT NULL,
    authors          text[] NOT NULL,
    created          date NOT NULL,       -- the date of the first version
    updated          date,                -- the date of the newest version, if there is more than one
    doi              text,
    journal_ref      text,
    comments         text,                -- the authors' note, for example "12 pages" or "withdrawn"
    paper_licence    text,                -- the licence of the paper itself, not of this metadata
    abstract_tsv     tsvector GENERATED ALWAYS AS (to_tsvector('english', abstract)) STORED,
    CONSTRAINT papers_id_format CHECK (arxiv_id ~ '^([0-9]{4}\.[0-9]{4,5}|[a-z-]+(\.[A-Z]{2})?/[0-9]{7})$'),
    CONSTRAINT papers_title_not_empty CHECK (title <> ''),
    CONSTRAINT papers_abstract_not_empty CHECK (abstract <> ''),
    CONSTRAINT papers_primary_is_first CHECK (primary_category = categories[1]),
    CONSTRAINT papers_dates_in_order CHECK (updated IS NULL OR updated >= created)
);

-- The metadata filter of the search, and the keyword search of the baseline.
CREATE INDEX papers_category_idx ON papers (primary_category);
CREATE INDEX papers_abstract_tsv_idx ON papers USING gin (abstract_tsv);
