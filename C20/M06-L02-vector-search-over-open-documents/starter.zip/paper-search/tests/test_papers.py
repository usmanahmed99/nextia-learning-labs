"""The rules of the papers table (migration 001)."""

import psycopg
import pytest

from conftest import add_paper


def test_a_paper_is_stored(conn):
    add_paper(conn, "2403.00001")
    assert conn.execute("SELECT count(*) FROM papers").fetchone()[0] == 1


def test_the_id_is_unique(conn):
    add_paper(conn, "2403.00001")
    with pytest.raises(psycopg.errors.UniqueViolation):
        add_paper(conn, "2403.00001")


def test_an_odd_id_is_rejected(conn):
    with pytest.raises(psycopg.errors.CheckViolation, match="papers_id_format"):
        add_paper(conn, "not-an-id")


def test_old_style_ids_are_accepted(conn):
    add_paper(conn, "cs/0601001")
    add_paper(conn, "math.CO/0601001")


def test_the_primary_category_is_the_first(conn):
    with pytest.raises(psycopg.errors.CheckViolation, match="papers_primary_is_first"):
        conn.execute(
            "INSERT INTO papers (arxiv_id, title, abstract, primary_category, categories, authors, created) "
            "VALUES ('2403.00002', 't', 'a', 'cs.DB', '{cs.LG,cs.DB}', '{}', '2024-03-01')")


def test_an_empty_abstract_is_rejected(conn):
    with pytest.raises(psycopg.errors.CheckViolation, match="papers_abstract_not_empty"):
        add_paper(conn, "2403.00003", abstract="")
