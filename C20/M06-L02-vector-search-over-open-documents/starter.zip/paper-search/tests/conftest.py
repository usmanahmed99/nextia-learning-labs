"""A test database of its own, made fresh for each test: TEST_DATABASE_URL (its name must end in _test)."""

import os
from urllib.parse import urlsplit, urlunsplit

import psycopg
import pytest

from paper_search import migrate
from paper_search.config import load_env


@pytest.fixture
def db_url():
    load_env()
    url = os.environ.get("TEST_DATABASE_URL")
    if not url:
        pytest.skip("TEST_DATABASE_URL is not set")
    parts = urlsplit(url)
    name = parts.path.lstrip("/")
    if not name.endswith("_test"):
        pytest.exit(f"TEST_DATABASE_URL must name a database that ends in _test (the tests drop it), not {name!r}")
    admin = urlunsplit(parts._replace(path="/postgres"))
    try:
        with psycopg.connect(admin, autocommit=True, connect_timeout=3) as conn:
            conn.execute(f'DROP DATABASE IF EXISTS "{name}" WITH (FORCE)')
            conn.execute(f'CREATE DATABASE "{name}"')
    except psycopg.OperationalError as error:
        pytest.skip(f"PostgreSQL is not running: {str(error).splitlines()[0]}")
    assert migrate.main([], url=url, quiet=True) == 0
    return url


@pytest.fixture
def conn(db_url):
    with psycopg.connect(db_url) as c:
        yield c


def add_paper(conn, arxiv_id, category="cs.DB", abstract=None, title=None):
    conn.execute(
        "INSERT INTO papers (arxiv_id, title, abstract, primary_category, categories, authors, created) "
        "VALUES (%s, %s, %s, %s, %s, %s, '2024-03-01')",
        (arxiv_id, title or f"Paper {arxiv_id}", f"Abstract of {arxiv_id}." if abstract is None else abstract, category,
         [category, "cs.LG"], ["A. Author"]),
    )
