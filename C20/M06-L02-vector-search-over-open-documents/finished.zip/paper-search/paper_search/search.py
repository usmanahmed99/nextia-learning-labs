"""Find the papers nearest to a query vector, with one embedding version on both sides."""

from dataclasses import dataclass

import psycopg
from psycopg import sql

ITERATIVE = ("off", "strict_order", "relaxed_order")


@dataclass(frozen=True)
class Hit:
    arxiv_id: str
    title: str
    primary_category: str
    distance: float


def search(conn: psycopg.Connection, query_vector: str, version: str, *, k: int = 10,
           category: str | None = None, exclude: str | None = None, exact: bool = False,
           ef_search: int = 40, iterative: str = "relaxed_order") -> list[Hit]:
    """The k nearest papers of one version.

    exact=True reads every vector (no index): always right, slower.
    Otherwise the partial HNSW index of the version is used. hnsw.ef_search is the length of its
    candidate list; with a filter, the iterative scan keeps reading the index until k rows pass.
    The version goes into the SQL as a literal (PostgreSQL must see it to use the partial index);
    it comes from embedding_versions, never from a user. Every other value is a parameter.
    """
    if iterative not in ITERATIVE:
        raise ValueError(f"iterative must be one of {ITERATIVE}")
    where = [sql.SQL("e.embedding_version = {}").format(sql.Literal(version))]
    params: dict = {"q": query_vector, "k": k}
    if category is not None:
        where.append(sql.SQL("p.primary_category = %(category)s"))
        params["category"] = category
    if exclude is not None:
        where.append(sql.SQL("p.arxiv_id <> %(exclude)s"))
        params["exclude"] = exclude
    query = sql.SQL(
        "SELECT p.arxiv_id, p.title, p.primary_category, e.embedding <=> %(q)s::vector AS distance "
        "FROM paper_embeddings e JOIN papers p USING (arxiv_id) "
        "WHERE {where} ORDER BY e.embedding <=> %(q)s::vector LIMIT %(k)s"
    ).format(where=sql.SQL(" AND ").join(where))
    with conn.transaction():
        # Set all three every time. SET LOCAL lasts to the end of the outer transaction, so a value
        # left by an earlier search in the same transaction would otherwise still apply.
        conn.execute(sql.SQL("SET LOCAL enable_indexscan = {}").format(sql.SQL("off" if exact else "on")))
        conn.execute(sql.SQL("SET LOCAL hnsw.ef_search = {}").format(sql.Literal(int(ef_search))))
        conn.execute(sql.SQL("SET LOCAL hnsw.iterative_scan = {}").format(sql.Literal(iterative)))
        rows = conn.execute(query, params).fetchall()
    hits = [Hit(*r) for r in rows]
    # relaxed_order may return the rows slightly out of order: sort them again.
    return sorted(hits, key=lambda h: h.distance)
