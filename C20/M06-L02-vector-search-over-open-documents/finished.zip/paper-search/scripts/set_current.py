"""Make another embedding version the current one, only when it is ready.

    python -m scripts.set_current bge-small-v1

Ready means: every paper has an up-to-date vector of that version, and a valid HNSW index covers
it. The switch is one UPDATE in one transaction, so every search sees either the old version or
the new one, never a mix. To go back, run the command with the old version: its vectors are kept.
"""

import argparse
import sys

from paper_search import versions
from paper_search.db import connect

COVERAGE = """
SELECT count(*) FILTER (WHERE e.arxiv_id IS NULL) AS missing,
       count(*) FILTER (WHERE e.source_sha256 <> encode(sha256(convert_to(p.abstract, 'UTF8')), 'hex')) AS stale
FROM papers p
LEFT JOIN paper_embeddings e ON e.arxiv_id = p.arxiv_id AND e.embedding_version = %s
"""
INDEX = """
SELECT i.indexrelid::regclass::text
FROM pg_index i JOIN pg_am am ON am.oid = (SELECT relam FROM pg_class WHERE oid = i.indexrelid)
WHERE i.indrelid = 'paper_embeddings'::regclass AND am.amname = 'hnsw' AND i.indisvalid
  AND pg_get_expr(i.indpred, i.indrelid) = format('(embedding_version = %%L::text)', %s::text)
"""


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("version")
    args = parser.parse_args()
    with connect() as conn:
        v = versions.get(conn, args.version)
        if v.is_current:
            print(f"{v.version} is already the current version.")
            return 0
        missing, stale = conn.execute(COVERAGE, (v.version,)).fetchone()
        index = conn.execute(INDEX, (v.version,)).fetchone()
        problems = []
        if missing or stale:
            problems.append(f"{missing:,} papers have no vector of {v.version} and {stale:,} have a stale one. "
                            f"Run: python -m scripts.embed --version {v.version}")
        if index is None:
            problems.append(f"No valid HNSW index covers {v.version}: every search would read every vector. "
                            "Build it first, with a migration (CREATE INDEX CONCURRENTLY).")
        if problems:
            print(f"Not switched. {v.version} is not ready:", file=sys.stderr)
            for p in problems:
                print(f"- {p}", file=sys.stderr)
            return 1
        old = versions.get(conn)
        with conn.transaction():
            conn.execute("UPDATE embedding_versions SET is_current = false WHERE is_current")
            conn.execute("UPDATE embedding_versions SET is_current = true WHERE version = %s", (v.version,))
        print(f"The current version is now {v.version} (index {index[0]}). "
              f"{old.version} and its vectors are kept: to go back, run this command with {old.version}.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
