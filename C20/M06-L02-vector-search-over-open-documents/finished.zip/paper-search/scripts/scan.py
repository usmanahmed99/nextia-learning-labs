"""Find vectors that no longer match the papers.

    python -m scripts.scan          report
    python -m scripts.scan --fix    delete orphans and vectors of removed papers (the rest needs the model)

The five checks:
- orphan vectors: a vector whose paper does not exist
- removed but searchable: a vector of a paper in the removals table
- stale vectors: the abstract changed after the vector of the current version was made
- missing vectors: a paper with no vector of the current version
- other versions: vectors of versions that are not current (kept for a rollback, or forgotten)
"""

import argparse
import sys

from paper_search.db import connect

CHECKS = {
    "orphan vectors": """SELECT count(*) FROM paper_embeddings e
        WHERE NOT EXISTS (SELECT FROM papers p WHERE p.arxiv_id = e.arxiv_id)""",
    "removed but searchable": """SELECT count(*) FROM paper_embeddings e JOIN removals r USING (arxiv_id)""",
    "stale vectors": """SELECT count(*) FROM paper_embeddings e JOIN papers p USING (arxiv_id)
        JOIN embedding_versions v ON v.version = e.embedding_version
        WHERE v.is_current AND e.source_sha256 <> encode(sha256(convert_to(p.abstract, 'UTF8')), 'hex')""",
    "missing vectors": """SELECT count(*) FROM papers p WHERE NOT EXISTS (
        SELECT FROM paper_embeddings e JOIN embedding_versions v ON v.version = e.embedding_version
        WHERE e.arxiv_id = p.arxiv_id AND v.is_current)""",
    "other versions": """SELECT count(*) FROM paper_embeddings e JOIN embedding_versions v
        ON v.version = e.embedding_version WHERE NOT v.is_current""",
}
FIX = {
    "orphan vectors": """DELETE FROM paper_embeddings e
        WHERE NOT EXISTS (SELECT FROM papers p WHERE p.arxiv_id = e.arxiv_id)""",
    "removed but searchable": """DELETE FROM paper_embeddings e USING removals r WHERE r.arxiv_id = e.arxiv_id""",
}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--fix", action="store_true")
    args = parser.parse_args()
    with connect() as conn:
        if conn.execute("SELECT to_regclass('removals')").fetchone()[0] is None:
            CHECKS.pop("removed but searchable")
        for name, query in CHECKS.items():
            print(f"{name + ':':<24}{conn.execute(query).fetchone()[0]:>7,}")
        if args.fix:
            with conn.transaction():
                for name, query in FIX.items():
                    if name in CHECKS:
                        print(f"fixed {name}: {conn.execute(query).rowcount} deleted")
            print("Stale and missing vectors need the model: run python -m scripts.embed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
