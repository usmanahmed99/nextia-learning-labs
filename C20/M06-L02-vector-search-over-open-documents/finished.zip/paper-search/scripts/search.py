"""Search the papers with a question in your own words.

    python -m scripts.search "how to keep vector indexes correct when documents are deleted"
    python -m scripts.search "..." --category cs.DB -k 5

The question is embedded with the current version's model and query prefix, then searched with the
HNSW index of that version (iterative scan on, so a filter still returns k papers).
"""

import argparse
import sys
import time

from paper_search import versions
from paper_search.db import connect
from paper_search.embedding import encode, load_model, to_sql
from paper_search.search import search


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("question")
    parser.add_argument("-k", type=int, default=5)
    parser.add_argument("--category")
    args = parser.parse_args()
    with connect() as conn:
        v = versions.get(conn)
        model = load_model(v)
        t = time.perf_counter()
        vector = to_sql(encode(model, [args.question], v.query_prefix)[0])
        t_embed = time.perf_counter()
        hits = search(conn, vector, v.version, k=args.k, category=args.category)
        t_search = time.perf_counter()
    print(f"Version {v.version} ({v.model}); embed {1000 * (t_embed - t):.0f} ms, "
          f"search {1000 * (t_search - t_embed):.1f} ms")
    for h in hits:
        print(f"{h.distance:.3f}  {h.arxiv_id:<12} {h.primary_category:<8} {h.title[:80]}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
