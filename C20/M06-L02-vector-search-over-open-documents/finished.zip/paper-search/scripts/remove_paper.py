"""Remove a paper from the collection, everywhere it is stored.

    python -m scripts.remove_paper 2403.01234 --reason "withdrawn from the source"

One transaction: record the ID in removals, then delete the paper. The foreign key deletes its
vectors of every version (ON DELETE CASCADE). If any step fails, nothing changes.
"""

import argparse
import sys

from paper_search.db import connect


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("arxiv_id")
    parser.add_argument("--reason", required=True)
    args = parser.parse_args()
    with connect() as conn, conn.transaction():
        vectors = conn.execute("SELECT count(*) FROM paper_embeddings WHERE arxiv_id = %s",
                               (args.arxiv_id,)).fetchone()[0]
        deleted = conn.execute("DELETE FROM papers WHERE arxiv_id = %s RETURNING title", (args.arxiv_id,)).fetchone()
        if deleted is None:
            print(f"No paper {args.arxiv_id}. Nothing changed.", file=sys.stderr)
            return 1
        left = conn.execute("SELECT count(*) FROM paper_embeddings WHERE arxiv_id = %s",
                            (args.arxiv_id,)).fetchone()[0]
        conn.execute("INSERT INTO removals (arxiv_id, reason) VALUES (%s, %s)", (args.arxiv_id, args.reason))
    print(f"Removed {args.arxiv_id} ({deleted[0][:60]}): 1 paper, {vectors} vectors ({left} left).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
