"""Removal and the scan (migration 006, scripts/remove_paper.py, scripts/scan.py, scripts/load.py)."""

import os

import numpy as np

from conftest import add_paper
from scripts import load, remove_paper, scan
from test_vectors import add_vector


def setup(conn):
    for i in range(3):
        add_paper(conn, f"2403.{i:05d}")
        add_vector(conn, f"2403.{i:05d}", "minilm-v1", np.ones(384) / np.sqrt(384))
    conn.commit()


def run(module, argv, db_url, monkeypatch):
    monkeypatch.setenv("DATABASE_URL", db_url)
    monkeypatch.setattr("sys.argv", ["x", *argv])
    return module.main()


def test_remove_reaches_every_vector_and_is_recorded(conn, db_url, monkeypatch, capsys):
    setup(conn)
    assert run(remove_paper, ["2403.00001", "--reason", "test"], db_url, monkeypatch) == 0
    assert "1 paper, 1 vectors (0 left)" in capsys.readouterr().out
    assert conn.execute("SELECT count(*) FROM paper_embeddings WHERE arxiv_id = '2403.00001'").fetchone()[0] == 0
    assert conn.execute("SELECT reason FROM removals").fetchone()[0] == "test"


def test_an_unknown_paper_changes_nothing(conn, db_url, monkeypatch):
    setup(conn)
    assert run(remove_paper, ["2403.09999", "--reason", "test"], db_url, monkeypatch) == 1
    assert conn.execute("SELECT count(*) FROM removals").fetchone()[0] == 0


def test_an_update_file_never_brings_a_removed_paper_back(conn, db_url, monkeypatch, tmp_path):
    import gzip
    import json

    setup(conn)
    run(remove_paper, ["2403.00001", "--reason", "test"], db_url, monkeypatch)
    record = {"arxiv_id": "2403.00001", "title": "Back", "abstract": "Back again.", "categories": ["cs.DB"],
              "authors": [], "created": "2024-03-01", "updated": None, "doi": None, "journal_ref": None,
              "comments": None, "paper_licence": None}
    path = tmp_path / "updates.jsonl.gz"
    with gzip.open(path, "wt", encoding="utf-8") as f:
        f.write(json.dumps(record) + "\n")
    assert run(load, ["--updates", str(path)], db_url, monkeypatch) == 0
    assert conn.execute("SELECT count(*) FROM papers WHERE arxiv_id = '2403.00001'").fetchone()[0] == 0


def test_the_scan_finds_stale_missing_and_orphan_vectors(conn, db_url, monkeypatch, capsys):
    setup(conn)
    conn.execute("UPDATE papers SET abstract = 'A corrected abstract.' WHERE arxiv_id = '2403.00000'")
    add_paper(conn, "2403.00009")
    # Constructed: a vector without its paper, as a data-only restore with disabled triggers can leave.
    conn.execute("SET session_replication_role = replica")
    add_paper(conn, "2403.00008")
    add_vector(conn, "2403.00008", "minilm-v1", np.ones(384) / np.sqrt(384))
    conn.execute("DELETE FROM papers WHERE arxiv_id = '2403.00008'")
    conn.execute("SET session_replication_role = origin")
    conn.commit()
    assert run(scan, [], db_url, monkeypatch) == 0
    counts = {line.split(":")[0]: int(line.split(":")[1]) for line in capsys.readouterr().out.splitlines()}
    assert counts == {"orphan vectors": 1, "removed but searchable": 0, "stale vectors": 1,
                      "missing vectors": 1, "other versions": 0}
    run(scan, ["--fix"], db_url, monkeypatch)
    assert "fixed orphan vectors: 1 deleted" in capsys.readouterr().out
