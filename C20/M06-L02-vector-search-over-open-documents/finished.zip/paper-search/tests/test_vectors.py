"""Versions, the search and the switch (migrations 002 to 005). Made-up vectors: no model needed."""

import numpy as np
import psycopg
import pytest

from conftest import add_paper
from paper_search.embedding import sha256, to_sql
from paper_search.search import search


def add_vector(conn, arxiv_id, version, vector):
    abstract = conn.execute("SELECT abstract FROM papers WHERE arxiv_id = %s", (arxiv_id,)).fetchone()[0]
    conn.execute("INSERT INTO paper_embeddings VALUES (%s, %s, %s, %s::vector)",
                 (arxiv_id, version, sha256(abstract), to_sql(vector)))


def unit(rng):
    v = rng.normal(size=384)
    return v / np.linalg.norm(v)


@pytest.fixture
def papers(conn):
    """60 papers in three categories, with a MiniLM-like vector each."""
    rng = np.random.default_rng(0)
    for i in range(60):
        pid = f"2403.{i:05d}"
        add_paper(conn, pid, category=("cs.DB", "cs.LG", "cs.CV")[i % 3])
        add_vector(conn, pid, "minilm-v1", unit(rng))
    conn.commit()
    return rng


def test_only_one_version_is_current(conn):
    with pytest.raises(psycopg.errors.UniqueViolation):
        conn.execute("UPDATE embedding_versions SET is_current = true")


def test_a_vector_needs_a_known_version(conn):
    add_paper(conn, "2403.00001")
    with pytest.raises(psycopg.errors.ForeignKeyViolation):
        add_vector(conn, "2403.00001", "made-up-v9", np.ones(384) / np.sqrt(384))


def test_a_vector_needs_its_paper(conn):
    with pytest.raises(psycopg.errors.ForeignKeyViolation):
        conn.execute("INSERT INTO paper_embeddings VALUES ('2403.99999', 'minilm-v1', %s, %s::vector)",
                     ("0" * 64, to_sql(np.ones(384))))


def test_exact_and_index_agree_on_a_small_collection(conn, papers):
    query = to_sql(unit(papers))
    exact = [h.arxiv_id for h in search(conn, query, "minilm-v1", k=10, exact=True)]
    approx = [h.arxiv_id for h in search(conn, query, "minilm-v1", k=10)]
    assert approx == exact


def test_the_index_is_used(conn, papers):
    conn.execute("SET enable_seqscan = off")
    plan = "\n".join(r[0] for r in conn.execute(
        "EXPLAIN SELECT arxiv_id FROM paper_embeddings WHERE embedding_version = 'minilm-v1' "
        "ORDER BY embedding <=> %s::vector LIMIT 10", (to_sql(unit(papers)),)))
    assert "paper_embeddings_minilm_v1_hnsw" in plan


def test_a_search_never_mixes_versions(conn, papers):
    add_paper(conn, "2403.90000")
    target = unit(papers)
    add_vector(conn, "2403.90000", "bge-small-v1", target)
    hits = search(conn, to_sql(target), "minilm-v1", k=60, exact=True)
    assert "2403.90000" not in [h.arxiv_id for h in hits]
    assert [h.arxiv_id for h in search(conn, to_sql(target), "bge-small-v1", k=1)] == ["2403.90000"]


def test_a_filter_still_returns_k_papers(conn, papers):
    hits = search(conn, to_sql(unit(papers)), "minilm-v1", k=10, category="cs.DB")
    assert len(hits) == 10 and {h.primary_category for h in hits} == {"cs.DB"}


def test_deleting_a_paper_deletes_its_vectors(conn, papers):
    add_vector(conn, "2403.00000", "bge-small-v1", unit(papers))
    conn.execute("DELETE FROM papers WHERE arxiv_id = '2403.00000'")
    assert conn.execute("SELECT count(*) FROM paper_embeddings WHERE arxiv_id = '2403.00000'").fetchone()[0] == 0


def test_an_exact_search_does_not_turn_the_index_off_for_the_next_one(conn, papers):
    conn.execute("SELECT 1")  # an open transaction, as in a script that reads first
    search(conn, to_sql(unit(papers)), "minilm-v1", exact=True)
    search(conn, to_sql(unit(papers)), "minilm-v1")
    assert conn.execute("SHOW enable_indexscan").fetchone()[0] == "on"
