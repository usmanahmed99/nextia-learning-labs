# paper-search

Find related papers in 15,469 open arXiv records (computer science, February and March 2024) with PostgreSQL and pgvector. The case study [Vector search over an open document collection](https://learning.nextia-ai.com/courses/databases/m06/vector-search-over-open-documents/) of Nextia Learning builds it step by step.

- The papers table is the original. Every vector is a copy made from an abstract, with its **embedding version** and the **SHA-256 of the text** it was made from.
- Exact search and an approximate **HNSW** index, compared on recall@10 and time.
- A **metadata filter** (the primary category) that still returns k papers, with pgvector's iterative scan.
- A second model added and switched to **safely**: backfill, index, compare, then one `UPDATE`.
- **Removal** of a paper reaches every vector, and a **scan** finds orphan, stale and missing vectors.

Everything runs on your computer. No account and no paid service.

## Run it

You need Python 3.12 or newer, Docker (or PostgreSQL 18 with pgvector 0.8), and about 2 GB of disk space (the packages and the two models).

```sh
python3 -m venv .venv
source .venv/bin/activate                  # Windows: .venv\Scripts\Activate.ps1
python -m pip install -r requirements-lock.txt
cp .env.example .env                       # Windows: Copy-Item .env.example .env
docker compose up -d
python -m scripts.get_data
python -m scripts.load
python -m pytest
```

## Commands

| Command | What it does |
|---|---|
| `python -m paper_search.migrate [--status]` | apply the SQL files in `migrations/`, in order, once each |
| `python -m scripts.get_data` | download the two data files and check their SHA-256 |
| `python -m scripts.load [--updates FILE]` | load the papers (once); apply newer records |
| `python -m scripts.embed [--version V]` | make the missing or stale vectors of a version, in batches |
| `python -m scripts.evaluate [--mix Q:S]` | keyword search and each version on 500 titles: hit@10, MRR@10 |
| `python -m scripts.bench [--category C]` | exact search against the HNSW index: recall@10 and time |
| `python -m scripts.search "question" [--category C]` | search with your own words |
| `python -m scripts.set_current V` | switch the current version, only when it is ready |
| `python -m scripts.remove_paper ID --reason R` | remove a paper and all its vectors, and remember the removal |
| `python -m scripts.scan [--fix]` | orphan, removed, stale, missing and other-version vectors |

## Data and licence

The records are arXiv's metadata, under CC0 1.0: see `DATASET.md`. Metadata from arXiv.org. Thank you to arXiv for use of its open access interoperability. This project is not endorsed by arXiv. The code is under the MIT licence (`LICENSE`).
