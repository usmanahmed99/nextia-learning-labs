-- migrate: no-transaction
-- The index of the new version, ready before the switch.
CREATE INDEX CONCURRENTLY paper_embeddings_bge_small_v1_hnsw ON paper_embeddings
    USING hnsw (embedding vector_cosine_ops) WITH (m = 16, ef_construction = 64)
    WHERE embedding_version = 'bge-small-v1';
