-- Papers that were removed from the collection, and why. No title, no abstract: only the ID.
-- The loader skips these IDs, so a reload of the source file never brings a removed paper back.
CREATE TABLE removals (
    arxiv_id   text PRIMARY KEY,
    removed_at timestamptz NOT NULL DEFAULT now(),
    reason     text NOT NULL CHECK (reason <> '')
);
