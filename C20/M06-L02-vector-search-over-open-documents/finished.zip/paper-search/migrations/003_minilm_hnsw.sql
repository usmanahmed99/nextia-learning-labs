-- migrate: no-transaction
-- An approximate index for the current version only (a partial index), built without blocking writes.
CREATE INDEX CONCURRENTLY paper_embeddings_minilm_v1_hnsw ON paper_embeddings
    USING hnsw (embedding vector_cosine_ops) WITH (m = 16, ef_construction = 64)
    WHERE embedding_version = 'minilm-v1';
