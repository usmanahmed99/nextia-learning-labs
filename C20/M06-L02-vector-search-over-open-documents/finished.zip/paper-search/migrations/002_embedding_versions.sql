-- Vectors with a version. A version names one recipe: one model, one revision, one prefix.
-- Exactly one version is current, and every search uses it on both sides.
CREATE TABLE embedding_versions (
    version         text PRIMARY KEY,
    model           text NOT NULL,
    revision        text NOT NULL,
    dimensions      integer NOT NULL CHECK (dimensions = 384),
    query_prefix    text NOT NULL DEFAULT '',
    document_prefix text NOT NULL DEFAULT '',
    is_current      boolean NOT NULL DEFAULT false
);
CREATE UNIQUE INDEX embedding_versions_one_current ON embedding_versions (is_current) WHERE is_current;

INSERT INTO embedding_versions (version, model, revision, dimensions, is_current)
VALUES ('minilm-v1', 'sentence-transformers/all-MiniLM-L6-v2', '1110a243fdf4706b3f48f1d95db1a4f5529b4d41', 384, true);

CREATE TABLE paper_embeddings (
    arxiv_id          text NOT NULL REFERENCES papers (arxiv_id) ON DELETE CASCADE,
    embedding_version text NOT NULL REFERENCES embedding_versions (version),
    source_sha256     text NOT NULL CHECK (source_sha256 ~ '^[0-9a-f]{64}$'),
    embedding         vector(384) NOT NULL,
    PRIMARY KEY (arxiv_id, embedding_version)
);
