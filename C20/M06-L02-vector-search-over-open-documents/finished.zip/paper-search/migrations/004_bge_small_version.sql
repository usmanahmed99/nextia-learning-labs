-- A second version: BAAI/bge-small-en-v1.5 (MIT), also 384 numbers. It is not current yet.
-- bge asks for an instruction in front of a short query that looks for passages.
INSERT INTO embedding_versions (version, model, revision, dimensions, query_prefix, is_current)
VALUES ('bge-small-v1', 'BAAI/bge-small-en-v1.5', '5c38ec7c405ec4b44b94cc5a9bb96e735b38267a', 384,
        'Represent this sentence for searching relevant passages: ', false);
