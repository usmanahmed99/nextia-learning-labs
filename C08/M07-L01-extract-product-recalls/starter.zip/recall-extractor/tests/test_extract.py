from recalls.extract import extract
from recalls.notices import NEW_NOTICE
from recalls.providers import RecordingNotFound
from recalls.request import build_request


def test_the_plain_request_differs_only_in_the_schema(notices):
    with_schema = build_request(notices["26382"], "chat-small", schema=True)
    plain = build_request(notices["26382"], "chat-small", schema=False)
    assert with_schema["messages"] == plain["messages"]
    assert "response_format" in with_schema and "response_format" not in plain


def test_the_new_notice_end_to_end(mock, notices):
    outcome = extract(mock, notices[NEW_NOTICE], "chat-small")
    assert outcome.status == "valid"
    assert outcome.verdict.record.units == 10605
    assert outcome.cost_usd < 0.001


def test_a_correct_sum_is_flagged_for_a_person(mock, notices):
    """Thermos: 5.8 million + 2.3 million. The record is right, but 8,100,000 is not written in the notice."""
    outcome = extract(mock, notices["26444"], "chat-small")
    assert outcome.status == "flagged"
    assert [p.code for p in outcome.verdict.problems] == ["units_not_in_notice"]
    assert outcome.verdict.record.units == 8_100_000


def test_the_local_model_without_a_schema_writes_a_markdown_fence(mock, notices):
    outcome = extract(mock, notices["26382"], "gemma3:4b", schema=False)
    assert outcome.status == "rejected"
    assert outcome.completion.text.startswith("```json")


def test_the_local_server_did_not_enforce_the_pattern(mock, notices):
    outcome = extract(mock, notices["26382"], "gemma3:4b", schema=True)
    assert outcome.status == "rejected"
    assert "sold_from" in outcome.verdict.problems[0].message


def test_a_request_that_was_not_recorded(mock, notices):
    request = build_request(notices["26382"], "another-model")
    try:
        mock.complete(request)
    except RecordingNotFound:
        return
    raise AssertionError("the mock answered a request that was never recorded")
