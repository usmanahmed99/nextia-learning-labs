import pytest

from recalls.notices import load_notices
from recalls.providers import MockProvider
from recalls.score import load_reference


@pytest.fixture(autouse=True)
def use_the_mock(monkeypatch):
    """Tests always use the recorded answers, even when .env names a live provider."""
    monkeypatch.setenv("RECALLS_PROVIDER", "mock")


@pytest.fixture(scope="session")
def mock():
    return MockProvider()


@pytest.fixture(scope="session")
def notices():
    return load_notices()


@pytest.fixture(scope="session")
def reference():
    return load_reference()
