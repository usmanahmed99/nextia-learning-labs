"""The comparison of the case study, replayed from the recordings: the numbers on the page."""

import pytest

from recalls.__main__ import main


@pytest.mark.parametrize("args, expected", [
    (["--baseline"], "fields right: 377/400 (94.2%) | notices with every field right: 21/40"),
    (["--model", "chat-small"], "fields right: 397/400 (99.2%) | notices with every field right: 37/40"),
    (["--model", "chat-strong"], "fields right: 398/400 (99.5%) | notices with every field right: 38/40"),
    (["--model", "gemma3:4b"], "fields right: 77/400 (19.2%) | notices with every field right: 1/40"),
    (["--model", "gemma3:4b", "--plain"], "fields right: 0/400 (0.0%) | notices with every field right: 0/40"),
])
def test_eval(capsys, args, expected):
    assert main(["eval", *args]) == 0
    assert expected in capsys.readouterr().out
