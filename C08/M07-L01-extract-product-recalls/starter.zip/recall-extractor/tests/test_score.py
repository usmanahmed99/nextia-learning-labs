from recalls.schema import RecallRecord
from recalls.score import FIELDS, compare, retailer_key
from tests.test_schema import GOOD


def test_retailer_names_are_compared_as_shops():
    assert retailer_key("www.Walmart.com") == retailer_key("Walmart") == "walmart"
    assert retailer_key("Kohl's") == "kohls"


def test_a_record_is_scored_field_by_field(reference):
    record = RecallRecord.model_validate({**GOOD, "units": 3600, "contact_phone": "(none)"})
    result = compare(record, reference["26406"])
    assert [f for f in FIELDS if not result[f]] == ["units", "contact_phone"]


def test_no_record_scores_zero(reference):
    assert not any(compare(None, reference["26406"]).values())
