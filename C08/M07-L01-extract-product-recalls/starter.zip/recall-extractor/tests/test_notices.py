from recalls.notices import NEW_NOTICE, section


def test_the_sample_is_the_course_copy(notices, reference):
    assert len(notices) == 41  # 40 with a reference record, and the new notice
    assert set(reference) | {NEW_NOTICE} == set(notices)


def test_a_notice_has_the_page_sections(notices):
    text = notices["26406"].text
    assert section(text, "Recall date") == "April 16, 2026"
    assert section(text, "Units") == "360"
    assert section(text, "Sold at").startswith("Online at Amazon.com")
    assert section(text, "No such label") == ""
