import pytest
from pydantic import ValidationError

from recalls.schema import RecallRecord, response_format

GOOD = {
    "recall_number": "26406", "product_name": "BAYOTAK USA Electric Pressure Washers", "category": "tools_cleaning",
    "hazards": ["electric_shock"], "hazard_quote": "The recalled pressure washers lack an integral ground-fault "
    "circuit-interrupter (GFCI), posing a serious risk of injury or death from shock and electrocution hazards.",
    "units": 360, "remedies": ["replace"], "recall_date": "2026-04-16", "sold_from": "2025-10", "sold_to": "2026-01",
    "retailers": ["Amazon.com"], "contact_phone": None, "contact_email": "bayotakservice@163.com",
}


def test_strict_mode_needs_every_field_required():
    schema = response_format()["json_schema"]
    assert schema["strict"] is True
    assert set(schema["schema"]["required"]) == set(schema["schema"]["properties"])


def test_a_good_record_passes():
    assert RecallRecord.model_validate(GOOD).units == 360


@pytest.mark.parametrize("change", [
    {"category": "garden"},              # not in the list
    {"hazards": []},                     # at least one hazard
    {"hazards": ["sharp edges"]},        # not a hazard type
    {"units": "about 360"},              # text, not a number
    {"recall_date": "April 16, 2026"},   # not YYYY-MM-DD
    {"recall_date": "2026-02-30"},       # the right shape, but no such day
    {"sold_from": "2025-10-01"},         # a day, not a month
    {"price": 110},                      # a field that the schema does not have
])
def test_the_schema_stops_wrong_shapes(change):
    with pytest.raises(ValidationError):
        RecallRecord.model_validate({**GOOD, **change})


def test_the_schema_cannot_see_wrong_facts():
    """Gate 1 passes a record whose units, date and retailer are all wrong: only gate 2 can catch them."""
    wrong = RecallRecord.model_validate({**GOOD, "units": 3600, "recall_date": "2026-04-17",
                                         "retailers": ["Walmart.com"]})
    assert wrong.units == 3600
