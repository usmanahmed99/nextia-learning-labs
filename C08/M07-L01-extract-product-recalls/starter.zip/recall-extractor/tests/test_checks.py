from datetime import date

from recalls.checks import check_rules, parse
from recalls.providers import Completion
from recalls.schema import RecallRecord
from tests.test_schema import GOOD

TODAY = date(2026, 10, 8)


def completion(text, finish_reason="stop"):
    return Completion(text, finish_reason, None, [], "m", "id", 0, 0, 0, 0.0, {})


def codes(record, notice):
    return [p.code for p in check_rules(record, notice, TODAY)]


def test_gate_1_names_what_went_wrong():
    assert parse(completion('```json\n{"recall_number": "26406"}\n```')).problems[0].code == "malformed_json"
    assert parse(completion('{"recall_number": "26406"}')).problems[0].code == "schema"
    assert parse(completion('{"recall_number": "264', "length")).problems[0].code == "truncated"


def test_a_correct_record_passes_gate_2(notices):
    assert codes(RecallRecord.model_validate(GOOD), notices["26406"]) == []


def test_gate_2_catches_facts_that_are_not_in_the_notice(notices):
    wrong = RecallRecord.model_validate({
        **GOOD, "units": 3600, "recall_date": "2026-04-17", "retailers": ["Walmart.com"],
        "contact_phone": "800-555-0100", "hazards": ["electric_shock", "fire"],
        "hazard_quote": "The pressure washers can shock users.",
    })
    assert codes(wrong, notices["26406"]) == [
        "date_not_in_notice", "units_not_in_notice", "quote_not_in_notice", "hazard_not_in_notice",
        "retailer_not_in_notice", "phone_not_in_notice"]


def test_gate_2_checks_the_calendar(notices):
    wrong = RecallRecord.model_validate({**GOOD, "recall_date": "2027-04-16", "sold_from": "2026-03",
                                         "sold_to": "2025-10"})
    found = codes(wrong, notices["26406"])
    assert {"date_in_future", "dates_out_of_order"} <= set(found)


def test_units_from_another_country_are_flagged(notices):
    """26382: about 5,600 in the US and 516 in Canada. 6,116 is not written in the notice."""
    record = RecallRecord.model_validate({
        **GOOD, "recall_number": "26382", "units": 6116, "recall_date": "2026-04-02", "sold_from": "2024-10",
        "sold_to": "2026-02", "retailers": ["Costco.com"], "hazards": ["impact"], "contact_email": None,
        "hazard_quote": "The canopy beams of the bed frames can collapse primarily when the bed is moved, posing "
                        "impact and injury hazards to consumers."})
    assert codes(record, notices["26382"]) == ["units_not_in_notice"]
