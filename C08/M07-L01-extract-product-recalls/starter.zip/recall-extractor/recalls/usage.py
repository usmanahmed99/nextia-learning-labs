"""Prices and cost (the course project's price table, with the same date)."""

# US dollars per million tokens (input, output). Output includes reasoning tokens.
# Azure AI Foundry, Global Standard deployments, prices checked on 2026-10-08. Check the current price page.
PRICES_CHECKED = "2026-10-08"
PRICES = {
    "chat-small": (0.10, 0.50),   # gpt-6-luna 2026-09-22
    "chat-strong": (2.00, 10.00),  # gpt-6.1-sol 2026-09-29
    "gemma3:4b": (0.0, 0.0),       # local model through Ollama: no price per token (your own computer)
}


def cost_usd(model: str, input_tokens: int, output_tokens: int) -> float | None:
    """None when the model is not in the price table: unknown cost is not zero cost."""
    if model not in PRICES:
        return None
    price_in, price_out = PRICES[model]
    return (input_tokens * price_in + output_tokens * price_out) / 1_000_000
