"""The shape of one extracted recall, as a Pydantic model and as the JSON schema sent to the provider.

Gate 1 (the schema) checks types, lists of allowed values and formats. It cannot check that a
value is true: that is the job of gate 2, the business checks in `checks.py`.
"""

from datetime import date
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

Category = Literal["furniture", "kitchen", "home_appliance", "heating_cooling", "lighting_decor",
                   "tools_cleaning", "pool_spa", "outdoor_living", "home_safety", "other"]
Hazard = Literal["fire", "burn", "electric_shock", "fall", "tip_over", "entrapment", "drowning", "impact",
                 "laceration", "amputation", "chemical", "poisoning", "choking", "carbon_monoxide", "other"]
Remedy = Literal["refund", "replace", "repair", "other"]


class RecallRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")

    recall_number: str = Field(pattern=r"^\d{5}$", description="The recall number of the notice.")
    product_name: str = Field(min_length=1, max_length=200,
                              description="The recalled product, with its brand, as the notice names it.")
    category: Category = Field(description="The kind of product. Use other if no value fits.")
    hazards: list[Hazard] = Field(min_length=1, max_length=4,
                                  description="Every hazard type that the notice names. Use other if none fits.")
    hazard_quote: str = Field(min_length=1, max_length=600,
                              description="The sentence of the notice that states the hazard, copied word for word.")
    units: int | None = Field(description="Units sold in the United States, as a whole number. Add the units of "
                                          "all recalled models. Do not add units sold in other countries. Null "
                                          "if the notice gives no number.")
    remedies: list[Remedy] = Field(min_length=1, max_length=3,
                                   description="What the consumer can get: refund, replace, repair or other.")
    recall_date: str = Field(pattern=r"^\d{4}-\d{2}-\d{2}$", description="The recall date, YYYY-MM-DD.")
    sold_from: str | None = Field(pattern=r"^\d{4}-\d{2}$",
                                  description="The first month of sale, YYYY-MM. Null if the notice does not say.")
    sold_to: str | None = Field(pattern=r"^\d{4}-\d{2}$",
                                description="The last month of sale, YYYY-MM. Null if the notice does not say.")
    retailers: list[str] = Field(max_length=12,
                                 description="Each store or website under Sold at, one name each, as written. "
                                             "Empty if the notice names none.")
    contact_phone: str | None = Field(description="The consumer contact phone number as written, or null.")
    contact_email: str | None = Field(description="The consumer contact email address as written, or null.")

    @field_validator("recall_date")
    @classmethod
    def real_date(cls, value: str) -> str:
        date.fromisoformat(value)  # 2026-02-30 matches the pattern but is not a date
        return value


def response_format() -> dict:
    """Ask the provider for JSON that follows the schema (structured output, strict mode)."""
    return {
        "type": "json_schema",
        "json_schema": {"name": "recall_record", "strict": True, "schema": RecallRecord.model_json_schema()},
    }
