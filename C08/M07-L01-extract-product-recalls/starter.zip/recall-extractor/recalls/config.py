"""Configuration from environment variables, and the choice of provider (as in the course project).

The key is read here and given only to the provider. It is never printed, logged or saved.
"""

import os
from dataclasses import dataclass, field
from pathlib import Path

from .providers import MockProvider, OpenAICompatibleProvider

ENV_FILE = Path(__file__).resolve().parent.parent / ".env"


def load_env_file(path: Path = ENV_FILE) -> None:
    """Read KEY=value lines from .env into the environment (variables already set win)."""
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            name, value = line.split("=", 1)
            os.environ.setdefault(name.strip(), value.strip().strip('"').strip("'"))


@dataclass(frozen=True)
class Settings:
    provider: str = "mock"            # "mock" or "openai_compatible"
    base_url: str = ""                # for example http://localhost:11434/v1 for Ollama
    api_key: str = field(default="", repr=False)  # repr=False: printing the settings never shows the key
    timeout_s: float = 60.0

    @classmethod
    def from_env(cls) -> "Settings":
        load_env_file()
        env = os.environ
        return cls(
            provider=env.get("RECALLS_PROVIDER", "mock"),
            base_url=env.get("RECALLS_BASE_URL", ""),
            api_key=env.get("RECALLS_API_KEY", ""),
            timeout_s=float(env.get("RECALLS_TIMEOUT_S", "60")),
        )


def make_provider(settings: Settings):
    if settings.provider == "mock":
        return MockProvider()
    if settings.provider == "openai_compatible":
        if not settings.base_url:
            raise ValueError("Set RECALLS_BASE_URL, for example http://localhost:11434/v1 for Ollama.")
        return OpenAICompatibleProvider(settings.base_url, settings.api_key, settings.timeout_s)
    raise ValueError(f"Unknown RECALLS_PROVIDER {settings.provider!r}: use mock or openai_compatible.")
