"""The recall notices: load the fixed sample and turn one record into the text a person reads.

The sample is 40 notices of the US Consumer Product Safety Commission (CPSC), from its Recalls API,
plus one later notice for the end-to-end run. `notice_text()` lays a record out with the headings of
the notice page on cpsc.gov. The model sees only this text.
"""

import hashlib
import json
from dataclasses import dataclass
from datetime import date
from pathlib import Path

DATA = Path(__file__).resolve().parent.parent / "data"
NOTICES = DATA / "notices.json"
NOTICES_SHA256 = "8deb39097a91aba3c201a188045504342353916f6a743cedb595f7e06f31ffe7"
NEW_NOTICE = "26773"  # September 2026: not in the reference set


@dataclass
class Notice:
    number: str
    url: str
    text: str
    record: dict


def _names(items: list[dict], key: str = "Name") -> list[str]:
    return [item[key].strip() for item in items if item.get(key, "").strip()]


def _long_date(value: str) -> str:
    day = date.fromisoformat(value[:10])
    return f"{day:%B} {day.day}, {day.year}"


def notice_text(record: dict) -> str:
    """The notice as one text, in the order of the cpsc.gov page."""
    products = record["Products"]
    firms = (_names(record["Manufacturers"]) + _names(record["Importers"])
             + _names(record["Distributors"]))
    parts = [
        ("Recall number", record["RecallNumber"]),
        ("Title", record["Title"]),
        ("Name of product", "; ".join(_names(products))),
        ("Hazard", " ".join(_names(record["Hazards"]))),
        ("Remedy", ", ".join(_names(record["RemedyOptions"], "Option"))),
        ("Recall date", _long_date(record["RecallDate"])),
        ("Units", "; ".join(p["NumberOfUnits"].strip() for p in products if p["NumberOfUnits"].strip())),
        ("Consumer contact", record["ConsumerContact"]),
        ("Description", record["Description"]),
        ("Remedy details", " ".join(_names(record["Remedies"]))),
        ("Incidents/Injuries", " ".join(_names(record["Injuries"]))),
        ("Sold at", " ".join(_names(record["Retailers"]))),
        ("Manufacturer / importer / distributor", "; ".join(firms)),
        ("Manufactured in", ", ".join(_names(record["ManufacturerCountries"], "Country"))),
    ]
    return "\n".join(f"{label}: {' '.join(value.split())}" for label, value in parts if value.strip())


def load_notices(check: bool = True) -> dict[str, Notice]:
    raw = NOTICES.read_bytes()
    if check and hashlib.sha256(raw).hexdigest() != NOTICES_SHA256:
        raise ValueError(f"{NOTICES} has changed: its SHA-256 does not match the course's copy.")
    return {r["RecallNumber"]: Notice(r["RecallNumber"], r["URL"], notice_text(r), r)
            for r in json.loads(raw)}


def load_notice(number: str) -> Notice:
    notices = load_notices()
    if number not in notices:
        raise KeyError(f"No notice {number} in the sample.")
    return notices[number]


def section(text: str, label: str) -> str:
    """The value of one 'Label: value' line of a notice text ('' if the notice has no such line)."""
    for line in text.splitlines():
        if line.startswith(label + ": "):
            return line[len(label) + 2:]
    return ""
