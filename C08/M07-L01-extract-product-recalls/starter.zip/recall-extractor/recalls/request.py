"""Build one Chat Completions request for one notice: the same prompt with or without the schema."""

from pathlib import Path

from .notices import Notice
from .schema import response_format

PROMPT = Path(__file__).resolve().parent / "prompts" / "extract.md"
MAX_TOKENS = 4000  # room for hidden reasoning and the JSON record (about 250 tokens)


def build_messages(notice: Notice) -> list[dict]:
    text = PROMPT.read_text(encoding="utf-8")
    system, user = text.split("[system]\n", 1)[1].split("[user]\n", 1)
    body = notice.text.replace("<notice>", "(notice)").replace("</notice>", "(/notice)")
    return [
        {"role": "system", "content": system.strip()},
        {"role": "user", "content": user.strip().replace("{notice}", body)},
    ]


def build_request(notice: Notice, model: str, schema: bool = True) -> dict:
    """schema=True sends the JSON schema (structured output, strict). schema=False: the prompt alone."""
    request = {"model": model, "messages": build_messages(notice), "max_completion_tokens": MAX_TOKENS}
    if schema:
        request["response_format"] = response_format()
    return request
