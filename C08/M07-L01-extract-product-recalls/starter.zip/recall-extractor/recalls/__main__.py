"""The command line.

    python -m recalls show 26406                        the notice text that the model reads
    python -m recalls extract 26406                     one notice: the record, both gates, the cost
    python -m recalls extract 26406 --plain             the same prompt without the schema
    python -m recalls eval --model chat-strong          40 notices against the reference
    python -m recalls eval --baseline                   the same, with plain code and no model
    python -m recalls errors                            schema-valid fields that are still wrong
"""

import argparse
import json
import statistics
import sys
from collections import Counter

from .baseline import extract as baseline_extract
from .checks import check_rules
from .config import Settings, make_provider
from .extract import TODAY, extract
from .notices import load_notice, load_notices
from .score import FIELDS, compare, load_reference


def percentile(values: list[float], share: float) -> float:
    values = sorted(values)
    return values[min(len(values) - 1, int(round(share * (len(values) - 1))))]


def run_all(args) -> list:
    """One outcome per reference notice (the recorded answers through the mock, or a live provider)."""
    notices, reference = load_notices(), load_reference()
    if args.baseline:
        rows = []
        for number in sorted(reference):
            record = baseline_extract(notices[number])
            rows.append((number, record, check_rules(record, notices[number], TODAY), None))
        return rows
    provider = make_provider(Settings.from_env())
    rows = []
    for number in sorted(reference):
        outcome = extract(provider, notices[number], args.model, not args.plain)
        record = outcome.verdict.record if outcome.verdict else None
        problems = outcome.verdict.problems if outcome.verdict else []
        rows.append((number, record, problems, outcome))
    return rows


def cmd_show(args) -> int:
    print(load_notice(args.number).text)
    return 0


def cmd_extract(args) -> int:
    notice = load_notice(args.number)
    outcome = extract(make_provider(Settings.from_env()), notice, args.model, not args.plain)
    if outcome.status == "failed":
        print(f"failed | {outcome.error}")
        return 2
    c, verdict = outcome.completion, outcome.verdict
    if verdict.record is not None:
        print(json.dumps(verdict.record.model_dump(), indent=2, ensure_ascii=False))
    elif c.text:
        print("The answer starts with:\n" + "\n".join(c.text.splitlines()[:4]))
    for problem in verdict.problems:
        print(f"  {problem.code}: {problem.message}")
    cost = outcome.cost_usd
    print(f"{outcome.status} | {args.model} | {'plain prompt' if args.plain else 'schema'} | "
          f"{c.input_tokens} tokens in, {c.output_tokens} out ({c.reasoning_tokens} reasoning) | "
          f"{c.latency_s:.2f} s | " + (f"US${cost:.5f}" if cost is not None else "cost unknown"))
    return 0 if outcome.status == "valid" else 1


def cmd_eval(args) -> int:
    reference = load_reference()
    rows = run_all(args)
    correct, gate1, gate2 = Counter(), Counter(), Counter()
    flagged = all_right = 0
    for number, record, problems, outcome in rows:
        if record is None:
            gate1.update(p.code for p in outcome.verdict.problems) if outcome.verdict else gate1.update(["failed"])
        elif problems:
            flagged += 1
            gate2.update(p.code for p in problems)
        result = compare(record, reference[number])
        correct.update(f for f, ok in result.items() if ok)
        all_right += all(result.values())
    n = len(rows)
    name = "baseline (no model)" if args.baseline else f"{args.model} | {'plain prompt' if args.plain else 'schema'}"
    print(f"{name} | {n} notices")
    print(f"gate 1 (schema): {n - sum(gate1.values())} passed" +
          (f", {sum(gate1.values())} without a record {dict(gate1)}" if gate1 else ""))
    print(f"gate 2 (business checks): {flagged} flagged" + (f" {dict(gate2)}" if gate2 else ""))
    for f in FIELDS:
        print(f"  {f:<14} {correct[f]:>2}/{n}")
    total = sum(correct.values())
    print(f"fields right: {total}/{n * len(FIELDS)} ({total / (n * len(FIELDS)):.1%}) | "
          f"notices with every field right: {all_right}/{n}")
    outcomes = [o for *_, o in rows if o and o.completion]
    if outcomes:
        tokens_in = statistics.median(o.completion.input_tokens for o in outcomes)
        tokens_out = statistics.median(o.completion.output_tokens for o in outcomes)
        latencies = [o.completion.latency_s for o in outcomes]
        costs = [o.cost_usd for o in outcomes]
        print(f"median tokens in / out: {tokens_in:.0f} / {tokens_out:.0f} | latency median "
              f"{statistics.median(latencies):.2f} s, p95 {percentile(latencies, 0.95):.2f} s")
        if None not in costs:
            print(f"cost per 1,000 notices: US${statistics.mean(costs) * 1000:.2f} (prices of 2026-10-08)")
    return 0


def cmd_errors(args) -> int:
    """Fields that passed the schema (and maybe gate 2) but differ from the reference."""
    reference = load_reference()
    shown = 0
    for number, record, problems, _ in run_all(args):
        if record is None:
            continue
        data = record.model_dump()
        for field, ok in compare(record, reference[number]).items():
            if not ok:
                gate = "flagged by gate 2" if problems else "passed both gates"
                print(f"{number} {field:<13} got {json.dumps(data[field], ensure_ascii=False)} | "
                      f"reference {json.dumps(reference[number][field], ensure_ascii=False)} | {gate}")
                shown += 1
    print(f"{shown} wrong fields in records that passed the schema")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="python -m recalls")
    sub = parser.add_subparsers(dest="command", required=True)
    show = sub.add_parser("show")
    show.add_argument("number")
    for name in ("extract", "eval", "errors"):
        p = sub.add_parser(name)
        if name == "extract":
            p.add_argument("number")
        else:
            p.add_argument("--baseline", action="store_true", help="plain code, no model")
        p.add_argument("--model", default="chat-small")
        p.add_argument("--plain", action="store_true", help="the same prompt without the schema")
    args = parser.parse_args(argv)
    return {"show": cmd_show, "extract": cmd_extract, "eval": cmd_eval, "errors": cmd_errors}[args.command](args)


if __name__ == "__main__":
    sys.exit(main())
