"""The baseline: plain code, no model. It reads the labelled lines of the notice with patterns.

It shows what a model must beat. Fields that are already structured (the date, the Remedy line,
the phone and email) need no model at all.
"""

import re
from datetime import datetime

from .notices import Notice, section
from .schema import RecallRecord

MONTHS = "January|February|March|April|May|June|July|August|September|October|November|December"
CATEGORY_WORDS = [  # the first match wins
    ("pool_spa", r"pool|spa\b|hot tub"),
    ("furniture", r"dresser|bed frame|chair|sofa|table|shelf|furniture"),
    ("kitchen", r"pan|pot|kettle|coffee|range|oven|food|bottle|bowl|cooker"),
    ("heating_cooling", r"heater|fan|air condition|heat pump|kerosene"),
    ("lighting_decor", r"light|lamp|ornament|sphere"),
    ("tools_cleaning", r"pressure washer|extension cord|generator|tool|cleaner|sodium hydroxide|lye"),
    ("outdoor_living", r"patio|swing|grill|cooler|outdoor"),
    ("home_safety", r"smoke|detector|alarm|camera"),
]
HAZARD_WORDS = [("fire", r"fire"), ("burn", r"burn"), ("electric_shock", r"shock|electrocut"), ("fall", r"\bfall"),
                ("tip_over", r"tip-over"), ("entrapment", r"entrap"), ("drowning", r"drown"), ("impact", r"impact"),
                ("laceration", r"lacerat"), ("amputation", r"amputat"), ("chemical", r"chemical"),
                ("poisoning", r"poison"), ("choking", r"chok"), ("carbon_monoxide", r"carbon monoxide")]


def _first_number(text: str) -> int | None:
    match = re.search(r"(\d[\d,]*(?:\.\d+)?)( million)?", text)
    if not match:
        return None
    number = float(match.group(1).replace(",", ""))
    return int(round(number * 1_000_000)) if match.group(2) else int(number)


def _month(text: str) -> str:
    return datetime.strptime(text, "%B %Y").strftime("%Y-%m")


def _retailers(sold_at: str) -> list[str]:
    before = re.split(rf"\b(?:from|between|since)\b (?:around )?(?:{MONTHS})", sold_at)[0]
    before = re.sub(r"(?i)^(the recalled .*? were sold )?(online )?(at|in stores at) ", "", before.strip())
    names = []
    for part in re.split(r",| and | including |online at|stores nationwide", before):
        part = re.sub(r"(?i)\b(online|in stores at|at|stores?|nationwide|other.*|exclusively)\b", "", part).strip(" .")
        if part and part[0].isupper():
            names.append(part)
    return names


def extract(notice: Notice) -> RecallRecord:
    text = notice.text
    hazard = section(text, "Hazard")
    dates = re.findall(rf"({MONTHS}) (?:of )?(\d{{4}})", section(text, "Sold at"))
    phone = re.search(r"\d{3}-\d{3}-\d{4}", section(text, "Consumer contact"))
    email = re.search(r"[\w.+-]+@[\w-]+\.[a-z]+", section(text, "Consumer contact"))
    product = section(text, "Name of product")
    category = next((c for c, words in CATEGORY_WORDS if re.search(words, product, re.I)), "other")
    hazards = [h for h, words in HAZARD_WORDS if re.search(words, hazard, re.I)] or ["other"]
    remedies = [r.strip().lower() for r in section(text, "Remedy").split(",") if r.strip()]
    return RecallRecord(
        recall_number=notice.number,
        product_name=product[:200] or "(none)",
        category=category,
        hazards=hazards[:4],
        hazard_quote=re.split(r"(?<=\.) ", hazard)[0] or "(none)",
        units=_first_number(section(text, "Units")),
        remedies=[r if r in ("refund", "replace", "repair") else "other" for r in remedies][:3] or ["other"],
        recall_date=datetime.strptime(section(text, "Recall date"), "%B %d, %Y").strftime("%Y-%m-%d"),
        sold_from=_month(" ".join(dates[0])) if dates else None,
        sold_to=_month(" ".join(dates[-1])) if len(dates) > 1 else None,
        retailers=_retailers(section(text, "Sold at"))[:12],
        contact_phone=phone.group(0) if phone else None,
        contact_email=email.group(0) if email else None,
    )
