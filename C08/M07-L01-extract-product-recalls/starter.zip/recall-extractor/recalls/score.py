"""Compare extracted records with the hand-checked reference, field by field.

Ten fields are scored. product_name and hazard_quote are free text: a person reads them, and gate 2
checks that the quote is in the notice. A notice without a record (gate 1 failed) scores 0 on every
field: nothing usable came back.
"""

import json
from pathlib import Path

from .schema import RecallRecord

REFERENCE = Path(__file__).resolve().parent.parent / "data" / "reference.json"
FIELDS = ["category", "hazards", "units", "remedies", "recall_date", "sold_from", "sold_to", "retailers",
          "contact_phone", "contact_email"]


def load_reference() -> dict[str, dict]:
    return {r["number"]: r for r in json.loads(REFERENCE.read_text(encoding="utf-8"))}


def retailer_key(name: str) -> str:
    """'www.Walmart.com' and 'Walmart' are the same shop for the safety team: 'walmart'."""
    raise NotImplementedError("Write retailer_key() in Part 4 of the case study.")


def normalise(field: str, value):
    """Put a value in the form we compare: sets for lists, digits for phones, lower case for emails."""
    raise NotImplementedError("Write normalise() in Part 4 of the case study.")


def compare(record: RecallRecord | None, reference: dict) -> dict[str, bool]:
    """True for each field that matches the reference."""
    raise NotImplementedError("Write compare() in Part 4 of the case study.")
