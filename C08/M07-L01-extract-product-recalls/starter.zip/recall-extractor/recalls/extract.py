"""Extract one notice: build the request, call the provider, run both gates, and measure the call."""

from dataclasses import dataclass
from datetime import date

from .checks import Verdict, validate
from .notices import Notice
from .providers import Completion, ProviderError
from .request import build_request
from .usage import cost_usd

TODAY = date(2026, 10, 8)  # the day the sample was downloaded; the checks compare dates with it


@dataclass
class Outcome:
    notice: Notice
    model: str  # the deployment name, for the price table
    status: str  # "valid" (both gates passed), "flagged" (gate 2 found problems), "rejected" (gate 1), "failed"
    verdict: Verdict | None
    completion: Completion | None
    error: str = ""

    @property
    def cost_usd(self) -> float | None:
        c = self.completion
        return cost_usd(self.model, c.input_tokens, c.output_tokens) if c else None


def extract(provider, notice: Notice, model: str, schema: bool = True, today: date = TODAY) -> Outcome:
    request = build_request(notice, model, schema)
    try:
        completion = provider.complete(request)
    except ProviderError as e:
        return Outcome(notice, model, "failed", None, None, str(e))
    verdict = validate(completion, notice, today)
    if verdict.record is None:
        status = "rejected"
    else:
        status = "flagged" if verdict.problems else "valid"
    return Outcome(notice, model, status, verdict, completion)
