# recall-extractor

Turn public product-recall notices into structured, checked records. A case study of the course *Building Reliable Applications with LLM APIs* on Nextia Learning: https://learning.nextia-ai.com/courses/llm-apps/m07/extract-product-recalls/

The project reads 40 recall notices of the US Consumer Product Safety Commission (CPSC), asks a model to fill one record per notice, and checks every record twice: against a schema (gate 1) and against the notice itself (gate 2). It then scores each field against a reference that a person checked by hand.

**No account is needed.** The default provider is a mock that replays real recorded answers (gpt-6-luna as `chat-small` and gpt-6.1-sol as `chat-strong` on Azure, and Gemma 3 4B through Ollama). A live run is optional.

## Set up

Python 3.12 or newer.

```sh
python3 -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m pytest
```

## Commands

```sh
python -m recalls show 26382                         # the notice text that the model reads
python -m recalls extract 26382                      # one record, both gates, tokens, time and cost
python -m recalls extract 26382 --plain              # the same prompt, without the schema
python -m recalls extract 26382 --model gemma3:4b    # the recorded answer of the local model
python -m recalls eval --baseline                    # plain code, no model
python -m recalls eval --model chat-strong           # 40 notices against the reference
python -m recalls errors --model gemma3:4b --plain   # fields that passed the schema but are wrong
python -m recalls extract 26773                      # the new notice (September 2026), not in the reference
```

## Files

| File | What it does |
|---|---|
| `recalls/notices.py` | Loads `data/notices.json` (SHA-256 checked) and lays a record out as the notice text |
| `recalls/schema.py` | `RecallRecord` (Pydantic) and `response_format()` (strict JSON schema) |
| `recalls/prompts/extract.md` | The instructions; the same for both modes |
| `recalls/request.py` | `build_request(notice, model, schema)` |
| `recalls/providers.py`, `recalls/config.py` | The course's adapter: `MockProvider` and `OpenAICompatibleProvider` |
| `recalls/checks.py` | Gate 1 `parse()` and gate 2 `check_rules()` |
| `recalls/extract.py` | One notice end to end: `Outcome` with `valid`, `flagged`, `rejected` or `failed` |
| `recalls/score.py` | Field-by-field comparison with `data/reference.json` |
| `recalls/baseline.py` | The baseline without a model |
| `recalls/usage.py` | The dated price table and `cost_usd()` |
| `data/notices.json` | 41 CPSC notices (40 in the reference, and 26773) |
| `data/reference.json` | The hand-checked records of the 40 notices |
| `recordings/*.jsonl` | The recorded answers that the mock replays |

## Live run (optional)

Copy `.env.example` to `.env`. For a free local run, install Ollama, run `ollama pull gemma3:4b`, and set `RECALLS_PROVIDER=openai_compatible` and `RECALLS_BASE_URL=http://localhost:11434/v1`. Then `python -m recalls extract 26382 --model gemma3:4b`. A local model gives other answers than the recordings: the numbers change.

## Data and licence

The notices come from the CPSC Recalls API (https://www.saferproducts.gov/RestWebServices/Recall), downloaded on 2026-10-08. They are US government works; CPSC allows free copying and distribution of recall notices, asks for credit, and does not allow any use that states or implies its endorsement. See `DATASET.md`. **The records that this project makes are not official recall information.** Always check the notice on cpsc.gov.

The code is under the MIT licence (`LICENSE`).
