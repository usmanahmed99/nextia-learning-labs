"""Two gates between the model and the safety team's list: the schema, then the business checks.

Gate 1 (`parse`) asks: is there a complete answer, and does it follow the schema?
Gate 2 (`check_rules`) asks: does the record agree with the notice and with the calendar?
A record that passes both gates can still be wrong. A person checks it before anyone uses it.
"""

import json
import re
from dataclasses import dataclass, field
from datetime import date

from pydantic import ValidationError

from .notices import Notice, section
from .providers import Completion
from .schema import RecallRecord

# The words that show each hazard type in the notice (the Hazard line or the title).
HAZARD_WORDS = {
    "fire": r"fire|flame|ignit",
    "burn": r"burn|scald",
    "electric_shock": r"shock|electrocut",
    "fall": r"\bfall",
    "tip_over": r"tip-over|tip over",
    "entrapment": r"entrap",
    "drowning": r"drown",
    "impact": r"impact|struck",
    "laceration": r"lacerat|\bcut",
    "amputation": r"amputat",
    "chemical": r"chemical|corros",
    "poisoning": r"poison",
    "choking": r"chok",
    "carbon_monoxide": r"carbon monoxide|\bCO\b",
    "other": r".",
}


@dataclass
class Problem:
    code: str
    message: str


@dataclass
class Verdict:
    record: RecallRecord | None
    problems: list[Problem] = field(default_factory=list)

    @property
    def valid(self) -> bool:
        return self.record is not None and not self.problems


def parse(completion: Completion) -> Verdict:
    """Gate 1: is there a complete answer, and does it follow the schema?"""
    if completion.refusal:
        return Verdict(None, [Problem("refusal", f"The model refused: {completion.refusal}")])
    if completion.finish_reason == "length":
        return Verdict(None, [Problem("truncated", "The answer was cut off at the token limit.")])
    if not completion.text:
        return Verdict(None, [Problem("empty", "The answer has no text.")])
    try:
        data = json.loads(completion.text)
    except json.JSONDecodeError as e:
        return Verdict(None, [Problem("malformed_json", f"Not valid JSON: {e.msg} at character {e.pos}.")])
    try:
        return Verdict(RecallRecord.model_validate(data))
    except ValidationError as e:
        details = "; ".join(f"{'.'.join(map(str, err['loc'])) or '(top)'}: {err['msg']}" for err in e.errors())
        return Verdict(None, [Problem("schema", details)])


def _flat(text: str) -> str:
    """Lower case, one space between words, straight quotes: for 'does this text appear in the notice?'"""
    text = text.replace("’", "'").replace("“", '"').replace("”", '"')
    return " ".join(text.lower().split())


def _long_date(day: date) -> str:
    return f"{day:%B} {day.day}, {day.year}"


def _month(value: str) -> tuple[int, int]:
    year, month = value.split("-")
    return int(year), int(month)


def _units_forms(units: int) -> list[str]:
    """The ways a notice writes a number of units: 5600, 5,600, 1.7 million."""
    forms = [str(units), f"{units:,}"]
    if units >= 1_000_000:
        forms.append(f"{units / 1_000_000:g} million")
    return forms


def check_rules(record: RecallRecord, notice: Notice, today: date) -> list[Problem]:
    """Gate 2: valid JSON can still be wrong. Check it against the notice and the calendar."""
    problems = []
    text = _flat(notice.text)
    hazard_text = _flat(section(notice.text, "Hazard") + " " + section(notice.text, "Title"))
    sold_at = _flat(section(notice.text, "Sold at"))
    contact = _flat(section(notice.text, "Consumer contact"))

    if record.recall_number != notice.number:
        problems.append(Problem("wrong_notice", f"Recall number {record.recall_number} is not {notice.number}."))
    recalled = date.fromisoformat(record.recall_date)
    if recalled > today:
        problems.append(Problem("date_in_future", f"The recall date {recalled} is after today ({today})."))
    if _flat(_long_date(recalled)) not in text:
        problems.append(Problem("date_not_in_notice", f"The notice does not give {_long_date(recalled)}."))
    if record.sold_from and record.sold_to and _month(record.sold_from) > _month(record.sold_to):
        problems.append(Problem("dates_out_of_order", f"Sold from {record.sold_from} is after {record.sold_to}."))
    if record.sold_to and _month(record.sold_to) > (recalled.year, recalled.month):
        problems.append(Problem("sold_after_recall", f"Sold to {record.sold_to} is after the recall date."))
    if record.units is not None:
        if record.units <= 0:
            problems.append(Problem("units_not_positive", f"Units must be a positive number, not {record.units}."))
        elif not any(_flat(form) in text for form in _units_forms(record.units)):
            problems.append(Problem("units_not_in_notice",
                                    f"{record.units:,} units is not written in the notice: a person checks the sum."))
    if _flat(record.hazard_quote) not in text:
        problems.append(Problem("quote_not_in_notice", "The hazard quote is not in the notice word for word."))
    for hazard in record.hazards:
        if not re.search(HAZARD_WORDS[hazard], hazard_text, re.IGNORECASE):
            problems.append(Problem("hazard_not_in_notice", f"The notice's hazard text does not mention {hazard}."))
    for name in record.retailers:
        if _flat(name) not in sold_at:
            problems.append(Problem("retailer_not_in_notice", f"{name!r} is not named under Sold at."))
    if record.contact_phone and _flat(record.contact_phone) not in contact:
        problems.append(Problem("phone_not_in_notice", f"{record.contact_phone} is not in the consumer contact."))
    if record.contact_email and _flat(record.contact_email) not in contact:
        problems.append(Problem("email_not_in_notice", f"{record.contact_email} is not in the consumer contact."))
    return problems


def validate(completion: Completion, notice: Notice, today: date) -> Verdict:
    verdict = parse(completion)
    if verdict.record is not None:
        verdict.problems = check_rules(verdict.record, notice, today)
    return verdict
