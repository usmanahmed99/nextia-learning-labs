"""Compare extracted records with the hand-checked reference, field by field.

Ten fields are scored. product_name and hazard_quote are free text: a person reads them, and gate 2
checks that the quote is in the notice. A notice without a record (gate 1 failed) scores 0 on every
field: nothing usable came back.
"""

import json
import re
from pathlib import Path

from .schema import RecallRecord

REFERENCE = Path(__file__).resolve().parent.parent / "data" / "reference.json"
FIELDS = ["category", "hazards", "units", "remedies", "recall_date", "sold_from", "sold_to", "retailers",
          "contact_phone", "contact_email"]


def load_reference() -> dict[str, dict]:
    return {r["number"]: r for r in json.loads(REFERENCE.read_text(encoding="utf-8"))}


def retailer_key(name: str) -> str:
    """'www.Walmart.com' and 'Walmart' are the same shop for the safety team: 'walmart'."""
    name = name.lower().strip()
    name = re.sub(r"^www\.", "", name)
    name = re.sub(r"\.com$", "", name)
    return re.sub(r"[^a-z0-9]", "", name)


def normalise(field: str, value):
    """Put a value in the form we compare: sets for lists, digits for phones, lower case for emails."""
    if value is None:
        return None
    if field in ("hazards", "remedies"):
        return frozenset(value)
    if field == "retailers":
        return frozenset(retailer_key(v) for v in value)
    if field == "contact_phone":
        return re.sub(r"\D", "", value)
    if field == "contact_email":
        return value.lower()
    return value


def compare(record: RecallRecord | None, reference: dict) -> dict[str, bool]:
    """True for each field that matches the reference."""
    if record is None:
        return {f: False for f in FIELDS}
    data = record.model_dump()
    return {f: normalise(f, data[f]) == normalise(f, reference[f]) for f in FIELDS}
