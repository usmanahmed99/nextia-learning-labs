# stats-assistant

> **This is the starter project.** It has the adapter, the settings, the data snapshot with its checksums,
> the instructions and the schema, the scoring, the recordings and the tests. You write four files, part by
> part, as the case study page shows: `stats_assistant/tools.py` (Part 2), `stats_assistant/loop.py` (Part 3),
> `stats_assistant/check.py` and `stats_assistant/ask.py` (Part 4). The tests of each part are skipped until its
> file exists. Until Part 4, only the commands `python -m pytest` and (from Part 2) `tool` work.

An assistant that answers questions about public statistics, built in the case study *Answer questions with tools over open data* of the course *Building Reliable Applications with LLM APIs* on [Nextia Learning](https://learning.nextia-ai.com/courses/llm-apps/m07/answer-questions-with-tools/).

The model never sees the data directly. It asks for numbers through three **read-only tools**, and the application checks every argument against an allow-list before it reads anything. A **bounded loop** limits steps, tool calls, time and result size. Before an answer is shown, an **answer check** rejects any number that the application did not give the model. The application, not the model, writes the source line.

You need no account and no key. The **mock provider** replays the answers that real models gave when the case study was recorded (gpt-6-luna as `chat-small` and gpt-6.1-sol as `chat-strong` on Azure, 2026-10-08).

## Set up (once)

You need Python 3.12 or newer. In a terminal, in this folder:

```sh
python3 -m venv .venv
source .venv/bin/activate              # Windows (PowerShell): .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m pytest
```

On Windows, use `python` where these steps say `python3`.

## Run

```sh
python -m stats_assistant ask Q01                                   # one question of the set, with tools
python -m stats_assistant ask Q20                                   # a ratio the model calculated: rejected
python -m stats_assistant ask Q05 --design fetch-first              # the whole table in the prompt, no tools
python -m stats_assistant ask Q01 --model chat-strong               # HTTP 400: no tools on that deployment
python -m stats_assistant eval                                      # the 27 questions, scored
python -m stats_assistant eval --design fetch-first --model chat-strong
python -m stats_assistant tool get_values '{"country_code": "CAN", "indicator_code": "SP.POP.TOTL", "start_year": 2023, "end_year": 2024}'
```

In PowerShell, write the JSON of the `tool` command with doubled inner quotes or from a variable; the case study page shows how.

`ask` prints the result and one line: `valid` (shown to a reader, with the source), `rejected` (a check stopped it; `problems` says which) or `failed` (no answer; `error` says why).

## What is where

| Path | What it does |
|---|---|
| `stats_assistant/providers.py`, `config.py` | The adapter and the settings, copied unchanged from the course's `ticket-assistant` |
| `stats_assistant/data.py` | The snapshot: checksums first, then read-only access |
| `stats_assistant/tools.py` | The three tools: descriptions, argument checks, the reads |
| `stats_assistant/loop.py` | The bounded tool loop |
| `stats_assistant/context.py` | The instructions, the question as untrusted text, the output schema, the two designs |
| `stats_assistant/check.py`, `ask.py` | The answer check (no unsupported numbers) and one question end to end |
| `stats_assistant/evaluate.py`, `usage.py` | Scoring, prices |
| `data/` | The snapshot, `SHA256SUMS`, and `questions.json` (27 questions with expected answers computed from the data) |
| `recordings/` | The recorded answers that the mock replays |

## Optional: a live model

Copy `.env.example` to `.env` and set a provider. A request that was not recorded cannot be replayed by the mock: you see `No recording for this request`. That happens with your own questions while the mock is on. Not tested for this case study: Ollama models with tools.

## Data and licence

Code: MIT (see `LICENSE`). Data: The World Bank: World Development Indicators, CC BY 4.0, snapshot of 2026-10-08, reshaped by Nextia Learning; see `DATASET.md` for the data providers and the limits. The recorded answers are model outputs, CC0 1.0.

An answer from this assistant is not an official figure. Check the World Bank's current value and its date before you publish a number.
