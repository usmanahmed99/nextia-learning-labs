import json

import pytest

pytest.importorskip("stats_assistant.tools", reason="Part 2: write stats_assistant/tools.py")
from stats_assistant.tools import TOOLS, run_tool  # noqa: E402


def call(name, data, **arguments):
    return run_tool(name, json.dumps(arguments), data)


def test_three_tools_each_strict_with_no_extra_arguments():
    assert [t["function"]["name"] for t in TOOLS] == ["get_values", "rank_countries", "get_change"]
    assert all(t["function"]["strict"] and not t["function"]["parameters"]["additionalProperties"] for t in TOOLS)


def test_get_values_reads_the_snapshot(data):
    output, outcome = call("get_values", data, country_code="CAN", indicator_code="SP.POP.TOTL",
                           start_year=2023, end_year=2024)
    assert outcome == "ok"
    assert output["values"] == [{"year": 2023, "value": 40049088}, {"year": 2024, "value": 41262329}]


@pytest.mark.parametrize("arguments, code", [
    ({"country_code": "FRA", "indicator_code": "SP.POP.TOTL", "start_year": 2023, "end_year": 2023}, "not_allowed"),
    ({"country_code": "ALL", "indicator_code": "SP.POP.TOTL", "start_year": 1900, "end_year": 2100}, "not_allowed"),
    ({"country_code": "CAN", "indicator_code": "SL.UEM.TOTL.ZS", "start_year": 2023, "end_year": 2023},
     "not_allowed"),
    ({"country_code": "CAN", "indicator_code": "SP.POP.TOTL", "start_year": 1960, "end_year": 2025},
     "year_out_of_range"),
    ({"country_code": "CAN", "indicator_code": "SP.POP.TOTL", "start_year": 2024, "end_year": 2020},
     "invalid_argument"),
    ({"country_code": "CAN", "indicator_code": "SP.POP.TOTL", "start_year": "2020", "end_year": 2024},
     "invalid_argument"),
    ({"country_code": "CAN", "indicator_code": "SP.POP.TOTL", "start_year": True, "end_year": 2024},
     "invalid_argument"),
    ({"country_code": ["CAN"], "indicator_code": "SP.POP.TOTL", "start_year": 2020, "end_year": 2024},
     "not_allowed"),
    ({"country_code": "CAN", "indicator_code": "SP.POP.TOTL", "start_year": 2020, "end_year": 2024, "sql": "x"},
     "invalid_argument"),
])
def test_bad_arguments_are_refused_before_any_read(data, arguments, code):
    output, outcome = call("get_values", data, **arguments)
    assert output["ok"] is False and outcome == f"refused: {code}"


def test_a_refusal_says_what_is_allowed(data):
    output, _ = call("get_values", data, country_code="FRA", indicator_code="SP.POP.TOTL",
                     start_year=2023, end_year=2023)
    assert "Available: BRA, CAN, GBR, IND, JPN, MEX, NGA, USA." in output["error"]


def test_unknown_tool_and_broken_json_are_refused(data):
    assert run_tool("delete_values", "{}", data)[1] == "refused: unknown_tool"
    assert run_tool("get_values", "{not json", data)[1] == "refused: invalid_argument"


def test_rank_countries_lists_missing_values_apart(data):
    output, _ = call("rank_countries", data, indicator_code="SP.DYN.LE00.IN", year=2023)
    assert output["ranking"][0]["country"] == "Japan" and output["missing"] == []
    output, _ = call("rank_countries", data, indicator_code="SP.DYN.LE00.IN", year=2025)
    assert output["ranking"] == [] and len(output["missing"]) == 8


def test_get_change_does_the_arithmetic(data):
    output, _ = call("get_change", data, country_code="NGA", indicator_code="NY.GDP.MKTP.CD",
                     from_year=2023, to_year=2024)
    assert output["percent_change"] == -48.24


def test_get_change_refuses_a_missing_value(data):
    _, outcome = call("get_change", data, country_code="JPN", indicator_code="SP.DYN.LE00.IN",
                      from_year=2020, to_year=2025)
    assert outcome == "refused: no_value"
