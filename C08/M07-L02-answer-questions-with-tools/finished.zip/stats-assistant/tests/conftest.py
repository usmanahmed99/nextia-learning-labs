import pytest

from stats_assistant.data import load_snapshot


@pytest.fixture(autouse=True)
def use_the_mock(monkeypatch):
    """Tests always use the recorded answers, even when .env names a live provider."""
    monkeypatch.setenv("ASSISTANT_PROVIDER", "mock")
    monkeypatch.setenv("ASSISTANT_MODEL", "chat-small")


@pytest.fixture(scope="session")
def data():
    return load_snapshot()
