import pytest

pytest.importorskip("stats_assistant.ask", reason="Part 4: write stats_assistant/ask.py")
from stats_assistant.ask import ask  # noqa: E402
from stats_assistant.evaluate import load_questions, row, summary  # noqa: E402
from stats_assistant.providers import MockProvider  # noqa: E402

QUESTIONS = {q["id"]: q for q in load_questions()}


@pytest.fixture(scope="module")
def mock():
    return MockProvider()


def run(mock, data, qid, model="chat-small", design="tools"):
    return ask(QUESTIONS[qid]["question"], mock, model, data, design=design)


def test_a_lookup_is_valid_and_the_application_writes_the_source(mock, data):
    outcome = run(mock, data, "Q01")
    assert outcome.status == "valid" and "41,262,329" in outcome.answer["answer"]
    assert outcome.source.startswith("Source: World Bank, World Development Indicators (CC BY 4.0)")
    assert "SP.POP.TOTL" in outcome.source


def test_a_ratio_that_the_model_calculated_is_rejected(mock, data):
    outcome = run(mock, data, "Q20")
    assert outcome.status == "rejected" and outcome.problems == ["unsupported_number: 12.9"]


def test_a_forbidden_argument_is_refused_and_the_model_declines(mock, data):
    outcome = run(mock, data, "Q27")
    assert [s.outcome for s in outcome.steps] == ["refused: not_allowed"]
    assert outcome.status == "valid" and outcome.answer["status"] == "cannot_answer"


def test_chat_strong_cannot_use_tools_in_chat_completions(mock, data):
    outcome = run(mock, data, "Q01", model="chat-strong")
    assert outcome.status == "failed" and "HTTP 400" in outcome.error


def test_a_question_that_was_not_recorded_fails_clearly(mock, data):
    outcome = ask("What was Canada's population in 2023?", mock, "chat-small", data)
    assert outcome.status == "failed" and "No recording" in outcome.error


def test_the_check_cannot_see_a_number_from_the_wrong_year(mock, data):
    outcome = run(mock, data, "Q05", design="fetch-first")  # real: the 2021 value given for 2022
    assert outcome.status == "valid" and "75.62650476" in outcome.answer["answer"]


def test_the_question_set_with_tools(mock, data):
    rows = [row(q, ask(q["question"], mock, "chat-small", data), "chat-small") for q in QUESTIONS.values()]
    result = summary(rows)
    assert result["correct"] == 27 and result["valid_but_wrong"] == []
    assert result["rejected"] == ["Q20", "Q21", "Q26"] == result["rejected_but_right"]
