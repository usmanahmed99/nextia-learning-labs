import json

import pytest

pytest.importorskip("stats_assistant.loop", reason="Part 3: write stats_assistant/loop.py")
from stats_assistant.loop import Limits, run_tool_loop  # noqa: E402
from stats_assistant.providers import Completion  # noqa: E402


def scripted(*calls):
    """A constructed model response (no model wrote it) that asks for the given tool calls."""
    data = {"choices": [{"finish_reason": "tool_calls", "message": {"content": None, "tool_calls": [
        {"id": f"call_{i}", "type": "function", "function": {"name": name, "arguments": json.dumps(args)}}
        for i, (name, args) in enumerate(calls)]}}]}
    return Completion.from_response(data, 0.0)


def answer(text):
    data = {"choices": [{"finish_reason": "stop", "message": {"content": text}}]}
    return Completion.from_response(data, 0.0)


def fake_tool(name, arguments):
    return {"ok": True, "value": 1}, "ok"


def test_a_repeated_call_stops_the_loop():
    result = run_tool_loop(lambda r: scripted(("get_values", {"a": 1})), {"messages": []}, fake_tool)
    assert [s.outcome for s in result.steps] == ["ok", "stopped: repeated call"]
    assert result.stopped == "repeated_call" and result.completion is None


def test_the_step_limit_stops_a_model_that_never_answers():
    counter = iter(range(100))
    result = run_tool_loop(lambda r: scripted(("get_values", {"a": next(counter)})), {"messages": []}, fake_tool,
                           Limits(max_steps=3))
    assert result.stopped == "max_steps" and len(result.completions) == 3


def test_the_tool_call_limit_counts_parallel_calls():
    many = [("get_values", {"a": i}) for i in range(12)]
    result = run_tool_loop(lambda r: scripted(*many), {"messages": []}, fake_tool, Limits(max_tool_calls=10))
    assert result.stopped == "max_tool_calls" and len(result.tool_texts) == 10


def test_the_time_limit_uses_the_clock_that_it_is_given():
    times = iter([0.0, 61.0])
    result = run_tool_loop(lambda r: scripted(("get_values", {"a": 1})), {"messages": []}, fake_tool,
                           clock=lambda: next(times))
    assert result.stopped == "time"


def test_a_long_result_is_cut_and_the_cut_text_is_kept():
    def big_tool(name, arguments):
        return {"ok": True, "text": "x" * 5000}, "ok"

    replies = iter([scripted(("get_values", {"a": 1})), answer("done")])
    result = run_tool_loop(lambda r: next(replies), {"messages": []}, big_tool, Limits(max_result_chars=100))
    assert result.completion.text == "done" and len(result.tool_texts[0]) == 100
