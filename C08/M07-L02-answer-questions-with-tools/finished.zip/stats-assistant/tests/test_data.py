import shutil

import pytest

from stats_assistant.data import DATA, SnapshotChanged, load_snapshot


def test_the_snapshot_has_8_countries_6_indicators_and_26_years(data):
    assert len(data.countries) == 8 and len(data.indicators) == 6
    assert len(data.values) == 8 * 6 * 26
    assert data.value("CAN", "SP.POP.TOTL", 2024) == 41262329


def test_a_missing_value_is_none_not_zero(data):
    assert data.value("JPN", "SP.DYN.LE00.IN", 2025) is None


def test_a_changed_file_stops_the_assistant(tmp_path):
    copy = tmp_path / "data"
    shutil.copytree(DATA, copy)
    path = copy / "wdi_snapshot.csv"
    path.write_text(path.read_text().replace("41262329", "41262330"))  # one digit changed
    with pytest.raises(SnapshotChanged, match="wdi_snapshot.csv"):
        load_snapshot(copy)
