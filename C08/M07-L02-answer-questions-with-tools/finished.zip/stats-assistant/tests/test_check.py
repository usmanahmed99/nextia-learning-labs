import pytest

pytest.importorskip("stats_assistant.check", reason="Part 4: write stats_assistant/check.py")
from stats_assistant.check import mentions, unsupported_numbers  # noqa: E402

RESULT = '{"ok": true, "values": [{"year": 2024, "value": 41262329}]}'


def test_numbers_are_read_with_the_precision_they_show():
    found = mentions("41.3 million people, 41,262,329 exactly, 94.4%")
    assert [(m.value, m.step) for m in found] == [(41_300_000, 100_000), (41_262_329, 1), (94.4, 0.1)]


@pytest.mark.parametrize("answer", ["41,262,329 people in 2024", "about 41.3 million in 2024",
                                    "about 41 million in 2024", "41.26 million (2024)"])
def test_a_rounded_number_is_supported(answer):
    assert unsupported_numbers(answer, [RESULT]) == []


@pytest.mark.parametrize("answer, bad", [("41.2 million in 2024", "41.2 million"),  # rounded wrongly
                                         ("41,262,330 in 2024", "41,262,330"),
                                         ("in 2023 it was 40 million", "2023")])
def test_a_number_without_a_source_is_reported(answer, bad):
    assert bad in unsupported_numbers(answer, [RESULT])


def test_a_derived_number_is_rejected_even_when_it_is_right():
    # 29,298,013,000,000 / 2,270,076,189,683.46 = 12.906..., but no tool result contains 12.9.
    evidence = ['{"year": 2024, "value": 29298013000000.0}', '{"year": 2024, "value": 2270076189683.46}']
    assert unsupported_numbers("about 12.9 times larger in 2024", evidence) == ["12.9"]


def test_known_limit_a_number_from_another_row_passes():
    # Real (chat-small, fetch-first): 75.62650476 is Mexico's 2021 value, given as the 2022 value.
    evidence = ["MEX,IT.NET.USER.ZS,...,75.62650476,78.63217894"]
    assert unsupported_numbers("75.62650476% of people used the Internet in 2022", evidence + ["2022"]) == []


def test_known_limit_numbers_in_words_are_not_seen():
    assert unsupported_numbers("about twice as large", [RESULT]) == []
