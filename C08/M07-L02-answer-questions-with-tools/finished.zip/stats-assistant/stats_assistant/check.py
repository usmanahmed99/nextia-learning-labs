"""The answer check: no unsupported numbers.

Every number in the final answer must match a number that the application gave the model: in a tool
result, in its own instructions, or in the question. A number "matches" when the source value, rounded
to the precision that the answer shows, gives the number in the answer. "41.3 million" matches
41,288,599 (rounded to 0.1 million); "41 million" matches it too (rounded to 1 million).

What the check can and cannot do:
- It proves that a number was seen, not that it belongs to the right country, indicator or year.
- A number that the model calculated itself (a sum, an average, a ratio) has no source, so the check
  rejects it, even when the arithmetic is right. Ask a tool to calculate instead (get_change).
- Numbers written in words ("twice", "a third") are not numbers to this check: they pass unseen.
- A coarse number ("1 billion") matches many values: precision is the answer's choice, not the check's.
"""

import re
from dataclasses import dataclass

SCALES = {"thousand": 1e3, "million": 1e6, "billion": 1e9, "trillion": 1e12}
NUMBER = re.compile(r"(?<![\w.])(\d{1,3}(?:,\d{3})+|\d+)(\.\d+)?(?:\s*(thousand|million|billion|trillion)\b)?",
                    re.IGNORECASE)


@dataclass(frozen=True)
class Mention:
    text: str      # as written in the answer, for example "41.3 million"
    value: float   # 41300000.0
    step: float    # the precision shown: 100000.0 (0.1 million)


def mentions(text: str) -> list[Mention]:
    """Find the numbers in a text, with the precision each one shows."""
    found = []
    for m in NUMBER.finditer(text):
        whole, decimals, scale = m.group(1), m.group(2) or "", (m.group(3) or "").lower()
        factor = SCALES.get(scale, 1.0)
        value = float(whole.replace(",", "") + decimals) * factor
        step = 10 ** -(len(decimals) - 1 if decimals else 0) * factor
        found.append(Mention(m.group(0), value, step))
    return found


def source_values(texts: list[str]) -> list[float]:
    """Every number in the texts that the application gave the model (exact, as written there)."""
    values = []
    for text in texts:
        for m in re.finditer(r"\d+(?:\.\d+)?(?:[eE][-+]?\d+)?", text):
            values.append(float(m.group(0)))
    return values


def supported(mention: Mention, values: list[float]) -> bool:
    half = mention.step / 2 * (1 + 1e-9)
    return any(abs(abs(v) - mention.value) <= half for v in values)


def unsupported_numbers(answer: str, evidence: list[str]) -> list[str]:
    values = source_values(evidence)
    return [m.text for m in mentions(answer) if not supported(m, values)]
