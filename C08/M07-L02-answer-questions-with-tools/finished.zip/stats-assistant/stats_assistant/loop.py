"""The tool loop, as in ticket-assistant: the model proposes calls, the application decides, and the loop ends.

Two changes from the course's loop: the tools are passed in (`run_tool`), and the loop keeps the exact
text of every tool result that the model saw. The answer check needs that text.
"""

import json
import time
from dataclasses import dataclass, field
from typing import Callable

from .providers import Completion


@dataclass
class Limits:
    max_steps: int = 5            # model calls in one loop
    max_tool_calls: int = 10      # tool calls in one loop, over all steps
    max_seconds: float = 60.0     # wall-clock time for the whole loop
    max_result_chars: int = 3000  # a tool result longer than this is cut before the model sees it


@dataclass
class Step:
    name: str
    arguments: str
    outcome: str  # "ok", "refused: <code>" or "stopped: ..."


@dataclass
class LoopResult:
    completion: Completion | None                # the final answer, or None when the loop was stopped
    completions: list[Completion] = field(default_factory=list)
    steps: list[Step] = field(default_factory=list)
    tool_texts: list[str] = field(default_factory=list)  # every tool result, exactly as the model saw it
    stopped: str = ""                             # "", "max_steps", "max_tool_calls", "repeated_call" or "time"


def run_tool_loop(complete: Callable[[dict], Completion], request: dict,
                  run_tool: Callable[[str, str], tuple[dict, str]], limits: Limits = Limits(),
                  clock: Callable[[], float] = time.monotonic) -> LoopResult:
    result = LoopResult(None)
    messages = list(request["messages"])
    seen = set()
    start = clock()
    for _ in range(limits.max_steps):
        completion = complete({**request, "messages": list(messages)})
        result.completions.append(completion)
        if not completion.tool_calls:
            result.completion = completion
            return result
        messages.append({"role": "assistant", "content": completion.text, "tool_calls": [
            {"id": c.id, "type": "function", "function": {"name": c.name, "arguments": c.arguments}}
            for c in completion.tool_calls]})
        for call in completion.tool_calls:
            signature = (call.name, call.arguments.replace(" ", ""))
            if signature in seen:
                result.steps.append(Step(call.name, call.arguments, "stopped: repeated call"))
                result.stopped = "repeated_call"
                return result
            if len(result.steps) >= limits.max_tool_calls:
                result.steps.append(Step(call.name, call.arguments, "stopped: too many tool calls"))
                result.stopped = "max_tool_calls"
                return result
            seen.add(signature)
            output, outcome = run_tool(call.name, call.arguments)
            result.steps.append(Step(call.name, call.arguments, outcome))
            text = json.dumps(output, ensure_ascii=False)[:limits.max_result_chars]
            result.tool_texts.append(text)
            messages.append({"role": "tool", "tool_call_id": call.id, "content": text})
        if clock() - start > limits.max_seconds:
            result.stopped = "time"
            return result
    result.stopped = "max_steps"
    return result
