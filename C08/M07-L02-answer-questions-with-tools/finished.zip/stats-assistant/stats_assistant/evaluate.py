"""Score the fixed question set: correct answers, rejected answers and why, tool calls, cost and time.

Every answer is graded, including the answers that the check rejected: a rejected answer can be right
(the check was too strict) or wrong (the check did its job). The two numbers that matter most:
- "valid but wrong": answers that would reach a reader and are wrong. Keep this at zero.
- "rejected but right": the price of the check, paid in a person's time.
"""

from __future__ import annotations

import json
import statistics
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

from .check import mentions
from .data import DATA
from .usage import cost_usd

if TYPE_CHECKING:
    from .ask import Outcome


def load_questions(path: Path = DATA / "questions.json") -> list[dict]:
    return json.loads(path.read_text(encoding="utf-8"))


def has_number(text: str, expected: float) -> bool:
    return any(abs(abs(expected) - m.value) <= m.step / 2 * (1 + 1e-9) for m in mentions(text))


def grade(question: dict, outcome: Outcome) -> bool:
    """True when the model's answer says what the data says (checked whether or not the gate passed)."""
    if outcome.answer is None:
        return False
    expect, answer = question["expect"], outcome.answer
    if expect["status"] != "any" and answer["status"] != expect["status"]:
        return False
    text = answer["answer"].lower()
    if not all(word.lower() in text for word in expect["words"]):
        return False
    return all(has_number(answer["answer"], n["value"]) for n in expect["numbers"])


@dataclass
class Row:
    question_id: str
    kind: str
    status: str            # valid, rejected, failed
    correct: bool
    declined: bool         # the model said cannot_answer although the data can answer
    problems: list[str]
    tool_calls: int
    refused_calls: int
    model_calls: int
    input_tokens: int
    output_tokens: int
    latency_s: float
    cost_usd: float | None


def row(question: dict, outcome: Outcome, model: str) -> Row:
    tokens_in = sum(c.input_tokens for c in outcome.completions)
    tokens_out = sum(c.output_tokens for c in outcome.completions)
    costs = [cost_usd(model, c.input_tokens, c.output_tokens) for c in outcome.completions]
    declined = bool(outcome.answer) and outcome.answer["status"] == "cannot_answer" and \
        question["expect"]["status"] == "answered"
    return Row(question["id"], question["kind"], outcome.status, grade(question, outcome), declined,
               outcome.problems + ([outcome.error] if outcome.error else []), len(outcome.steps),
               sum(s.outcome.startswith("refused") for s in outcome.steps), len(outcome.completions),
               tokens_in, tokens_out, round(sum(c.latency_s for c in outcome.completions), 3),
               None if None in costs else sum(costs))


def summary(rows: list[Row]) -> dict:
    latencies = sorted(r.latency_s for r in rows)
    costs = [r.cost_usd for r in rows]
    reasons: dict[str, int] = {}
    for r in rows:
        if r.status == "rejected":
            for p in r.problems:
                key = p.split(":")[0]
                reasons[key] = reasons.get(key, 0) + 1
    return {
        "questions": len(rows),
        "correct": sum(r.correct for r in rows),
        "valid": sum(r.status == "valid" for r in rows),
        "valid_and_correct": sum(r.status == "valid" and r.correct for r in rows),
        "valid_but_wrong": [r.question_id for r in rows if r.status == "valid" and not r.correct and not r.declined],
        "declined": [r.question_id for r in rows if r.declined],
        "rejected": [r.question_id for r in rows if r.status == "rejected"],
        "rejected_but_right": [r.question_id for r in rows if r.status == "rejected" and r.correct],
        "rejection_reasons": reasons,
        "failed": [r.question_id for r in rows if r.status == "failed"],
        "tool_calls": sum(r.tool_calls for r in rows),
        "refused_tool_calls": sum(r.refused_calls for r in rows),
        "tool_calls_per_question_max": max(r.tool_calls for r in rows),
        "model_calls": sum(r.model_calls for r in rows),
        "latency_median_s": round(statistics.median(latencies), 2),
        "latency_p95_s": round(latencies[min(len(latencies) - 1, int(0.95 * len(latencies)))], 2),
        "cost_per_1000_questions_usd": None if None in costs else round(sum(costs) / len(rows) * 1000, 2),
    }
