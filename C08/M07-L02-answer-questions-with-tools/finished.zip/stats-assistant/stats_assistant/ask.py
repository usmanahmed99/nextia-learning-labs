"""One question, end to end: request -> (tool loop) -> parse -> answer check -> the answer with its source."""

import json
from dataclasses import asdict, dataclass, field

from .check import unsupported_numbers
from .context import build_request
from .data import LICENCE, SNAPSHOT_DATE, SOURCE, Snapshot
from .loop import Limits, LoopResult, Step, run_tool_loop
from .providers import Completion, ProviderError
from .tools import run_tool

MAX_ANSWER_CHARS = 800


@dataclass
class Outcome:
    status: str                                  # "valid", "rejected" or "failed"
    answer: dict | None = None                   # {"status": "answered" | "cannot_answer", "answer": "..."}
    problems: list[str] = field(default_factory=list)
    steps: list[Step] = field(default_factory=list)
    completions: list[Completion] = field(default_factory=list)
    source: str = ""                             # written by the application, never by the model
    error: str = ""

    def to_dict(self) -> dict:
        return {"status": self.status, "answer": self.answer, "problems": self.problems, "source": self.source,
                "tool_steps": [asdict(s) for s in self.steps], "error": self.error}


def parse(completion: Completion) -> tuple[dict | None, list[str]]:
    """Gate 1: a complete JSON object of the schema."""
    if completion.refusal:
        return None, ["refusal"]
    if completion.finish_reason == "length":
        return None, ["truncated"]
    try:
        data = json.loads(completion.text or "")
    except json.JSONDecodeError:
        return None, ["malformed_json"]
    if not isinstance(data, dict) or set(data) != {"status", "answer"} or \
            data["status"] not in ("answered", "cannot_answer") or not isinstance(data["answer"], str):
        return None, ["schema"]
    return data, []


def check(answer: dict, evidence: list[str]) -> list[str]:
    """Gate 2: the rules of meaning."""
    problems = []
    text = answer["answer"]
    if not text.strip():
        problems.append("empty_answer")
    if len(text) > MAX_ANSWER_CHARS:
        problems.append("answer_too_long")
    for number in unsupported_numbers(text, evidence):
        problems.append(f"unsupported_number: {number}")
    if answer["status"] == "answered" and not any(str(y) in text for y in range(2000, 2026)):
        problems.append("no_year")
    return problems


def source_line(steps: list[Step], design: str) -> str:
    """The application states the source from what it really read, not from the model's text."""
    used = sorted({json.loads(s.arguments).get("indicator_code", "") for s in steps if s.outcome == "ok"} - {""})
    series = f"; series {', '.join(used)}" if used else ("; the whole snapshot" if design == "fetch-first" else "")
    return f"Source: {SOURCE} ({LICENCE}), snapshot of {SNAPSHOT_DATE}{series}. Check the official figure before publishing."


def ask(question: str, provider, model: str, data: Snapshot, design: str = "tools", reasoning_effort: str = "",
        limits: Limits = Limits()) -> Outcome:
    request = build_request(question, model, design, data, reasoning_effort)
    try:
        if design == "tools":
            result = run_tool_loop(provider.complete, request, lambda name, args: run_tool(name, args, data), limits)
        else:
            completion = provider.complete(request)
            result = LoopResult(completion, [completion])
    except ProviderError as error:
        return Outcome("failed", error=str(error))
    if result.stopped:
        return Outcome("failed", steps=result.steps, completions=result.completions,
                       error=f"The tool loop was stopped: {result.stopped}.")
    answer, problems = parse(result.completion)
    if answer is not None:
        evidence = [m["content"] for m in request["messages"]] + result.tool_texts
        problems = check(answer, evidence)
    status = "valid" if answer is not None and not problems else "rejected"
    return Outcome(status, answer, problems, result.steps, result.completions,
                   source_line(result.steps, design) if answer is not None else "")
