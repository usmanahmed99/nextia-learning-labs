"""Answer questions about public statistics with read-only tools, a bounded loop and checked numbers."""
