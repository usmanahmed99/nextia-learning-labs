"""Three read-only tools over the snapshot. The model only proposes a call; this code decides.

Every argument is checked before any data is read: the exact argument names, the types, the
country and indicator codes against an allow-list, and the years against the snapshot's range.
A refused call gets a short message that says what is allowed, so the model can correct itself.
"""

import json

from .data import FIRST_YEAR, LAST_YEAR, SNAPSHOT_DATE, SOURCE, Snapshot

COUNTRY = {"type": "string", "description": "A country code: BRA, CAN, GBR, IND, JPN, MEX, NGA or USA."}
INDICATOR = {"type": "string", "description": ("An indicator code: SP.POP.TOTL (population), NY.GDP.MKTP.CD (GDP, "
                                                "current US$), NY.GDP.PCAP.CD (GDP per capita, current US$), "
                                                "SP.DYN.LE00.IN (life expectancy at birth, years), EG.ELC.ACCS.ZS "
                                                "(access to electricity, % of population) or IT.NET.USER.ZS "
                                                "(Internet users, % of population).")}
YEAR = {"type": "integer", "description": f"A year from {FIRST_YEAR} to {LAST_YEAR}."}


def _tool(name: str, description: str, properties: dict) -> dict:
    return {"type": "function", "function": {
        "name": name, "description": description, "strict": True,
        "parameters": {"type": "object", "properties": properties, "required": list(properties),
                       "additionalProperties": False}}}


GET_VALUES = _tool(
    "get_values",
    "Read the values of one indicator for one country, for each year from start_year to end_year. Read-only. "
    "A missing value is null.",
    {"country_code": COUNTRY, "indicator_code": INDICATOR, "start_year": YEAR, "end_year": YEAR})
RANK_COUNTRIES = _tool(
    "rank_countries",
    "Rank the 8 countries by one indicator in one year, highest value first. Read-only. Countries without a "
    "value that year are listed as missing.",
    {"indicator_code": INDICATOR, "year": YEAR})
GET_CHANGE = _tool(
    "get_change",
    "Compute the change of one indicator for one country between two years: the difference (to minus from) and "
    "the percent change. The application does the arithmetic. Read-only.",
    {"country_code": COUNTRY, "indicator_code": INDICATOR, "from_year": YEAR, "to_year": YEAR})
TOOLS = [GET_VALUES, RANK_COUNTRIES, GET_CHANGE]
ARGUMENTS = {t["function"]["name"]: list(t["function"]["parameters"]["properties"]) for t in TOOLS}


class ToolRefused(Exception):
    """The application refused the model's proposal. `code` says why (for the log)."""

    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


def check_country(code, data: Snapshot) -> str:
    if not isinstance(code, str) or code not in data.countries:
        raise ToolRefused("not_allowed", f"Country code {code!r} is not available. "
                                         f"Available: {', '.join(sorted(data.countries))}.")
    return code


def check_indicator(code, data: Snapshot) -> str:
    if not isinstance(code, str) or code not in data.indicators:
        raise ToolRefused("not_allowed", f"Indicator code {code!r} is not available. "
                                         f"Available: {', '.join(data.indicators)}.")
    return code


def check_year(year) -> int:
    if isinstance(year, bool) or not isinstance(year, int):
        raise ToolRefused("invalid_argument", "A year must be a whole number, for example 2020.")
    if not FIRST_YEAR <= year <= LAST_YEAR:
        raise ToolRefused("year_out_of_range", f"The data covers {FIRST_YEAR} to {LAST_YEAR} only; {year} is outside.")
    return year


def _about(data: Snapshot, indicator: str) -> dict:
    about = data.indicators[indicator]
    return {"indicator_code": indicator, "indicator": about["name"], "unit": about["unit"], "source": SOURCE,
            "snapshot": SNAPSHOT_DATE}


def get_values(data: Snapshot, country_code, indicator_code, start_year, end_year) -> dict:
    country, indicator = check_country(country_code, data), check_indicator(indicator_code, data)
    start, end = check_year(start_year), check_year(end_year)
    if start > end:
        raise ToolRefused("invalid_argument", "start_year must not be after end_year.")
    return {"country_code": country, "country": data.countries[country], **_about(data, indicator),
            "values": [{"year": y, "value": data.value(country, indicator, y)} for y in range(start, end + 1)]}


def rank_countries(data: Snapshot, indicator_code, year) -> dict:
    indicator, year = check_indicator(indicator_code, data), check_year(year)
    known = [(data.value(c, indicator, year), c) for c in data.countries]
    ranked = sorted((v, c) for v, c in known if v is not None)[::-1]
    return {**_about(data, indicator), "year": year,
            "ranking": [{"rank": i, "country_code": c, "country": data.countries[c], "value": v}
                        for i, (v, c) in enumerate(ranked, 1)],
            "missing": [c for v, c in known if v is None]}


def get_change(data: Snapshot, country_code, indicator_code, from_year, to_year) -> dict:
    country, indicator = check_country(country_code, data), check_indicator(indicator_code, data)
    first, last = check_year(from_year), check_year(to_year)
    a, b = data.value(country, indicator, first), data.value(country, indicator, last)
    for year, v in ((first, a), (last, b)):
        if v is None:
            raise ToolRefused("no_value", f"There is no value for {country} {indicator} in {year}.")
    return {"country_code": country, "country": data.countries[country], **_about(data, indicator),
            "from": {"year": first, "value": a}, "to": {"year": last, "value": b},
            "difference": round(b - a, 4), "percent_change": round((b - a) / a * 100, 2) if a else None}


FUNCTIONS = {"get_values": get_values, "rank_countries": rank_countries, "get_change": get_change}


def run_tool(name: str, arguments: str, data: Snapshot) -> tuple[dict, str]:
    """Run one proposed call. Return (the result for the model, the outcome for the log)."""
    try:
        if name not in FUNCTIONS:
            raise ToolRefused("unknown_tool", f"There is no tool named {name}.")
        try:
            args = json.loads(arguments)
        except json.JSONDecodeError:
            raise ToolRefused("invalid_argument", "The arguments are not valid JSON.") from None
        if not isinstance(args, dict) or set(args) != set(ARGUMENTS[name]):
            raise ToolRefused("invalid_argument", f"{name} takes exactly: {', '.join(ARGUMENTS[name])}.")
        return {"ok": True, **FUNCTIONS[name](data, **args)}, "ok"
    except ToolRefused as refused:
        return {"ok": False, "error": str(refused)}, f"refused: {refused.code}"
