"""The fixed data snapshot: World Bank World Development Indicators for 8 countries and 6 indicators.

The files in data/ never change while the assistant runs. `load_snapshot()` checks their SHA-256
checksums first, so every answer comes from the exact data that the case study tested.
Nothing in this file writes data: the assistant can only read.
"""

import csv
import hashlib
from dataclasses import dataclass
from pathlib import Path

DATA = Path(__file__).resolve().parent.parent / "data"
FIRST_YEAR, LAST_YEAR = 2000, 2025
SNAPSHOT_DATE = "2026-10-08"
SOURCE = "World Bank, World Development Indicators"
LICENCE = "CC BY 4.0"


class SnapshotChanged(Exception):
    """A data file is not the one that was tested."""


def verify(folder: Path = DATA) -> None:
    """Compare every file in SHA256SUMS with its checksum. Stop at the first difference."""
    for line in (folder / "SHA256SUMS").read_text(encoding="utf-8").splitlines():
        expected, name = line.split("  ", 1)
        actual = hashlib.sha256((folder / name).read_bytes()).hexdigest()
        if actual != expected:
            raise SnapshotChanged(f"{name}: SHA-256 {actual[:12]}... is not the tested {expected[:12]}...")


@dataclass(frozen=True)
class Snapshot:
    countries: dict[str, str]                       # code -> name, e.g. "CAN" -> "Canada"
    indicators: dict[str, dict]                     # code -> {"name": ..., "unit": ...}
    values: dict[tuple[str, str, int], float | None]  # (country, indicator, year) -> value; None = missing

    def value(self, country: str, indicator: str, year: int) -> float | None:
        return self.values.get((country, indicator, year))


def load_snapshot(folder: Path = DATA) -> Snapshot:
    verify(folder)
    with (folder / "countries.csv").open(encoding="utf-8") as f:
        countries = {r["country_code"]: r["country_name"] for r in csv.DictReader(f)}
    with (folder / "indicators.csv").open(encoding="utf-8") as f:
        indicators = {r["indicator_code"]: {"name": r["indicator_name"], "unit": r["unit"]} for r in csv.DictReader(f)}
    values = {}
    with (folder / "wdi_snapshot.csv").open(encoding="utf-8") as f:
        for r in csv.DictReader(f):
            number = float(r["value"]) if r["value"] else None
            if number is not None and number.is_integer() and r["indicator_code"] == "SP.POP.TOTL":
                number = int(number)  # population is a count of people
            values[(r["country_code"], r["indicator_code"], int(r["year"]))] = number
    return Snapshot(countries, indicators, values)
