"""Command line.

    python -m stats_assistant ask Q01                      # one question of the set (or your own text, in quotes)
    python -m stats_assistant ask Q20 --design fetch-first --model chat-strong
    python -m stats_assistant eval                         # the whole question set, scored
    python -m stats_assistant tool get_values '{"country_code": "CAN", "indicator_code": "SP.POP.TOTL", "start_year": 2023, "end_year": 2024}'
"""

import argparse
import json
import sys
from dataclasses import asdict

from .config import Settings, make_provider
from .context import DESIGNS
from .data import load_snapshot
from .usage import cost_usd

# The parts that you build in the case study are imported when a command needs them, so that the
# starter project runs before they exist: tools.py (Part 2), loop.py (Part 3), check.py and ask.py (Part 4).


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="stats_assistant")
    sub = parser.add_subparsers(dest="command", required=True)
    one = sub.add_parser("ask", help="answer one question")
    one.add_argument("question", help="a question ID such as Q01, or your own question in quotes")
    many = sub.add_parser("eval", help="answer and score the whole question set")
    for p in (one, many):
        p.add_argument("--design", choices=DESIGNS, default="tools")
        p.add_argument("--model", default=None, help="default: ASSISTANT_MODEL, else chat-small")
    many.add_argument("--rows", action="store_true", help="also print one JSON line per question")
    tool = sub.add_parser("tool", help="run one tool yourself, without a model")
    tool.add_argument("name")
    tool.add_argument("arguments", help="the arguments as JSON text")
    args = parser.parse_args(argv)

    data = load_snapshot()
    if args.command == "tool":
        from .tools import run_tool

        output, outcome = run_tool(args.name, args.arguments, data)
        print(json.dumps(output, indent=2, ensure_ascii=False))
        print(outcome)
        return 0

    from .ask import ask
    from .evaluate import load_questions, row, summary

    settings = Settings.from_env()
    provider = make_provider(settings)
    model = args.model or settings.model
    options = dict(design=args.design, reasoning_effort=settings.reasoning_effort)
    questions = {q["id"]: q for q in load_questions()}

    if args.command == "ask":
        text = questions[args.question]["question"] if args.question in questions else args.question
        outcome = ask(text, provider, model, data, **options)
        print(json.dumps(outcome.to_dict(), indent=2, ensure_ascii=False))
        if outcome.status == "valid":
            print(f"\n{outcome.answer['answer']}\n{outcome.source}\n")
        tokens_in = sum(c.input_tokens for c in outcome.completions)
        tokens_out = sum(c.output_tokens for c in outcome.completions)
        cost = cost_usd(model, tokens_in, tokens_out)
        seconds = sum(c.latency_s for c in outcome.completions)
        print(f"{outcome.status} | {model} | {args.design} | {len(outcome.completions)} model call(s), "
              f"{len(outcome.steps)} tool call(s) | {tokens_in} tokens in, {tokens_out} out | "
              f"{'cost unknown' if cost is None else f'US${cost:.5f}'} | {seconds:.2f} s")
        return 0 if outcome.status == "valid" else 1

    rows = []
    for q in questions.values():
        r = row(q, ask(q["question"], provider, model, data, **options), model)
        rows.append(r)
        mark = "right" if r.correct else "declined" if r.declined else "wrong"
        print(f"{r.question_id} {r.kind:<10} {r.status:<8} {mark:<8} tools {r.tool_calls} "
              f"{'; '.join(r.problems)}")
        if args.rows:
            print(json.dumps(asdict(r)))
    print(json.dumps({"model": model, "design": args.design, **summary(rows)}, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
