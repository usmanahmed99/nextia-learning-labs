# city-requests-api (starter of the authentication case study)

The starting point of the case study [Add sign-in and roles to an existing API](https://learning.nextia-ai.com/courses/auth/m07/add-sign-in-and-roles-to-an-existing-api/).
It is the finished project of the API course's case study, with version 2 of the data: the
requests of a second department, parks. The page tells you what to add, step by step.

What is ready:

- `city_api/`: the API of the API course (one shared `X-API-Key`), reading version 2 of
  the database. `city_api/auth.py`: the token validator of the authentication course,
  copied, not used yet. `city_api/access_schema.sql`: the access database.
- `idp/`: the practice identity provider of the authentication course (a mock: made-up
  people, no passwords). `data/identity/`: the departments, the people and their roles.
- `scripts/get_db.py`: downloads and checks the database. `scripts/login.py`: signs in.
  `scripts/init_access.py`: makes the access database. `scripts/attempts_shared_key.py`: five
  things that must not work once two departments share the API. `scripts/attempts.py`,
  `token.py`, `matrix_report.py` and `audit.py`: checks that work once you have added the
  identity layer (the page says when).
- `optional/keycloak/`: a real identity provider in Docker, for the last part.
- `tests/`: the API course's tests.

## Set up

```sh
python3 -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\Activate.ps1
python -m pip install -r requirements-lock.txt
python scripts/get_db.py
python -m pytest
```

## Data and licence

The code is under the MIT licence (`LICENSE`). The data is from NYC Open Data; `DATASET.md`
describes it and every change. The people are made up.
