"""Five things that must not work once Parks uses this API too, sent to the running API.

    python -m scripts.attempts_shared_key

Needs the API running (API_KEY=local-dev-key fastapi dev). The plan "give Parks the same
key" is tried here: every caller sends the one shared X-API-Key. The people are made up;
every attempt targets only the API on your own computer. The script also opens the data
file read-only, to tell which requests belong to which department.
"""

import os
import sqlite3
import sys
from pathlib import Path

import httpx

API = os.environ.get("API_URL", "http://127.0.0.1:8000")
KEY = {"X-API-Key": os.environ.get("API_KEY", "local-dev-key")}
DB = Path(os.environ.get("DATABASE_PATH", "data/service_requests_2025h1_v2.db"))
TRANSPORT_ID = 64246800  # a transport request: a missing speed-limit sign in Manhattan


def main() -> int:
    data = sqlite3.connect(f"{DB.resolve().as_uri()}?mode=ro", uri=True)

    def department_of(request_id: int) -> str:
        return data.execute(
            "SELECT department FROM service_requests WHERE id = ?", (request_id,)
        ).fetchone()[0]

    transport_types = {
        t for (t,) in data.execute(
            "SELECT DISTINCT complaint_type FROM service_requests WHERE department = 'transport'"
        )
    }
    got = 0
    with httpx.Client(base_url=API, headers=KEY, timeout=10) as api:
        r = api.get(f"/v1/service-requests/{TRANSPORT_ID}")
        bad = r.status_code == 200
        print(f"{'GOT IT' if bad else 'refused':<8} Jamal (parks) reads transport request "
              f"{TRANSPORT_ID}: {r.status_code} {r.json().get('complaint_type', '')}")
        got += bad

        items = api.get("/v1/service-requests", params={"limit": 100}).json()["items"]
        mixed = sum(department_of(i["id"]) == "transport" for i in items)
        print(f"{'GOT IT' if mixed else 'refused':<8} Jamal lists requests: {mixed} of the first "
              f"{len(items)} are transport's")
        got += mixed > 0

        types = [i["complaint_type"] for i in api.get("/v1/complaint-types").json()["items"]]
        theirs = [t for t in types if t in transport_types]
        print(f"{'GOT IT' if theirs else 'refused':<8} Lena (parks) opens the complaint-type menu: "
              f"{len(theirs)} of {len(types)} types are transport's, first {types[0]!r}")
        got += bool(theirs)

        day = api.get(
            "/v1/stats/daily", params={"created_from": "2025-03-03", "created_to": "2025-03-04"}
        ).json()["items"][0]
        parks = data.execute(
            "SELECT COUNT(*) FROM service_requests WHERE department = 'parks'"
            " AND created_at >= '2025-03-03' AND created_at < '2025-03-04'"
        ).fetchone()[0]
        print(f"{'GOT IT' if parks else 'refused':<8} Transport's dashboard, 3 March 2025: opened "
              f"{day['opened']}, of which {parks} are parks requests")
        got += parks > 0

        r = api.get("/v1/dataset")
        bad = r.status_code == 200
        print(f"{'GOT IT' if bad else 'refused':<8} Oliver left the team last month; "
              f"his copy of the key still works: {r.status_code}")
        got += bad
    print(f"\n{got} of 5 attempts got what they should not get. The API saw the same caller "
          "every time: the key.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
