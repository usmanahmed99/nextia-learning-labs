"""Token validation: the issuer, the audience, the expiry, the signature and the type.

Each made-up token of scripts/token.py must be refused by the check named here."""

import json

import pytest

from scripts.token import make_cases
from tests.conftest import ISSUER, audit_rows

EXPECTED = {
    "valid": (200, "passed"),
    "no_token": (401, ""),
    "expired": (401, "expired"),
    "wrong_audience": (401, "wrong_audience"),
    "wrong_issuer": (401, "wrong_issuer"),
    "id_token": (401, "wrong_token_type"),
    "alg_none": (401, "algorithm_not_allowed"),
    "unknown_key": (401, "unknown_key"),
    "wrong_key_same_kid": (401, "bad_signature"),
    "tampered": (401, "bad_signature"),
    "missing_sub": (401, "missing_claim"),
    "not_a_jwt": (401, "malformed"),
}


@pytest.fixture(scope="module")
def cases(idp_store):
    return {c["case"]: c for c in make_cases(idp_store, ISSUER)}


@pytest.mark.parametrize("case", list(EXPECTED))
def test_each_bad_token_is_refused_by_its_check(make_client, cases, case):
    token = cases[case]["token"]
    headers = {"Authorization": f"Bearer {token}"} if token else {}
    response = make_client().get("/v1/me", headers=headers)
    status, check = EXPECTED[case]
    assert response.status_code == status, response.text
    assert response.headers.get("x-token-check", "passed" if status == 200 else "") == check
    if status == 401:
        assert response.headers["www-authenticate"].startswith("Bearer")


def test_no_token_says_not_signed_in(make_client):
    body = make_client().get("/v1/me").json()
    assert body["error"]["code"] == "not_signed_in"


def test_with_typ_jwt_allowed_the_audience_still_refuses_an_id_token(make_client, cases):
    # Keycloak and Entra ID put typ JWT in their access tokens: ACCESS_TOKEN_TYPES=JWT.
    client = make_client(access_token_types=("JWT",))
    response = client.get("/v1/me", headers={"Authorization": f"Bearer {cases['id_token']['token']}"})
    assert response.status_code == 401
    assert response.headers["x-token-check"] == "wrong_audience"


def test_a_refused_token_is_audited_without_the_token(make_client, access_db, cases):
    token = cases["wrong_audience"]["token"]
    make_client().get("/v1/me", headers={"Authorization": f"Bearer {token}"})
    events = [e for e in audit_rows(access_db) if e["action"] == "token.check"]
    assert [(e["result"], e["reason"]) for e in events] == [("denied", "wrong_audience")]
    assert token not in json.dumps(events)
    assert "eyJ" not in json.dumps(events)


def test_keys_are_fetched_once_and_cached(make_client, token_for):
    client = make_client()
    for user in ("usr-priya", "usr-lena", "usr-hana"):
        assert client.get("/v1/me", headers={"Authorization": f"Bearer {token_for(user)}"}).status_code == 200
    assert client.app.state.validator.provider.fetches == 1


def test_without_an_issuer_sign_in_is_unavailable(make_client):
    response = make_client(user="usr-priya", oidc_issuer=None).get("/v1/me")
    assert response.status_code == 503
    assert response.json()["error"]["code"] == "sign_in_unavailable"
