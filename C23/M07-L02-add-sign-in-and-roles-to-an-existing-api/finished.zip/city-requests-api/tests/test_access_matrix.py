"""The access-control test matrix.

Every identity x every department x every department route, with the answer that the
access matrix (city_api/access.py, docs/access-matrix.md) says it must get. Then requests
with another department's ID, and every route with each kind of bad identity. A row that
fails is an access-control bug.

    python -m pytest tests/test_access_matrix.py
    python -m scripts.matrix_report        runs it and prints the grid
"""

import pytest

from city_api.access import decide
from tests.conftest import MEMBERSHIPS, PEOPLE

DEPARTMENTS = ("transport", "parks")
REQUEST = {"transport": 64246800, "parks": 64225360}  # a real request of each department
STAFF = {"transport": "usr-priya", "parks": "usr-jamal"}  # a member that an owner removes

# name: (action, method, path, body, status when allowed)
ROUTES = {
    "list requests": ("request.read", "GET", "/service-requests", None, 200),
    "read a request": ("request.read", "GET", "/service-requests/{request}", None, 200),
    "read notes": ("request.read", "GET", "/service-requests/{request}/notes", None, 200),
    "add a note": (
        "note.write",
        "POST",
        "/service-requests/{request}/notes",
        {"body": "Matrix test."},
        201,
    ),
    "complaint types": ("request.read", "GET", "/complaint-types", None, 200),
    "daily numbers": (
        "request.read",
        "GET",
        "/stats/daily?created_from=2025-03-01&created_to=2025-03-06",
        None,
        200,
    ),
    "list members": ("member.read", "GET", "/members", None, 200),
    "set a role": ("member.manage", "PUT", "/members/usr-oliver", {"role": "read_only"}, 200),
    "remove a member": ("member.manage", "DELETE", "/members/{staff}", None, 204),
    "read the audit": ("audit.read", "GET", "/audit", None, 200),
}


def expected(user: str, department: str, route: str) -> int:
    action, *_, ok = ROUTES[route]
    decision = decide(MEMBERSHIPS.get((department, user)), action)
    return ok if decision.allowed else decision.status


def call(client, department: str, route: str, request_id: int | None = None, headers=None):
    _, method, path, body, _ = ROUTES[route]
    url = f"/v1/departments/{department}" + path.format(
        request=request_id or REQUEST[department], staff=STAFF[department]
    )
    return client.request(method, url, json=body, headers=headers or {})


CASES = [(u, d, r) for u in PEOPLE for d in DEPARTMENTS for r in ROUTES]


@pytest.mark.parametrize("user, department, route", CASES, ids=["|".join(c) for c in CASES])
def test_matrix(client_as, user, department, route):
    response = call(client_as(user), department, route)
    assert response.status_code == expected(user, department, route), response.text


# A member uses their own department's path with the other department's request ID (BOLA:
# a guessed or copied ID). The answer must be "not found", or 403 when the role could not
# write anyway.
BOLA = [
    ("usr-priya", "transport", "parks"),
    ("usr-jamal", "parks", "transport"),
    ("usr-hana", "transport", "parks"),
    ("usr-hana", "parks", "transport"),
    ("transport-dashboards", "transport", "parks"),
]


@pytest.mark.parametrize("user, department, other", BOLA, ids=["|".join(b) for b in BOLA])
def test_another_departments_request_id(client_as, user, department, other):
    client = client_as(user)
    for route in ("read a request", "read notes", "add a note"):
        response = call(client, department, route, request_id=REQUEST[other])
        allowed = expected(user, department, route) < 400
        assert response.status_code == (404 if allowed else 403), (route, response.text)


def bad_headers(kind: str, token_for, signer, idp_store) -> dict:
    if kind == "no identity":
        return {}
    if kind == "expired":
        return {"Authorization": f"Bearer {token_for('usr-teresa', exp=1, iat=0, nbf=0)}"}
    if kind == "wrong audience":
        return {"Authorization": f"Bearer {token_for('usr-teresa', aud='billing-api')}"}
    if kind == "wrong issuer":
        return {"Authorization": f"Bearer {token_for('usr-teresa', iss='http://localhost:9999')}"}
    if kind == "ID token":
        user = idp_store.users()["usr-teresa"]
        return {"Authorization": f"Bearer {signer.id_token(user, 'city-cli', 'n', 0)}"}
    if kind == "no scope":
        return {"Authorization": f"Bearer {token_for('usr-teresa', scope='')}"}
    raise ValueError(kind)


BAD = ["no identity", "expired", "wrong audience", "wrong issuer", "ID token", "no scope"]
BAD_CASES = [(k, r) for k in BAD for r in ROUTES]


@pytest.mark.parametrize("kind, route", BAD_CASES, ids=["|".join(c) for c in BAD_CASES])
def test_bad_identity(make_client, token_for, signer, idp_store, kind, route):
    headers = bad_headers(kind, token_for, signer, idp_store)
    response = call(make_client(), "transport", route, headers=headers)
    assert response.status_code == (403 if kind == "no scope" else 401), response.text
