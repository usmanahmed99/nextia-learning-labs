import csv
import sqlite3
from dataclasses import replace
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from city_api.config import Settings
from city_api.db import SCHEMA_VERSION
from city_api.main import create_app
from idp.app import create_app as create_provider
from idp.store import Store
from idp.tokens import Signer
from scripts.init_access import build as build_access_db

HERE = Path(__file__).parent
SCHEMA = HERE.parent / "city_api" / "schema.sql"

ISSUER = "http://localhost:8410"
ALL_SCOPES = "requests:read requests:write members:manage"
# The people of data/identity/, and their roles. The access matrix test uses them.
PEOPLE = [
    "usr-teresa",
    "usr-priya",
    "usr-hana",
    "usr-lena",
    "usr-jamal",
    "usr-marcus",
    "usr-oliver",
    "transport-dashboards",
]
MEMBERSHIPS = {
    ("transport", "usr-teresa"): "owner",
    ("transport", "usr-priya"): "staff",
    ("transport", "usr-hana"): "read_only",
    ("transport", "transport-dashboards"): "read_only",
    ("parks", "usr-lena"): "owner",
    ("parks", "usr-jamal"): "staff",
    ("parks", "usr-marcus"): "read_only",
    ("parks", "usr-hana"): "staff",
}


def build_fixture_db(path: Path) -> None:
    """Make a 42-row database with the real schema: 30 transport rows from
    fixture_rows.csv and 12 parks rows from fixture_rows_parks.csv, of the same days."""
    con = sqlite3.connect(path)
    con.executescript(SCHEMA.read_text(encoding="utf-8"))
    total = 0
    for name, department in (("fixture_rows.csv", "transport"), ("fixture_rows_parks.csv", "parks")):
        with (HERE / name).open(newline="", encoding="utf-8") as file:
            rows = [
                [value or None for value in row.values()] + [department]
                for row in csv.DictReader(file)
            ]
        con.executemany(f"INSERT INTO service_requests VALUES ({', '.join('?' * 16)})", rows)
        total += len(rows)
    con.executemany(
        "INSERT INTO meta VALUES (?, ?)",
        [
            ("source", "Test rows from NYC 311 Service Requests"),
            ("pulled_on", "2026-10-07"),
            ("created_from", "2025-03-01"),
            ("created_to", "2025-03-13"),
            ("rows", str(total)),
            ("rules", "The rules of scripts/build_db.py."),
        ],
    )
    con.execute(f"PRAGMA user_version = {SCHEMA_VERSION}")
    con.commit()
    con.close()


@pytest.fixture(scope="session")
def fixture_db(tmp_path_factory) -> Path:
    path = tmp_path_factory.mktemp("data") / "fixture.db"
    build_fixture_db(path)
    return path


@pytest.fixture
def access_db(tmp_path) -> Path:
    """A new access database for each test: departments, people and memberships."""
    path = tmp_path / "access.db"
    build_access_db(path)
    return path


# ---------- the practice identity provider, in the test process ----------
# The provider runs as a test client (no server, no port). The API fetches its discovery
# document and its keys through that client instead of over the network.


@pytest.fixture(scope="session")
def idp_store(tmp_path_factory) -> Store:
    store = Store(tmp_path_factory.mktemp("idp"))
    store.secrets = store.init()
    return store


@pytest.fixture(scope="session")
def provider(idp_store) -> TestClient:
    return TestClient(create_provider(idp_store, issuer=ISSUER), raise_server_exceptions=False)


@pytest.fixture(scope="session")
def signer(idp_store) -> Signer:
    return Signer(idp_store, ISSUER)


@pytest.fixture
def token_for(signer):
    """token_for("usr-priya") -> an access token from the provider, as after a sign-in.
    A service (transport-dashboards) gets a token for itself: sub = client_id."""

    def make(user: str, scope: str = ALL_SCOPES, **claims) -> str:
        client_id = user if user == "transport-dashboards" else "city-cli"
        if user == "transport-dashboards" and scope == ALL_SCOPES:
            scope = "requests:read"
        return signer.access_token(user, client_id, scope, **claims)

    return make


@pytest.fixture
def make_client(fixture_db, access_db, provider, token_for):
    """make_client(user="usr-priya", **settings) -> a test client of the API. With a user,
    every request carries that person's access token."""
    settings = Settings(
        allowed_origins=[],
        database_path=fixture_db,
        log_level="WARNING",
        show_docs=True,
        access_db_path=access_db,
        oidc_issuer=ISSUER,
    )

    def make(user: str | None = None, **changes) -> TestClient:
        app = create_app(replace(settings, **changes))
        if app.state.validator is not None:
            app.state.validator.provider.fetch = lambda url: provider.get(
                url.removeprefix(ISSUER)
            ).json()
        client = TestClient(app, raise_server_exceptions=False)
        if user:
            client.headers["Authorization"] = f"Bearer {token_for(user)}"
        return client

    return make


@pytest.fixture
def client(make_client) -> TestClient:
    """The API, called by Teresa (owner in transport): the API course's tests use it."""
    return make_client(user="usr-teresa")


@pytest.fixture
def client_as(make_client):
    """client_as("usr-hana") -> the API, called by that person with their access token."""
    return lambda user: make_client(user=user)


def audit_rows(path: Path) -> list[dict]:
    con = sqlite3.connect(path)
    con.row_factory = sqlite3.Row
    rows = [dict(r) for r in con.execute("SELECT * FROM audit_events ORDER BY event_id")]
    con.close()
    return rows
