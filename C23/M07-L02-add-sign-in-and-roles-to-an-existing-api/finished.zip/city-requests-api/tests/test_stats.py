import pytest


def stats(client, start, end, **filters):
    return client.get(
        "/v1/departments/transport/stats/daily", params={"created_from": start, "created_to": end, **filters}
    )


def test_daily_numbers(client):
    items = stats(client, "2025-03-01", "2025-03-06").json()["items"]
    assert items == [
        {"date": "2025-03-01", "opened": 6, "closed_within_14_days": 5,
         "share_closed_within_14_days": 0.833, "median_days_to_close": 1.9},
        {"date": "2025-03-02", "opened": 2, "closed_within_14_days": 1,
         "share_closed_within_14_days": 0.5, "median_days_to_close": 0.71},
        {"date": "2025-03-03", "opened": 11, "closed_within_14_days": 10,
         "share_closed_within_14_days": 0.909, "median_days_to_close": 1.15},
        {"date": "2025-03-04", "opened": 4, "closed_within_14_days": 4,
         "share_closed_within_14_days": 1.0, "median_days_to_close": 6.87},
        {"date": "2025-03-05", "opened": 6, "closed_within_14_days": 6,
         "share_closed_within_14_days": 1.0, "median_days_to_close": 0.35},
    ]


def test_days_without_requests_are_included(client):
    items = stats(client, "2025-03-10", "2025-03-13").json()["items"]
    assert [item["opened"] for item in items] == [0, 0, 1]
    assert items[0]["share_closed_within_14_days"] is None
    # 2025-03-12: one request, still pending
    assert items[2]["closed_within_14_days"] == 0
    assert items[2]["median_days_to_close"] is None


def test_filters_apply_to_the_numbers(client):
    items = stats(client, "2025-03-03", "2025-03-04", borough="staten_island").json()["items"]
    assert items[0]["opened"] == 6


@pytest.mark.parametrize(("end", "status"), [("2025-06-01", 200), ("2025-06-02", 422)])
def test_range_of_92_days_is_the_limit(client, end, status):
    response = stats(client, "2025-03-01", end)  # 92 and 93 days
    assert response.status_code == status
    if status == 422:
        assert response.json()["error"]["code"] == "range_too_large"
    else:
        assert len(response.json()["items"]) == 92


def test_dates_are_required(client):
    response = client.get("/v1/departments/transport/stats/daily", params={"created_from": "2025-03-01"})
    assert response.status_code == 422
    assert response.json()["error"]["fields"] == ["created_to"]


def test_reversed_range(client):
    response = stats(client, "2025-03-05", "2025-03-01")
    assert response.json()["error"]["code"] == "invalid_range"
