"""The department rules: 404 for outsiders, 403 for members whose role or scope is too
small, tenant-scoped queries, notes, members, and the audit of every change and refusal."""

import sqlite3

import pytest

from tests.conftest import audit_rows

T = "/v1/departments/transport"
P = "/v1/departments/parks"
TRANSPORT_ID, PARKS_ID = 64246800, 64225360  # one real request of each department


def body_without_id(response) -> dict:
    error = dict(response.json()["error"])
    error.pop("request_id")
    return error


def test_me_shows_the_memberships_from_the_api_table(client_as):
    me = client_as("usr-hana").get("/v1/me").json()
    assert me["user_id"] == "usr-hana" and me["kind"] == "person"
    assert me["memberships"] == [
        {"department": "parks", "role": "staff"},
        {"department": "transport", "role": "read_only"},
    ]
    assert client_as("usr-oliver").get("/v1/me").json()["memberships"] == []


def test_each_department_sees_only_its_requests(client_as):
    transport = client_as("usr-priya").get(f"{T}/service-requests", params={"limit": 200}).json()
    parks = client_as("usr-jamal").get(f"{P}/service-requests", params={"limit": 200}).json()
    assert len(transport["items"]) == 30 and len(parks["items"]) == 12
    assert not {r["id"] for r in transport["items"]} & {r["id"] for r in parks["items"]}


def test_statistics_and_types_are_per_department(client_as):
    hana = client_as("usr-hana")  # a member of both: read_only in transport, staff in parks
    types_t = {i["complaint_type"] for i in hana.get(f"{T}/complaint-types").json()["items"]}
    types_p = {i["complaint_type"] for i in hana.get(f"{P}/complaint-types").json()["items"]}
    assert "Damaged Tree" in types_p and "Damaged Tree" not in types_t
    params = {"created_from": "2025-03-01", "created_to": "2025-03-06"}
    opened_t = sum(d["opened"] for d in hana.get(f"{T}/stats/daily", params=params).json()["items"])
    opened_p = sum(d["opened"] for d in hana.get(f"{P}/stats/daily", params=params).json()["items"])
    assert (opened_t, opened_p) == (29, 12)


def test_an_outsider_gets_the_same_404_for_a_real_and_a_made_up_department(client_as):
    oliver = client_as("usr-oliver")
    real = oliver.get(f"{T}/service-requests/{TRANSPORT_ID}")
    made_up = oliver.get(f"/v1/departments/sanitation/service-requests/{TRANSPORT_ID}")
    assert real.status_code == made_up.status_code == 404
    assert body_without_id(real) == body_without_id(made_up) == {
        "code": "not_found",
        "message": "Not found.",
        "fields": [],
    }


def test_another_departments_request_is_not_found_through_your_own_path(client_as):
    priya = client_as("usr-priya")
    guessed = priya.get(f"{T}/service-requests/{PARKS_ID}")
    missing = priya.get(f"{T}/service-requests/1")
    assert guessed.status_code == missing.status_code == 404
    assert guessed.json()["error"]["message"] == f"No service request has the ID {PARKS_ID}."
    assert priya.get(f"{T}/service-requests/{PARKS_ID}/notes").status_code == 404
    note = priya.post(f"{T}/service-requests/{PARKS_ID}/notes", json={"body": "x"})
    assert note.status_code == 404


def test_a_department_in_a_header_or_the_query_is_ignored(client_as):
    jamal = client_as("usr-jamal")  # staff in parks only
    forged = {"X-Department": "transport", "X-Tenant-ID": "transport"}
    assert jamal.get(f"{T}/service-requests", headers=forged).status_code == 404
    page = jamal.get(f"{P}/service-requests", params={"department": "transport"})
    assert page.status_code == 422  # an unknown parameter, as in the API course


def test_a_read_only_member_may_read_but_not_write(client_as):
    hana = client_as("usr-hana")
    assert hana.get(f"{T}/service-requests/{TRANSPORT_ID}").status_code == 200
    response = hana.post(f"{T}/service-requests/{TRANSPORT_ID}/notes", json={"body": "Crew sent."})
    assert response.status_code == 403
    assert response.json()["error"]["code"] == "forbidden"
    # The same person is staff in parks: there she may.
    assert hana.post(f"{P}/service-requests/{PARKS_ID}/notes", json={"body": "Crew sent."}).status_code == 201


def test_a_token_without_the_scope_gets_403_insufficient_scope(make_client, token_for):
    client = make_client()
    token = token_for("usr-priya", scope="requests:read")  # a read-only app, for example
    response = client.post(
        f"{T}/service-requests/{TRANSPORT_ID}/notes",
        json={"body": "x"},
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 403
    assert response.json()["error"]["code"] == "insufficient_scope"
    assert 'error="insufficient_scope"' in response.headers["www-authenticate"]


def test_the_dashboard_service_reads_but_does_not_write(client_as):
    service = client_as("transport-dashboards")
    assert service.get("/v1/me").json()["kind"] == "service"
    assert service.get(f"{T}/service-requests").status_code == 200
    assert service.get(f"{P}/service-requests").status_code == 404
    note = service.post(f"{T}/service-requests/{TRANSPORT_ID}/notes", json={"body": "x"})
    assert note.status_code == 403


def test_notes_belong_to_the_department(client_as, access_db):
    priya = client_as("usr-priya")
    created = priya.post(f"{T}/service-requests/{TRANSPORT_ID}/notes", json={"body": "Crew sent."})
    assert created.status_code == 201
    assert created.json()["author_id"] == "usr-priya"
    notes = client_as("usr-hana").get(f"{T}/service-requests/{TRANSPORT_ID}/notes").json()["items"]
    assert [n["body"] for n in notes] == ["Crew sent."]
    assert client_as("usr-jamal").get(f"{T}/service-requests/{TRANSPORT_ID}/notes").status_code == 404
    event = [e for e in audit_rows(access_db) if e["action"] == "note.create"][0]
    assert (event["actor_id"], event["department_id"], event["result"]) == (
        "usr-priya",
        "transport",
        "allowed",
    )
    assert "Crew sent" not in str(event)  # the note's text is not in the audit


def test_an_owner_adds_changes_and_removes_a_member(client_as, access_db):
    teresa, oliver = client_as("usr-teresa"), client_as("usr-oliver")
    oliver.get("/v1/me")  # Oliver signs in: the API learns his ID
    assert oliver.get(f"{T}/service-requests").status_code == 404
    assert teresa.put(f"{T}/members/usr-oliver", json={"role": "read_only"}).status_code == 200
    assert oliver.get(f"{T}/service-requests").status_code == 200
    assert oliver.post(f"{T}/service-requests/{TRANSPORT_ID}/notes", json={"body": "x"}).status_code == 403
    assert teresa.put(f"{T}/members/usr-oliver", json={"role": "staff"}).status_code == 200
    assert oliver.post(f"{T}/service-requests/{TRANSPORT_ID}/notes", json={"body": "x"}).status_code == 201
    assert teresa.delete(f"{T}/members/usr-oliver").status_code == 204
    assert oliver.get(f"{T}/service-requests").status_code == 404  # the same token, next request
    events = [
        (e["action"], e["result"]) for e in audit_rows(access_db) if e["department_id"] == "transport"
    ]
    assert events == [
        ("member.add", "allowed"),
        ("note.write", "denied"),  # Oliver, read_only, tried a note
        ("member.change_role", "allowed"),
        ("note.create", "allowed"),
        ("member.remove", "allowed"),
    ]


def test_staff_may_list_members_but_not_change_them(client_as):
    priya = client_as("usr-priya")
    assert priya.get(f"{T}/members").status_code == 200
    assert priya.put(f"{T}/members/usr-oliver", json={"role": "owner"}).status_code == 403
    assert priya.get(f"{T}/audit").status_code == 403


def test_the_last_owner_cannot_leave(client_as):
    teresa = client_as("usr-teresa")
    assert teresa.put(f"{T}/members/usr-teresa", json={"role": "staff"}).status_code == 409
    assert teresa.delete(f"{T}/members/usr-teresa").json()["error"]["code"] == "last_owner"


def test_an_unknown_person_cannot_be_added(client_as):
    response = client_as("usr-teresa").put(f"{T}/members/usr-nobody", json={"role": "staff"})
    assert response.status_code == 404
    assert response.json()["error"]["code"] == "unknown_user"


def test_refusals_are_audited_outsiders_without_the_department(client_as, access_db):
    client_as("usr-oliver").get(f"{T}/service-requests")  # outsider: 404
    client_as("usr-hana").post(f"{T}/service-requests/{TRANSPORT_ID}/notes", json={"body": "x"})
    denied = [e for e in audit_rows(access_db) if e["result"] == "denied"]
    assert [(e["actor_id"], e["department_id"], e["reason"]) for e in denied] == [
        ("usr-oliver", None, "not_a_member"),
        ("usr-hana", "transport", "role_cannot"),
    ]
    log = client_as("usr-teresa").get(f"{T}/audit").json()["items"]
    assert [e["actor_id"] for e in log] == ["usr-hana"]  # Oliver's attempt is not in it


def test_the_audit_is_append_only(access_db, client_as):
    client_as("usr-hana").post(f"{T}/service-requests/{TRANSPORT_ID}/notes", json={"body": "x"})
    con = sqlite3.connect(access_db)
    with pytest.raises(sqlite3.IntegrityError, match="append-only"):
        con.execute("UPDATE audit_events SET result = 'allowed'")
    with pytest.raises(sqlite3.IntegrityError, match="append-only"):
        con.execute("DELETE FROM audit_events")
    con.close()


def test_a_query_without_the_department_fails_before_any_sql(fixture_db):
    from city_api import db, queries

    con = db.connect(fixture_db)
    with pytest.raises(TypeError, match="department"):
        queries.get_request(con, TRANSPORT_ID)
    con.close()
