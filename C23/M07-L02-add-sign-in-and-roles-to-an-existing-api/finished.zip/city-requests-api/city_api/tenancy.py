"""The department of a request, and the check that runs before every department route.

    @router.get("/v1/departments/{department}/service-requests")
    def list_requests(caller: Annotated[Caller, Depends(require("request.read"))], ...):
        queries.list_requests(con, department=caller.department, ...)

`require(action)` answers the three questions in order:
1. who:    the checked access token, else 401
2. where:  the caller's membership in the department of the PATH, else 404
3. what:   the membership's role and the token's scopes allow the action, else 403

The department comes from the path and is checked against the caller's own membership.
A department in a header, a query parameter or a body is never used. Memberships are
read on every request (no cache): a removed member loses access at their next request.
"""

import sqlite3
from collections.abc import Iterator
from dataclasses import dataclass
from typing import Annotated

from fastapi import Depends, Path, Request

from city_api import audit, db
from city_api.access import Decision, decide
from city_api.auth import Identity
from city_api.security import CurrentIdentity

DepartmentId = Annotated[
    str, Path(pattern=r"^[a-z][a-z0-9-]{1,30}$", examples=["transport"])
]


def get_access_db(request: Request) -> Iterator[sqlite3.Connection]:
    """Give the route a connection to the access database, and close it afterwards."""
    con = db.connect_access(request.app.state.settings.access_db_path)
    try:
        yield con
    finally:
        con.close()


AccessDb = Annotated[sqlite3.Connection, Depends(get_access_db)]


class AccessDenied(Exception):
    """The caller may not do this here: 404 (not a member) or 403 (a role or scope too small)."""

    def __init__(self, decision: Decision, department: str, action: str):
        super().__init__(decision.rule)
        self.decision, self.department, self.action = decision, department, action


@dataclass(frozen=True)
class Caller:
    """A checked request: who, in which department, with which role."""

    identity: Identity
    department: str
    role: str

    @property
    def user_id(self) -> str:
        return self.identity.user_id


def role_of(con: sqlite3.Connection, department: str, user_id: str) -> str | None:
    row = con.execute(
        "SELECT role FROM memberships WHERE department_id = ? AND user_id = ?",
        (department, user_id),
    ).fetchone()
    return row["role"] if row else None


def check(
    request: Request, con: sqlite3.Connection, identity: Identity, department: str, action: str
) -> Caller:
    role = role_of(con, department, identity.user_id)
    decision = decide(role, action, identity.scopes)
    if not decision.allowed:
        # Who TRIED matters as much as who did. The department is recorded only for a
        # member (403): an outsider's attempt is not written into its log.
        audit.record(
            request.app.state.settings.access_db_path,
            action=action,
            result="denied",
            actor_id=identity.user_id,
            actor_kind=identity.kind,
            department_id=department if decision.status == 403 else None,
            target=f"{request.method} {request.url.path}",
            reason=decision.code,
            request_id=getattr(request.state, "request_id", None),
            details={"rule": decision.rule, "department_in_path": department},
        )
        raise AccessDenied(decision, department, action)
    return Caller(identity, department, role)


def require(action: str):
    """A FastAPI dependency: the route runs only if the caller may do `action` in the
    department named in the path."""

    def dependency(
        request: Request, department: DepartmentId, identity: CurrentIdentity, con: AccessDb
    ) -> Caller:
        return check(request, con, identity, department, action)

    return dependency
