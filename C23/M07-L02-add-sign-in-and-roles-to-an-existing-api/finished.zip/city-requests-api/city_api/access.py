"""Who may do what: the access matrix of the city requests API, as code.

Three questions decide every request (the authentication course, Module 1):

1. Who is the caller?          a user ID ("sub") from a checked access token
2. In which department?        the department in the request path, and the caller's
                               membership there
3. What may they do there?     the role of that membership, and the scopes of the token

A role belongs to a membership, not to a person: Hana is read_only in transport and staff
in parks, so the same person gets two different answers.

`decide()` is a pure function: no database, no web request. That makes the matrix easy to
read, to test and to print (docs/access-matrix.md).
"""

from dataclasses import dataclass

ROLES = ("owner", "staff", "read_only")

ACTIONS = ("request.read", "note.write", "member.read", "member.manage", "audit.read")

# What each role may do in its department.
ROLE_ACTIONS: dict[str, frozenset[str]] = {
    "owner": frozenset(ACTIONS),
    "staff": frozenset({"request.read", "note.write", "member.read"}),
    "read_only": frozenset({"request.read"}),
}

# The token scope that an action needs. A role says what the PERSON may do; a scope says
# what the APPLICATION may do for them (what they allowed at sign-in). Both must allow it.
ACTION_SCOPE = {
    "request.read": "requests:read",
    "member.read": "requests:read",
    "note.write": "requests:write",
    "member.manage": "members:manage",
    "audit.read": "members:manage",
}


@dataclass(frozen=True)
class Decision:
    allowed: bool
    status: int  # the HTTP status the API answers: 200 (allowed), 403 or 404
    code: str  # allowed | not_a_member | role_cannot | missing_scope
    rule: str  # the rule that made the decision, in words


def decide(role: str | None, action: str, scopes: frozenset[str] | None = None) -> Decision:
    """Decide one action for a caller whose membership in the department has `role`
    (None: no membership). `scopes`: the token's scopes (None: not checked).

    Without a membership the answer is 404, never 403: an outsider learns nothing, not
    even whether the department or the request exists. A member who may read but not
    change gets 403: they already know that the department exists."""
    if action not in ACTION_SCOPE:
        raise ValueError(f"unknown action {action!r}")
    if role is None:
        return Decision(False, 404, "not_a_member", "no membership in this department")
    if action not in ROLE_ACTIONS.get(role, frozenset()):
        return Decision(False, 403, "role_cannot", f"{role} may not {action}")
    needed = ACTION_SCOPE[action]
    if scopes is not None and needed not in scopes:
        return Decision(False, 403, "missing_scope", f"the token has no {needed} scope")
    return Decision(True, 200, "allowed", f"{role} may {action}")
