"""Who is calling: the checked access token of the request (Authorization: Bearer ...).

The API course's shared X-API-Key is gone: one key for a whole team cannot say who is
calling, cannot be taken away from one person, and cannot have a role.
"""

from typing import Annotated

from fastapi import Depends, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from city_api.auth import Identity

bearer = HTTPBearer(auto_error=False, description="An access token from the identity provider.")


class NotSignedIn(Exception):
    """The request has no access token."""


class SignInUnavailable(Exception):
    """The API has no identity provider configured (OIDC_ISSUER is not set)."""


def current_identity(
    request: Request,
    credentials: Annotated[HTTPAuthorizationCredentials | None, Depends(bearer)],
) -> Identity:
    validator = request.app.state.validator
    if validator is None:
        raise SignInUnavailable("OIDC_ISSUER is not set")
    if credentials is None:
        raise NotSignedIn("Send an access token: Authorization: Bearer <token>.")
    identity = validator.validate(credentials.credentials)  # raises TokenRejected
    request.state.identity = identity  # for the access log
    return identity


CurrentIdentity = Annotated[Identity, Depends(current_identity)]
