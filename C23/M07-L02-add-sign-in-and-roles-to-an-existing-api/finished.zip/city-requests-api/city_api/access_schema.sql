-- The access database: who may do what, in which department, and what happened.
-- scripts/init_access.py makes it from data/identity/; tests/conftest.py makes one
-- for each test. Change it only together with ACCESS_SCHEMA_VERSION in city_api/db.py.

PRAGMA journal_mode = WAL;

-- A department is the organization (the tenant): its people see only its requests.
CREATE TABLE departments (
    department_id TEXT PRIMARY KEY CHECK (department_id GLOB '[a-z]*'),
    name          TEXT NOT NULL
);

-- A person or a service, by the identity provider's stable ID (the token's sub).
-- The API learns a person's ID when they first call GET /v1/me.
CREATE TABLE users (
    user_id    TEXT PRIMARY KEY,
    name       TEXT,
    kind       TEXT NOT NULL DEFAULT 'person' CHECK (kind IN ('person', 'service')),
    first_seen TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);

-- The role belongs to the membership, not to the person: Hana is read_only in
-- transport and staff in parks.
CREATE TABLE memberships (
    department_id TEXT NOT NULL REFERENCES departments (department_id),
    user_id       TEXT NOT NULL REFERENCES users (user_id),
    role          TEXT NOT NULL CHECK (role IN ('owner', 'staff', 'read_only')),
    created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
    PRIMARY KEY (department_id, user_id)
);

-- A note of a department's staff on one of its requests (the first thing the API can
-- write). The request is in the read-only data file, so the API checks that it belongs
-- to the department before it writes the note.
CREATE TABLE request_notes (
    note_id       INTEGER PRIMARY KEY,
    department_id TEXT NOT NULL REFERENCES departments (department_id),
    request_id    INTEGER NOT NULL,
    author_id     TEXT NOT NULL REFERENCES users (user_id),
    body          TEXT NOT NULL CHECK (length(body) BETWEEN 1 AND 1000),
    created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);
CREATE INDEX ix_notes_request ON request_notes (department_id, request_id, note_id);

-- Who did, or tried, what, where, and the result. Never a token or a secret.
-- department_id is NULL for an attempt by someone who is not a member: it is not
-- written into the log of a department that they cannot see.
CREATE TABLE audit_events (
    event_id      INTEGER PRIMARY KEY,
    at            TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    actor_id      TEXT,
    actor_kind    TEXT,
    department_id TEXT,
    action        TEXT NOT NULL,
    target        TEXT,
    result        TEXT NOT NULL CHECK (result IN ('allowed', 'denied')),
    reason        TEXT,
    request_id    TEXT,
    details       TEXT NOT NULL DEFAULT '{}'
);
CREATE INDEX ix_audit_department ON audit_events (department_id, event_id);

-- Append-only: nobody changes or deletes an event, not even the API.
CREATE TRIGGER audit_no_update BEFORE UPDATE ON audit_events
BEGIN SELECT RAISE(ABORT, 'audit_events is append-only'); END;
CREATE TRIGGER audit_no_delete BEFORE DELETE ON audit_events
BEGIN SELECT RAISE(ABORT, 'audit_events is append-only'); END;

PRAGMA user_version = 1;
