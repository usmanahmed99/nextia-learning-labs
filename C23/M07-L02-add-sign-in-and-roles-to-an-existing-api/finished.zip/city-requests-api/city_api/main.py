import logging
import time
import uuid

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware

from city_api import db, people, routes
from city_api.auth import make_validator
from city_api.config import Settings, load_settings
from city_api.errors import add_error_handlers, error_response
from city_api.models import ErrorResponse, Health, Readiness

MAX_BODY_BYTES = 16_384

logger = logging.getLogger("city_api")

DESCRIPTION = """
New York City's 311 requests of two departments, January to June 2025, cleaned
and without addresses: transport (DOT) and parks (DPR). Each department's
people see only its requests, and add notes to them.

Every /v1 route needs an access token from the identity provider
(`Authorization: Bearer ...`). The department is in the path; the API reads
your role there from its own membership table. Not a member: 404. A role or
a token scope too small: 403.

Lists are paged: follow `next_cursor` until it is null. Times are New York
local time. Every error has the same shape:
`{"error": {"code": ..., "message": ..., "request_id": ..., "fields": [...]}}`.

Data: NYC Open Data, 311 Service Requests (erm2-nwe9), snapshots of
2026-10-07 (DOT) and 2026-10-10 (DPR).
"""


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or load_settings()
    logging.basicConfig(
        level=settings.log_level, format="%(levelname)s %(name)s: %(message)s"
    )

    app = FastAPI(
        title="City Service Requests API",
        version="2.0.0",
        description=DESCRIPTION,
        openapi_tags=[
            {"name": "service requests", "description": "Find and read requests."},
            {"name": "notes", "description": "The department's notes on its requests."},
            {"name": "people", "description": "Who you are; members, roles and the audit."},
            {"name": "statistics", "description": "Daily numbers and data facts."},
            {"name": "health", "description": "Check that the service runs."},
        ],
        docs_url="/docs" if settings.show_docs else None,
        redoc_url="/redoc" if settings.show_docs else None,
        openapi_url="/openapi.json" if settings.show_docs else None,
    )
    app.state.settings = settings
    app.state.validator = make_validator(settings)
    if app.state.validator is None:
        logger.warning("OIDC_ISSUER is not set: every /v1 route answers 503")
    if not settings.access_db_path.is_file():
        logger.warning("no access database at %s: run python -m scripts.init_access",
                       settings.access_db_path)
    if not settings.database_path.is_file():
        logger.warning("no database at %s: /ready answers 503", settings.database_path)

    @app.middleware("http")
    async def request_id_and_limits(request: Request, call_next):
        request.state.request_id = uuid.uuid4().hex[:12]
        started = time.perf_counter()
        length = request.headers.get("content-length")
        if length and int(length) > MAX_BODY_BYTES:
            response = error_response(
                request,
                413,
                "body_too_large",
                f"The body is larger than {MAX_BODY_BYTES} bytes.",
            )
        else:
            response = await call_next(request)
        response.headers["X-Request-ID"] = request.state.request_id
        identity = getattr(request.state, "identity", None)
        logger.info(
            "%s %s %d %.0fms id=%s user=%s",
            request.method,
            request.url.path,
            response.status_code,
            (time.perf_counter() - started) * 1000,
            request.state.request_id,
            identity.user_id if identity else "-",
        )
        return response

    if settings.allowed_origins:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=settings.allowed_origins,
            allow_methods=["GET", "POST", "PUT", "DELETE"],
            allow_headers=["Authorization", "Content-Type"],
        )

    add_error_handlers(app)
    app.include_router(routes.signed_in)
    app.include_router(people.signed_in)
    app.include_router(routes.router)
    app.include_router(people.router)

    @app.get("/health", tags=["health"], summary="Check that the service runs")
    def health() -> Health:
        return Health(status="ok")

    @app.get(
        "/ready",
        tags=["health"],
        summary="Check that the service can read the data",
        responses={503: {"model": ErrorResponse, "description": "Not ready."}},
    )
    def ready() -> Readiness:
        con = db.connect(settings.database_path)
        try:
            con.execute("SELECT id FROM service_requests LIMIT 1").fetchone()
        finally:
            con.close()
        return Readiness(status="ready")

    return app


app = create_app()
