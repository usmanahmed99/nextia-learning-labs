import logging

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException

from city_api import audit
from city_api.auth import ProviderUnavailable, TokenRejected
from city_api.db import DatabaseUnavailable
from city_api.models import ErrorDetail, ErrorResponse
from city_api.security import NotSignedIn, SignInUnavailable

logger = logging.getLogger("city_api")

CODES = {401: "unauthorized", 404: "not_found", 405: "method_not_allowed"}


class ApiError(Exception):
    """An error that a route raises on purpose, with its status and code."""

    def __init__(self, status: int, code: str, message: str, fields=()):
        super().__init__(message)
        self.status, self.code, self.message, self.fields = status, code, message, fields


def field_name(error: dict) -> str:
    """Return the field that a validation error is about, such as "borough"."""
    if error["type"] == "json_invalid":
        return "body"
    return ".".join(str(part) for part in error["loc"][1:]) or "body"


def error_response(
    request: Request, status: int, code: str, message: str, fields=()
) -> JSONResponse:
    detail = ErrorDetail(
        code=code,
        message=message,
        request_id=getattr(request.state, "request_id", None),
        fields=list(fields),
    )
    return JSONResponse(
        status_code=status, content=ErrorResponse(error=detail).model_dump()
    )


def add_error_handlers(app: FastAPI) -> None:
    from city_api.tenancy import AccessDenied

    @app.exception_handler(RequestValidationError)
    async def invalid_request(request: Request, exc: RequestValidationError):
        fields = [field_name(e) for e in exc.errors()]
        return error_response(
            request, 422, "invalid_request", "The request is not valid.", fields
        )

    @app.exception_handler(HTTPException)
    async def http_error(request: Request, exc: HTTPException):
        code = CODES.get(exc.status_code, "http_error")
        return error_response(request, exc.status_code, code, str(exc.detail))

    @app.exception_handler(ApiError)
    async def api_error(request: Request, exc: ApiError):
        return error_response(request, exc.status, exc.code, exc.message, exc.fields)

    @app.exception_handler(DatabaseUnavailable)
    async def database_unavailable(request: Request, exc: DatabaseUnavailable):
        logger.warning("database unavailable: %s id=%s", exc, request.state.request_id)
        return error_response(
            request,
            503,
            "database_unavailable",
            "The data is not available. Try again later.",
        )

    # ---------- sign-in and roles (the authentication course's case study) ----------

    @app.exception_handler(NotSignedIn)
    async def not_signed_in(request: Request, exc: NotSignedIn):
        response = error_response(request, 401, "not_signed_in", str(exc))
        response.headers["WWW-Authenticate"] = 'Bearer realm="city-requests-api"'
        return response

    @app.exception_handler(TokenRejected)
    async def token_rejected(request: Request, exc: TokenRejected):
        logger.info("token rejected: %s id=%s", exc.code, request.state.request_id)
        # A refused token is an attempt too. The event names the check, never the token.
        audit.record(
            request.app.state.settings.access_db_path,
            action="token.check",
            result="denied",
            actor_id=None,
            reason=exc.code,
            target=f"{request.method} {request.url.path}",
            request_id=request.state.request_id,
        )
        response = error_response(request, 401, "invalid_token", str(exc))
        response.headers["WWW-Authenticate"] = (
            f'Bearer realm="city-requests-api", error="invalid_token", error_description="{exc}"'
        )
        response.headers["X-Token-Check"] = exc.code  # which check refused it
        return response

    @app.exception_handler(AccessDenied)
    async def access_denied(request: Request, exc: AccessDenied):
        d = exc.decision
        logger.info(
            "access denied: %s %s %s in %s id=%s",
            d.code,
            getattr(getattr(request.state, "identity", None), "user_id", "?"),
            exc.action,
            exc.department,
            request.state.request_id,
        )
        if d.status == 404:
            # The same answer as for a department that does not exist: an outsider learns
            # nothing.
            return error_response(request, 404, "not_found", "Not found.")
        if d.code == "missing_scope":
            response = error_response(
                request, 403, "insufficient_scope", d.rule[0].upper() + d.rule[1:] + "."
            )
            response.headers["WWW-Authenticate"] = (
                'Bearer realm="city-requests-api", error="insufficient_scope"'
            )
            return response
        return error_response(request, 403, "forbidden", f"Your role may not do this ({d.rule}).")

    @app.exception_handler(SignInUnavailable)
    async def sign_in_unavailable(request: Request, exc: SignInUnavailable):
        return error_response(
            request, 503, "sign_in_unavailable", "Sign-in is not set up on this server."
        )

    @app.exception_handler(ProviderUnavailable)
    async def provider_unavailable(request: Request, exc: ProviderUnavailable):
        logger.warning("identity provider unavailable: %s id=%s", exc, request.state.request_id)
        return error_response(
            request,
            503,
            "identity_provider_unavailable",
            "The identity provider does not answer. Try again later.",
        )

    @app.exception_handler(Exception)
    async def unexpected(request: Request, exc: Exception):
        logger.exception("unexpected error id=%s", request.state.request_id)
        return error_response(
            request, 500, "internal_error", "Something went wrong on the server."
        )
