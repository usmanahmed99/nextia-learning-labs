"""Audit events: who did, or tried, what, in which department, and the result.

An event never holds a token, a password, a secret or a note's text. The `details` are
cleaned before they are written: keys that name a secret are dropped, and any value that
looks like a JWT is replaced.
"""

import json
import logging
import re
import sqlite3

logger = logging.getLogger("city_api")

SECRET_KEYS = re.compile(r"token|secret|password|authorization|code|body", re.I)
JWT = re.compile(r"\beyJ[\w-]+\.[\w-]+\.[\w-]*")


def clean(details: dict | None) -> dict:
    out = {}
    for key, value in (details or {}).items():
        if SECRET_KEYS.search(key):
            continue
        if isinstance(value, str):
            value = JWT.sub("[removed]", value)
        out[key] = value
    return out


def write(
    con: sqlite3.Connection,
    *,
    action: str,
    result: str,
    actor_id: str | None,
    actor_kind: str | None = None,
    department_id: str | None = None,
    target: str | None = None,
    reason: str | None = None,
    request_id: str | None = None,
    details: dict | None = None,
) -> None:
    """Write one event with the caller's connection: it commits with the change it records."""
    con.execute(
        "INSERT INTO audit_events (actor_id, actor_kind, department_id, action, target,"
        " result, reason, request_id, details) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (
            actor_id,
            actor_kind,
            department_id,
            action,
            target,
            result,
            reason,
            request_id,
            json.dumps(clean(details), sort_keys=True),
        ),
    )


def record(path, **event) -> None:
    """Write one event in its own short transaction (for refusals: nothing else commits)."""
    from city_api.db import connect_access

    try:
        con = connect_access(path)
        try:
            with con:
                write(con, **event)
        finally:
            con.close()
    except Exception:  # an audit failure must not hide the answer; it is logged instead
        logger.exception("audit event not written: %s", json.dumps(clean(event), default=str))
