"""Who you are, the department's members and their roles, and the audit log.

The token says WHO (sub). The API's own access database says WHERE and WHAT: the
memberships and their roles. An owner changes them here; every change is an audit event.
"""

import sqlite3
from typing import Annotated

from fastapi import APIRouter, Depends, Path, Query, Request, Response

from city_api import audit
from city_api.errors import ApiError
from city_api.models import AuditList, Me, MemberIn, MemberList
from city_api.routes import ERRORS, SIGN_IN_ERRORS
from city_api.security import CurrentIdentity
from city_api.tenancy import AccessDb, Caller, require

router = APIRouter(prefix="/v1/departments/{department}", responses=ERRORS)
signed_in = APIRouter(prefix="/v1", responses=SIGN_IN_ERRORS)

UserId = Annotated[str, Path(min_length=1, max_length=100, examples=["usr-oliver"])]


@signed_in.get("/me", tags=["people"], summary="Who you are, and your memberships")
def me(identity: CurrentIdentity, access: AccessDb) -> Me:
    with access:  # the API learns a person's ID the first time they call it
        access.execute(
            "INSERT OR IGNORE INTO users (user_id, kind) VALUES (?, ?)",
            (identity.user_id, identity.kind),
        )
    rows = access.execute(
        "SELECT department_id AS department, role FROM memberships WHERE user_id = ?"
        " ORDER BY department_id",
        (identity.user_id,),
    ).fetchall()
    return Me(
        user_id=identity.user_id,
        kind=identity.kind,
        client_id=identity.client_id,
        scopes=sorted(identity.scopes),
        memberships=[dict(row) for row in rows],
    )


@router.get("/members", tags=["people"], summary="List the department's members (owner, staff)")
def list_members(
    caller: Annotated[Caller, Depends(require("member.read"))], access: AccessDb
) -> MemberList:
    rows = access.execute(
        "SELECT m.user_id, u.name, u.kind, m.role FROM memberships m"
        " JOIN users u ON u.user_id = m.user_id"
        " WHERE m.department_id = ? ORDER BY m.role, m.user_id",
        (caller.department,),
    ).fetchall()
    return MemberList(items=[dict(row) for row in rows])


def owners(access: sqlite3.Connection, department: str) -> int:
    return access.execute(
        "SELECT COUNT(*) FROM memberships WHERE department_id = ? AND role = 'owner'",
        (department,),
    ).fetchone()[0]


def role_in(access: sqlite3.Connection, department: str, user_id: str) -> str | None:
    row = access.execute(
        "SELECT role FROM memberships WHERE department_id = ? AND user_id = ?",
        (department, user_id),
    ).fetchone()
    return row["role"] if row else None


@router.put(
    "/members/{user_id}",
    tags=["people"],
    summary="Add a person to the department, or change their role (owner)",
    responses={409: {"description": "The department would have no owner."}},
)
def set_member(
    caller: Annotated[Caller, Depends(require("member.manage"))],
    user_id: UserId,
    member: MemberIn,
    request: Request,
    access: AccessDb,
) -> MemberList:
    with access:
        if access.execute("SELECT 1 FROM users WHERE user_id = ?", (user_id,)).fetchone() is None:
            raise ApiError(
                404, "unknown_user", "No person with this ID has signed in to the API yet."
            )
        before = role_in(access, caller.department, user_id)
        if before == "owner" and member.role != "owner" and owners(access, caller.department) == 1:
            raise ApiError(409, "last_owner", "A department needs at least one owner.")
        access.execute(
            "INSERT INTO memberships (department_id, user_id, role) VALUES (?, ?, ?)"
            " ON CONFLICT (department_id, user_id) DO UPDATE SET role = excluded.role",
            (caller.department, user_id, member.role),
        )
        audit.write(
            access,
            action="member.add" if before is None else "member.change_role",
            result="allowed",
            actor_id=caller.user_id,
            actor_kind=caller.identity.kind,
            department_id=caller.department,
            target=f"user {user_id}",
            request_id=request.state.request_id,
            details={"role_before": before, "role_after": member.role},
        )
    return list_members(caller, access)


@router.delete(
    "/members/{user_id}",
    status_code=204,
    tags=["people"],
    summary="Remove a person from the department (owner)",
    responses={409: {"description": "The department would have no owner."}},
)
def remove_member(
    caller: Annotated[Caller, Depends(require("member.manage"))],
    user_id: UserId,
    request: Request,
    access: AccessDb,
) -> Response:
    with access:
        before = role_in(access, caller.department, user_id)
        if before is None:
            raise ApiError(404, "not_found", "This person is not a member of the department.")
        if before == "owner" and owners(access, caller.department) == 1:
            raise ApiError(409, "last_owner", "A department needs at least one owner.")
        access.execute(
            "DELETE FROM memberships WHERE department_id = ? AND user_id = ?",
            (caller.department, user_id),
        )
        audit.write(
            access,
            action="member.remove",
            result="allowed",
            actor_id=caller.user_id,
            actor_kind=caller.identity.kind,
            department_id=caller.department,
            target=f"user {user_id}",
            request_id=request.state.request_id,
            details={"role_before": before},
        )
    return Response(status_code=204)


@router.get("/audit", tags=["people"], summary="Read the department's audit events (owner)")
def read_audit(
    caller: Annotated[Caller, Depends(require("audit.read"))],
    access: AccessDb,
    limit: Annotated[int, Query(ge=1, le=200)] = 50,
) -> AuditList:
    rows = access.execute(
        "SELECT event_id, at, actor_id, action, target, result, reason, request_id"
        " FROM audit_events WHERE department_id = ? ORDER BY event_id DESC LIMIT ?",
        (caller.department, limit),
    ).fetchall()
    return AuditList(items=[dict(row) for row in rows])
