"""Every SQL statement of the API.

Values from the request reach SQLite only as parameters (the ? marks), never
as part of the SQL text. Column names and SQL words come only from this file.

Every function that reads requests takes the department as a required keyword
argument, and every statement has department = ?. The department comes from
the caller's checked membership (city_api/tenancy.py), never from the client.
A call that forgets it fails in Python, before any SQL runs.
"""

import sqlite3
import statistics
from datetime import date, timedelta

COLUMNS = (
    "id, created_at, closed_at, status, complaint_type, descriptor, location_type, "
    "borough, community_board, council_district, incident_zip, channel, "
    "latitude, longitude, days_to_close"
)

# The filters that a request may use, and the condition each one adds.
# A filter that is not in this table cannot reach the SQL.
CONDITIONS = {
    "borough": "borough = ?",
    "complaint_type": "complaint_type = ?",
    "status": "status = ?",
    "created_from": "created_at >= ?",
    "created_to": "created_at < ?",
}


def where(filters: dict, *, department: str) -> tuple[str, list]:
    """Build the WHERE clause and its parameters: the department first, then the
    filters that are set."""
    parts, params = ["department = ?"], [department]
    for name, value in filters.items():
        if value is not None:
            parts.append(CONDITIONS[name])
            params.append(value)
    return " AND ".join(parts), params


def get_request(
    con: sqlite3.Connection, request_id: int, *, department: str
) -> sqlite3.Row | None:
    """One request of this department. Another department's request is not found."""
    return con.execute(
        f"SELECT {COLUMNS} FROM service_requests WHERE department = ? AND id = ?",
        (department, request_id),
    ).fetchone()


def list_requests(
    con: sqlite3.Connection,
    filters: dict,
    after: tuple[str, int] | None,
    limit: int,
    *,
    department: str,
) -> list[sqlite3.Row]:
    """One page, oldest first. Asks for limit + 1 rows to know if more exist."""
    condition, params = where(filters, department=department)
    if after is not None:
        condition += " AND (created_at, id) > (?, ?)"
        params += list(after)
    sql = (
        f"SELECT {COLUMNS} FROM service_requests WHERE {condition} "
        "ORDER BY created_at, id LIMIT ?"
    )
    return con.execute(sql, [*params, limit + 1]).fetchall()


def complaint_types(con: sqlite3.Connection, *, department: str) -> list[sqlite3.Row]:
    return con.execute(
        "SELECT complaint_type, COUNT(*) AS count FROM service_requests "
        "WHERE department = ? GROUP BY complaint_type ORDER BY count DESC, complaint_type",
        (department,),
    ).fetchall()


def daily_stats(
    con: sqlite3.Connection, filters: dict, start: date, end: date, *, department: str
) -> list[dict]:
    """Opened, closed within 14 days and the median days to close, for each day."""
    condition, params = where(
        {**filters, "created_from": start.isoformat(), "created_to": end.isoformat()},
        department=department,
    )
    counts = con.execute(
        "SELECT substr(created_at, 1, 10) AS day, COUNT(*) AS opened, "
        "SUM(CASE WHEN closed_at IS NOT NULL AND days_to_close <= 14 THEN 1 ELSE 0 END) AS within_14 "
        f"FROM service_requests WHERE {condition} GROUP BY day",
        params,
    ).fetchall()
    # SQLite has no MEDIAN function, so Python computes it from the values.
    durations: dict[str, list[float]] = {}
    for day, days in con.execute(
        "SELECT substr(created_at, 1, 10), days_to_close FROM service_requests "
        f"WHERE {condition} AND closed_at IS NOT NULL",
        params,
    ):
        durations.setdefault(day, []).append(days)

    by_day = {row["day"]: row for row in counts}
    result = []
    for offset in range((end - start).days):
        day = (start + timedelta(days=offset)).isoformat()
        row = by_day.get(day)
        opened = row["opened"] if row else 0
        within = row["within_14"] if row else 0
        values = durations.get(day)
        result.append(
            {
                "date": day,
                "opened": opened,
                "closed_within_14_days": within,
                "share_closed_within_14_days": round(within / opened, 3) if opened else None,
                "median_days_to_close": round(statistics.median(values), 2) if values else None,
            }
        )
    return result


def dataset_info(con: sqlite3.Connection) -> dict[str, str]:
    return dict(con.execute("SELECT name, value FROM meta").fetchall())
