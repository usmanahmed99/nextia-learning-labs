import sqlite3
from collections.abc import Iterator
from datetime import datetime
from typing import Annotated

from fastapi import APIRouter, Depends, Path, Query, Request

from city_api import audit, db, queries
from city_api.errors import ApiError
from city_api.models import (
    ComplaintTypeList,
    DailyStats,
    DatasetInfo,
    ErrorResponse,
    ListQuery,
    Note,
    NoteIn,
    NoteList,
    ServiceRequest,
    ServiceRequestPage,
    StatsQuery,
)
from city_api.pagination import decode_cursor, encode_cursor
from city_api.security import CurrentIdentity
from city_api.tenancy import AccessDb, Caller, require

MAX_STATS_DAYS = 92

SIGN_IN_ERRORS = {
    401: {"model": ErrorResponse, "description": "No access token, or the token is not valid."},
    503: {"model": ErrorResponse, "description": "The data or the sign-in is not available."},
}
ERRORS = {
    **SIGN_IN_ERRORS,
    403: {"model": ErrorResponse, "description": "Your role or the token's scope is too small."},
    404: {"model": ErrorResponse, "description": "Not found, or not a member of the department."},
    422: {"model": ErrorResponse, "description": "A parameter is not valid."},
}

router = APIRouter(prefix="/v1/departments/{department}", responses=ERRORS)
signed_in = APIRouter(prefix="/v1", responses=SIGN_IN_ERRORS)

ReadRequests = Annotated[Caller, Depends(require("request.read"))]
WriteNotes = Annotated[Caller, Depends(require("note.write"))]
RequestId = Annotated[int, Path(ge=1, description="The request's id.")]


def get_db(request: Request) -> Iterator[sqlite3.Connection]:
    """Give the route a read-only connection, and close it after the response."""
    con = db.connect(request.app.state.settings.database_path)
    try:
        yield con
    finally:
        con.close()


Database = Annotated[sqlite3.Connection, Depends(get_db)]


def iso(moment: datetime | None) -> str | None:
    """2025-03-01 00:00 -> '2025-03-01T00:00:00', the format of the database."""
    return moment.isoformat() if moment else None


def check_range(start, end) -> None:
    if start is not None and end is not None and start >= end:
        raise ApiError(
            422,
            "invalid_range",
            "created_from must be before created_to.",
            ["created_from", "created_to"],
        )


def request_of_department(con: sqlite3.Connection, request_id: int, department: str):
    """The request, if it is this department's. Another department's request gets the
    same answer as an ID that does not exist: inside this department, it does not."""
    row = queries.get_request(con, request_id, department=department)
    if row is None:
        raise ApiError(404, "not_found", f"No service request has the ID {request_id}.")
    return row


@router.get(
    "/service-requests",
    tags=["service requests"],
    summary="List the department's service requests, one page at a time",
    description=(
        "Requests of the department that match every filter, oldest first (by created_at, "
        "then id). Each page has at most `limit` requests. If `next_cursor` is not null, "
        "send it as `cursor`, with the same filters, to get the next page."
    ),
)
def list_service_requests(
    caller: ReadRequests, query: Annotated[ListQuery, Query()], con: Database
) -> ServiceRequestPage:
    check_range(query.created_from, query.created_to)
    filters = {
        "borough": query.borough,
        "complaint_type": query.complaint_type,
        "status": query.status,
        "created_from": iso(query.created_from),
        "created_to": iso(query.created_to),
    }
    # The cursor belongs to one department's list too: a cursor of another list is refused.
    bound = {**filters, "department": caller.department}
    after = decode_cursor(query.cursor, bound) if query.cursor else None
    rows = queries.list_requests(con, filters, after, query.limit, department=caller.department)
    page = rows[: query.limit]
    next_cursor = None
    if len(rows) > query.limit:
        last = page[-1]
        next_cursor = encode_cursor(last["created_at"], last["id"], bound)
    return ServiceRequestPage(items=[dict(row) for row in page], next_cursor=next_cursor)


@router.get(
    "/service-requests/{request_id}",
    tags=["service requests"],
    summary="Get one of the department's service requests",
)
def get_service_request(caller: ReadRequests, request_id: RequestId, con: Database) -> ServiceRequest:
    return ServiceRequest(**dict(request_of_department(con, request_id, caller.department)))


@router.get(
    "/service-requests/{request_id}/notes",
    tags=["notes"],
    summary="Read the department's notes on a request",
)
def list_notes(
    caller: ReadRequests, request_id: RequestId, con: Database, access: AccessDb
) -> NoteList:
    request_of_department(con, request_id, caller.department)
    rows = access.execute(
        "SELECT note_id, request_id, author_id, body, created_at FROM request_notes"
        " WHERE department_id = ? AND request_id = ? ORDER BY note_id",
        (caller.department, request_id),
    ).fetchall()
    return NoteList(items=[dict(row) for row in rows])


@router.post(
    "/service-requests/{request_id}/notes",
    status_code=201,
    tags=["notes"],
    summary="Add a note to a request (owner or staff)",
)
def add_note(
    caller: WriteNotes,
    request_id: RequestId,
    note: NoteIn,
    request: Request,
    con: Database,
    access: AccessDb,
) -> Note:
    request_of_department(con, request_id, caller.department)
    with access:  # the note and its audit event commit together, or not at all
        cursor = access.execute(
            "INSERT INTO request_notes (department_id, request_id, author_id, body)"
            " VALUES (?, ?, ?, ?) RETURNING note_id, request_id, author_id, body, created_at",
            (caller.department, request_id, caller.user_id, note.body),
        )
        row = cursor.fetchone()
        cursor.close()
        audit.write(
            access,
            action="note.create",
            result="allowed",
            actor_id=caller.user_id,
            actor_kind=caller.identity.kind,
            department_id=caller.department,
            target=f"service-request {request_id}",
            request_id=request.state.request_id,
            details={"note_id": row["note_id"], "length": len(note.body)},
        )
    return Note(**dict(row))


@router.get(
    "/complaint-types",
    tags=["service requests"],
    summary="List the department's complaint types, with the number of requests",
)
def list_complaint_types(caller: ReadRequests, con: Database) -> ComplaintTypeList:
    rows = queries.complaint_types(con, department=caller.department)
    return ComplaintTypeList(items=[dict(row) for row in rows])


@router.get(
    "/stats/daily",
    tags=["statistics"],
    summary="Count the department's requests opened and closed for each day",
    description=(
        "For each day from `created_from` to the day before `created_to`: the requests "
        "opened, how many of them were closed within 14 days, and the median days to "
        f"close. The range is at most {MAX_STATS_DAYS} days. Days without requests are "
        "included, with `opened` 0."
    ),
)
def daily_stats(
    caller: ReadRequests, query: Annotated[StatsQuery, Query()], con: Database
) -> DailyStats:
    check_range(query.created_from, query.created_to)
    if (query.created_to - query.created_from).days > MAX_STATS_DAYS:
        raise ApiError(
            422,
            "range_too_large",
            f"The range is longer than {MAX_STATS_DAYS} days. Ask for a shorter one.",
            ["created_from", "created_to"],
        )
    filters = {"borough": query.borough, "complaint_type": query.complaint_type}
    items = queries.daily_stats(
        con, filters, query.created_from, query.created_to, department=caller.department
    )
    return DailyStats(items=items)


@signed_in.get(
    "/dataset",
    tags=["statistics"],
    summary="Where the data comes from, and its snapshot date",
)
def dataset(identity: CurrentIdentity, con: Database) -> DatasetInfo:
    return DatasetInfo(**queries.dataset_info(con))
