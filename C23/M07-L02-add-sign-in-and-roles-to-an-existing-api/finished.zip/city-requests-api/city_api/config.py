import os
from dataclasses import dataclass
from pathlib import Path

# RFC 9068 access tokens say "at+jwt" in their header. Keycloak and Microsoft Entra ID
# say "JWT": for them, set ACCESS_TOKEN_TYPES=JWT (the audience check still refuses an
# ID token, because an ID token's audience is the application, not this API).
DEFAULT_TOKEN_TYPES = "at+jwt,application/at+jwt"


@dataclass(frozen=True)
class Settings:
    allowed_origins: list[str]
    database_path: Path
    log_level: str
    show_docs: bool
    # Sign-in and roles (the authentication course's case study).
    access_db_path: Path = Path("data/access.db")
    oidc_issuer: str | None = None  # not set: sign-in is off, and /v1 answers 503
    oidc_audience: str = "city-requests-api"
    oidc_internal_url: str | None = None  # where the API reaches the provider, if different
    access_token_types: tuple[str, ...] = tuple(DEFAULT_TOKEN_TYPES.split(","))
    jwks_cache_seconds: float = 600
    jwks_min_refresh_seconds: float = 10
    token_leeway_seconds: float = 30
    user_id_claim: str = "sub"  # Microsoft Entra ID: "oid" (see docs/entra-id.md)


def load_env() -> None:
    """Read .env (if there is one) into the environment, without overriding what is set."""
    from dotenv import load_dotenv

    load_dotenv(Path.cwd() / ".env", override=False)


def load_settings() -> Settings:
    """Read the settings from .env and the environment, with safe defaults."""
    load_env()
    origins = os.environ.get("ALLOWED_ORIGINS", "")
    types = os.environ.get("ACCESS_TOKEN_TYPES", DEFAULT_TOKEN_TYPES)
    return Settings(
        allowed_origins=[o.strip() for o in origins.split(",") if o.strip()],
        database_path=Path(
            os.environ.get("DATABASE_PATH", "data/service_requests_2025h1_v2.db")
        ),
        log_level=os.environ.get("LOG_LEVEL", "INFO").upper(),
        show_docs=os.environ.get("SHOW_DOCS", "true").lower() == "true",
        access_db_path=Path(os.environ.get("ACCESS_DB_PATH", "data/access.db")),
        oidc_issuer=os.environ.get("OIDC_ISSUER") or None,
        oidc_audience=os.environ.get("OIDC_AUDIENCE", "city-requests-api"),
        oidc_internal_url=os.environ.get("OIDC_INTERNAL_URL") or None,
        access_token_types=tuple(t.strip() for t in types.split(",") if t.strip()),
        jwks_cache_seconds=float(os.environ.get("JWKS_CACHE_SECONDS", "600")),
        jwks_min_refresh_seconds=float(os.environ.get("JWKS_MIN_REFRESH_SECONDS", "10")),
        token_leeway_seconds=float(os.environ.get("TOKEN_LEEWAY_SECONDS", "30")),
        user_id_claim=os.environ.get("USER_ID_CLAIM", "sub"),
    )
