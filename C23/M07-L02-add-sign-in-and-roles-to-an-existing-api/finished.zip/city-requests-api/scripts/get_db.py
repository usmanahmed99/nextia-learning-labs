"""Download the database of the case study, check it, and unpack it.

    python scripts/get_db.py                  # downloads about 13 MB
    python scripts/get_db.py --file FILE      # uses a .db.gz that you have

It writes data/service_requests_2025h1_v2.db (about 65 MB): the 311 requests of two
departments, transport and parks (version 2 of the API course's database). To make the
same database yourself from the NYC 311 files, use scripts/build_db.py instead.
"""

import argparse
import gzip
import hashlib
import shutil
import sqlite3
import subprocess
import sys
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
URL = (
    "https://github.com/usmanahmed99/nextia-learning-labs/raw/main/"
    "C23/M07-L02-add-sign-in-and-roles-to-an-existing-api/data/service_requests_2025h1_v2.db.gz"
)
SHA256 = "f6d4201fd8494690dc9f3aec76c295ce1bec79c846c46d9b799b04692adabd8c"
GZ = ROOT / "data" / "service_requests_2025h1_v2.db.gz"
DB = ROOT / "data" / "service_requests_2025h1_v2.db"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as file:
        for block in iter(lambda: file.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--file", help="a local copy of service_requests_2025h1_v2.db.gz")
    args = parser.parse_args()

    GZ.parent.mkdir(exist_ok=True)
    if args.file:
        shutil.copyfile(args.file, GZ)
    elif not GZ.exists():
        print(f"Downloading {URL}")
        try:
            urllib.request.urlretrieve(URL, GZ)
        except OSError as error:
            # Python from the python.org installer on macOS has no certificates
            # until you run "Install Certificates.command". curl uses the
            # computer's own certificates, so try it before giving up. The
            # checksum below still checks the file.
            try:
                subprocess.run(["curl", "-fsSL", "-o", str(GZ), URL], check=True)
            except (OSError, subprocess.CalledProcessError):
                GZ.unlink(missing_ok=True)
                sys.exit(
                    f"Could not download the database: {error}\n"
                    "Check your internet connection, then run the script again. On macOS, if the\n"
                    "error says CERTIFICATE_VERIFY_FAILED, open Applications > Python 3.x and run\n"
                    "Install Certificates.command, or use --file with a copy you downloaded."
                )
    if sha256(GZ) != SHA256:
        GZ.unlink()
        sys.exit("The download is not the expected file (SHA-256 differs). Run the script again.")
    print(f"Checked {GZ.name}: SHA-256 {SHA256[:12]}... is correct")

    with gzip.open(GZ, "rb") as source, DB.open("wb") as target:
        shutil.copyfileobj(source, target)
    con = sqlite3.connect(f"{DB.resolve().as_uri()}?mode=ro", uri=True)
    counts = con.execute(
        "SELECT department, COUNT(*) FROM service_requests GROUP BY department ORDER BY 1 DESC"
    ).fetchall()
    con.close()
    print(
        f"Wrote {DB.relative_to(ROOT)}: "
        + ", ".join(f"{department} {n:,}" for department, n in counts)
        + " service requests"
    )


if __name__ == "__main__":
    main()
