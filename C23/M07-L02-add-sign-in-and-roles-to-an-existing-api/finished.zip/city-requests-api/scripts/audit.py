"""Read the audit events, and check that none holds a token or a secret.

    python -m scripts.audit                      the last 20 events, newest first
    python -m scripts.audit --department transport --result denied
    python -m scripts.audit --check              scan every event for a JWT, "Bearer" and
                                                 the secrets of .env
"""

import argparse
import os
import re
import sqlite3
import sys
from pathlib import Path

from scripts import load_env

JWT = re.compile(r"eyJ[\w-]+\.[\w-]+")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--department")
    parser.add_argument("--result", choices=["allowed", "denied"])
    parser.add_argument("--limit", type=int, default=20)
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args(argv)
    load_env()
    con = sqlite3.connect(Path(os.environ.get("ACCESS_DB_PATH", "data/access.db")))
    con.row_factory = sqlite3.Row
    if args.check:
        secrets = [v for k, v in os.environ.items() if k.endswith("SECRET") and len(v) >= 8]
        rows = con.execute("SELECT * FROM audit_events").fetchall()
        bad = 0
        for row in rows:
            text = " ".join(str(v) for v in dict(row).values())
            if JWT.search(text) or "Bearer" in text or any(s in text for s in secrets):
                bad += 1
                print(f"event {row['event_id']}: holds a token or a secret")
        print(f"{len(rows)} audit events checked, {bad} with a token or a secret.")
        return 1 if bad else 0
    where, params = ["1 = 1"], []
    if args.department:
        where.append("department_id = ?")
        params.append(args.department)
    if args.result:
        where.append("result = ?")
        params.append(args.result)
    rows = con.execute(
        f"SELECT * FROM audit_events WHERE {' AND '.join(where)} ORDER BY event_id DESC LIMIT ?",
        [*params, args.limit],
    ).fetchall()
    for r in rows:
        print(
            f"{r['event_id']:>4} {r['at'][11:23]} {r['actor_id'] or '-':<21} "
            f"{r['department_id'] or '-':<10} {r['action']:<18} {r['result']:<7} "
            f"{r['reason'] or '':<21} {r['target'] or ''}"
        )
    return 0


if __name__ == "__main__":
    sys.exit(main())
