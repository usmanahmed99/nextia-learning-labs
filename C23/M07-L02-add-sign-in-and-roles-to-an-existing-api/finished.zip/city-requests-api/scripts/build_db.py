"""Build data/service_requests_2025h1_v2.db from the NYC 311 files of two departments.

You do not need this script to do the case study: scripts/get_db.py downloads
the finished database. Use this one to see, check or change how the database
is made.

    python scripts/build_db.py                          # downloads the two files (20 MB)
    python scripts/build_db.py --dot FILE --dpr FILE    # uses copies that you have

The inputs are two frozen copies of NYC 311 Service Requests (erm2-nwe9):
- agency DOT (transport), created 2024-01-01 to 2025-06-30, pulled on 2026-10-07:
  the file of the SQL course and of the API course's case study;
- agency DPR (parks), created 2025-01-01 to 2025-06-30, pulled on 2026-10-10:
  added by the authentication course's case study.
The script keeps January to June 2025 and applies the rules in RULES below.
Version 2 of the database: the column department ('transport' or 'parks').
The transport rows are the same 109,915 rows as in version 1.
"""

import argparse
import csv
import gzip
import hashlib
import sqlite3
import sys
import urllib.request
from collections import Counter
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SCHEMA = ROOT / "city_api" / "schema.sql"
OUT = ROOT / "data" / "service_requests_2025h1_v2.db"
LABS = "https://github.com/usmanahmed99/nextia-learning-labs/raw/main/"
# department: (agency, file name, where it is published, its SHA-256)
SOURCES = {
    "transport": (
        "DOT",
        "nyc311_dot_2024-01_2025-06.csv.gz",
        LABS + "C04/case-studies/data/nyc311_dot_2024-01_2025-06.csv.gz",
        "31240271a6961024526bca4750f09ed6297b24fee1dcc5d506004102066cf9e2",
    ),
    "parks": (
        "DPR",
        "nyc311_dpr_2025h1.csv.gz",
        LABS + "C23/M07-L02-add-sign-in-and-roles-to-an-existing-api/data/nyc311_dpr_2025h1.csv.gz",
        "df10c9ba1f1b81a5c9b6013624298b1ff818702b33f771192374b7ba8b0f986e",
    ),
}
SCHEMA_VERSION = 2
FIRST, END = "2025-01-01", "2025-07-01"  # keep FIRST <= created < END

RULES = """\
R1 Keep requests created from 2025-01-01 to 2025-06-30 (New York local time).
R2 Remove repeated submissions: rows that are equal in every column except the
   ID are one request sent more than once. Keep the lowest ID.
R3 Leave out requests whose close time is before their creation time: we
   cannot correct them with confidence.
R4 Keep no address, no free text and no columns that are the same in every row:
   drop city, address_type, due_date, resolution_description and
   resolution_action_updated_date. The agency becomes the department (R10).
R5 Write times as 2025-03-01T07:00:00 (the source adds .000, and has no time zone).
R6 'Unspecified' and empty values become NULL: borough, community board,
   status, channel ('UNKNOWN'), location type, council district, ZIP code
   (if not five digits), latitude and longitude.
R7 Short, fixed codes: borough 'STATEN ISLAND' becomes 'staten_island',
   status 'In Progress' becomes 'in_progress', channel 'PHONE' becomes 'phone'.
R8 days_to_close = closed_at - created_at in days, 2 decimals, when closed_at is set.
R9 Every request ID is unique (checked; the script stops if not).
R10 department = 'transport' for agency DOT and 'parks' for agency DPR. R2 and R9
   are applied to each department's file; the IDs are unique across both too."""

# R2: the columns that must be equal for two rows to be one repeated request.
COMPARED = [
    "created_date", "closed_date", "status", "complaint_type", "descriptor",
    "location_type", "borough", "community_board", "council_district",
    "incident_zip", "open_data_channel_type", "latitude", "longitude",
    "resolution_description", "resolution_action_updated_date",
]

BOROUGHS = {
    "BRONX": "bronx",
    "BROOKLYN": "brooklyn",
    "MANHATTAN": "manhattan",
    "QUEENS": "queens",
    "STATEN ISLAND": "staten_island",
}
STATUSES = {
    "Open": "open",
    "Assigned": "assigned",
    "In Progress": "in_progress",
    "Pending": "pending",
    "Closed": "closed",
}
CHANNELS = {"ONLINE": "online", "PHONE": "phone", "MOBILE": "mobile", "OTHER": "other"}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as file:
        for block in iter(lambda: file.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def get_source(department: str, source: str | None) -> Path:
    _, name, url, expected = SOURCES[department]
    path = Path(source) if source else ROOT / "data" / name
    if not path.exists():
        print(f"Downloading {url}")
        path.parent.mkdir(exist_ok=True)
        urllib.request.urlretrieve(url, path)
    if sha256(path) != expected:
        sys.exit(f"{path} is not the expected file (SHA-256 differs). Delete it and try again.")
    return path


def clock(value: str) -> str | None:
    """'2025-03-01T07:00:00.000' -> '2025-03-01T07:00:00'; '' -> None."""
    return value[:19] if value else None


def days_between(start: str, end: str) -> float:
    seconds = (datetime.fromisoformat(end) - datetime.fromisoformat(start)).total_seconds()
    return round(seconds / 86400, 2)


def clean(row: dict, counts: Counter, department: str) -> tuple:
    created, closed = clock(row["created_date"]), clock(row["closed_date"])
    if row["borough"] not in BOROUGHS:
        counts[f"R6 borough {row['borough']!r} -> NULL"] += 1
    if row["open_data_channel_type"] not in CHANNELS:
        counts[f"R6 channel {row['open_data_channel_type']!r} -> NULL"] += 1
    if row["status"] not in STATUSES:
        counts[f"R6 status {row['status']!r} -> NULL"] += 1
    board = row["community_board"]
    if "Unspecified" in board:
        counts["R6 community board 'Unspecified ...' -> NULL"] += 1
        board = ""
    return (
        int(row["unique_key"]),
        created,
        closed,
        STATUSES.get(row["status"]),
        row["complaint_type"].strip(),
        row["descriptor"].strip() or None,
        row["location_type"].strip() or None,
        BOROUGHS.get(row["borough"]),
        board or None,
        int(row["council_district"]) if row["council_district"] else None,
        row["incident_zip"] if len(row["incident_zip"]) == 5 and row["incident_zip"].isdigit() else None,
        CHANNELS.get(row["open_data_channel_type"]),
        float(row["latitude"]) if row["latitude"] else None,
        float(row["longitude"]) if row["longitude"] else None,
        days_between(created, closed) if closed else None,
        department,
    )


def read_department(department: str, source: Path, counts: Counter) -> list[tuple]:
    agency = SOURCES[department][0]
    with gzip.open(source, "rt", encoding="utf-8", newline="") as file:
        raw = [row for row in csv.DictReader(file) if row["agency"] == agency]
    selected = [row for row in raw if FIRST <= row["created_date"] < END]  # R1
    selected.sort(key=lambda row: int(row["unique_key"]))
    print(f"{department} ({agency}): read {len(raw):,} requests; {len(selected):,} created in 2025-H1 (R1)")
    rows, seen_ids, seen_content = [], set(), set()
    for row in selected:
        if row["unique_key"] in seen_ids:
            sys.exit(f"R9 failed: request {row['unique_key']} appears twice")
        seen_ids.add(row["unique_key"])
        content = tuple(row[column] for column in COMPARED)
        if content in seen_content:
            counts[f"R2 {department}: repeated submissions removed"] += 1
            continue
        seen_content.add(content)
        if row["closed_date"] and row["closed_date"] < row["created_date"]:
            counts[f"R3 {department}: closed before created, left out"] += 1
            continue
        rows.append(clean(row, counts, department))
    return rows


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--dot", help="a local copy of the DOT .csv.gz file")
    parser.add_argument("--dpr", help="a local copy of the DPR .csv.gz file")
    parser.add_argument("--out", default=str(OUT), help="the database to write")
    args = parser.parse_args()

    counts: Counter = Counter()
    sources = {
        "transport": get_source("transport", args.dot),
        "parks": get_source("parks", args.dpr),
    }
    rows = []
    for department, source in sources.items():
        rows += read_department(department, source, counts)
    ids = [r[0] for r in rows]
    if len(ids) != len(set(ids)):
        sys.exit("R10 failed: a request ID is in both departments")
    rows.sort(key=lambda r: (r[1], r[0]))  # the same file every time

    out = Path(args.out)
    out.parent.mkdir(exist_ok=True)
    out.unlink(missing_ok=True)
    con = sqlite3.connect(out)
    con.executescript(SCHEMA.read_text(encoding="utf-8"))
    con.executemany(f"INSERT INTO service_requests VALUES ({', '.join('?' * 16)})", rows)
    info = {
        "source": "NYC 311 Service Requests from 2020 to Present (data.cityofnewyork.us, erm2-nwe9), "
        "agencies DOT (department transport) and DPR (department parks)",
        "source_file": "; ".join(
            f"{SOURCES[d][1]} (SHA-256 {SOURCES[d][3]})" for d in SOURCES
        ),
        "pulled_on": "2026-10-07 (DOT), 2026-10-10 (DPR)",
        "created_from": FIRST,
        "created_to": END,
        "rows": str(len(rows)),
        "rules": RULES,
    }
    con.executemany("INSERT INTO meta VALUES (?, ?)", info.items())
    con.execute(f"PRAGMA user_version = {SCHEMA_VERSION}")
    con.commit()
    con.execute("VACUUM")
    con.close()

    kept = Counter(r[-1] for r in rows)
    print(f"Kept {len(rows):,}: transport {kept['transport']:,}, parks {kept['parks']:,}.")
    for change, number in sorted(counts.items()):
        print(f"  {number:>6,}  {change}")
    print(f"Wrote {out} ({out.stat().st_size / 1e6:.1f} MB)")


if __name__ == "__main__":
    main()
