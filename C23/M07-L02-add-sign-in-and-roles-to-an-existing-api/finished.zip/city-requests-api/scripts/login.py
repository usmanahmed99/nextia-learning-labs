"""Sign in and get an access token for the city requests API.

    python -m scripts.login --user usr-teresa          the practice provider: pick a made-up person
    python -m scripts.login --user usr-teresa --print-access-token     only the access token
    python -m scripts.login --browser --name teresa    any provider (also Keycloak): sign in in
                                                       your browser; the code comes back to
                                                       http://127.0.0.1:8775/callback
    python -m scripts.login --service                  the dashboard server's own token
    python -m scripts.login --refresh usr-teresa       new tokens for the saved refresh token

It is the application "city-cli": a public client (it cannot keep a secret), so it uses the
authorization code flow with PKCE (RFC 7636). The provider is OIDC_ISSUER from .env. The
tokens are saved in .tokens/<name>.json (git-ignored) for the next commands.
"""

import argparse
import base64
import hashlib
import json
import os
import secrets
import sys
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlencode, urlparse

import httpx
import jwt

from scripts import load_env

REDIRECT_URI = "http://127.0.0.1:8775/callback"
SCOPE = "openid profile email offline_access requests:read requests:write members:manage"
TOKENS = Path(".tokens")


def short(token: str, n: int = 24) -> str:
    return f"{token[:n]}...({len(token)} characters)"


def claims(token: str) -> dict:
    """The claims WITHOUT checking the token: only to look. The API checks (city_api/auth.py)."""
    return jwt.decode(token, options={"verify_signature": False})


def pkce_pair() -> tuple[str, str]:
    verifier = secrets.token_urlsafe(48)  # 64 characters: RFC 7636 needs 43 to 128
    digest = hashlib.sha256(verifier.encode("ascii")).digest()
    return verifier, base64.urlsafe_b64encode(digest).decode().rstrip("=")


def save(name: str, body: dict) -> Path:
    TOKENS.mkdir(exist_ok=True)
    path = TOKENS / f"{name}.json"
    path.write_text(json.dumps(body, indent=2) + "\n", encoding="utf-8")
    path.chmod(0o600)
    return path


def discovery(issuer: str) -> dict:
    return httpx.get(f"{issuer}/.well-known/openid-configuration", timeout=10).json()


def start(issuer: str, client_id: str) -> tuple[dict, str, str]:
    """The sign-in request: (its parameters, the PKCE verifier, the authorization URL)."""
    verifier, challenge = pkce_pair()
    params = {
        "response_type": "code",
        "client_id": client_id,
        "redirect_uri": REDIRECT_URI,
        "scope": SCOPE,
        "state": secrets.token_urlsafe(16),
        "nonce": secrets.token_urlsafe(16),
        "code_challenge": challenge,
        "code_challenge_method": "S256",
    }
    url = discovery(issuer)["authorization_endpoint"] + "?" + urlencode(params)
    return params, verifier, url


def finish(issuer: str, params: dict, verifier: str, redirect: str, say) -> dict:
    """Check the redirect's state, swap the code and the verifier for tokens."""
    query = parse_qs(urlparse(redirect).query)
    if "error" in query:
        reason = query.get("error_description", [""])[0]
        raise SystemExit(f"The provider refused: {query['error'][0]} {reason}")
    if query.get("state") != [params["state"]]:
        raise SystemExit("The state is not the one we sent: stop (a forged redirect?).")
    say("2. The provider sent the browser back with a one-time code; the state matches.")
    response = httpx.post(
        discovery(issuer)["token_endpoint"],
        data={
            "grant_type": "authorization_code",
            "client_id": params["client_id"],
            "code": query["code"][0],
            "redirect_uri": REDIRECT_URI,
            "code_verifier": verifier,
        },
        timeout=10,
    )
    if response.status_code != 200:
        raise SystemExit(f"{response.status_code} {response.text}")
    body = response.json()
    if claims(body["id_token"]).get("nonce") != params["nonce"]:
        raise SystemExit("The ID token's nonce is not ours: stop.")
    say("3. The code and the PKCE verifier were swapped for tokens (POST /token):")
    say(f"   200: token_type {body['token_type']}, expires_in {body['expires_in']} s")
    say(f"   access_token  {short(body['access_token'])}")
    say(f"   id_token      {short(body['id_token'])}")
    return body


def pick(issuer: str, client_id: str, user: str, say) -> dict:
    """The practice provider only: its sign-in page lists made-up people, no password."""
    params, verifier, url = start(issuer, client_id)
    say(f"1. The sign-in page of the practice provider, with a PKCE challenge: {url[:60]}...")
    with httpx.Client(timeout=10, follow_redirects=False) as http:
        if http.get(url).status_code != 200:
            raise SystemExit("The provider refused the sign-in request.")
        chosen = http.post(url, data={"user": user})
    if chosen.status_code != 302:
        raise SystemExit(f"Sign-in failed: {chosen.status_code} {chosen.text}")
    say(f"   You picked {user}.")
    return finish(issuer, params, verifier, chosen.headers["location"], say)


def browser(issuer: str, client_id: str, open_it: bool, say) -> dict:
    """Any provider: you sign in in your browser; the provider sends the code back to a
    small web server of this script on 127.0.0.1:8775 (a loopback redirect, RFC 8252)."""
    params, verifier, url = start(issuer, client_id)
    received: list[str] = []

    class Callback(BaseHTTPRequestHandler):
        def do_GET(self):  # the name is set by http.server
            received.append(f"{REDIRECT_URI}?{urlparse(self.path).query}")
            self.send_response(200)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.end_headers()
            self.wfile.write(b"Signed in. You can close this tab and go back to the terminal.")

        def log_message(self, *args):
            pass

    server = HTTPServer(("127.0.0.1", 8775), Callback)
    thread = threading.Thread(target=server.handle_request, daemon=True)
    thread.start()
    say("1. Sign in in your browser (the script waits for 5 minutes):")
    print(f"   {url}", flush=True)
    if open_it:
        webbrowser.open(url)
    thread.join(timeout=300)
    server.server_close()
    if not received:
        raise SystemExit("No sign-in in 5 minutes. Run the command again.")
    return finish(issuer, params, verifier, received[0], say)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    who = parser.add_mutually_exclusive_group(required=True)
    who.add_argument("--user", help="practice provider: the made-up person, e.g. usr-teresa")
    who.add_argument("--browser", action="store_true", help="sign in in the browser")
    who.add_argument("--service", action="store_true", help="the dashboard server's token")
    who.add_argument("--refresh", metavar="NAME", help="new tokens for the saved refresh token")
    parser.add_argument("--name", help="--browser: save the tokens as .tokens/NAME.json")
    parser.add_argument("--no-open", action="store_true", help="--browser: only print the URL")
    parser.add_argument("--print-access-token", action="store_true")
    args = parser.parse_args(argv)
    load_env()
    issuer = os.environ.get("OIDC_ISSUER", "http://localhost:8410").rstrip("/")
    client_id = os.environ.get("OIDC_CLIENT_ID", "city-cli")
    quiet = args.print_access_token
    say = (lambda *a: None) if quiet else print
    try:
        if args.user:
            body, name = pick(issuer, client_id, args.user, say), args.user
        elif args.browser:
            body = browser(issuer, client_id, not args.no_open, say)
            name = args.name or claims(body["access_token"])["sub"]
        elif args.refresh:
            name = args.refresh
            saved = json.loads((TOKENS / f"{name}.json").read_text(encoding="utf-8"))
            response = httpx.post(
                discovery(issuer)["token_endpoint"],
                data={
                    "grant_type": "refresh_token",
                    "client_id": client_id,
                    "refresh_token": saved["refresh_token"],
                },
            )
            if response.status_code != 200:
                print(f"{response.status_code} {response.json()}", file=sys.stderr)
                return 1
            body = response.json()
            say("New tokens. The old refresh token cannot be used again (rotation).")
        else:
            name = "transport-dashboards"
            response = httpx.post(
                discovery(issuer)["token_endpoint"],
                data={"grant_type": "client_credentials", "scope": "requests:read"},
                auth=(name, os.environ.get("DASHBOARDS_CLIENT_SECRET", "")),
            )
            if response.status_code != 200:
                print(f"{response.status_code} {response.json()}", file=sys.stderr)
                return 1
            body = response.json()
            say(f"200: a token for the service {name}, scope {body['scope']}")
    except httpx.ConnectError:
        print(f"The provider does not answer at {issuer}. Start it: python -m idp", file=sys.stderr)
        return 1
    except FileNotFoundError:
        print(f"No saved tokens for {args.refresh}. Sign in first.", file=sys.stderr)
        return 1
    path = save(name, body)
    if quiet:
        print(body["access_token"])
        return 0
    header = jwt.get_unverified_header(body["access_token"])
    print("\naccess_token (decoded, not checked):")
    print(f"  header {json.dumps(header)}")
    print("  claims " + json.dumps(claims(body["access_token"]), indent=2).replace("\n", "\n  "))
    print(f"\nSaved in {path}.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
