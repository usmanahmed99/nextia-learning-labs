"""Make the access database: departments, people, memberships (and empty notes and audit).

    python -m scripts.init_access                 make data/access.db from data/identity/
    python -m scripts.init_access --reset         delete it and make it again
    python -m scripts.init_access grant --department transport --user ID --role owner
                                                  give a person a role (the operator's way to
                                                  make the first owner, for example a person
                                                  from Keycloak; owners use the API after that)
    python -m scripts.init_access show            the memberships, department by department

ACCESS_DB_PATH (default data/access.db) says where the file is.
"""

import argparse
import csv
import os
import sqlite3
import sys
from pathlib import Path

from scripts import load_env

ROOT = Path(__file__).resolve().parent.parent
SCHEMA = ROOT / "city_api" / "access_schema.sql"
IDENTITY = ROOT / "data" / "identity"


def build(path: Path, identity: Path = IDENTITY) -> dict[str, int]:
    """Write a new access database at `path` from the CSV files in `identity`."""

    def rows(name: str) -> list[dict]:
        with (identity / name).open(encoding="utf-8", newline="") as file:
            return list(csv.DictReader(file))

    path.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(path)
    con.executescript(SCHEMA.read_text(encoding="utf-8"))
    con.executemany(
        "INSERT INTO departments (department_id, name) VALUES (:department_id, :name)",
        rows("departments.csv"),
    )
    con.executemany(
        "INSERT INTO users (user_id, name, kind) VALUES (:user_id, :name, :kind)",
        rows("users.csv"),
    )
    con.executemany(
        "INSERT INTO memberships (department_id, user_id, role)"
        " VALUES (:department_id, :user_id, :role)",
        rows("memberships.csv"),
    )
    con.commit()
    counts = {
        table: con.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
        for table in ("departments", "users", "memberships")
    }
    con.close()
    return counts


def show(con: sqlite3.Connection) -> None:
    for department, user, role in con.execute(
        "SELECT department_id, user_id, role FROM memberships ORDER BY department_id, role, user_id"
    ):
        print(f"{department:<10} {role:<10} {user}")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--reset", action="store_true")
    sub = parser.add_subparsers(dest="command")
    grant = sub.add_parser("grant")
    grant.add_argument("--department", required=True)
    grant.add_argument("--user", required=True)
    grant.add_argument("--role", required=True, choices=["owner", "staff", "read_only"])
    grant.add_argument("--name", help="a name for a person the API has not seen yet")
    sub.add_parser("show")
    args = parser.parse_args(argv)
    load_env()
    path = Path(os.environ.get("ACCESS_DB_PATH", "data/access.db"))

    if args.command is None:
        if path.exists() and not args.reset:
            print(f"{path} exists. Use --reset to make it again (notes and audit are lost).")
            return 0
        for suffix in ("", "-wal", "-shm"):
            Path(f"{path}{suffix}").unlink(missing_ok=True)
        counts = build(path)
        print(f"Wrote {path}: " + ", ".join(f"{n} {t}" for t, n in counts.items()) + ".")
        return 0
    if not path.exists():
        print(f"No {path}. Run: python -m scripts.init_access", file=sys.stderr)
        return 1
    con = sqlite3.connect(path)
    con.execute("PRAGMA foreign_keys = ON")
    if args.command == "show":
        show(con)
        return 0
    with con:
        con.execute(
            "INSERT OR IGNORE INTO users (user_id, name) VALUES (?, ?)", (args.user, args.name)
        )
        con.execute(
            "INSERT INTO memberships (department_id, user_id, role) VALUES (?, ?, ?)"
            " ON CONFLICT (department_id, user_id) DO UPDATE SET role = excluded.role",
            (args.department, args.user, args.role),
        )
        con.execute(
            "INSERT INTO audit_events (actor_id, actor_kind, department_id, action, target,"
            " result, reason) VALUES ('operator', 'operator', ?, 'member.grant', ?, 'allowed',"
            " 'scripts.init_access grant')",
            (args.department, f"user {args.user}"),
        )
    print(f"{args.user} is {args.role} in {args.department} (an audit event records it).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
