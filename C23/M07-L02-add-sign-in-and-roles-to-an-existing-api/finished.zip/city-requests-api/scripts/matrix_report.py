"""Run the access-control test matrix and print it as a grid.

    python -m scripts.matrix_report             runs tests/test_access_matrix.py, prints the grid
    python -m scripts.matrix_report --json FILE also writes every cell as JSON

Each cell is the status that the identity must get for the route in the department, with
a mark when the test failed. The grid is the access matrix of docs/access-matrix.md, checked.
"""

import argparse
import json
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path

from tests.conftest import PEOPLE
from tests.test_access_matrix import DEPARTMENTS, ROUTES, expected

SHORT = {
    "list requests": "list",
    "read a request": "read",
    "read notes": "notes",
    "add a note": "note+",
    "complaint types": "types",
    "daily numbers": "daily",
    "list members": "membr",
    "set a role": "role",
    "remove a member": "remove",
    "read the audit": "audit",
}


def run() -> dict[str, bool]:
    """Run the matrix test file; return {test id: passed}."""
    with tempfile.TemporaryDirectory() as tmp:
        report = Path(tmp) / "junit.xml"
        subprocess.run(
            [sys.executable, "-m", "pytest", "-q", "-p", "no:logging",
             "tests/test_access_matrix.py", f"--junitxml={report}"],
            check=False,
            capture_output=True,
        )
        results = {}
        for case in ET.parse(report).getroot().iter("testcase"):
            failed = case.find("failure") is not None or case.find("error") is not None
            results[case.get("name")] = not failed
    return results


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--json", help="write the cells to this file")
    args = parser.parse_args(argv)
    results = run()
    cells = []
    print(f"{'':<34}" + "".join(f"{SHORT[r]:>7}" for r in ROUTES))
    for user in PEOPLE:
        for department in DEPARTMENTS:
            row = f"{user + " @ " + department:<34}"
            for route in ROUTES:
                passed = results.get(f"test_matrix[{user}|{department}|{route}]", False)
                status = expected(user, department, route)
                cells.append(
                    {"user": user, "department": department, "route": route,
                     "status": status, "passed": passed}
                )
                row += f"{status:>6}{' ' if passed else '!'}"
            print(row)
    total, passed = len(results), sum(results.values())
    print(f"\n{passed} of {total} checks passed.", end=" ")
    print("(The grid: 160 cells. The other checks: another department's request ID, 5 x 3,"
          " and 6 bad identities x 10 routes.)")
    if args.json:
        Path(args.json).write_text(
            json.dumps({"passed": passed, "total": total, "cells": cells}, indent=1) + "\n",
            encoding="utf-8",
        )
    return 0 if passed == total else 1


if __name__ == "__main__":
    sys.exit(main())
