"""The project's scripts. Run them from the project folder: python -m scripts.<name>"""

from pathlib import Path


def load_env() -> None:
    """Read .env (if there is one) into the environment, without overriding what is set."""
    from dotenv import load_dotenv

    load_dotenv(Path.cwd() / ".env", override=False)
