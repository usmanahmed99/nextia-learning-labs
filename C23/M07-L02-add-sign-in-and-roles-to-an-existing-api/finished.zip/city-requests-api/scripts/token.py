"""Look inside a token, and see which check of the API refuses a bad one.

    python -m scripts.token decode --user usr-priya   the saved access token (decoded, NOT checked)
    python -m scripts.token cases                     made-up bad tokens, sent to GET /v1/me
    python -m scripts.token cases --json

`cases` makes each token with the practice provider's keys in .idp/ (python -m idp init
first) and sends it to the API code in this folder (no server needed). Every bad token is
constructed: it is how a mistake or an attack would look.
"""

import argparse
import json
import sys
import time
from dataclasses import replace
from datetime import UTC, datetime
from pathlib import Path

import jwt
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from fastapi.testclient import TestClient

from idp.store import Store
from idp.tokens import Signer

ISSUER = "http://localhost:8410"
SCOPE = "requests:read requests:write members:manage"


def when(seconds: int) -> str:
    return datetime.fromtimestamp(seconds, UTC).strftime("%Y-%m-%d %H:%M:%S UTC")


def decode(token: str) -> None:
    header = jwt.get_unverified_header(token)
    body = jwt.decode(token, options={"verify_signature": False})
    print(f"header  {json.dumps(header)}")
    print("claims")
    for k, v in body.items():
        extra = f"   ({when(v)})" if k in ("exp", "iat", "nbf", "auth_time") else ""
        print(f"  {k:<10} {json.dumps(v)}{extra}")
    print("Decoding is not checking: the API trusts these claims only after it checks the")
    print(f"signature with the provider's public key {header.get('kid')!r}.")


def other_key() -> bytes:
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    return key.private_bytes(
        serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()
    )


def make_cases(store: Store, issuer: str = ISSUER, now: float | None = None) -> list[dict]:
    """One good token of Priya, then one mistake or attack each."""
    now = int(now or time.time())
    signer = Signer(store, issuer)
    kid = store.keys()["active"]
    own = store.private_key(kid)
    good = signer.access_token("usr-priya", "city-cli", SCOPE, now=now)
    claims = jwt.decode(good, options={"verify_signature": False})
    header = {"kid": kid, "typ": "at+jwt"}

    def signed(changes: dict, key: bytes = own, headers: dict = header) -> str:
        return jwt.encode({**claims, **changes}, key, algorithm="RS256", headers=headers)

    head, _, sig = good.split(".")
    forged = jwt.utils.base64url_encode(
        json.dumps({**claims, "sub": "usr-teresa"}, separators=(",", ":")).encode()
    ).decode()
    priya = store.users()["usr-priya"]
    return [
        {"case": "valid", "what": "Priya's access token, as the provider issued it", "token": good},
        {"case": "no_token", "what": "no Authorization header", "token": None},
        {
            "case": "expired",
            "what": "expired 5 minutes ago",
            "token": signed({"exp": now - 300, "iat": now - 900, "nbf": now - 900}),
        },
        {
            "case": "wrong_audience",
            "what": "made for another API (aud billing-api)",
            "token": signed({"aud": "billing-api"}),
        },
        {
            "case": "wrong_issuer",
            "what": "from another issuer",
            "token": signed({"iss": "http://localhost:9999"}),
        },
        {
            "case": "id_token",
            "what": "Priya's ID token sent as an access token",
            "token": signer.id_token(priya, "city-cli", "n-1", now, now=now),
        },
        {
            "case": "alg_none",
            "what": "unsigned (alg none)",
            "token": jwt.encode(claims, None, algorithm="none", headers=header),
        },
        {
            "case": "unknown_key",
            "what": "signed with a key the provider never published",
            "token": signed({}, key=other_key(), headers={"kid": "made-up-key", "typ": "at+jwt"}),
        },
        {
            "case": "wrong_key_same_kid",
            "what": "signed with another key, with the provider's kid",
            "token": signed({}, key=other_key()),
        },
        {
            "case": "tampered",
            "what": "sub changed to usr-teresa after signing",
            "token": f"{head}.{forged}.{sig}",
        },
        {
            "case": "missing_sub",
            "what": "no sub claim",
            "token": jwt.encode(
                {k: v for k, v in claims.items() if k != "sub"}, own, "RS256", headers=header
            ),
        },
        {"case": "not_a_jwt", "what": "a random string", "token": "abc.def"},
    ]


def run_cases(store: Store, client: TestClient) -> list[dict]:
    out = []
    for c in make_cases(store):
        headers = {"Authorization": f"Bearer {c['token']}"} if c["token"] else {}
        r = client.get("/v1/me", headers=headers)
        error = r.json().get("error", {}) if r.status_code != 200 else {}
        out.append(
            {
                "case": c["case"],
                "what": c["what"],
                "status": r.status_code,
                "check": r.headers.get("x-token-check", "passed" if r.status_code == 200 else ""),
                "code": error.get("code"),
                "message": error.get("message"),
            }
        )
    return out


def api_client(store: Store) -> TestClient:
    """The API in this process, with the provider's keys read straight from .idp/."""
    from city_api.config import load_settings
    from city_api.main import create_app

    app = create_app(replace(load_settings(), oidc_issuer=ISSUER))
    docs = {
        "/.well-known/openid-configuration": {"issuer": ISSUER, "jwks_uri": f"{ISSUER}/jwks.json"}
    }
    app.state.validator.provider.fetch = lambda url: (
        docs.get(url.removeprefix(ISSUER)) or store.jwks()
    )
    return TestClient(app, raise_server_exceptions=False)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    sub = parser.add_subparsers(dest="command", required=True)
    d = sub.add_parser("decode")
    d.add_argument("token", nargs="?")
    d.add_argument("--user", help="decode the saved access token of this user (.tokens/)")
    c = sub.add_parser("cases")
    c.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)
    if args.command == "decode":
        token = args.token
        if args.user:
            saved = json.loads(Path(f".tokens/{args.user}.json").read_text(encoding="utf-8"))
            token = saved["access_token"]
        if not token:
            parser.error("give a token, or --user")
        decode(token)
        return 0
    store = Store()
    if not store.exists():
        print("The provider has no keys yet. Run: python -m idp init", file=sys.stderr)
        return 1
    with api_client(store) as client:
        results = run_cases(store, client)
    if args.json:
        print(json.dumps(results, indent=2, ensure_ascii=False))
        return 0
    print("Made-up tokens sent to GET /v1/me (constructed for this case study):\n")
    for r in results:
        verdict = "accepted" if r["status"] == 200 else f"refused: {r['check'] or r['code']}"
        print(f"  {r['case']:<19} {r['status']}  {verdict:<31} {r['what']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
