"""Ten things that must fail, sent to the running API with real tokens.

    python -m scripts.attempts

Needs the practice provider (python -m idp) and the API (fastapi dev) running. Each line
says what was tried, the answer, and whether the caller got something they should not.
The people are made up; every attempt targets only the API on your own computer. The
expired token and the token for another API are constructed with the provider's key in
.idp/ (labelled "constructed").
"""

import os
import sys
import time

import httpx

from scripts import load_env
from idp.store import Store
from idp.tokens import Signer
from scripts.login import pick

API = os.environ.get("API_URL", "http://127.0.0.1:8000")
T, P = "/v1/departments/transport", "/v1/departments/parks"
TRANSPORT_ID = 64246800  # a transport request: a missing speed-limit sign in Manhattan


def main() -> int:
    load_env()
    issuer = os.environ.get("OIDC_ISSUER", "http://localhost:8410")
    quiet = lambda *a: None  # noqa: E731
    try:
        signed_in = {u: pick(issuer, "city-cli", u, quiet) for u in
                     ("usr-jamal", "usr-oliver", "usr-hana", "usr-priya")}
        service = httpx.post(
            f"{issuer}/token",
            data={"grant_type": "client_credentials", "scope": "requests:read"},
            auth=("transport-dashboards", os.environ.get("DASHBOARDS_CLIENT_SECRET", "")),
        ).json()["access_token"]
    except httpx.ConnectError:
        print(f"The provider does not answer at {issuer}. Start it: python -m idp", file=sys.stderr)
        return 1
    token = {u: body["access_token"] for u, body in signed_in.items()}
    signer, now = Signer(Store(), issuer), int(time.time())
    expired = signer.access_token("usr-priya", "city-cli", "requests:read", now=now - 900)
    other_api = Signer(Store(), issuer, audience="billing-api").access_token(
        "usr-priya", "city-cli", "requests:read"
    )

    def bearer(t: str) -> dict:
        return {"Authorization": f"Bearer {t}"}

    attempts = [
        ("Jamal (parks) reads a transport request", "GET", f"{T}/service-requests/{TRANSPORT_ID}",
         bearer(token["usr-jamal"]), None),
        ("Jamal asks for it through his own department", "GET",
         f"{P}/service-requests/{TRANSPORT_ID}", bearer(token["usr-jamal"]), None),
        ("Jamal adds the header X-Department: transport", "GET", f"{T}/service-requests",
         {**bearer(token["usr-jamal"]), "X-Department": "transport"}, None),
        ("Oliver (no membership) lists transport", "GET", f"{T}/service-requests",
         bearer(token["usr-oliver"]), None),
        ("Hana (read_only in transport) adds a note", "POST",
         f"{T}/service-requests/{TRANSPORT_ID}/notes", bearer(token["usr-hana"]), {"body": "x"}),
        ("The dashboard service adds a note", "POST", f"{T}/service-requests/{TRANSPORT_ID}/notes",
         bearer(service), {"body": "x"}),
        ("Priya's ID token as an access token", "GET", f"{T}/service-requests",
         bearer(signed_in["usr-priya"]["id_token"]), None),
        ("An expired token (constructed)", "GET", f"{T}/service-requests", bearer(expired), None),
        ("A token for another API (constructed)", "GET", f"{T}/service-requests",
         bearer(other_api), None),
        ("The old shared key X-API-Key", "GET", f"{T}/service-requests",
         {"X-API-Key": "local-dev-key"}, None),
    ]
    got = 0
    with httpx.Client(base_url=API, timeout=10) as client:
        for what, method, path, headers, extra in attempts:
            r = client.request(method, path, headers=headers, json=extra)
            code = r.json().get("error", {}).get("code") if r.status_code >= 400 else "ok"
            check = r.headers.get("x-token-check")
            answer = f"{r.status_code} {code}" + (f" ({check})" if check else "")
            bad = r.status_code < 400
            got += bad
            print(f"{'GOT IT' if bad else 'refused':<8} {what:<46} {answer}")
    print(f"\n{got} of {len(attempts)} attempts got what they should not get.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
