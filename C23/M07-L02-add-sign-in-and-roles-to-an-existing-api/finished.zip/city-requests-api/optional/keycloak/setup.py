"""Set up Keycloak (a real, open-source identity provider) for the city requests API.

    docker run -d --name city-keycloak -p 127.0.0.1:8480:8080 \
        -e KC_BOOTSTRAP_ADMIN_USERNAME=admin -e KC_BOOTSTRAP_ADMIN_PASSWORD=<a password> \
        quay.io/keycloak/keycloak:26.8.0 start-dev
    KEYCLOAK_ADMIN_PASSWORD=<the same password> python optional/keycloak/setup.py

It makes, through Keycloak's admin REST API: a realm "city"; the client scopes
requests:read, requests:write and members:manage; an audience mapper that puts
"city-requests-api" into the access tokens; the application "city-cli" (public, PKCE S256,
the redirect URI of scripts/login.py); and one made-up person, "teresa", with a new random
password. It prints the settings for .env. Delete everything afterwards:
docker rm -f city-keycloak

Adapted from the authentication course's optional/keycloak/setup.py (MIT licence).
No account and no money: Keycloak runs only on your computer. "start-dev" is Keycloak's
development mode (plain HTTP, an in-memory database): never use it for real people.
"""

import os
import secrets
import sys

import httpx

BASE = os.environ.get("KEYCLOAK_URL", "http://127.0.0.1:8480")
REALM = "city"
REDIRECT = "http://127.0.0.1:8775/callback"
SCOPES = ("requests:read", "requests:write", "members:manage")


def main() -> int:
    password = os.environ.get("KEYCLOAK_ADMIN_PASSWORD")
    if not password:
        print("Set KEYCLOAK_ADMIN_PASSWORD (the password you gave the container).", file=sys.stderr)
        return 1
    token = httpx.post(
        f"{BASE}/realms/master/protocol/openid-connect/token",
        data={
            "grant_type": "password",
            "client_id": "admin-cli",
            "username": "admin",
            "password": password,
        },
    ).json()["access_token"]
    api = httpx.Client(
        base_url=f"{BASE}/admin/realms", timeout=20, headers={"Authorization": f"Bearer {token}"}
    )

    def ok(response: httpx.Response) -> httpx.Response:
        if response.status_code >= 400 and response.status_code != 409:  # 409: it exists
            raise SystemExit(
                f"{response.request.method} {response.request.url}: "
                f"{response.status_code} {response.text}"
            )
        return response

    ok(api.post("", json={"realm": REALM, "enabled": True, "accessTokenLifespan": 600}))
    for name in SCOPES:
        ok(
            api.post(
                f"/{REALM}/client-scopes",
                json={
                    "name": name,
                    "protocol": "openid-connect",
                    "attributes": {
                        "include.in.token.scope": "true",
                        "display.on.consent.screen": "false",
                    },
                },
            )
        )
    ok(
        api.post(
            f"/{REALM}/client-scopes",
            json={
                "name": "city-requests-api-audience",
                "protocol": "openid-connect",
                "attributes": {"include.in.token.scope": "false"},
                "protocolMappers": [
                    {
                        "name": "audience city-requests-api",
                        "protocol": "openid-connect",
                        "protocolMapper": "oidc-audience-mapper",
                        "config": {
                            "included.custom.audience": "city-requests-api",
                            "access.token.claim": "true",
                            "id.token.claim": "false",
                        },
                    }
                ],
            },
        )
    )
    ok(
        api.post(
            f"/{REALM}/clients",
            json={
                "clientId": "city-cli",
                "name": "City requests (command line)",
                "protocol": "openid-connect",
                "publicClient": True,
                "standardFlowEnabled": True,
                "directAccessGrantsEnabled": False,
                "redirectUris": [REDIRECT],
                "attributes": {"pkce.code.challenge.method": "S256"},
                # "basic" puts sub (the user ID) into the tokens: without it, the API refuses them.
                "defaultClientScopes": [
                    "basic",
                    "profile",
                    "email",
                    "city-requests-api-audience",
                    *SCOPES,
                ],
                "optionalClientScopes": ["offline_access"],
            },
        )
    )
    person_password = secrets.token_urlsafe(12)
    ok(
        api.post(
            f"/{REALM}/users",
            json={
                "username": "teresa",
                "email": "teresa@city.example",
                "firstName": "Teresa",
                "lastName": "Okafor",
                "emailVerified": True,
                "enabled": True,
                "credentials": [{"type": "password", "value": person_password, "temporary": False}],
            },
        )
    )
    user = ok(api.get(f"/{REALM}/users", params={"username": "teresa", "exact": "true"})).json()[0]
    print("Keycloak is ready. Put these lines in .env (instead of the practice provider's):")
    print(f"OIDC_ISSUER={BASE}/realms/{REALM}")
    print("OIDC_CLIENT_ID=city-cli")
    print("ACCESS_TOKEN_TYPES=JWT")
    print(f"\nSign in as teresa with the password {person_password} (made up; shown once).")
    print(f"Keycloak's user ID for teresa (the token's sub): {user['id']}")
    print("Make her the owner of transport:")
    print(
        f"  python -m scripts.init_access grant --department transport --user {user['id']}"
        " --role owner --name 'Teresa (Keycloak)'"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
