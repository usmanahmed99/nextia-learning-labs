# Optional: a real identity provider (Keycloak)

The practice provider (`python -m idp`) is a mock. To see the same API work with a real
identity provider without an account or money, run [Keycloak](https://www.keycloak.org/)
(Apache-2.0) in Docker on your computer, then delete it. Tested with Keycloak 26.8.0 on
macOS (Apple silicon).

1. Start Keycloak (choose your own admin password):

   ```sh
   docker run -d --name city-keycloak -p 127.0.0.1:8480:8080 \
     -e KC_BOOTSTRAP_ADMIN_USERNAME=admin -e KC_BOOTSTRAP_ADMIN_PASSWORD=choose-one \
     quay.io/keycloak/keycloak:26.8.0 start-dev
   ```

2. About one minute later, set up the realm, the application and one made-up person:

   ```sh
   KEYCLOAK_ADMIN_PASSWORD=choose-one python optional/keycloak/setup.py
   ```

   On Windows PowerShell: `$env:KEYCLOAK_ADMIN_PASSWORD="choose-one"; python optional/keycloak/setup.py`.

3. Put the three lines that it prints into `.env`, instead of the practice provider's
   `OIDC_ISSUER`. Restart the API (`fastapi dev`).
4. Sign in: `python -m scripts.login --browser --name teresa-kc`. Your browser opens
   Keycloak's sign-in page; sign in as `teresa` with the password that step 2 printed.
5. `GET /v1/me` shows Keycloak's user ID and no membership. Make her the owner of transport
   with the `grant` command that step 2 printed, and call the API again.
6. Delete everything: `docker rm -f city-keycloak`, and put the practice lines back in `.env`.

What is different from the practice provider:

- Keycloak's access tokens say `typ: JWT`, not `at+jwt`: set `ACCESS_TOKEN_TYPES=JWT`. The
  audience check still refuses an ID token (its audience is `city-cli`).
- Keycloak puts `city-requests-api` into the audience only with an audience mapper
  (`setup.py` makes one), and `sub` only with its `basic` client scope.
- Keycloak's `sub` is a UUID, so the person needs a new membership row.
- The issuer is built from the address that you use (`http://127.0.0.1:8480/realms/city`).

`start-dev` is Keycloak's development mode (plain HTTP, an in-memory database). Never use it
for real people.
