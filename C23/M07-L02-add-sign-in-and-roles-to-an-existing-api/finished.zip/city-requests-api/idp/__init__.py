"""A small identity provider for practice: OpenID Connect on your own computer.

Copied from the project of the Nextia Learning course "Authentication, Permissions and
Multi-Tenant Applications" (idp/, MIT licence, Copyright (c) 2026 Nextia Learning), with
these changes for the city requests API: the registered applications (city-cli and
transport-dashboards), the scopes (requests:read, requests:write, members:manage), the
audience (city-requests-api), the port (8410) and the people (data/identity/users.csv,
persons only).

It is a MOCK. It shows a list of made-up people instead of asking for a password, and it
keeps codes and refresh tokens in memory. Everything else is done the standard way, so the
API sees what a real provider sends: a discovery document, published keys (JWKS), the
authorization code flow with PKCE, signed ID and access tokens (RS256), refresh tokens,
client credentials and logout. The signing and the key handling use PyJWT and cryptography;
there is no hand-written cryptography here.

    python -m idp init            make the keys and the client secret (once)
    python -m idp                 run it on http://localhost:8410
"""
