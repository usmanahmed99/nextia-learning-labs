# city-requests-api 2.0: sign-in and roles

New York City's 311 requests of two departments, transport (DOT) and parks (DPR), January to
June 2025, behind one API. Each department's people see only their department's requests and
add notes to them. The project of the case study
[Add sign-in and roles to an existing API](https://learning.nextia-ai.com/courses/auth/m07/add-sign-in-and-roles-to-an-existing-api/);
version 1 is the API course's case study
[Build a data API for city service requests](https://learning.nextia-ai.com/courses/api/m08/build-a-data-api-for-city-service-requests/).

## Design

- **Who:** every `/v1` route needs an access token (a JWT signed with RS256) from the
  identity provider in `OIDC_ISSUER`. `city_api/auth.py` checks the algorithm, the type, the
  key, the signature, the expiry, the issuer and the audience (`city-requests-api`). The
  shared `X-API-Key` of version 1 is gone.
- **Where and what:** the department is in the path, `/v1/departments/{department}/...`. The
  token has no department and no role: `city_api/tenancy.py` reads the caller's membership
  and its role (`owner`, `staff`, `read_only`) from the access database on every request.
- **Answers:** no membership, or no such department: `404 Not found.`. A role or a token
  scope too small: `403`. Another department's request through your own path: the same 404
  as a missing ID. See `docs/access-matrix.md`.
- **Tenant-scoped queries:** every function in `city_api/queries.py` takes `department` as a
  required keyword argument, and every statement has `department = ?`.
- **Audit:** notes, member changes and every refusal (also refused tokens) are written to
  `audit_events`, without tokens or note text. The table is append-only (triggers).
- **Data:** the request data is a read-only SQLite file; the access data (departments,
  people, memberships, notes, audit) is a second, writable SQLite file, `data/access.db`.

## Run it (macOS/Linux; Windows: `python` and `.venv\Scripts\Activate.ps1`)

```sh
python3 -m venv .venv && source .venv/bin/activate
python -m pip install -r requirements-lock.txt
python scripts/get_db.py              # 13 MB download, checked with SHA-256
python -m idp init                    # the practice provider's key; writes .env
python -m scripts.init_access         # data/access.db from data/identity/
python -m pytest                      # 326 tests
python -m idp                         # terminal 1: the provider on http://localhost:8410
fastapi dev                           # terminal 2: the API on http://127.0.0.1:8000
python -m scripts.login --user usr-priya    # terminal 3: sign in as a made-up person
python -m scripts.attempts            # 0 of 10 attempts got what they should not get
python -m scripts.matrix_report       # 225 of 225 checks passed
```

A real provider: `optional/keycloak/README.md` (tested, Keycloak 26.8.0 in Docker) and
`docs/entra-id.md` (Microsoft Entra ID, described, not tested).

## Data and licence

The code is under the MIT licence (`LICENSE`); `idp/` and parts of `city_api/auth.py` come
from the Nextia Learning authentication course's project (MIT). The data is from NYC Open
Data; `DATASET.md` describes it and every change. The people are made up.
