# The access matrix

Who may do what, in which department. `city_api/access.py` is this table as code, and
`tests/test_access_matrix.py` checks every cell (`python -m scripts.matrix_report`).

| Action | owner | staff | read_only | Token scope it needs |
|---|---|---|---|---|
| `request.read`: list, read, notes (read), complaint types, daily numbers | yes | yes | yes | `requests:read` |
| `note.write`: add a note to a request | yes | yes | 403 | `requests:write` |
| `member.read`: list the members | yes | yes | 403 | `requests:read` |
| `member.manage`: add, change the role, remove | yes | 403 | 403 | `members:manage` |
| `audit.read`: read the department's audit events | yes | 403 | 403 | `members:manage` |

- **No membership in the department** (or no such department): `404 Not found.` for every
  action, the same bytes for a real and a made-up department.
- **A request of another department**, through your own department's path: `404 No service
  request has the ID ...`, the same answer as for an ID that does not exist.
- **A role or a scope too small:** `403 forbidden` or `403 insufficient_scope`.
- **No token, or a token that fails a check:** `401`.
- A department always keeps one owner (`409 last_owner`).

| Person (made up) | transport | parks |
|---|---|---|
| Teresa Okafor | owner | - |
| Priya Nair | staff | - |
| Hana Sato | read_only | staff |
| Lena Fischer | - | owner |
| Jamal Carter | - | staff |
| Marcus Bell | - | read_only |
| Oliver Grant | - | - |
| transport-dashboards (a service) | read_only | - |
