# Microsoft Entra ID: what changes (described, not tested)

This page maps the city requests API to Microsoft Entra ID (the identity service of
Microsoft 365 and Azure). **It is written from Microsoft's documentation and was not run**:
the case study needs no account and no money, and an Entra ID tenant needs a Microsoft
account. The tested real provider is Keycloak (`optional/keycloak/`).

Sources: [Access token claims reference](https://learn.microsoft.com/en-us/entra/identity-platform/access-token-claims-reference),
[Expose a web API](https://learn.microsoft.com/en-us/entra/identity-platform/quickstart-configure-app-expose-web-apis),
[OpenID Connect on the Microsoft identity platform](https://learn.microsoft.com/en-us/entra/identity-platform/v2-protocols-oidc).

## A word clash: "tenant"

In Entra ID, a **tenant** is a whole organization's directory (for example, the city).
In this API, the tenant is a **department**. The city would have one Entra ID tenant; the
two departments stay in the API's own `memberships` table, as with the practice provider.

## The two app registrations

| Practice provider / Keycloak | Entra ID |
|---|---|
| The API's audience `city-requests-api` | An app registration for the API. **Expose an API**: an Application ID URI such as `api://city-requests-api`, and delegated scopes |
| Scopes `requests:read`, `requests:write`, `members:manage` | Scopes such as `Requests.Read`, `Requests.Write`, `Members.Manage` (Entra ID's usual style). Map them in `city_api/access.py` `ACTION_SCOPE` |
| The client `city-cli` (public, PKCE, redirect `http://127.0.0.1:8775/callback`) | A second app registration, platform **Mobile and desktop applications**, redirect URI `http://127.0.0.1:8775/callback`; API permissions: the API's scopes |
| The service `transport-dashboards` (client credentials, `requests:read`) | An app registration with a secret or a certificate, and an **app role** of the API (for example `Requests.Read.All`). Its tokens carry `roles`, not `scp`: the API needs one more rule for them |

## The settings

```text
OIDC_ISSUER=https://login.microsoftonline.com/<directory (tenant) ID>/v2.0
OIDC_AUDIENCE=<the API's application (client) ID, a GUID>
ACCESS_TOKEN_TYPES=JWT
USER_ID_CLAIM=oid
```

- **Issuer.** For v2.0 tokens the issuer ends in `/v2.0`. Ask for v2.0 access tokens in the
  API's manifest (`requestedAccessTokenVersion: 2`); otherwise the API gets v1.0 tokens with
  an issuer of the form `https://sts.windows.net/<tenant ID>/`, and the issuer check refuses them.
- **Audience.** "In v2.0 tokens, this value is always the client ID of the API": a GUID, not
  the Application ID URI.
- **Type.** The header's `typ` is always `JWT`, as with Keycloak: set `ACCESS_TOKEN_TYPES=JWT`.
  The audience check still refuses an ID token (its audience is the client application).
- **The user ID.** `sub` is a *pairwise* ID: the same person gets a different `sub` in each
  application. `oid` is the same across the applications of the directory. Use
  `USER_ID_CLAIM=oid`, so that the membership rows still match if a second client (a web
  front end) is added later.
- **Scopes.** Entra ID puts delegated scopes in `scp` (the validator already reads `scp`
  when there is no `scope`). Application tokens (client credentials) have `roles` instead.
- **The client.** v2.0 tokens name the client in `azp` (v1.0: `appid`); the validator reads both.
- **Keys.** Discovery at `<issuer>/.well-known/openid-configuration` gives `jwks_uri`; the
  API's key cache and its refresh on an unknown `kid` work as they are.

## What stays the same

The token still carries no department and no role that the API trusts. Membership rows are
keyed by the `oid` of each person; an operator makes the first owner with
`python -m scripts.init_access grant --department transport --user <oid> --role owner`.
Entra ID's own `roles` and `groups` claims could carry roles, but then the directory's
administrators, not the department's owners, would decide them: this design keeps the
decision in the API, as the course does.
