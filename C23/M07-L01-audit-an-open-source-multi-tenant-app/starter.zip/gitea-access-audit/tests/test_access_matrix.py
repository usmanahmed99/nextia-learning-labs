"""The access-control test matrix, run against your local Gitea.

STARTER. The four groups are sketched. The first test (the matrix) is complete and will run
once you fill `ALLOWED` in audit/matrix.py. The other three have one worked example each and
TODOs for the rest. Add the cases the comments describe, then run:

    python -m pytest
"""

import httpx
import pytest

from audit.matrix import ROUTES, expected_status, fill_path
from audit.people import MEMBERSHIPS, PEOPLE
from tests.conftest import API

PERSONS = list(PEOPLE)
ORGS = ("larkfield", "bramble")
ADMIN = "kwame"


def role_of(org: str, person: str) -> str | None:
    return MEMBERSHIPS.get((org, person))


def send(client, person, org, route, state):
    method, path, opts, _ok = ROUTES[route]
    return client(person).request(method, fill_path(path, org, state), **opts)


# 1. The matrix: person x organization x route. Complete once ALLOWED is filled.
MATRIX = [(p, o, r) for p in PERSONS for o in ORGS for r in ROUTES]


@pytest.mark.parametrize("person, org, route", MATRIX,
                         ids=[f"{p}|{o}|{r}" for p, o, r in MATRIX])
def test_matrix(client, state, person, org, route):
    role = role_of(org, person)
    want = ROUTES[route][3] if person == ADMIN else expected_status(role, route)
    response = send(client, person, org, route, state)
    assert response.status_code == want, (
        f"{person} ({role}) {route} in {org}: got {response.status_code}, "
        f"expected {want}. {response.text[:200]}")


# 2. Object-level access (BOLA): a GLOBAL ID of the other organization, through your own path.
# Worked example: Sam opens Bramble's repository by its global numeric ID.
def test_sam_cannot_open_brambles_repository(client, state):
    bramble_repo_id = state["orgs"]["bramble"]["repo_id"]
    assert client("sam").get(f"/repositories/{bramble_repo_id}").status_code == 404
    # TODO: also test Sam reading Bramble's comment by its global ID, and downloading Bramble's
    # attachment ID through a Larkfield issue. Do the mirror cases for Ines.


# 3. Role escalation: a member tries to grow their own powers. Worked example below.
def test_staff_cannot_join_owners(client, state):
    teams = state["orgs"]["larkfield"]["teams"]
    assert client("sam").put(f"/teams/{teams['Owners']}/members/sam").status_code == 403
    # TODO: Sam makes an admin team; Omar raises read-only's permission; Camille joins
    # Bramble's Owners; a non-admin uses sudo. Each must be refused (403).


# 4. Bad identity on a protected route. Worked example below.
PROTECTED = "/repos/larkfield/help-desk/issues/1"


def test_no_identity_is_refused(client):
    assert client(None).get(PROTECTED).status_code == 403  # Gitea answers 403, not 401
    # TODO: an invalid token (40 zeros) must get 401; a read-only-scoped token must read (200)
    # but not comment (403). The read-only-scoped token is state["tokens"]["grace-read-only-token"].
