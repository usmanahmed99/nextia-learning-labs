"""The access matrix: who may do what, in which organization, and the answer we expect.

STARTER. The routes are given. Your job is to fill `ALLOWED`: for each route, the set of
roles that may do it (members only). Read the course's access matrix, then decide each one,
then run the tests. The finished project has one correct answer; yours may differ where you
can argue it from Gitea's behaviour, as long as the tests pass and the report is honest.

The course's three questions decide each cell:
- No membership in the organization -> 404 (the caller learns nothing).
- A member whose role is too small -> 403.
- Otherwise the "allowed" status (200, 201).

Remember two things you will find about Gitea while you test:
- Gitea's "read" role may still open issues and comment. "Read" is not "read-only".
- No token -> 403 (not 401); an invalid token -> 401.
"""

READ = 200
CREATED = 201
FORBIDDEN = 403
NOT_FOUND = 404

ROUTES = {
    "list issues": ("GET", "/repos/{org}/{repo}/issues", {}, READ),
    "read an issue": ("GET", "/repos/{org}/{repo}/issues/{issue}", {}, READ),
    "read the repository": ("GET", "/repos/{org}/{repo}", {}, READ),
    "download the archive": ("GET", "/repos/{org}/{repo}/archive/main.zip", {}, READ),
    "download a file": ("GET", "/repos/{org}/{repo}/issues/{issue}/assets/{asset}", {}, READ),
    "list members": ("GET", "/orgs/{org}/members", {}, READ),
    "open an issue": ("POST", "/repos/{org}/{repo}/issues",
                      {"json": {"title": "Matrix probe"}}, CREATED),
    "comment on an issue": ("POST", "/repos/{org}/{repo}/issues/{issue}/comments",
                            {"json": {"body": "Access-matrix probe."}}, CREATED),
    "edit an issue": ("PATCH", "/repos/{org}/{repo}/issues/{issue}",
                      {"json": {"title": "Matrix probe edit"}}, CREATED),
    "upload a file": ("POST", "/repos/{org}/{repo}/issues/{issue}/assets",
                      {"files": {"attachment": ("m.txt", b"probe", "text/plain")}}, CREATED),
}

# TODO: for each route, which roles may do it? Fill every set. Example given for the first one.
ALLOWED = {
    "list issues": {"owner", "staff", "read_only"},
    "read an issue": set(),            # TODO
    "read the repository": set(),      # TODO
    "download the archive": set(),     # TODO
    "download a file": set(),          # TODO
    "list members": set(),             # TODO
    "open an issue": set(),            # TODO (what can Gitea's "read" role do?)
    "comment on an issue": set(),      # TODO
    "edit an issue": set(),            # TODO (needs write)
    "upload a file": set(),            # TODO (needs write)
}


def expected_status(role: str | None, route: str) -> int:
    """The status the course says this role must get on this route in its own organization."""
    _method, _path, _opts, ok = ROUTES[route]
    if role is None:
        return NOT_FOUND
    if role in ALLOWED[route]:
        return ok
    return FORBIDDEN


def fill_path(path: str, org: str, state: dict) -> str:
    """Put the organization's real IDs into a route path."""
    o = state["orgs"][org]
    return path.format(org=org, repo=o["repo"], issue=o["issues"][0]["number"],
                       asset=o["attachment"]["id"])
