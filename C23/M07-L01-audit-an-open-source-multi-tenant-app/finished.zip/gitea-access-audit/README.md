# gitea-access-audit

An access-control audit of a real, open-source, multi-tenant web application —
[Gitea](https://about.gitea.com/) — run on your own computer, tested with the
authentication course's access matrix.

Everything runs locally in Docker with made-up users and records. The audit never touches any
server other than the Gitea container on your own machine. **This is not a full security audit
of Gitea.** It tests the routes in `audit/matrix.py` with the course's three questions (who,
where, what). A complete audit would also cover cross-references between repositories, search,
webhooks, notifications, packages, the web UI and the Git protocol.

## What is here

```
gitea-access-audit/
  compose.yaml          Gitea 28.1.0 (pinned by digest), SQLite, audit log on, 512 MB
  audit/
    people.py           the course's people, the two organizations, roles -> Gitea teams
    client.py           settings and HTTP clients
    seed.py             fill a fresh Gitea with the people, organizations and records
    matrix.py           the access matrix: routes, roles, and the expected status of each cell
    report.py           run the matrix + extra checks, write reports/REPORT.md
  tests/
    conftest.py         fixtures: the state file and a client per person
    test_access_matrix.py  the matrix, object-level access, role escalation, bad identity
  reports/              written by `python -m audit.report` (Git-ignored)
  pyproject.toml, requirements.txt
```

## How the course's model maps onto Gitea

| Course | Gitea |
|---|---|
| tenant / organization | an **organization** |
| membership | membership of an organization, through a **team** |
| role `owner` | the organization's **Owners** team |
| role `staff` | a team with **write** permission |
| role `read_only` | a team with **read** permission |
| the platform administrator (Kwame) | a **site administrator** |
| a tenant-scoped record | an issue, a comment or a file in an organization's repository |

Two differences from the course, worth knowing (the lesson explains them):

- Gitea's **read** role may still open issues and comment. "Read" is not "read-only".
- A request with **no token** gets **403**, not the course's 401. An invalid token gets 401.

## Run it in VS Code

You need Docker Desktop (running) and Python 3.12 or newer.

1. Unzip the project and open the folder in VS Code (**File > Open Folder**). Open a terminal
   (**Terminal > New Terminal**).

2. Start Gitea. A unique project name and port keep it clear of anything else you run:

   **macOS / Linux**
   ```sh
   export COMPOSE_PROJECT_NAME=gitea-audit GITEA_PORT=3300
   docker compose up -d --wait
   ```
   **Windows (PowerShell)**
   ```powershell
   $env:COMPOSE_PROJECT_NAME = "gitea-audit"; $env:GITEA_PORT = "3300"
   docker compose up -d --wait
   ```
   Open <http://localhost:3300> to see the sign-in page. (The commands below use port 3300.
   If 3300 is busy, pick another and set `GITEA_URL` to match.)

3. Make a virtual environment and install the packages:

   **macOS / Linux**
   ```sh
   python3 -m venv .venv
   source .venv/bin/activate
   python -m pip install -r requirements.txt
   ```
   **Windows (PowerShell)**
   ```powershell
   python -m venv .venv
   .venv\Scripts\Activate.ps1
   python -m pip install -r requirements.txt
   ```
   If VS Code asks to use the new environment for this folder, choose **Yes**.

4. Fill Gitea with the two organizations, their people and their records:

   ```sh
   python -m audit.seed
   ```
   It prints what it made and writes `.audit-state.json` (the IDs and the people's tokens; it
   is Git-ignored; the tokens are local and made-up). You can now sign in at
   <http://localhost:3300> as, for example, `sam` with the password `practice-sam-2026`.

5. Run the access-control tests:

   ```sh
   python -m pytest
   ```
   Every test must pass. A failing test names the person, the organization, the route, the
   status it got and the status the course's rule expects.

6. Write the report:

   ```sh
   python -m audit.report
   ```
   It prints a summary and writes `reports/REPORT.md`, `reports/responses.json` (every status
   code) and `reports/audit-export.jsonl` (what Gitea's own audit log recorded).

7. Stop and remove Gitea when you are done (`-v` also deletes its data):

   ```sh
   docker compose down -v
   ```

## The settings that matter

`compose.yaml` turns on the parts an audit needs and keeps the rest off:

- `INSTALL_LOCK=true` and settings in the file, so there is no install page.
- `DISABLE_REGISTRATION=true`: only the administrator makes accounts.
- `REQUIRE_SIGNIN_VIEW=true`: nothing is visible without signing in.
- `audit.RECORD_OUTPUT=database`: the audit log is **off by default** in Gitea; this turns it
  on. The administrator exports it from `/-/admin/monitor/audit_logs/export`.

## Licence

Gitea is under the MIT licence. This audit project's own code is yours to use and publish.
