"""Shared fixtures: the state file, and a client for each person.

The tests talk to a local Gitea that `python -m audit.seed` has filled. They never change
another server. If the state file or the server is missing, the tests are skipped with a
message that tells you what to run.
"""

import json
import os
from pathlib import Path

import httpx
import pytest

GITEA_URL = os.environ.get("GITEA_URL", "http://127.0.0.1:3300").rstrip("/")
API = f"{GITEA_URL}/api/v1"
STATE_FILE = Path(os.environ.get("AUDIT_STATE", ".audit-state.json"))


@pytest.fixture(scope="session")
def state() -> dict:
    if not STATE_FILE.exists():
        pytest.skip(f"{STATE_FILE} not found. Run `python -m audit.seed` first.")
    try:
        httpx.get(f"{GITEA_URL}/api/healthz", timeout=3)
    except httpx.HTTPError:
        pytest.skip(f"Gitea does not answer at {GITEA_URL}. Run `docker compose up -d`.")
    return json.loads(STATE_FILE.read_text())


@pytest.fixture(scope="session")
def client(state):
    """A function: client(person) -> an httpx client with that person's token.

    person=None sends no identity. Any other name uses that person's token from the state.
    """
    def make(person: str | None):
        headers = {}
        if person is not None:
            token = state["tokens"][person]
            headers = {"Authorization": f"token {token}"}
        return httpx.Client(base_url=API, headers=headers, timeout=30, follow_redirects=False)

    return make
