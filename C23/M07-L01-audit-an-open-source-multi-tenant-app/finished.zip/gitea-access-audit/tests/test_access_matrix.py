"""The access-control test matrix, run against your local Gitea.

Four groups, like the course's own test file:

1. test_matrix:            every person x every organization x every route.
2. test_other_organization: a member uses the right path but the OTHER organization's record
                            ID (object-level access, BOLA). The answer must be "not found".
3. test_role_escalation:   a member tries to grow their own powers. The answer must be refused.
4. test_bad_identity:      no identity, and an invalid token, on a protected route.

A cell that does not match the course's rule is an access-control finding. Run it with:

    python -m pytest
"""

import httpx
import pytest

from audit.matrix import ROUTES, expected_status, fill_path
from audit.people import MEMBERSHIPS, PEOPLE
from tests.conftest import API

PERSONS = list(PEOPLE)  # grace, sam, omar, ines, camille, tomas, kwame
ORGS = ("larkfield", "bramble")
ADMIN = "kwame"


def role_of(org: str, person: str) -> str | None:
    return MEMBERSHIPS.get((org, person))


def send(client, person, org, route, state):
    method, path, opts, _ok = ROUTES[route]
    return client(person).request(method, fill_path(path, org, state), **opts)


# ---------------------------------------------------------------------------
# 1. The matrix: person x organization x route.
MATRIX = [(p, o, r) for p in PERSONS for o in ORGS for r in ROUTES]


@pytest.mark.parametrize("person, org, route", MATRIX,
                         ids=[f"{p}|{o}|{r}" for p, o, r in MATRIX])
def test_matrix(client, state, person, org, route):
    role = role_of(org, person)
    want = expected_status(role, route)
    if person == ADMIN:
        # The site administrator may read and write every organization. We only check that an
        # administrator is never refused where a role-holder would succeed (Gitea's design).
        want = ROUTES[route][3]
    response = send(client, person, org, route, state)
    assert response.status_code == want, (
        f"{person} ({role}) {route} in {org}: got {response.status_code}, "
        f"expected {want}. {response.text[:200]}")


# ---------------------------------------------------------------------------
# 2. Object-level access (BOLA): the other organization's record ID, through your own path.
# A member of one organization, the other organization's issue number and attachment ID.
OTHER = [
    ("sam", "larkfield"),       # staff at larkfield; tries bramble's records
    ("ines", "bramble"),        # owner at bramble; tries larkfield's records
    ("camille", "larkfield"),   # staff at larkfield (and read_only at bramble)
]


@pytest.mark.parametrize("person, org", OTHER, ids=[f"{p}|{o}" for p, o in OTHER])
def test_other_organization(client, state, person, org):
    # A global record ID of the other organization, reached through your own path. Issue
    # numbers are per-repository (number 1 under your org is your own issue), so the real
    # cross-organization vector is a global ID: an attachment ID, a comment ID, a repo ID.
    other = "bramble" if org == "larkfield" else "larkfield"
    o_other = state["orgs"][other]
    repo = state["orgs"][org]["repo"]
    my_issue = state["orgs"][org]["issues"][0]["number"]
    c = client(person)
    # The other organization's attachment ID, through your own issue.
    r = c.get(f"/repos/{org}/{repo}/issues/{my_issue}/assets/{o_other['attachment']['id']}")
    assert r.status_code == 404, r.text
    # The other organization's issue comment by its global ID, through your own path.
    assert c.get(
        f"/repos/{org}/{repo}/issues/comments/{o_other['comment_id']}").status_code == 404
    # The other organization's repository by its global numeric ID. Only an outsider of that
    # organization must be refused; a dual member (Camille) legitimately reads both.
    if role_of(other, person) is None:
        assert c.get(f"/repositories/{o_other['repo_id']}").status_code == 404


# ---------------------------------------------------------------------------
# 3. Role escalation: a member tries to grow their own powers.
def test_staff_cannot_join_owners(client, state):
    teams = state["orgs"]["larkfield"]["teams"]
    r = client("sam").put(f"/teams/{teams['Owners']}/members/sam")
    assert r.status_code == 403, r.text


def test_staff_cannot_make_an_admin_team(client, state):
    r = client("sam").post("/orgs/larkfield/teams",
                            json={"name": "sneaky", "permission": "admin"})
    assert r.status_code == 403, r.text


def test_read_only_cannot_raise_a_teams_permission(client, state):
    teams = state["orgs"]["larkfield"]["teams"]
    r = client("omar").patch(f"/teams/{teams['read-only']}",
                             json={"name": "read-only", "permission": "admin"})
    assert r.status_code == 403, r.text


def test_a_dual_member_cannot_join_the_other_organizations_owners(client, state):
    # Camille is read_only at bramble; she may not add herself to bramble's Owners.
    teams = state["orgs"]["bramble"]["teams"]
    r = client("camille").put(f"/teams/{teams['Owners']}/members/camille")
    assert r.status_code == 403, r.text


def test_a_non_admin_cannot_act_as_another_user(client, state):
    # Gitea's "sudo" is for administrators only.
    r = client("sam").get("/user", params={"sudo": "grace"})
    assert r.status_code == 403, r.text


# ---------------------------------------------------------------------------
# 4. Bad identity on a protected route.
PROTECTED = "/repos/larkfield/help-desk/issues/1"


def test_no_identity_is_refused(client):
    assert client(None).get(PROTECTED).status_code == 403  # Gitea answers 403, not 401


def test_an_invalid_token_is_refused():
    with httpx.Client(base_url=API, headers={"Authorization": "token " + "0" * 40},
                      timeout=30) as c:
        assert c.get(PROTECTED).status_code == 401


def test_a_smaller_token_scope_cannot_write(state):
    # Grace's read-only-scoped token may read, but not comment or manage members.
    read_token = state["tokens"]["grace-read-only-token"]
    with httpx.Client(base_url=API, headers={"Authorization": f"token {read_token}"},
                      timeout=30) as c:
        assert c.get(PROTECTED).status_code == 200
        assert c.post("/repos/larkfield/help-desk/issues/1/comments",
                      json={"body": "x"}).status_code == 403
