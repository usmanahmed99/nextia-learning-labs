"""Settings and HTTP clients for the local Gitea."""

import json
import os
from pathlib import Path

import httpx

GITEA_URL = os.environ.get("GITEA_URL", "http://127.0.0.1:3300").rstrip("/")
API = f"{GITEA_URL}/api/v1"
STATE_FILE = Path(os.environ.get("AUDIT_STATE", ".audit-state.json"))


def load_state() -> dict:
    """The IDs and tokens that the seed wrote. Tokens are local and made-up."""
    if not STATE_FILE.exists():
        raise SystemExit(f"{STATE_FILE} not found: run `python -m audit.seed` first.")
    return json.loads(STATE_FILE.read_text())


def as_user(token: str | None, **kwargs) -> httpx.Client:
    """A client that calls the API with one person's token (or with no identity)."""
    headers = {"Authorization": f"token {token}"} if token else {}
    return httpx.Client(base_url=API, headers=headers, timeout=30, follow_redirects=False, **kwargs)


def with_password(user: str, password: str) -> httpx.Client:
    """Basic authentication: used only by the seed, to make each person's token."""
    return httpx.Client(base_url=API, auth=(user, password), timeout=30)
