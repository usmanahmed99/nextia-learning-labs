"""Run the access matrix and the extra checks, and write a short report.

    python -m audit.report

It prints the result table and writes reports/REPORT.md and reports/responses.json with the
real status codes. It does not run pytest; it calls the same routes once each, so the report
shows the exact answers your instance gave. The two must agree.
"""

import json
from pathlib import Path

import httpx

from audit.client import API, GITEA_URL, load_state
from audit.matrix import ROUTES, expected_status, fill_path
from audit.people import MEMBERSHIPS, PEOPLE

OUT = Path("reports")
PERSONS = list(PEOPLE)
ORGS = ("larkfield", "bramble")
ADMIN = "kwame"


def role_of(org, person):
    return MEMBERSHIPS.get((org, person))


def client(token):
    headers = {"Authorization": f"token {token}"} if token else {}
    return httpx.Client(base_url=API, headers=headers, timeout=30, follow_redirects=False)


def run_matrix(state):
    rows = []
    for person in PERSONS:
        token = state["tokens"][person]
        with client(token) as c:
            for org in ORGS:
                role = role_of(org, person)
                for route, (method, path, opts, ok) in ROUTES.items():
                    want = ok if person == ADMIN else expected_status(role, route)
                    got = c.request(method, fill_path(path, org, state), **opts).status_code
                    rows.append({"person": person, "role": role, "org": org, "route": route,
                                 "expected": want, "got": got, "pass": got == want})
    return rows


def run_extra(state):
    """The cross-organization, escalation and bad-identity checks, as named cases."""
    cases = []
    lark = state["orgs"]["larkfield"]
    bram = state["orgs"]["bramble"]

    def case(name, token, method, path, expected, **kw):
        with client(token) as c:
            got = c.request(method, path, **kw).status_code
        cases.append({"name": name, "expected": expected, "got": got, "pass": got == expected})

    sam, ines, camille = (state["tokens"][p] for p in ("sam", "ines", "camille"))
    # Object-level access (BOLA): a GLOBAL record ID of the other organization. Issue numbers
    # are per-repository (number 1 under larkfield is Larkfield's own issue), so the real
    # cross-organization vector is a global ID: a comment ID, an attachment ID, a repo ID.
    case("Sam downloads Bramble's file ID through Larkfield's issue", sam, "GET",
         f"/repos/larkfield/help-desk/issues/1/assets/{bram['attachment']['id']}", 404)
    case("Sam reads Bramble's comment by its global ID", sam, "GET",
         f"/repos/larkfield/help-desk/issues/comments/{bram['comment_id']}", 404)
    case("Sam opens Bramble's repository by its global ID", sam, "GET",
         f"/repositories/{bram['repo_id']}", 404)
    case("Ines opens Larkfield's repository by its global ID", ines, "GET",
         f"/repositories/{lark['repo_id']}", 404)
    # Role escalation.
    case("Sam (staff) adds himself to Owners", sam, "PUT",
         f"/teams/{lark['teams']['Owners']}/members/sam", 403)
    case("Sam (staff) makes an admin team", sam, "POST", "/orgs/larkfield/teams", 403,
         json={"name": "sneaky", "permission": "admin"})
    case("Camille (read_only at Bramble) joins Bramble's Owners", camille, "PUT",
         f"/teams/{bram['teams']['Owners']}/members/camille", 403)
    case("Sam acts as Grace (sudo)", sam, "GET", "/user", 403, params={"sudo": "grace"})
    # Bad identity.
    case("No identity on a protected route", None, "GET",
         "/repos/larkfield/help-desk/issues/1", 403)
    case("An invalid token on a protected route", "0" * 40, "GET",
         "/repos/larkfield/help-desk/issues/1", 401)
    # Token scope.
    case("A read-only-scoped token tries to comment", state["tokens"]["grace-read-only-token"],
         "POST", "/repos/larkfield/help-desk/issues/1/comments", 403, json={"body": "x"})
    return cases


def audit_summary(state):
    """What Gitea's own audit log recorded (admin-only export). Changes only, not refusals."""
    with httpx.Client(timeout=30, follow_redirects=False) as c:
        c.get(f"{GITEA_URL}/user/login")
        c.post(f"{GITEA_URL}/user/login",
               data={"user_name": "kwame", "password": "practice-kwame-2026"})
        r = c.get(f"{GITEA_URL}/-/admin/monitor/audit_logs/export")
    events = [json.loads(line) for line in r.text.splitlines() if line.strip()]
    (OUT / "audit-export.jsonl").write_text(r.text)
    by_action = {}
    for e in events:
        by_action[e["action"]] = by_action.get(e["action"], 0) + 1
    return events, by_action


def main():
    OUT.mkdir(exist_ok=True)
    state = load_state()
    matrix = run_matrix(state)
    extra = run_extra(state)
    events, by_action = audit_summary(state)

    m_pass = sum(r["pass"] for r in matrix)
    e_pass = sum(c["pass"] for c in extra)
    (OUT / "responses.json").write_text(json.dumps(
        {"matrix": matrix, "extra": extra, "audit_actions": by_action}, indent=2) + "\n")

    lines = ["# Access-control audit report", ""]
    lines.append(f"Target: a local Gitea at {GITEA_URL}, with made-up users and records. "
                 "This report is the output of `python -m audit.report`.")
    lines.append("")
    lines.append(f"- Matrix cells: **{m_pass} of {len(matrix)}** match the course's rule "
                 f"({len(PERSONS)} people x {len(ORGS)} organizations x {len(ROUTES)} routes).")
    lines.append(f"- Extra checks (object-level, escalation, bad identity, scope): "
                 f"**{e_pass} of {len(extra)}**.")
    lines.append(f"- Gitea audit events recorded during the seed and this run: "
                 f"**{len(events)}** (changes only; refusals are not recorded).")
    lines.append("")
    lines.append("## Extra checks")
    lines.append("")
    lines.append("| Check | Expected | Got | |")
    lines.append("|---|---|---|---|")
    for c in extra:
        mark = "ok" if c["pass"] else "FAIL"
        lines.append(f"| {c['name']} | {c['expected']} | {c['got']} | {mark} |")
    lines.append("")
    lines.append("## What the audit log recorded")
    lines.append("")
    lines.append("| Action | Count |")
    lines.append("|---|---|")
    for action, n in sorted(by_action.items()):
        lines.append(f"| `{action}` | {n} |")
    (OUT / "REPORT.md").write_text("\n".join(lines) + "\n")

    print(f"Matrix: {m_pass}/{len(matrix)} as expected.")
    print(f"Extra checks: {e_pass}/{len(extra)} as expected.")
    print(f"Audit events: {len(events)} (actions: {sorted(by_action)}).")
    print(f"Wrote {OUT/'REPORT.md'}, {OUT/'responses.json'}, {OUT/'audit-export.jsonl'}.")


if __name__ == "__main__":
    main()
