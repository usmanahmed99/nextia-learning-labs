"""Fill a fresh local Gitea with two made-up organizations, their people and records.

    python -m audit.seed

It makes the administrator with Gitea's own command (through Docker Compose), then uses
the API as each person: users, organizations, teams (the roles), one private repository per
organization, issues, a comment and a file on the first issue, and one token per person.
The IDs and tokens go to .audit-state.json (Git ignores it). Tokens are for your local
practice server only.
"""

import json
import subprocess
import sys
import time

import httpx

from audit.client import API, GITEA_URL, STATE_FILE, as_user, with_password
from audit.people import ADMIN, ISSUES, MEMBERSHIPS, ORGS, PASSWORDS, PEOPLE, TEAM_FOR_ROLE

# A tiny made-up receipt, uploaded as an attachment to each organization's first issue.
RECEIPT = "Receipt (made up)\nOrder {order}\nTotal 47.50\n"


def wait_for_gitea() -> None:
    for _ in range(60):
        try:
            if httpx.get(f"{GITEA_URL}/api/healthz", timeout=2).status_code == 200:
                return
        except httpx.HTTPError:
            pass
        time.sleep(1)
    raise SystemExit(f"Gitea does not answer at {GITEA_URL}. Is `docker compose up -d` running?")


def ensure_admin() -> None:
    """The first administrator can only be made on the server: Gitea's `admin user create`."""
    name, email = ADMIN, PEOPLE[ADMIN][1]
    if with_password(name, PASSWORDS[name]).get("/user").status_code == 200:
        return
    command = [
        "docker", "compose", "exec", "-T", "-u", "git", "gitea",
        "gitea", "admin", "user", "create", "--admin", "--username", name,
        "--email", email, "--password", PASSWORDS[name], "--must-change-password=false",
    ]
    subprocess.run(command, check=True, capture_output=True, text=True)


def ok(response: httpx.Response, *expected: int) -> dict | list:
    if response.status_code not in (expected or (200, 201, 204)):
        raise SystemExit(f"{response.request.method} {response.request.url} -> "
                         f"{response.status_code} {response.text[:300]}")
    return response.json() if response.content else {}


def main() -> None:
    wait_for_gitea()
    ensure_admin()
    admin = with_password(ADMIN, PASSWORDS[ADMIN])
    if admin.get("/orgs/larkfield").status_code == 200:
        sys.exit("This Gitea already has the practice data. To start again:\n"
                 "  docker compose down -v\n  docker compose up -d\n  python -m audit.seed")

    for name, (full_name, email) in PEOPLE.items():
        if name == ADMIN:
            continue
        ok(admin.post("/admin/users", json={
            "username": name, "full_name": full_name, "email": email,
            "password": PASSWORDS[name], "must_change_password": False, "send_notify": False,
        }), 201)
    print(f"Made {len(PEOPLE)} people (1 site administrator).")

    tokens = {}
    for name in PEOPLE:
        client = with_password(name, PASSWORDS[name])
        tokens[name] = ok(client.post(f"/users/{name}/tokens",
                                      json={"name": "audit", "scopes": ["all"]}), 201)["sha1"]
    # A second token for Grace that may only read: for the scope test.
    grace = with_password("grace", PASSWORDS["grace"])
    read_scopes = ["read:organization", "read:repository", "read:issue", "read:user"]
    tokens["grace-read-only-token"] = ok(grace.post(
        "/users/grace/tokens", json={"name": "reporting", "scopes": read_scopes}), 201)["sha1"]

    state = {"gitea": GITEA_URL, "tokens": tokens, "orgs": {}}
    for org, (display, repo, owner) in ORGS.items():
        me = as_user(tokens[owner])
        ok(me.post("/orgs", json={"username": org, "full_name": display, "visibility": "private"}), 201)
        teams = {t["name"]: t["id"] for t in ok(me.get(f"/orgs/{org}/teams"))}
        for team, permission in (("staff", "write"), ("read-only", "read")):
            created = ok(me.post(f"/orgs/{org}/teams", json={
                "name": team, "permission": permission, "includes_all_repositories": True,
                "units": ["repo.code", "repo.issues", "repo.pulls", "repo.releases", "repo.wiki"],
            }), 201)
            teams[team] = created["id"]
        for (member_org, user), role in MEMBERSHIPS.items():
            if member_org == org and user != owner:
                ok(me.put(f"/teams/{teams[TEAM_FOR_ROLE[role]]}/members/{user}"), 204)

        made = ok(me.post(f"/orgs/{org}/repos", json={
            "name": repo, "private": True, "auto_init": True, "default_branch": "main",
            "description": f"{display}'s help desk (made-up records)"}), 201)
        issues = []
        for title, body in ISSUES[org]:
            issue = ok(me.post(f"/repos/{org}/{repo}/issues", json={"title": title, "body": body}), 201)
            issues.append({"number": issue["number"], "id": issue["id"], "title": title})
        first = issues[0]["number"]
        comment = ok(me.post(f"/repos/{org}/{repo}/issues/{first}/comments",
                             json={"body": "We have asked the warehouse. (made up)"}), 201)
        order = "BB-310729" if org == "bramble" else "L-88213"
        files = {"attachment": ("receipt.txt", RECEIPT.format(order=order).encode(), "text/plain")}
        asset = ok(me.post(f"/repos/{org}/{repo}/issues/{first}/assets", files=files), 201)
        state["orgs"][org] = {
            "repo": repo, "repo_id": made["id"], "teams": teams, "issues": issues,
            "comment_id": comment["id"],
            "attachment": {"id": asset["id"], "uuid": asset["uuid"],
                           "url": asset["browser_download_url"]},
        }
        print(f"{display}: organization '{org}', teams {sorted(teams)}, repository {org}/{repo}, "
              f"{len(issues)} issues, 1 comment, 1 file.")

    STATE_FILE.write_text(json.dumps(state, indent=2) + "\n")
    print(f"Wrote {STATE_FILE} ({len(tokens)} tokens; local and made-up). API: {API}")


if __name__ == "__main__":
    main()
