"""The access matrix: who may do what, in which organization, and the answer we expect.

The course's matrix asks three questions of every request: who is the caller, in which
organization, and what may they do there. This file writes that matrix for the local Gitea.
Each cell names a route, a person, an organization, and the HTTP status the course says the
person must get. The test harness (tests/test_access_matrix.py) runs every cell against your
own instance; `python -m audit.report` runs it and writes a Markdown report.

This is not a full security audit of Gitea. It tests the routes listed here with the course's
three questions. A complete audit would also cover cross-references between repositories,
search, webhooks, notifications, packages, the web UI and the Git protocol.

Expected statuses follow what the course teaches and what Gitea does here:

- No membership in the organization -> 404. The caller learns nothing, not even that the
  record exists. These routes are scoped by `/orgs/{org}/...` or `/repos/{org}/{repo}/...`,
  and Gitea answers 404 to a non-member.
- A member whose role is too small -> 403. Gitea's "read" team may still open issues and
  comment, so those are allowed for `read_only` here (a difference from the course, taught in
  the lesson).
- A record of the other organization, reached through this organization's path -> 404 (the
  cross-organization check, tested on its own in test_another_organizations_record_id).
- No identity -> Gitea answers 403 (not the course's 401); an invalid token -> 401.
"""

READ = 200
CREATED = 201
FORBIDDEN = 403
NOT_FOUND = 404

# Routes scoped by organization or repository: an outsider gets a clean 404 on every one.
# Each is (method, path template, request options, status when allowed). {repo}, {issue} and
# {asset} come from the organization's row in the state file.
ROUTES = {
    "list issues": ("GET", "/repos/{org}/{repo}/issues", {}, READ),
    "read an issue": ("GET", "/repos/{org}/{repo}/issues/{issue}", {}, READ),
    "read the repository": ("GET", "/repos/{org}/{repo}", {}, READ),
    "download the archive": ("GET", "/repos/{org}/{repo}/archive/main.zip", {}, READ),
    "download a file": ("GET", "/repos/{org}/{repo}/issues/{issue}/assets/{asset}", {}, READ),
    "list members": ("GET", "/orgs/{org}/members", {}, READ),
    "open an issue": ("POST", "/repos/{org}/{repo}/issues",
                      {"json": {"title": "Matrix probe"}}, CREATED),
    "comment on an issue": ("POST", "/repos/{org}/{repo}/issues/{issue}/comments",
                            {"json": {"body": "Access-matrix probe."}}, CREATED),
    "edit an issue": ("PATCH", "/repos/{org}/{repo}/issues/{issue}",
                      {"json": {"title": "Matrix probe edit"}}, CREATED),
    "upload a file": ("POST", "/repos/{org}/{repo}/issues/{issue}/assets",
                      {"files": {"attachment": ("m.txt", b"probe", "text/plain")}}, CREATED),
}

# Which roles may do each action (members only). An action a person is not a member for is
# always 404 (check 2 in the course). The site administrator is tested separately.
ALLOWED = {
    "list issues": {"owner", "staff", "read_only"},
    "read an issue": {"owner", "staff", "read_only"},
    "read the repository": {"owner", "staff", "read_only"},
    "download the archive": {"owner", "staff", "read_only"},
    "download a file": {"owner", "staff", "read_only"},
    "list members": {"owner", "staff", "read_only"},
    "open an issue": {"owner", "staff", "read_only"},
    "comment on an issue": {"owner", "staff", "read_only"},
    "edit an issue": {"owner", "staff"},
    "upload a file": {"owner", "staff"},
}


def expected_status(role: str | None, route: str) -> int:
    """The status the course says this role must get on this route in its own organization."""
    _method, _path, _opts, ok = ROUTES[route]
    if role is None:
        return NOT_FOUND  # not a member: 404 for everything
    if role in ALLOWED[route]:
        return ok
    return FORBIDDEN  # a member whose role is too small


def fill_path(path: str, org: str, state: dict) -> str:
    """Put the organization's real IDs into a route path."""
    o = state["orgs"][org]
    return path.format(org=org, repo=o["repo"], issue=o["issues"][0]["number"],
                       asset=o["attachment"]["id"])
