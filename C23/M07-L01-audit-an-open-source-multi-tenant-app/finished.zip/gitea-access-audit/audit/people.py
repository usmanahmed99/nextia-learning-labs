"""The made-up people and organizations of the audit, and the role each membership gives.

The people are the course's: every one of them, and every record, is made up. The roles
are the course's three, mapped to Gitea teams:

    owner      -> the organization's "Owners" team (Gitea makes it with the organization)
    staff      -> a team "staff" with write permission on every repository
    read_only  -> a team "read-only" with read permission on every repository
"""

PEOPLE = {
    # username: (full name, email)
    "grace": ("Grace", "grace@larkfield.example"),
    "sam": ("Sam", "sam@larkfield.example"),
    "omar": ("Omar", "omar@larkfield.example"),
    "ines": ("Ines", "ines@bramble.example"),
    "camille": ("Camille", "camille@larkfield.example"),
    "tomas": ("Tomás", "tomas@larkfield.example"),
    "kwame": ("Kwame", "kwame@larkfield.example"),  # the site administrator
}

ADMIN = "kwame"

# Made-up passwords for a practice server on your own computer. Never reuse them.
PASSWORDS = {name: f"practice-{name}-2026" for name in PEOPLE}

ORGS = {
    # org: (display name, the repository, the person who creates it and is its first owner)
    "larkfield": ("Larkfield", "help-desk", "grace"),
    "bramble": ("Bramble Books", "help-desk", "ines"),
}

MEMBERSHIPS = {
    ("larkfield", "grace"): "owner",
    ("larkfield", "sam"): "staff",
    ("larkfield", "omar"): "read_only",
    ("larkfield", "camille"): "staff",
    ("bramble", "ines"): "owner",
    ("bramble", "camille"): "read_only",
}

TEAM_FOR_ROLE = {"owner": "Owners", "staff": "staff", "read_only": "read-only"}

# A few tickets of each shop become issues (titles from the course's made-up data, CC0).
ISSUES = {
    "larkfield": [
        ("Refund for a broken hose reel", "Order L-88213 arrived with a cracked reel. Photo attached."),
        ("Delivery slot missed", "The driver did not come on Saturday morning."),
    ],
    "bramble": [
        ("Charged twice for order BB-310729", "My card was charged two times, 47.50 dollars each time."),
        ("Book arrived damaged", "A Field Guide to Moss arrived with a bent cover. Order BB-310166."),
    ],
}
