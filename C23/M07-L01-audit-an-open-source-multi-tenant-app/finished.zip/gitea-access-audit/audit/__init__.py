"""An access-control audit of a local Gitea, with the authentication course's matrix."""
