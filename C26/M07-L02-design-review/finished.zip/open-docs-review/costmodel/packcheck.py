"""Check the design review before you hand it in.

Each check is something a reviewer would ask: does every number say where it comes from, does the
calculator use this collection's own numbers, does every decision say when to revisit it, does every
failure have an owner and a recovery target?
"""

import re
from pathlib import Path

from .demand import load_demand
from .inputs import ROOT, InputError, load_measured, load_prices

ADR_HEADINGS = ("## Status", "## Context", "## Options", "## Decision", "## Consequences", "## Revisit when")
REVIEW_HEADINGS = ("## Recommendation", "## Cost per tenant", "## Assumptions", "## Risks")


def _corpus():
    if not (ROOT / "corpus.toml").exists():
        return "corpus.toml does not exist yet: run python -m corpus write"
    return None


def _decisions():
    adrs = sorted((ROOT / "decisions").glob("adr-*.md"))
    if len(adrs) < 2:
        return f"decisions/ needs at least 2 adr-*.md files (found {len(adrs)})"
    for a in adrs:
        text = a.read_text(encoding="utf-8")
        missing = [h for h in ADR_HEADINGS if h not in text]
        if missing:
            return f"{a.name} has no {', '.join(missing)}"
    return None


def _failures():
    text = (ROOT / "decisions" / "failure-modes.md").read_text(encoding="utf-8")
    rows = [line for line in text.splitlines() if line.startswith("| F")]
    if len(rows) < 5:
        return "failure-modes.md needs at least 5 failures (| F1 ...)"
    if any(re.search(r"\|\s*\|", line) or line.count("|") < 9 for line in rows):
        return "every failure needs an owner, a mitigation, a signal, an RTO and an RPO (no empty cells)"
    return None


def _review():
    text = (ROOT / "review.md").read_text(encoding="utf-8")
    missing = [h for h in REVIEW_HEADINGS if h not in text]
    if missing:
        return f"review.md has no {', '.join(missing)}"
    if "unresolved" not in text:
        return "review.md does not name an unresolved assumption"
    return None


def _measured():
    bad = [m.name for m in load_measured().values() if not m.source.startswith("measured:")]
    return f"measured values without a run: {bad}" if bad else None


def _prices():
    bad = [p.name for p in load_prices().values() if not p.source.startswith(("price:", "price page:"))]
    return f"prices without a source page: {bad}" if bad else None


CHECKS = (
    ("demand: every value has evidence (verified or assumed)", lambda: load_demand() and None),
    ("prices: every price has its source", _prices),
    ("measured: every value names its run", _measured),
    ("corpus: the calculator uses this collection's own numbers", _corpus),
    ("decisions: 2 or more ADRs with status, context, options, decision, consequences, revisit", _decisions),
    ("failures: at least 5, each with owner, mitigation, signal, RTO and RPO", _failures),
    ("review: recommendation, cost per tenant, assumptions, risks and an unresolved assumption", _review),
)


def _short(filename) -> str:
    path = Path(filename)
    return path.relative_to(ROOT).as_posix() if path.is_relative_to(ROOT) else str(filename)


def run() -> tuple[int, list[str]]:
    lines, passed = [], 0
    for name, check in CHECKS:
        try:
            problem = check()
        except FileNotFoundError as e:
            problem = f"{_short(e.filename)} does not exist yet"
        except (InputError, KeyError) as e:
            problem = str(e)
        passed += problem is None
        lines.append(f"  {'PASS' if problem is None else 'FAIL'}  {name}" + (f": {problem}" if problem else ""))
    lines.append(f"Design review check: {passed} of {len(CHECKS)} passed")
    return passed, lines
