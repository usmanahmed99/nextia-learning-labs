"""Read the frozen collection (one JSON object per document, gzip) and clean each text.

The Federal Register's "raw text" is a small web page: the text sits inside <pre> ... </pre>,
with a few tags (<a>, <span>, <bullet>, <INF> for subscripts) and HTML entities (&#160;).
clean() keeps only the text, so that we count words and tokens of the document, not of the page.
"""

import gzip
import html
import json
import re
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Document:
    document_number: str   # the Federal Register's ID, for example 2024-14824
    type: str              # Rule, Proposed Rule or Notice
    title: str
    publication_date: str  # YYYY-MM-DD
    pages: int             # printed pages in the Federal Register
    url: str
    text: str              # the plain text of the document (cleaned)
    raw_chars: int         # characters of the page before cleaning


def clean(raw: str) -> str:
    inside = re.search(r"<pre>(.*)</pre>", raw, re.S)
    text = inside.group(1) if inside else raw
    text = text.replace("<bullet>", "•")
    text = re.sub(r"<[^>]+>", "", text)        # the remaining tags; their text stays
    return html.unescape(text)


def read_corpus(path: Path) -> list[Document]:
    docs = []
    with gzip.open(path, "rt", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                d = json.loads(line)
                docs.append(Document(d["document_number"], d["type"], d["title"], d["publication_date"],
                                     int(d["pages"] or 0), d["url"], clean(d["text"]), len(d["text"])))
    return docs
