"""Download the frozen collection and check it with its SHA-256 checksum.

The Federal Register's documents are public domain, so a fixed copy is kept in the course's labs
repository: the same bytes for every learner, even when the Federal Register adds documents.
"""

import hashlib
import os
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
# CORPUS_URL: another copy of the same files (for example a local mirror); the checksums stay the same.
LABS = os.environ.get("CORPUS_URL", "https://github.com/usmanahmed99/nextia-learning-labs/raw/main/C26/M07-L02-design-review/data/")
FILES = {
    "osha-fr-2021-2025.jsonl.gz": "81b47f96634ae58085323327008297924914932d8687d4673ec55657465c03bc",
    "osha-fr-2026-new.jsonl.gz": "3ee6af82c1395bf549098772a76ffd1645009984aae5ef4dd3cae633bb1ba411",
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def get(name: str, folder: Path | None = None) -> Path:
    folder = folder or ROOT / "data"
    folder.mkdir(exist_ok=True)
    path = folder / name
    if not path.exists():
        print(f"Downloading {LABS}{name}")
        urllib.request.urlretrieve(LABS + name, path)
    digest = sha256(path)
    if digest != FILES[name]:
        path.rename(path.with_suffix(".bad"))
        raise SystemExit(f"{name}: SHA-256 {digest[:12]}... is not the expected {FILES[name][:12]}... "
                         "The file was moved to .bad; run the command again to download it again.")
    print(f"Checked {name}: SHA-256 {digest[:12]}... is correct")
    return path
