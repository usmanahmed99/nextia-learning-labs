"""The corpus commands.

    python -m corpus get        download the collection and check its SHA-256
    python -m corpus check      the first checks: documents, text, duplicates, dates
    python -m corpus size       documents, pages, words, tokens, chunks, storage, ingestion
    python -m corpus write      write corpus.toml: this collection's values for the calculator
    python -m corpus new        size the new documents (2026) and compare them with the plan
"""

import argparse
from collections import Counter

from costmodel.inputs import load_measured, load_prices

from . import size as sz
from .get import ROOT, get
from .load import read_corpus

MAIN = "osha-fr-2021-2025.jsonl.gz"
NEW = "osha-fr-2026-new.jsonl.gz"
FIRST, LAST = "2021-01", "2025-12"


def cmd_get(args):
    for name in (MAIN, NEW):
        get(name)


def cmd_check(args):
    docs = read_corpus(get(MAIN))
    numbers = Counter(d.document_number for d in docs)
    dates = sorted(d.publication_date for d in docs)
    print(f"Documents: {len(docs):,}; types: " + ", ".join(f"{t} {n}" for t, n in Counter(d.type for d in docs).most_common()))
    print(f"Published: {dates[0]} to {dates[-1]}")
    print(f"Without text: {sum(not d.text.strip() for d in docs)}; repeated document numbers: "
          f"{sum(n > 1 for n in numbers.values())}; without a page count: {sum(d.pages == 0 for d in docs)}")
    raw = sum(d.raw_chars for d in docs)
    kept = sum(len(d.text) for d in docs)
    print(f"Raw pages: {raw:,} characters; text after cleaning: {kept:,} ({1 - kept / raw:.1%} was markup)")
    short = sorted(docs, key=lambda d: len(d.text.split()))[0]
    print(f"Shortest: {short.document_number} ({short.type}, {len(short.text.split())} words, {short.pages} page)")


def report(s: sz.Sizing, m, p) -> None:
    print(f"Collection: {s.documents:,} documents, {s.pages:,} printed pages, {s.words:,} words")
    print(f"  tokens                {s.tokens:>12,}  ({s.tokens / s.words:.2f} per word, "
          f"{s.tokens / max(s.pages, 1):,.0f} per page; {sz.TOKENS_HOW})")
    print(f"  chunks                {s.chunks:>12,}  ({s.chunks / s.words * 1000:.1f} per 1,000 words; "
          f"{s.chunk_tokens / s.chunks:.0f} tokens each with the title)")
    print(f"  tokens to embed       {s.chunk_tokens:>12,}  (the chunks with their titles: "
          f"+{s.chunk_tokens / s.tokens - 1:.0%} on the text)")
    print("  by type               " + "; ".join(
        f"{t} {c['documents']} documents, {c['tokens'] / s.tokens:.0%} of the tokens" for t, c in
        sorted(s.by_type.items(), key=lambda kv: -kv[1]["tokens"])))
    print(f"  the 10 largest        {sz.largest_share(s):.0%} of all tokens")
    st = sz.storage_mb(s, m)
    print("Storage: " + ", ".join(f"{k} {v:,.1f} MB" for k, v in st.items()))
    db = st["vectors with table and index"] + st["chunk text"]
    print(f"  in the database {db:,.1f} MB = {db / 1000 / 32:.1%} of the smallest size (32 GB)")
    ing = sz.ingestion(s, m, p)
    print(f"Ingest everything once: {ing['tokens']:,} tokens, US${ing['usd']:.2f}, {ing['calls']:,} calls of up to 100 chunks")
    print(f"  one call at a time {ing['minutes_one_call_at_a_time']:,.0f} min; at the token quota "
          f"{ing['minutes_at_the_quota']:,.0f} min: about {ing['minutes']:,.0f} min")
    nm = sz.monthly_new(s, FIRST, LAST)
    print(f"New documents per month ({nm['months']} months): low {nm['low']}, median {nm['median']:g}, "
          f"mean {nm['mean']:.1f}, high {nm['high']}")


def cmd_size(args):
    report(sz.size(read_corpus(get(MAIN))), load_measured(), load_prices())


def cmd_write(args):
    s = sz.size(read_corpus(get(MAIN)))
    values = sz.corpus_values(s, load_measured(include_corpus=False))
    sz.write_toml(values, ROOT / "corpus.toml")
    for name, (value, unit, _) in values.items():
        print(f"  {name:<30} {value:>10,.2f} {unit}")
    print("Wrote corpus.toml: the calculator now uses this collection's values")


def cmd_new(args):
    m, p = load_measured(), load_prices()
    docs = read_corpus(get(NEW))
    s = sz.size(docs)
    months = sorted(s.per_month)
    print(f"New documents: {s.documents} from {months[0]} to {months[-1]} ({s.documents / len(months):.1f} a month)")
    print(f"  {s.pages:,} pages, {s.words:,} words, {s.chunks:,} chunks, {s.chunk_tokens:,} tokens to embed")
    ing = sz.ingestion(s, m, p)
    st = sz.storage_mb(s, m)
    print(f"  embedding US${ing['usd']:.4f}; database +{st['vectors with table and index'] + st['chunk text']:,.1f} MB")
    big = max(s.per_document, key=lambda r: r[4])
    print(f"  largest: {big[0]} ({big[1]}, {big[2]} pages, {big[4]:,} tokens)")


COMMANDS = {name[4:]: f for name, f in globals().items() if name.startswith("cmd_")}


def main(argv=None) -> None:
    ap = argparse.ArgumentParser(prog="python -m corpus", description="Size the document collection.")
    ap.add_argument("command", choices=sorted(COMMANDS))
    COMMANDS[ap.parse_args(argv).command](None)


if __name__ == "__main__":
    main()
