"""Cut a document into chunks, with the RAG course's rule in a simple form.

- A chunk is one or more whole paragraphs, at most MAX_WORDS words.
- A paragraph longer than MAX_WORDS is cut into pieces of MAX_WORDS words.
- Every chunk starts with the document's title, so a chunk keeps its context
  ("The employer shall ..." alone does not say which rule).
The title is repeated in every chunk, so it costs tokens and bytes in every chunk: we count it.
"""

import re

MAX_WORDS = 200   # the RAG course's longest structure chunk


def paragraphs(text: str) -> list[str]:
    """Paragraphs are separated by a blank line; line breaks inside a paragraph become spaces."""
    parts = re.split(r"\n\s*\n", text)
    return [" ".join(p.split()) for p in parts if p.strip()]


def chunk(title: str, text: str, max_words: int = MAX_WORDS) -> list[str]:
    pieces: list[list[str]] = []
    for para in paragraphs(text):
        words = para.split()
        for i in range(0, len(words), max_words):          # a long paragraph: pieces of max_words
            piece = words[i:i + max_words]
            if pieces and len(pieces[-1]) + len(piece) <= max_words:
                pieces[-1].extend(piece)                    # whole paragraphs share a chunk while they fit
            else:
                pieces.append(list(piece))
    return [f"{title}\n{' '.join(p)}" for p in pieces]
