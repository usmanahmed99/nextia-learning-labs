"""Size the collection: count, do not guess.

documents, pages and words are counted from the file; tokens are counted with a tokenizer
(tiktoken's cl100k_base, which gave the same count as the provider's bill for embed-small:
measured.toml, embed_tokenizer_check); chunks come from corpus/chunk.py. Storage and
ingestion multiply these counts by the course's measured values and the price list.
"""

import statistics
from collections import Counter, defaultdict
from dataclasses import dataclass, field

from .chunk import chunk
from .load import Document


@dataclass
class Sizing:
    documents: int = 0
    pages: int = 0
    words: int = 0
    tokens: int = 0              # the documents' words, counted with the tokenizer (spaces and line breaks collapsed)
    chunks: int = 0
    chunk_tokens: int = 0        # what embedding costs: the chunks, each with the title
    chunk_bytes: int = 0         # the chunks' text in the database (UTF-8)
    text_bytes: int = 0          # the documents' plain text files
    empty: int = 0               # documents without text
    by_type: dict = field(default_factory=lambda: defaultdict(Counter))
    per_document: list = field(default_factory=list)   # (document_number, type, pages, words, tokens, chunks)
    per_month: Counter = field(default_factory=Counter)  # YYYY-MM -> new documents


TOKENS_HOW = "cl100k_base"   # how the tokens below are found


def count_tokens(text: str) -> int:
    """Count with the tokenizer: the same count as the provider's bill for embed-small (measured)."""
    import tiktoken  # the embedding model's tokenizer; get_encoding keeps it loaded after the first call

    return len(tiktoken.get_encoding("cl100k_base").encode(text, disallowed_special=()))


def size(docs: list[Document]) -> Sizing:
    s = Sizing()
    for d in docs:
        words = d.text.split()
        tokens = count_tokens(" ".join(words))   # the page layout's spaces are not content
        words = len(words)
        chunks = chunk(d.title, d.text)
        s.documents += 1
        s.pages += d.pages
        s.words += words
        s.tokens += tokens
        s.chunks += len(chunks)
        s.chunk_tokens += sum(count_tokens(c) for c in chunks)
        s.chunk_bytes += sum(len(c.encode("utf-8")) for c in chunks)
        s.text_bytes += len(d.text.encode("utf-8"))
        s.empty += not d.text.strip()
        t = s.by_type[d.type]
        t["documents"] += 1
        t["pages"] += d.pages
        t["words"] += words
        t["tokens"] += tokens
        s.per_document.append((d.document_number, d.type, d.pages, words, tokens, len(chunks)))
        s.per_month[d.publication_date[:7]] += 1
    return s


def months_between(first: str, last: str) -> list[str]:
    """Every YYYY-MM from first to last, so a month without documents counts as 0."""
    y, m = int(first[:4]), int(first[5:7])
    out = []
    while f"{y:04d}-{m:02d}" <= last:
        out.append(f"{y:04d}-{m:02d}")
        y, m = (y + 1, 1) if m == 12 else (y, m + 1)
    return out


def monthly_new(s: Sizing, first: str, last: str) -> dict:
    counts = [s.per_month.get(mo, 0) for mo in months_between(first, last)]
    return {"months": len(counts), "low": min(counts), "median": statistics.median(counts),
            "mean": statistics.mean(counts), "high": max(counts)}


def largest_share(s: Sizing, n: int = 10) -> float:
    """The share of all tokens in the n largest documents."""
    top = sorted((row[4] for row in s.per_document), reverse=True)[:n]
    return sum(top) / s.tokens if s.tokens else 0.0


def storage_mb(s: Sizing, m: dict) -> dict:
    """The database (chunks with their vectors) and the file storage (plain text), in MB."""
    vectors = s.chunks * m["vector_row_bytes"].value
    return {"vectors with table and index": vectors / 1e6, "chunk text": s.chunk_bytes / 1e6,
            "document files": s.text_bytes / 1e6}


def ingestion(s: Sizing, m: dict, p: dict, batch: int = 100) -> dict:
    """Embed every chunk once: tokens, price, calls, and time (one call at a time, or at the token quota)."""
    calls = sum(-(-row[5] // batch) for row in s.per_document)      # ceil(chunks / batch) per document
    one_at_a_time_s = calls * m["embed_call_fixed_s"].value + s.chunk_tokens / 1000 * m["embed_call_s_per_1000_tokens"].value
    quota_min = s.chunk_tokens / m["embed_quota_tokens_per_minute"].value
    return {"tokens": s.chunk_tokens, "usd": s.chunk_tokens / 1e6 * p["embed_small_input"].value, "calls": calls,
            "minutes_one_call_at_a_time": one_at_a_time_s / 60, "minutes_at_the_quota": quota_min,
            "minutes": max(one_at_a_time_s / 60, quota_min)}


def answer_tokens_in(s: Sizing, m: dict, passages: int = 5) -> float:
    """The answer prompt with this collection's chunks instead of the RAG course's (an estimate from measured parts).

    The course measured 946.5 tokens per answer with 5 passages of the RAG course's collection, whose chunks
    have rag_chunk_tokens tokens on average. The rest (instructions, question, format) stays the same.
    """
    fixed = m["answer_small_tokens_in"].value - passages * m["rag_chunk_tokens"].value
    return fixed + passages * s.chunk_tokens / s.chunks


def corpus_values(s: Sizing, m: dict) -> dict:
    """The measured values that this collection replaces in the calculator (written to corpus.toml)."""
    src = f"measured: python -m corpus size, {s.documents} documents of the collection"
    answer = answer_tokens_in(s, m)
    return {
        "ingest_embed_tokens_per_word": (s.chunk_tokens / s.words, "tokens per word", src + ", chunks with titles, cl100k_base"),
        "chunks_per_1000_words": (s.chunks / s.words * 1000, "chunks", src + ", corpus/chunk.py (200 words at most)"),
        "chunk_text_bytes_per_word": (s.chunk_bytes / s.words, "bytes per word", src + ", chunk text with titles"),
        "document_file_bytes": (s.text_bytes / s.documents, "bytes per document (mean)", src + ", plain text"),
        "answer_small_tokens_in": (answer, "tokens per answer (estimate)",
                                   src + ": the course's 946.5 with 5 chunks of this collection instead of the RAG course's"),
        "answer_strong_tokens_in": (answer, "tokens per answer (estimate)", src + ": the same prompt for chat-strong"),
    }


def write_toml(values: dict, path) -> None:
    lines = ["# Written by `python -m corpus write`. These measured values replace the course's values",
             "# (measured.toml) with this collection's own. Do not edit by hand: run the command again.", ""]
    for name, (value, unit, source) in values.items():
        lines += [f"[{name}]", f"value = {round(value, 4)}", f'unit = "{unit}"', f'source = "{source}"', ""]
    path.write_text("\n".join(lines), encoding="utf-8")
