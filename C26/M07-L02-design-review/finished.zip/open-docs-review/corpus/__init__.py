"""Size an open document collection: documents, pages, words, tokens, chunks, storage and ingestion."""
