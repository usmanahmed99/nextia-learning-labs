"""The review's own numbers: the calculator with this collection and this tenant."""

from helpers import pack

from costmodel import packcheck
from costmodel.inputs import ROOT, load_measured
from costmodel.units import units


def test_the_calculator_uses_this_collections_values():
    m = load_measured()
    course = load_measured(include_corpus=False)
    if not (ROOT / "corpus.toml").exists():
        assert m == course
        return
    assert m["chunks_per_1000_words"].value != course["chunks_per_1000_words"].value
    assert m["answer_small_tokens_in"].source.startswith("measured: python -m corpus")


def test_one_tenant_pays_the_whole_cost():
    d, g, m, p = pack()
    u = units(d, g, m, p)
    assert len(u.per_tenant) == 1
    assert abs(sum(u.per_tenant.values()) - u.total) < 1e-9


def test_most_of_the_cost_is_fixed_in_the_base_scenario():
    d, g, m, p = pack()
    u = units(d, g, m, p)
    assert u.fixed / u.total > 0.8


def test_the_review_passes_its_checks():
    passed, lines = packcheck.run()
    assert passed == len(packcheck.CHECKS), "\n".join(lines)
