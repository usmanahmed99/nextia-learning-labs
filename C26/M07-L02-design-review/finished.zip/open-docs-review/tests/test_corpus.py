import gzip
import json

from helpers import pack

from corpus import size as sz
from corpus.chunk import MAX_WORDS, chunk, paragraphs
from corpus.load import read_corpus


def tiny_corpus(write):
    docs = [
        {"document_number": "2024-00001", "type": "Rule", "title": "Walking surfaces", "publication_date": "2024-01-05",
         "pages": 2, "url": "https://example.org/1",
         "text": "The employer shall keep floors dry.\n\nGuardrails are 42 inches high."},
        {"document_number": "2024-00002", "type": "Notice", "title": "Information collection", "publication_date": "2024-03-01",
         "pages": 1, "url": "https://example.org/2", "text": " ".join(["word"] * 450)},
    ]
    path = write("data/tiny.jsonl.gz", "")
    path.write_bytes(gzip.compress("".join(json.dumps(d) + "\n" for d in docs).encode()))
    return read_corpus(path)


def test_paragraphs_join_lines_and_split_on_blank_lines():
    assert paragraphs("One\nline.\n\n\nTwo.") == ["One line.", "Two."]


def test_short_paragraphs_share_a_chunk_and_each_chunk_has_the_title():
    chunks = chunk("Title", "A b c.\n\nD e f.")
    assert chunks == ["Title\nA b c. D e f."]


def test_a_long_paragraph_is_cut_at_max_words():
    chunks = chunk("T", " ".join(["w"] * 450))
    assert [len(c.split()) - 1 for c in chunks] == [MAX_WORDS, MAX_WORDS, 50]


def test_tokens_are_counted_with_the_tokenizer_not_guessed():
    # cl100k_base: "Guardrails are 42 inches high." is 8 tokens for 5 words
    assert sz.count_tokens("Guardrails are 42 inches high.") == 8


def test_size_counts_documents_pages_words_and_chunks(write):
    s = sz.size(tiny_corpus(write))
    assert (s.documents, s.pages, s.words, s.chunks) == (2, 3, 461, 4)
    assert s.chunk_tokens > s.tokens          # every chunk repeats the title
    assert s.per_month == {"2024-01": 1, "2024-03": 1}


def test_months_without_documents_count_as_zero(write):
    s = sz.size(tiny_corpus(write))
    nm = sz.monthly_new(s, "2024-01", "2024-03")
    assert (nm["months"], nm["low"], nm["high"]) == (3, 0, 1)


def test_ingestion_is_tokens_times_the_price_and_waits_for_the_quota(write):
    _, _, m, p = pack()
    s = sz.size(tiny_corpus(write))
    ing = sz.ingestion(s, m, p)
    assert ing["calls"] == 2                   # one call per document (fewer than 100 chunks each)
    assert abs(ing["usd"] - s.chunk_tokens / 1e6 * p["embed_small_input"].value) < 1e-12
    assert ing["minutes"] == max(ing["minutes_one_call_at_a_time"], ing["minutes_at_the_quota"])


def test_corpus_values_replace_the_course_values(write, tmp_path):
    _, _, m, _ = pack()
    s = sz.size(tiny_corpus(write))
    values = sz.corpus_values(s, m)
    assert values["chunks_per_1000_words"][0] == s.chunks / s.words * 1000
    assert all(source.startswith("measured:") for _, _, source in values.values())
    sz.write_toml(values, tmp_path / "corpus.toml")
    assert "[answer_small_tokens_in]" in (tmp_path / "corpus.toml").read_text()


def test_clean_keeps_the_text_inside_pre_without_tags_and_entities():
    from corpus.load import clean
    raw = '<html><body><pre>LD<INF>50</INF> values\n<bullet> one&#160;item</pre><script src="x.js"></script></body></html>'
    assert clean(raw) == "LD50 values\n• one item"
