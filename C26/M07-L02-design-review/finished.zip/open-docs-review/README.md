# Design review: an open document-question service

This folder is a design review. A small advice line for employers, Fernhollow, wants a free public service that answers questions about workplace-safety rules, with citations. Its documents are the Occupational Safety and Health Administration's (OSHA's) documents in the US Federal Register. The review sizes the collection, costs the service, chooses the model and the cache with measured numbers, and writes the decisions and the failure plan.

It is the case study *Design review of an open document-question service* of the course *AI System Design and Cost Engineering* (Nextia Learning). The people and Fernhollow are invented; the documents are real.

You need **Python 3.12 or newer**. Everything runs on your computer. You do not need an account or money.

## Set up (once)

macOS and Linux:

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

Windows (PowerShell):

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

Then download the collection (about 9 MB) and check it:

```sh
python -m corpus get
python -m pytest -q
```

## Commands

| Command | What it does |
|---|---|
| `python -m corpus check` | the first checks: documents, text, duplicates, dates |
| `python -m corpus size` | documents, pages, words, tokens, chunks, storage, ingestion |
| `python -m corpus write` | writes `corpus.toml`: this collection's numbers for the calculator |
| `python -m corpus new` | sizes the new documents (2026) and compares them with the plan |
| `python -m costmodel costs` | the monthly cost by driver |
| `python -m costmodel units` | cost per question and per tenant |
| `python -m costmodel scenarios` | low, base and high, now and in month 12 |
| `python -m costmodel options` | routing (the course's measured result) and caching |
| `python -m costmodel recovery` | RTO and RPO of two backup plans |
| `python -m costmodel growth` | the growth signals month by month |
| `python -m costmodel check` | checks the whole review before you hand it in |

Add `--scenario low` or `--scenario high`, and `--month 12`, to the `costmodel` commands.

## What is in the folder

| File or folder | What it is |
|---|---|
| `review.md` | the review for Lena: recommendation, cost per tenant, assumptions, risks |
| `decisions/` | the decision records (ADRs) and the failure table |
| `demand.toml` | the public service's demand, as ranges, each verified or assumed |
| `design.toml` | the design under review and its operating assumptions |
| `corpus.toml` | written by `python -m corpus write`: the collection's own measured values |
| `prices.toml`, `measured.toml` | the course's price list and measured values |
| `corpus/` | the sizing script: download, chunks, token counts, storage, ingestion |
| `costmodel/` | the course's calculator; `inputs.py` also reads `corpus.toml`, `packcheck.py` has this review's checks |
| `DATASET.md` | the collection's source, licence, checksum and limits |

## The three kinds of numbers

Every number is **measured** (`measured.toml`, `corpus.toml`: each names its run), a **price** (`prices.toml`: each names its price page; prices change, so check the current page), or an **assumption** (`demand.toml`, `design.toml`: a range with its reason).

The course's routing and quality numbers come from another question set (the RAG course's 67 questions about shop policies). This review quotes them; it does not measure quality on OSHA's documents. `review.md` says what to measure first.

## Licence

The code: MIT (see `LICENSE`). The documents: works of the US government, public domain in the United States (17 U.S.C. 105). See `DATASET.md`.
