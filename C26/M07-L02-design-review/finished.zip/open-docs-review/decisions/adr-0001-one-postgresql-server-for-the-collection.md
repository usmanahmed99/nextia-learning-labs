# ADR-0001: one PostgreSQL server holds the whole collection; load it once before launch

## Status

Accepted. Niko and Lena.

## Context

Niko's first design had a vector database service next to PostgreSQL, "because 3,676 pages is a lot". We sized the collection with `python -m corpus size` (measured): 628 documents, 2,450,514 words, 3,710,587 tokens, 14,961 chunks. In the database, the chunks and their vectors take 90.4 MB: 0.3% of the smallest storage size, 32 GB (price list). The course's vectors are 384 numbers (4,800 bytes each with the table and the HNSW index, measured in the databases course), and an HNSW search over 10,000 vectors took 0.22 ms there.

Loading everything once costs 3,941,704 embedding tokens: US$0.08 (price list). Time is set by the provider's token quota, not by the price: 100,000 tokens a minute for embed-small (measured, rate-limit header), so at least 39 minutes. One call at a time would take about 8 minutes (measured call times), so the quota is the limit. Questions use the same quota for their embeddings.

## Options

1. PostgreSQL B1ms with pgvector for chunks, vectors, the cache and the logs (the course's design): US$13.50 a month for the server + US$4.05 for 32 GB (price list).
2. PostgreSQL + a vector database service: a second service to pay, secure, back up and keep in step with the documents, for 15,000 vectors.
3. A bigger PostgreSQL server (B2s, US$0.074 an hour, about US$54 a month): room we do not need at 0.3% of the storage.

## Decision

Option 1. Load the collection once before launch, at about 70% of the embedding quota (about 56 minutes), so that a test question still gets its embedding.

## Consequences

- One store to back up and to restore (ADR-0003 and the failure table use this).
- The load before launch takes about an hour. After launch, new documents are small: about 10 a month (measured, 2021 to 2025).
- The server is 28% of the monthly cost (US$13.50 of US$48.31, base), and that does not change with the collection's size until about 32 GB.

## Revisit when

- the database uses 80% of its storage, or the search p95 passes 100 ms, or
- the collection grows to about ten times its size (for example, a second agency's documents: plan the load at the quota again).
