# ADR-0002: chat-small answers with five passages; no routing until this collection has its own question set

## Status

Accepted. Niko, with Aisha for the question set.

## Context

Niko's second idea: "legal text needs the strong model". The course measured three designs on the same 67 questions with the same search results (measured, **on another question set**: the RAG course's questions about shop policies): chat-small only 86.6% correct, chat-strong only 85.8%, routed 86.6%. The misses were search misses, which a stronger model cannot fix. We did not measure quality on OSHA's documents.

This collection's chunks are longer: 263 tokens on average with the title (measured), against 52 in the RAG course. Five passages make the answer prompt about 2,002 tokens (estimate from measured parts: the course's 946.5 tokens with five chunks of this collection instead). With the calculator, for Fernhollow's base workload: chat-small US$48.31 a month, routed US$61.13, chat-strong US$108.59 (+125%).

The longer prompt matters for the provider's quota: in the high scenario, the busiest minute needs 127% of chat-small's token quota (100,000 tokens a minute, measured) already in month 0.

## Options

1. chat-small, five passages of at most 200 words.
2. chat-strong for every answer: 2.2 times the monthly cost, no better on the measured set.
3. Routed (chat-small first, chat-strong when chat-small declines or a citation check fails): +27% a month, the same measured quality.

## Decision

Option 1. Before launch, Aisha writes 50 questions with their answers from OSHA's documents, and we run the course's routing comparison on them.

## Consequences

- The answer tokens cost about US$3.25 a month (base).
- The token quota, not the money, is the first limit if the service gets busy (the high scenario).
- Quality on this collection is unknown until the question set exists: this is the review's main unresolved assumption.

## Revisit when

- the 50-question set shows chat-strong at least 5 points better than chat-small, or
- the busiest minute uses 70% of the token quota: first ask the provider for a higher quota; then try three passages (about 1,475 tokens a prompt, an estimate) and check the quality on the question set.
