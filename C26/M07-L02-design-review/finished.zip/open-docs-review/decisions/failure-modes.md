# Failure modes

A tabletop review: for each failure, what users see, how we notice, what limits the damage, who acts, how fast we are back (RTO) and how much data we may lose (RPO). The targets (review.md): RTO 8 hours, RPO 1 day for the question log; the documents can always be downloaded again.

| ID | Failure | What users see | Detection signal | Mitigation | Owner | RTO | RPO |
|---|---|---|---|---|---|---|---|
| F1 | Model provider outage or 429 (quota) | answers fail or wait | share of 5xx and 429 from the provider over 5 minutes > 5% | timeout 10 s; circuit breaker; cached answers still served; a clear "try again later" message | Niko | when the provider is back; our message within 15 minutes | none: nothing is written |
| F2 | Bots or abuse (no sign-in) use up the quota and the budget | slow or refused answers for everyone; a higher bill | questions per visitor per hour; daily token spend > budget / 30 | a limit per visitor (20 questions an hour); a challenge on the form; a daily spending cap that switches to cached answers only | Niko | 60 minutes (block, cap) | none |
| F3 | A new rule or a correction is not loaded | an answer cites an old or corrected text | daily: OSHA's document count in the Federal Register API against ours; age of the newest loaded document | a daily check job; the collection version in the cache key (ADR-0003); every answer shows its documents' dates | Aisha | 1 day (the freshness target) | none: the source keeps every document |
| F4 | A very large document fails halfway (the 376-page heat proposal: 1,543 chunks, 16 calls) | the document is missing or partly searchable | a job "running" past its lease; chunks stored ≠ chunks expected | one transaction per document; batches of 100 chunks; retry with backoff; stay under 70% of the embedding quota | Niko | about 5 minutes for that document (485,000 tokens at the quota) | none: the job runs again |
| F5 | Database lost or corrupted | the service is down | availability alert | managed point-in-time restore (tested every quarter); second path: rebuild from the source in about an hour (ADR-0001) | Niko | about 70 minutes (estimate: people and a new server) | 5 minutes of the question log (assumed from the documentation); documents: none |
| F6 | An answer is wrong, or is read as legal advice | a visitor acts on a wrong reading of a rule | a "this answer is wrong" button; Aisha reviews 20 answers a week | citations with links and dates; "not legal advice; the rules in force are in the Code of Federal Regulations" on every answer; decline when no passage supports an answer | Lena | the cache entry is deleted within 1 working day | none |

## Single point of failure

The database is a single point of failure, as in the course's design. For a free service with an 8-hour RTO, a tested restore is enough; a standby server would cost about US$288 a month of compute (price list), six times the whole service. And this collection has a second way back that the course's tenants do not have: the source is public, so the documents can be downloaded and embedded again.
