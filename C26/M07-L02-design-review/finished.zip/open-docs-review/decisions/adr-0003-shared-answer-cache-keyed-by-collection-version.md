# ADR-0003: one shared answer cache, keyed by the collection version

## Status

Accepted. Niko and Aisha.

## Context

The answers are public: every visitor may see every answer, and no answer depends on who asks. So one cache entry can serve every visitor, unlike the course's tenants, where the tenant must be in the key. But the documents change: about 10 new documents a month (measured), and some are corrections (for example "Hazard Communication Standard; Corrections" in January 2026). An answer from the cache must not cite a text that a newer document corrects.

The hit share is an assumption (0%, 10%, 30%): the service has no questions yet. The time and cost per hit are measured: a miss takes 2.18 s (sum of medians), a hit 0.014 s (the scaling course, Valkey). With the calculator: 10% hits save US$0.37 a month, 30% save US$1.10. The money is small because 93% of the cost is fixed. The cache matters more for the quota: every hit is a question that uses no chat call.

## Options

1. No cache.
2. A cache keyed by the normalized question only: fast, but an answer can outlive a correction.
3. A cache keyed by the normalized question **and the collection version** (the number of the last document loaded), in PostgreSQL, with a 7-day expiry.

## Decision

Option 3.

## Consequences

- Each new document makes a new version, so every new question after a load is a miss once. Old entries expire unused.
- The cache is in the same database: nothing new to run or back up (ADR-0001).
- Aisha can delete one wrong answer from the cache at once (failure table, F6).

## Revisit when

- the measured hit share after one month is above 30% (the cache becomes a capacity tool: plan for it) or below 5% (remove it: it adds a code path for nothing), or
- answers start to depend on the visitor (for example, a state's own rules): then the key needs that too.
