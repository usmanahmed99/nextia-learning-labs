# Design review: Fernhollow's rules assistant

For Lena. One page: what to build, what it costs, what can go wrong, and what we still do not know. Every number is measured, a price or an assumption, and says which. Prices change: check the current price pages before you sign anything.

## The service and its targets

A free public page where employers ask questions about OSHA's rules and get short answers with citations to the Federal Register documents. No sign-in. Fernhollow's three advisers use it during calls too.

- Answers: a median under 3 seconds (the course's sum of medians: 2.18 s, measured).
- Freshness: a new OSHA document is searchable within 1 day.
- Recovery: back within 8 hours (RTO); lose at most 1 day of the question log (RPO). The documents themselves can always be downloaded again.
- Budget: US$100 a month (Lena's grant).

## Sizing

Measured with `python -m corpus size` on OSHA's Federal Register documents, 2021 to 2025:

| What | Amount |
|---|---|
| Documents | 628 (517 notices, 72 proposed rules, 39 rules) |
| Printed pages | 3,676 |
| Words | 2,450,514 (median document about 1,270 words; the largest 259,867) |
| Tokens (cl100k_base, the same count as the provider's bill) | 3,710,587 (1.51 a word); 3,941,704 to embed with titles |
| Chunks (at most 200 words) | 14,961 |
| Database | 90.4 MB: 0.3% of the smallest size (32 GB) |
| Load everything once | US$0.08; at least 39 minutes (the embedding quota), about 56 at 70% of it |
| New documents | 10.5 a month on average (median 10, busiest month 37); 9.2 a month in 2026 so far |

The 10 largest documents hold 49% of all tokens. An average hides this: plan the load and the failures for the largest one (the 376-page heat proposal, 484,968 tokens).

## Recommendation

Build the course's design for one public tenant (ADR-0001, ADR-0002, ADR-0003):

- one application and one PostgreSQL server (B1ms) for the chunks, the vectors, the cache and the logs; no vector database service;
- chat-small answers with five passages; no routing until Aisha's 50-question set says otherwise;
- one shared answer cache, keyed by the question and the collection version;
- a daily check for new documents; a limit per visitor and a daily spending cap, because there is no sign-in.

Not recommended: the whole collection in every prompt. 3,710,587 tokens is 37 minutes of chat-small's token quota for one question, and about US$0.037 a question even at the cached-input price (price list): about ten times the whole service's cost per question today.

## Cost per tenant

Fernhollow is the only tenant, so the cost per tenant is the whole cost (`python -m costmodel scenarios`):

| | low | base | high |
|---|---|---|---|
| Now (US$ a month) | 39.09 | 48.31 | 74.04 |
| Month 12 | 39.09 | 49.72 | 115.32 |

- Base: 93% is fixed: the always-on API replica US$27.43 and the database server US$13.50 + storage US$4.05. Model tokens for answers: US$3.25.
- Per question, all in: US$0.0037 (base). It falls as use grows: US$0.00078 in the high scenario.
- Usage ×2: +7% (US$51.63). chat-strong for every answer: +125% (US$108.59).
- The high scenario passes the budget in month 9 (US$100.26).
- If Fernhollow joined a shared platform with other tenants, the fixed part would be shared, as the course's shops share it.

## Assumptions

Verified: the documents and their sizes, the new documents a month, the three advisers. Assumed (demand.toml, design.toml): visitors a day (50 / 250 / 1,000), questions per visitor, growth, the busy-hour shape (the course's help desk), the cache hit share (0 / 10 / 30%), the recovery step times. Measured elsewhere and reused: answer quality and routing (the course's other question set), the cache hit time (the scaling course), the restore rate (the databases course).

## Risks

- The token quota is the first limit: the high scenario needs 127% of chat-small's token quota in month 0 (the long passages). Ask for a higher quota before any publicity.
- No sign-in: bots can use the quota and the budget (F2).
- An answer can be read as legal advice, or cite a corrected text (F3, F6).
- The answer prompt size is an estimate from measured parts, not a measurement on this collection.

**The unresolved assumption:** answer quality on OSHA's documents. The course measured 86.6% on another question set. Legal text with long passages and cross-references may score lower. Aisha's 50-question set must run before launch; if chat-small scores badly, ADR-0002 changes, and the cost changes with it.
