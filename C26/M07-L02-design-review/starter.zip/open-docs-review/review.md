# Design review: Fernhollow's rules assistant

For Lena. One page: what to build, what it costs, what can go wrong, and what we still do not know.

## The service and its targets

## Sizing

## Recommendation

## Cost per tenant

## Assumptions

## Risks

Name the open assumption that would change the recommendation if it is wrong.
