# Failure modes

A tabletop review: for each failure, what users see, how we notice, what limits the damage, who acts, and how fast we are back (RTO) and how much data we may lose (RPO). The targets are in review.md.

| ID | Failure | What users see | Detection signal | Mitigation | Owner | RTO | RPO |
|---|---|---|---|---|---|---|---|
| F1 | | | | | | | |
